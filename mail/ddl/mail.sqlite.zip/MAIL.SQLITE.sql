--
-- Arquivo gerado com SQLiteStudio v3.4.4 em ter ago 20 21:33:20 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: mail
CREATE TABLE IF NOT EXISTS mail (
    NUMERO  INTEGER,
    ERRO    CHAR (8),
    DATA    DATE,
    HORA    CHAR (8),
    DE      CHAR (12),
    DESTINO CHAR (12),
    ASSUNTO CHAR (120),
    TEXTO   TEXT,
    DATAOK  DATE,
    HORAOK  CHAR (8) 
);


-- Tabela: mailerro
CREATE TABLE IF NOT EXISTS mailerro (
    ERRO    CHAR (8),
    ASSUNTO CHAR (120) 
);

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'PCP00001',
                         'Nova Os Pedido Cliente                                                                                                  '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CUSTO001',
                         'Necessita Cota��o Viabilidade                                                                                           '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CUSTO002',
                         'Necessidade Norma                                                                                                       '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CUSTO003',
                         'Necessidade Viabilidade                                                                                                 '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'RIF00001',
                         'RIF - OS N�o Encontrado                                                                                                 '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'RIF00002',
                         'RIF - PF N�o Encontrado                                                                                                 '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'RIF00003',
                         'RIF - PC N�o Encontrado                                                                                                 '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CRM00001',
                         'Preco Divergente Controle Recebimento Mercadoria                                                                        '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CRM00002',
                         'Entrada Mercadoria Carta Corre�ao/Acordo Financeiro                                                                     '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CRM00003',
                         'Entrada de Mercadoria com Carga Excessiva                                                                               '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CRM00005',
                         'Entrada de Mercadoria com Carga Faltante                                                                                '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CRM00004',
                         'Entrada de Mercadoria com Carga Excessiva                                                                               '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'RACF0001',
                         'Nova RACF Gerada por RNC                                                                                                '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'RACF0002',
                         'Nova RACF Gerada por RAT                                                                                                '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'RNC00001',
                         'Nova RNC                                                                                                                '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'SAC00001',
                         'Nova Sac                                                                                                                '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'SAC00002',
                         'Erro Fechamento SAC/SAC sem PF                                                                                          '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'SAC00003',
                         'Fechamento SAC                                                                                                          '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CUSTO004',
                         'Viabilidade Preenchida Custo                                                                                            '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'VIA00001',
                         'Abertura Viabilidade                                                                                                    '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'VIA00002',
                         'Aprovacao Condicional  Norma/Desenho                                                                                    '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'VIA00003',
                         'Exclusao Viabilidade                                                                                                    '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'VIA00004',
                         'Obs  Norma/Desenho                                                                                                      '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CUSTO005',
                         'Estimativa de Processo Assinada                                                                                         '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'MAW00001',
                         'Cotacao Mateira Prima Concluida                                                                                         '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'VIA00005',
                         'Data Vencimento Viabilidade                                                                                             '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CD000001',
                         'Nova Condi�ao de Desenvolvimento                                                                                        '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'PF000001',
                         'Revisao Processo de Fabricacao                                                                                          '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'PPAP0001',
                         'Alteracao PPAP/GP11                                                                                                     '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CD000002',
                         'Conclus�o Condi�ao de Desenvolvimento                                                                                   '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CUSTO006',
                         'Planinha de Or�amento Concluida                                                                                         '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'DEL00001',
                         'Exclusao Codigo                                                                                                         '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'INC00001',
                         'Inclusao Codigo                                                                                                         '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'RIF00004',
                         'RIF - Os Com Numero PF Em Branco                                                                                        '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'RIF00005',
                         'RIF - OS Produto Fora de Uso Qualidade                                                                                  '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'RIF00006',
                         'RIF - OS Produto Nao Ativo PCP                                                                                          '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'RIF00007',
                         'RIF -  Cancelamento Inclusao                                                                                            '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CRM00006',
                         'Troca de Nota Fiscal                                                                                                    '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'RIF00008',
                         'OS - Sem Numero de Cliente                                                                                              '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'MOC00001',
                         'Importa�ao Prg Falta OS                                                                                                 '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'MOC00002',
                         'Planta Nao Associada Cliente                                                                                            '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'MOC00003',
                         'OS Cliente Sem Numero Ped Cliente                                                                                       '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'RIF00009',
                         'Troca Data Rif                                                                                                          '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'PROT0001',
                         'Novo GP11 de Prototipo                                                                                                  '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'PROT0002',
                         'Exclus�o GP11 de Prototipo                                                                                              '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'RIF00010',
                         'Produto Atingiu 1200 Pe�as                                                                                              '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CD000003',
                         'Exclusao Condi�ao de Desenvolvimento                                                                                    '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CD000004',
                         'Os Programa�ao Cliente Incompleta                                                                                       '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CD000005',
                         'Produto N�o Cadastrado Fiscal Porem com OS                                                                              '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CRM00007',
                         'Entrada de MP/Comp.  com Prg Entrega                                                                                    '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'RIF00011',
                         'Produto Atingiu Data Marcada Sele�ao 100%                                                                               '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'DEL00002',
                         'Programa Entrega Cujo Codigo Foi Excluido                                                                               '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'DEL00003',
                         'Pedido cujo Codigo foi Excluido                                                                                         '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'MUD00002',
                         'Descritivo Codigo Trocado Afetou Prg Entrega                                                                            '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'MUD00003',
                         'Descritivo Codigo Trocado Afetou Pedido                                                                                 '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'PRD00001',
                         'Importacao PF Materia Prima                                                                                             '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'PRD00002',
                         'Importacao PF Componentes                                                                                               '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'PRD00003',
                         'Importacao PF Mao de Obra                                                                                               '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'PRD00004',
                         'Importacao PF Sequencia                                                                                                 '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'CRM00008',
                         'Troca de Nota Fiscal                                                                                                    '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'FAT00001',
                         'Fatutamento Item Nao Liberado                                                                                           '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'RIF00012',
                         'RIF - Os Com Descri�ao Produto em Branco                                                                                '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'MAB00001',
                         'Troca Dados Fornecedor                                                                                                  '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'MOC00004',
                         'Falta Lista de Preco                                                                                                    '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'RIF00013',
                         'RIF -  OS Produto Quantidade Preliminar                                                                                 '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'FEM00001',
                         'Nova Revisao Femea                                                                                                      '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'PC000001',
                         'Nova Revisao Plano Controle                                                                                             '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'PCI00001',
                         'Alteracao Item do Plano de Controle                                                                                     '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'PFS00001',
                         'PF inclusao SEQ/SSQ                                                                                                     '
                     );

INSERT INTO mailerro (
                         ERRO,
                         ASSUNTO
                     )
                     VALUES (
                         'PFS00002',
                         'PF exclusao SEQ/SSQ                                                                                                     '
                     );


-- Tabela: mailpara
CREATE TABLE IF NOT EXISTS mailpara (
    ERRO    CHAR (8),
    DESTINO CHAR (12) 
);


-- Tabela: mailpg
CREATE TABLE IF NOT EXISTS mailpg (
    NUMERO  INTEGER,
    ERRO    CHAR (8),
    DATA    DATE,
    HORA    CHAR (8),
    DE      CHAR (12),
    DESTINO CHAR (12),
    ASSUNTO CHAR (120),
    TEXTO   TEXT,
    DATAOK  DATE,
    HORAOK  CHAR (8) 
);


-- �ndice: idx_mailerro_mailerro
CREATE INDEX IF NOT EXISTS idx_mailerro_mailerro ON mailerro (
    erro
);


-- �ndice: idx_mailpara
CREATE INDEX IF NOT EXISTS idx_mailpara ON mailpara (
    erro
);


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
