--
-- Arquivo gerado com SQLiteStudio v3.4.4 em qui ago 1 20:59:19 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: mail
CREATE TABLE IF NOT EXISTS [mail] ([numero] REAL NOT NULL, [erro] TEXT(8) NOT NULL, [data] SHORTDATE NOT NULL, [hora] TEXT(8) NOT NULL, [de] TEXT(12) NOT NULL, [destino] TEXT(12) NOT NULL, [assunto] TEXT(120) NOT NULL, [texto] TEXT(2147483647) NOT NULL, [dataok] SHORTDATE NOT NULL, [horaok] TEXT(8) NOT NULL);

-- Tabela: mailerro
CREATE TABLE IF NOT EXISTS [mailerro] ([erro] TEXT(8) NOT NULL, [assunto] TEXT(120) NOT NULL);

-- Tabela: mailpara
CREATE TABLE IF NOT EXISTS [mailpara] ([erro] TEXT(8) NOT NULL, [destino] TEXT(12) NOT NULL);

-- Tabela: mailpg
CREATE TABLE IF NOT EXISTS [mailpg] ([numero] REAL NOT NULL, [erro] TEXT(8) NOT NULL, [data] SHORTDATE NOT NULL, [hora] TEXT(8) NOT NULL, [de] TEXT(12) NOT NULL, [destino] TEXT(12) NOT NULL, [assunto] TEXT(120) NOT NULL, [texto] TEXT(2147483647) NOT NULL, [dataok] SHORTDATE NOT NULL, [horaok] TEXT(8) NOT NULL);

-- �ndice: idx_mailerro_mailerro
CREATE INDEX IF NOT EXISTS [idx_mailerro_mailerro] ON [mailerro] ([erro]);

-- �ndice: idx_mailpara
CREATE INDEX IF NOT EXISTS [idx_mailpara] ON [mailpara] ([erro]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
