--
-- Arquivo gerado com SQLiteStudio v3.4.4 em seg ago 5 13:26:47 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: rif
CREATE TABLE IF NOT EXISTS [rif] ([rif] REAL NOT NULL, [pf] REAL NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [revdata] SHORTDATE NOT NULL, [qtde] REAL NOT NULL, [os] REAL NOT NULL, [data] SHORTDATE NOT NULL, [isiii] REAL NOT NULL, [laudo] TEXT(1) NOT NULL, [rastro] TEXT(14) NOT NULL, [insnum] REAL NOT NULL, [insnom] TEXT(40) NOT NULL, [importado] BIT NOT NULL, [pcftipo] TEXT(1) NOT NULL, [codigoint] TEXT(24) NOT NULL);

-- Tabela: rifi
CREATE TABLE IF NOT EXISTS [rifi] ([rif] REAL NOT NULL, [tol] TEXT(150) NOT NULL, [min] REAL NOT NULL, [max] REAL NOT NULL, [ok] TEXT(1) NOT NULL, [instrume] TEXT(60) NOT NULL);

-- Tabela: rifpr
CREATE TABLE IF NOT EXISTS [rifpr] ([produto] TEXT(24) NOT NULL, [qtde] REAL NOT NULL, [rif1200] REAL NOT NULL, [rifult] REAL NOT NULL, [riftot] REAL NOT NULL, [sel100] SHORTDATE NOT NULL, [rifsel] REAL NOT NULL);

-- �ndice: idx_rif_rif
CREATE INDEX IF NOT EXISTS [idx_rif_rif] ON [rif] ([rastro]);

-- �ndice: idx_rif_rif-2
CREATE INDEX IF NOT EXISTS [idx_rif_rif-2] ON [rif] ([pf]);

-- �ndice: idx_rif_rif-3
CREATE INDEX IF NOT EXISTS [idx_rif_rif-3] ON [rif] ([data]);

-- �ndice: idx_rif_rif-4
CREATE INDEX IF NOT EXISTS [idx_rif_rif-4] ON [rif] ([codigo], [rif]);

-- �ndice: idx_rifi
CREATE INDEX IF NOT EXISTS [idx_rifi] ON [rifi] ([rif]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
