--
-- File generated with SQLiteStudio v3.4.21 on ter mai 12 17:56:52 2026
--
-- Text encoding used: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: cnpjxml
DROP TABLE IF EXISTS cnpjxml;

CREATE TABLE IF NOT EXISTS cnpjxml (
    cnpj       TEXT (14) NOT NULL,
    ie         TEXT (14) NOT NULL,
    nome       TEXT (60) NOT NULL,
    endereco   TEXT (60) NOT NULL,
    cidade     TEXT (35) NOT NULL,
    cep        TEXT (8)  NOT NULL,
    telefone   TEXT (14) NOT NULL,
    ddd        TEXT (2)  NOT NULL,
    uf         TEXT (2)  NOT NULL,
    iesubst    TEXT (14) NOT NULL,
    imunicipal TEXT (15) NOT NULL,
    cognome    TEXT (60) NOT NULL,
    email      TEXT (60) NOT NULL,
    numend     TEXT (15) NOT NULL,
    complem    TEXT (30) NOT NULL,
    bairro     TEXT (35) NOT NULL,
    bacen      TEXT (5)  NOT NULL,
    pais       TEXT (10) NOT NULL,
    cnae       TEXT (7)  NOT NULL,
    suframa    TEXT (9)  NOT NULL,
    codibge    TEXT (7)  NOT NULL,
    ultimaimp  SHORTDATE NOT NULL,
    codpart    TEXT (20) NOT NULL,
    csit       TEXT (1)  NOT NULL,
    indcrednfe TEXT (1)  NOT NULL,
    indcredcte TEXT (1)  NOT NULL,
    xregapur   TEXT (7)  NOT NULL,
    diniativ   TEXT (10) NOT NULL,
    dultsit    TEXT (10) NOT NULL,
    dinixml    SHORTDATE NOT NULL,
    endtip     TEXT (10) NOT NULL
);


-- Table: cnpjxmlfec
DROP TABLE IF EXISTS cnpjxmlfec;

CREATE TABLE IF NOT EXISTS cnpjxmlfec (
    cnpj       TEXT (14) NOT NULL,
    ie         TEXT (14) NOT NULL,
    nome       TEXT (60) NOT NULL,
    endereco   TEXT (60) NOT NULL,
    cidade     TEXT (35) NOT NULL,
    cep        TEXT (8)  NOT NULL,
    telefone   TEXT (14) NOT NULL,
    ddd        TEXT (2)  NOT NULL,
    uf         TEXT (2)  NOT NULL,
    iesubst    TEXT (14) NOT NULL,
    imunicipal TEXT (15) NOT NULL,
    cognome    TEXT (60) NOT NULL,
    email      TEXT (60) NOT NULL,
    numend     TEXT (15) NOT NULL,
    complem    TEXT (30) NOT NULL,
    bairro     TEXT (35) NOT NULL,
    bacen      TEXT (5)  NOT NULL,
    pais       TEXT (10) NOT NULL,
    cnae       TEXT (7)  NOT NULL,
    suframa    TEXT (9)  NOT NULL,
    codibge    TEXT (7)  NOT NULL,
    ultimaimp  SHORTDATE NOT NULL,
    codpart    TEXT (20) NOT NULL,
    csit       TEXT (1)  NOT NULL,
    indcrednfe TEXT (1)  NOT NULL,
    indcredcte TEXT (1)  NOT NULL,
    xregapur   TEXT (7)  NOT NULL,
    diniativ   TEXT (10) NOT NULL,
    dultsit    TEXT (10) NOT NULL,
    dinixml    SHORTDATE NOT NULL,
    endtip     TEXT (10) NOT NULL
);


-- Table: danfe
DROP TABLE IF EXISTS danfe;

CREATE TABLE IF NOT EXISTS danfe (
    id        TEXT (44) NOT NULL,
    cprod     TEXT (16) NOT NULL,
    xprod     TEXT (60) NOT NULL,
    qcom      REAL      NOT NULL,
    vuncom    REAL      NOT NULL,
    ucom      TEXT (4)  NOT NULL,
    cfop      TEXT (4)  NOT NULL,
    ncm       TEXT (10) NOT NULL,
    csticms   TEXT (4)  NOT NULL,
    cstipi    TEXT (4)  NOT NULL,
    cstpis    TEXT (4)  NOT NULL,
    cstcofins TEXT (4)  NOT NULL,
    vicms     REAL      NOT NULL,
    vpis      REAL      NOT NULL,
    vipi      REAL      NOT NULL,
    vcofins   REAL      NOT NULL,
    vbcicms   REAL      NOT NULL,
    vbcpis    REAL      NOT NULL,
    vbcipi    REAL      NOT NULL,
    vbccofins REAL      NOT NULL,
    picms     REAL      NOT NULL,
    ppis      REAL      NOT NULL,
    pipi      REAL      NOT NULL,
    pcofins   REAL      NOT NULL
);


-- Table: danfe2
DROP TABLE IF EXISTS danfe2;

CREATE TABLE IF NOT EXISTS danfe2 (
    id        TEXT (44) NOT NULL,
    cnpj      TEXT (14) NOT NULL,
    cnpjdest  TEXT (14) NOT NULL,
    nnf       TEXT (9)  NOT NULL,
    serie     TEXT (3)  NOT NULL,
    emissao   TEXT (10) NOT NULL,
    cancelada TEXT (1)  NOT NULL,
    avb       TEXT (1)  NOT NULL,
    xml       TEXT (1)  NOT NULL,
    danfeview TEXT (1)  NOT NULL,
    cstatus   TEXT (3)  NOT NULL,
    logixsup  TEXT (1)  NOT NULL,
    protocolo TEXT (20) NOT NULL
);


-- Table: danfe2fec
DROP TABLE IF EXISTS danfe2fec;

CREATE TABLE IF NOT EXISTS danfe2fec (
    id        TEXT (44) NOT NULL,
    cnpj      TEXT (14) NOT NULL,
    cnpjdest  TEXT (14) NOT NULL,
    nnf       TEXT (9)  NOT NULL,
    serie     TEXT (3)  NOT NULL,
    emissao   TEXT (10) NOT NULL,
    cancelada TEXT (1)  NOT NULL,
    avb       TEXT (1)  NOT NULL,
    xml       TEXT (1)  NOT NULL,
    danfeview TEXT (1)  NOT NULL,
    cstatus   TEXT (3)  NOT NULL,
    logixsup  TEXT (1)  NOT NULL,
    protocolo TEXT (20) NOT NULL
);


-- Table: nfe
DROP TABLE IF EXISTS nfe;

CREATE TABLE IF NOT EXISTS nfe (
    empresa   TEXT (2)  NOT NULL,
    sintel    SHORTDATE NOT NULL,
    nfs       REAL      NOT NULL,
    gmprotrec REAL      NOT NULL,
    danfevrec REAL      NOT NULL,
    statusrec REAL      NOT NULL,
    chavesup  REAL      NOT NULL
);


-- Table: nfecorrecao
DROP TABLE IF EXISTS nfecorrecao;

CREATE TABLE IF NOT EXISTS nfecorrecao (
    CODIGO    TEXT,
    DESCRICAO TEXT
);

INSERT INTO nfecorrecao (
                            CODIGO,
                            DESCRICAO
                        )
                        VALUES (
                            '1',
                            'RAZAO SOCIAL'
                        );

INSERT INTO nfecorrecao (
                            CODIGO,
                            DESCRICAO
                        )
                        VALUES (
                            '2',
                            'ENDERECO'
                        );

INSERT INTO nfecorrecao (
                            CODIGO,
                            DESCRICAO
                        )
                        VALUES (
                            '3',
                            'MUNICIPIO'
                        );

INSERT INTO nfecorrecao (
                            CODIGO,
                            DESCRICAO
                        )
                        VALUES (
                            '4',
                            'ESTADO'
                        );

INSERT INTO nfecorrecao (
                            CODIGO,
                            DESCRICAO
                        )
                        VALUES (
                            '5',
                            'NO. DE INSCRICAO NO CGC/MF'
                        );

INSERT INTO nfecorrecao (
                            CODIGO,
                            DESCRICAO
                        )
                        VALUES (
                            '6',
                            'NO. DE INSCRICAO ESTADUAL'
                        );

INSERT INTO nfecorrecao (
                            CODIGO,
                            DESCRICAO
                        )
                        VALUES (
                            '7',
                            'NATUREZA DA OPERACAO'
                        );

INSERT INTO nfecorrecao (
                            CODIGO,
                            DESCRICAO
                        )
                        VALUES (
                            '8',
                            'CODIGO FISCAL DA OPERACAO'
                        );

INSERT INTO nfecorrecao (
                            CODIGO,
                            DESCRICAO
                        )
                        VALUES (
                            '9',
                            'VIA DE TRANSPORTE'
                        );

INSERT INTO nfecorrecao (
                            CODIGO,
                            DESCRICAO
                        )
                        VALUES (
                            '10',
                            'DATA DE EMISSAO'
                        );

INSERT INTO nfecorrecao (
                            CODIGO,
                            DESCRICAO
                        )
                        VALUES (
                            '11',
                            'DATA DA SAIDA'
                        );

INSERT INTO nfecorrecao (
                            CODIGO,
                            DESCRICAO
                        )
                        VALUES (
                            '12',
                            'UNIDADE  PRODUTO'
                        );

INSERT INTO nfecorrecao (
                            CODIGO,
                            DESCRICAO
                        )
                        VALUES (
                            '13',
                            'QUANTIDADE  PRODUTO'
                        );

INSERT INTO nfecorrecao (
                            CODIGO,
                            DESCRICAO
                        )
                        VALUES (
                            '14',
                            'DESCRICAO DOS PRODUTOS'
                        );


-- Table: nfecret
DROP TABLE IF EXISTS nfecret;

CREATE TABLE IF NOT EXISTS nfecret (
    CODIGO    TEXT,
    DESCRICAO TEXT
);

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '100',
                        'Autorizado o uso da NF-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '101',
                        'Cancelamento de NF-e homologado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '102',
                        'Inutiliza��o de n�mero homologado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '103',
                        'Lote recebido com sucesso'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '104',
                        'Lote processado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '105',
                        'Lote em processamento'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '106',
                        'Lote n�o localizado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '107',
                        'Servi�o em Opera��o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '108',
                        'Servi�o Paralisado Momentaneamente  curto prazo'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '109',
                        'Servi�o Paralisado sem Previs�o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '110',
                        'Uso Denegado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '111',
                        'Consulta cadastro com uma ocorr�ncia'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '112',
                        'Consulta cadastro com mais de uma ocorr�ncia'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '113',
                        'SCAN sera desabilitado para a UF as hh:mm'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '114',
                        'SCAN desabilitado pela SEFAZ Origem'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '128',
                        'Lote de Evento Processado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '135',
                        'Evento registrado e vinculado a NF-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '136',
                        'Evento registrado  mas n�o vinculado a NF-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '137',
                        'Nenhum documento localizado para o Destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '138',
                        'Documento localizado para o Destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '139',
                        'Pedido de Download processado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '140',
                        'Download disponibilizado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '150',
                        'Autorizado o uso da NF-e  autoriza��o fora de prazo'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '151',
                        'Cancelamento de NF-e homologado fora de prazo'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '155',
                        'Cancelamento de NF-e homologado fora de prazo'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '201',
                        'rejeicao: N�mero m�ximo de numera��o a inutilizar ultrapassou o limite'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '202',
                        'rejeicao: Falha no reconhecimento da autoria ou integridade do arquivo digital'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '203',
                        'rejeicao: Emissor n�o habilitado para emiss�o de NF-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '204',
                        'Duplicidade de NF-e [nRec:999999999999999]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '205',
                        'NF-e est� denegada na base de dados da SEFAZ [nRec:999999999999999]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '206',
                        'rejeicao: NF-e j� est� inutilizada na Base de dados da SEFAZ'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '207',
                        'rejeicao: CNPJ do emitente inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '208',
                        'rejeicao: CNPJ do destinat�rio inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '209',
                        'rejeicao: IE do emitente inv�lida'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '210',
                        'rejeicao: IE do destinat�rio inv�lida'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '211',
                        'rejeicao: IE do substituto inv�lida'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '212',
                        'rejeicao: Data de emiss�o NF-e posterior a data de recebimento'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '213',
                        'rejeicao: CNPJ-Base do Emitente difere do CNPJ-Base do Certificado Digital'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '214',
                        'rejeicao: Tamanho da mensagem excedeu o limite estabelecido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '215',
                        'rejeicao: Falha no schema XML'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '216',
                        'rejeicao: Chave de Acesso difere da cadastrada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '217',
                        'rejeicao: NF-e n�o consta na base de dados da SEFAZ'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '218',
                        'NF-e j� est� cancelada na base de dados da SEFAZ [nRec:999999999999999]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '219',
                        'rejeicao: Circula��o da NF-e verificada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '220',
                        'rejeicao: Prazo de Cancelamento superior ao previsto na Legisla��o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '221',
                        'rejeicao: Confirmado o recebimento da NF-e pelo destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '222',
                        'rejeicao: Protocolo de Autoriza��o de Uso difere do cadastrado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '223',
                        'rejeicao: CNPJ do transmissor do lote difere do CNPJ do transmissor da consulta'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '224',
                        'rejeicao: A faixa inicial � maior que a faixa final'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '225',
                        'rejeicao: Falha no Schema XML do lote de NFe'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '226',
                        'rejeicao: C�digo da UF do Emitente diverge da UF autorizadora'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '227',
                        'rejeicao: Erro na Chave de Acesso ? Campo Id ? falta a literal NFe'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '228',
                        'rejeicao: Data de Emiss�o muito atrasada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '229',
                        'rejeicao: IE do emitente n�o informada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '230',
                        'rejeicao: IE do emitente n�o cadastrada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '231',
                        'rejeicao: IE do emitente n�o vinculada ao CNPJ'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '232',
                        'rejeicao: IE do destinat�rio n�o informada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '233',
                        'rejeicao: IE do destinat�rio n�o cadastrada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '234',
                        'rejeicao: IE do destinat�rio n�o vinculada ao CNPJ'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '235',
                        'rejeicao: Inscri��o SUFRAMA inv�lida'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '236',
                        'rejeicao: Chave de Acesso com d�gito verificador inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '237',
                        'rejeicao: CPF do destinat�rio inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '238',
                        'rejeicao: Cabe�alho ? Vers�o do arquivo XML superior a Vers�o vigente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '239',
                        'rejeicao: Cabe�alho ? Vers�o do arquivo XML n�o suportada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '240',
                        'rejeicao: Cancelamento/Inutiliza��o ? Irregularidade Fiscal do Emitente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '241',
                        'rejeicao: Um n�mero da faixa j� foi utilizado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '242',
                        'rejeicao: Cabe�alho ? Falha no Schema XML'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '243',
                        'rejeicao: XML Mal Formado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '244',
                        'rejeicao: CNPJ do Certificado Digital difere do CNPJ da Matriz e do CNPJ do Emitente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '245',
                        'rejeicao: CNPJ Emitente n�o cadastrado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '246',
                        'rejeicao: CNPJ Destinat�rio n�o cadastrado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '247',
                        'rejeicao: Sigla da UF do Emitente diverge da UF autorizadora'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '248',
                        'rejeicao: UF do Recibo diverge da UF autorizadora'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '249',
                        'rejeicao: UF da Chave de Acesso diverge da UF autorizadora'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '250',
                        'rejeicao: UF diverge da UF autorizadora'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '251',
                        'rejeicao: UF/Munic�pio destinat�rio n�o pertence a SUFRAMA'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '252',
                        'rejeicao: Ambiente informado diverge do Ambiente de recebimento'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '253',
                        'rejeicao: Digito Verificador da chave de acesso composta inv�lida'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '254',
                        'rejeicao: NF-e complementar n�o possui NF referenciada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '255',
                        'rejeicao: NF-e complementar possui mais de uma NF referenciada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '256',
                        'rejeicao: Uma NF-e da faixa j� est� inutilizada na Base de dados da SEFAZ'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '257',
                        'rejeicao: Solicitante n�o habilitado para emiss�o da NF-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '258',
                        'rejeicao: CNPJ da consulta inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '259',
                        'rejeicao: CNPJ da consulta n�o cadastrado como contribuinte na UF'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '260',
                        'rejeicao: IE da consulta inv�lida'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '261',
                        'rejeicao: IE da consulta n�o cadastrada como contribuinte na UF'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '262',
                        'rejeicao: UF n�o fornece consulta por CPF'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '263',
                        'rejeicao: CPF da consulta inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '264',
                        'rejeicao: CPF da consulta n�o cadastrado como contribuinte na UF'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '265',
                        'rejeicao: Sigla da UF da consulta difere da UF do Web Service'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '266',
                        'rejeicao: S�rie utilizada n�o permitida no Web Service'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '267',
                        'rejeicao: NF Complementar referencia uma NF-e inexistente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '268',
                        'rejeicao: NF Complementar referencia outra NF-e Complementar'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '269',
                        'rejeicao: CNPJ Emitente da NF Complementar difere do CNPJ da NF Referenciada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '270',
                        'rejeicao: C�digo Munic�pio do Fato Gerador: d�gito inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '271',
                        'rejeicao: C�digo Munic�pio do Fato Gerador: difere da UF do emitente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '272',
                        'rejeicao: C�digo Munic�pio do Emitente inexistente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '273',
                        'rejeicao: C�digo Munic�pio do Emitente: difere da UF do emitente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '274',
                        'rejeicao: C�digo Munic�pio do Destinat�rio inexistente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '275',
                        'rejeicao: C�digo Munic�pio do Destinat�rio: difere da UF do Destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '276',
                        'rejeicao: C�digo Munic�pio do Local de Retirada inexistente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '277',
                        'rejeicao: C�digo Munic�pio do Local de Retirada: difere da UF do Local de Retirada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '278',
                        'rejeicao: C�digo Munic�pio do Local de Entrega inexistente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '279',
                        'rejeicao: C�digo Munic�pio do Local de Entrega: difere da UF do Local de Entrega'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '280',
                        'rejeicao: Certificado Transmissor inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '281',
                        'rejeicao: Certificado Transmissor Data Validade'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '282',
                        'rejeicao: Certificado Transmissor sem CNPJ'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '283',
                        'rejeicao: Certificado Transmissor ? erro Cadeia de Certifica��o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '284',
                        'rejeicao: Certificado Transmissor revogado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '285',
                        'rejeicao: Certificado Transmissor difere ICP-Brasil'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '286',
                        'rejeicao: Certificado Transmissor erro no acesso a LCR'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '287',
                        'rejeicao: C�digo Munic�pio do Fato Gerador de ISSQN inexistente [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '288',
                        'rejeicao: C�digo Munic�pio do Fato Gerador do Transporte inexistente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '289',
                        'rejeicao: C�digo da UF informada diverge da UF solicitada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '290',
                        'rejeicao: Certificado Assinatura inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '291',
                        'rejeicao: Certificado Assinatura Data Validade'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '292',
                        'rejeicao: Certificado Assinatura sem CNPJ'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '293',
                        'rejeicao: Certificado Assinatura ? erro Cadeia de Certifica��o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '294',
                        'rejeicao: Certificado Assinatura revogado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '295',
                        'rejeicao: Certificado Assinatura difere ICP-Brasil'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '296',
                        'rejeicao: Certificado Assinatura erro no acesso a LCR'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '297',
                        'rejeicao: Assinatura difere do calculado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '298',
                        'rejeicao: Assinatura difere do padr�o do Sistema'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '299',
                        'rejeicao: XML da �rea de cabe�alho com codifica��o diferente de UTF-8'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '301',
                        'Uso Denegado: Irregularidade fiscal do emitente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '302',
                        'rejeicao: Irregularidade fiscal do destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '303',
                        'Uso Denegado: Destinat�rio n�o habilitado a operar na UF'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '321',
                        'rejeicao: NF-e de devolu��o de mercadoria n�o possui documento fiscal referenciado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '322',
                        'rejeicao: NF de produtor referenciada com data de emiss�o inv�lida'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '323',
                        'rejeicao: CNPJ autorizado para download inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '324',
                        'rejeicao: CNPJ do destinat�rio j� autorizado para download'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '325',
                        'rejeicao: CPF autorizado para download inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '326',
                        'rejeicao: CPF do destinat�rio j� autorizado para download'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '327',
                        'rejeicao: CFOP inv�lido para Nota Fiscal com finalidade de devolu��o de mercadoria [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '328',
                        'rejeicao: CFOP de devolu��o de mercadoria para NF-e que n�o tem finalidade de devolu��o de mercadoria'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '329',
                        'rejeicao: N�mero da DI /DSI inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '330',
                        'rejeicao: Informar o Valor da AFRMM na importa��o por via mar�tima'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '331',
                        'rejeicao: Informar o CNPJ do adquirente ou do encomendante nesta forma de importa��o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '332',
                        'rejeicao: CNPJ do adquirente ou do encomendante da importa��o inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '333',
                        'rejeicao: Informar a UF do adquirente ou do encomendante nesta forma de importa��o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '334',
                        'rejeicao: N�mero do processo de drawback n�o informado na importa��o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '335',
                        'rejeicao: N�mero do processo de drawback na importa��o inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '336',
                        'rejeicao: Informado o grupo de exporta��o no item para CFOP que n�o � de exporta��o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '337',
                        'rejeicao: NFC-e para emitente pessoa f�sica'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '338',
                        'rejeicao: N�mero do processo de drawback n�o informado na exporta��o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '339',
                        'rejeicao: N�mero do processo de drawback na exporta��o inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '340',
                        'rejeicao: N�o informado o grupo de exporta��o indireta no item'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '341',
                        'rejeicao: N�mero do registro de exporta��o inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '342',
                        'rejeicao: Chave de Acesso informada na Exporta��o Indireta com DV inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '343',
                        'rejeicao: Modelo da NF-e informada na Exporta��o Indireta diferente de 55'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '344',
                        'rejeicao: Duplicidade de NF-e informada na Exporta��o Indireta  Chave de Acesso informada mais de uma vez'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '345',
                        'rejeicao: Chave de Acesso informada na Exporta��o Indireta n�o consta como NF-e referenciada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '346',
                        'rejeicao: Somat�rio das quantidades informadas na Exporta��o Indiretan�o corresponde a quantidade total do item'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '347',
                        'rejeicao: Descri��o do combust�vel diverge da descri��o adotada pela ANP'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '348',
                        'rejeicao: NFC-e com grupo RECOPI'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '349',
                        'rejeicao: N�mero RECOPI n�o informado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '350',
                        'rejeicao: N�mero RECOPI inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '351',
                        'rejeicao: Valor do ICMS da Opera��o no CST=51 difere do produto BC e Al�quota'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '352',
                        'rejeicao: Valor do ICMS Diferido no CST=51 difere do produto Valor ICMS Opera��o e percentual diferimento'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '353',
                        'rejeicao: Valor do ICMS no CST=51 n�o corresponde a diferen�a do ICMS opera��o e ICMS diferido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '354',
                        'rejeicao: Informado grupo de devolu��o de tributos para NF-e que n�o tem finalidade de devolu��o de mercadoria'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '355',
                        'rejeicao: Informar o local de sa�da do Pais no caso da exporta��o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '356',
                        'rejeicao: Informar o local de sa�da do Pais somente no caso da exporta��o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '357',
                        'rejeicao: Chave de Acesso do grupo de Exporta��o Indireta inexistente [nRef: xxx]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '358',
                        'rejeicao: Chave de Acesso do grupo de Exporta��o Indireta cancelada ou denegada [nRef: xxx]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '401',
                        'rejeicao: CPF do emitente inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '402',
                        'rejeicao: XML da �rea de dados com codifica��o diferente de UTF-8'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '403',
                        'rejeicao: O grupo de informa��es da NF-e avulsa � de uso exclusivo do Fisco'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '404',
                        'rejeicao: Uso de prefixo de namespace n�o permitido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '405',
                        'rejeicao: C�digo do pa�s do emitente: d�gito inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '406',
                        'rejeicao: C�digo do pa�s do destinat�rio: d�gito inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '407',
                        'rejeicao: O CPF s� pode ser informado no campo emitente para a NF-e avulsa'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '409',
                        'rejeicao: Campo cUF inexistente no elemento nfeCabecMsg do SOAP Header'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '410',
                        'rejeicao: UF informada no campo cUF n�o � atendida pelo Web Service'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '411',
                        'rejeicao: Campo versaoDados inexistente no elemento nfeCabecMsg do SOAP Header'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '417',
                        'rejeicao: Total do ICMS superior ao valor limite estabelecido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '418',
                        'rejeicao: Total do ICMS ST superior ao valor limite estabelecido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '420',
                        'rejeicao: Cancelamento para NF-e j� cancelada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '450',
                        'rejeicao: Modelo da NF-e diferente de 55'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '451',
                        'rejeicao: Processo de emiss�o informado inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '452',
                        'rejeicao: Tipo Autorizador do Recibo diverge do �rg�o Autorizador'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '453',
                        'rejeicao: Ano de inutiliza��o n�o pode ser superior ao Ano atual'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '454',
                        'rejeicao: Ano de inutiliza��o n�o pode ser inferior a 2006'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '461',
                        'rejeicao: Informado percentual de G�s Natural na mistura para produto diferente de GLP'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '465',
                        'rejeicao: N�mero de Controle da FCI inexistente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '478',
                        'rejeicao: Local da entrega n�o informado para faturamento direto de ve�culos novos'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '479',
                        'rejeicao: Data de Emiss�o anterior a data de credenciamento ou anterior a Data de Abertura do estabelecimento'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '480',
                        'rejeicao: C�digo Munic�pio do Emitente diverge do cadastrado na UF'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '481',
                        'rejeicao: C�digo Regime Tribut�rio do emitente diverge do cadastro na SEFAZ'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '482',
                        'rejeicao: C�digo do Munic�pio do Destinat�rio diverge do cadastrado na UF'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '483',
                        'rejeicao: Valor do desconto maior que valor do produto [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '484',
                        'rejeicao: Chave de Acesso com tipo de emiss�o diferente de 4  posi��o 35 da Chave de Acesso'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '485',
                        'rejeicao: Duplicidade de numera��o do EPEC  Modelo  CNPJ  S�rie e N�mero'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '486',
                        'rejeicao: N�o informado o Grupo de Autoriza��o para UF que exige a identifica��o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '487',
                        'rejeicao: Escrit�rio de Contabilidade n�o cadastrado na SEFAZ'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '488',
                        'rejeicao: Vendas do Emitente incompat�veis com o Porte da Empresa'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '489',
                        'rejeicao: CNPJ informado inv�lido  DV ou zeros'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '490',
                        'rejeicao: CPF informado inv�lido  DV ou zeros'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '491',
                        'rejeicao: O tpEvento informado inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '492',
                        'rejeicao: O verEvento informado inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '493',
                        'rejeicao: Evento n�o atende o Schema XML espec�fico'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '494',
                        'rejeicao: Chave de Acesso inexistente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '501',
                        'rejeicao: Pedido de Cancelamento intempestivo  NF-e autorizada a mais de 7 dias'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '502',
                        'rejeicao: Erro na Chave de Acesso ? Campo Id n�o corresponde � concatena��o dos campos correspondentes'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '503',
                        'rejeicao: S�rie utilizada fora da faixa permitida no SCAN  900-999'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '504',
                        'rejeicao: Data de Entrada/Sa�da posterior ao permitido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '505',
                        'rejeicao: Data de Entrada/Sa�da anterior ao permitido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '506',
                        'rejeicao: Data de Sa�da menor que a Data de Emiss�o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '507',
                        'rejeicao: O CNPJ do destinat�rio/remetente n�o deve ser informado em opera��o com o exterior'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '508',
                        'rejeicao: CST incompat�vel na opera��o com N�o Contribuinte [nItem:999]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '509',
                        'rejeicao: Informado c�digo de munic�pio diferente de ?9999999? para opera��o com o exterior'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '510',
                        'rejeicao: Opera��o com Exterior e C�digo Pa�s destinat�rio � 1058  Brasil  ou n�o informado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '511',
                        'rejeicao: N�o � de Opera��o com Exterior e C�digo Pa�s destinat�rio difere de 1058  Brasil'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '512',
                        'rejeicao: CNPJ do Local de Retirada inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '513',
                        'rejeicao: C�digo Munic�pio do Local de Retirada deve ser 9999999 para UF retirada = EX'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '514',
                        'rejeicao: CNPJ do Local de Entrega inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '515',
                        'rejeicao: C�digo Munic�pio do Local de Entrega deve ser 9999999 para UF entrega = EX'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '516',
                        'rejeicao: Falha no schema XML ? inexiste a tag raiz esperada para a mensagem'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '517',
                        'rejeicao: Falha no schema XML ? inexiste atributo versao na tag raiz da mensagem'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '518',
                        'rejeicao: CFOP de entrada para NF-e de sa�da'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '519',
                        'rejeicao: CFOP de sa�da para NF-e de entrada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '520',
                        'rejeicao: CFOP de Opera��o com Exterior e UF destinat�rio difere de EX'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '521',
                        'rejeicao: CFOP de Opera��o Estadual e UF do emitente difere da UF do destinat�rio para destinat�rio contribuinte do ICMS'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '522',
                        'rejeicao: CFOP de Opera��o Estadual e UF emitente difere da UF remetente para remetente contribuinte do ICMS.'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '523',
                        'rejeicao: CFOP n�o � de Opera��o Estadual e UF emitente igual a UF destinat�rio.'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '524',
                        'rejeicao: CFOP de Opera��o com Exterior e n�o informado NCM'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '525',
                        'rejeicao: CFOP de Importa��o e n�o informado dados da DI'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '526',
                        'rejeicao: Consulta a uma Chave de Acesso muito antiga'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '527',
                        'rejeicao: Opera��o de Exporta��o com informa��o de ICMS incompat�vel'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '528',
                        'rejeicao: Valor do ICMS difere do produto BC e Al�quota'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '529',
                        'rejeicao: CST incompat�vel na opera��o com Contribuinte Isento de Inscri��o Estadual [nItem:999]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '530',
                        'rejeicao: Opera��o com tributa��o de ISSQN sem informar a Inscri��o Municipal'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '531',
                        'rejeicao: Total da BC ICMS difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '532',
                        'rejeicao: Total do ICMS difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '533',
                        'rejeicao: Total da BC ICMS-ST difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '534',
                        'rejeicao: Total do ICMS-ST difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '535',
                        'rejeicao: Total do Frete difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '536',
                        'rejeicao: Total do Seguro difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '537',
                        'rejeicao: Total do Desconto difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '538',
                        'rejeicao: Total do IPI difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '539',
                        'Duplicidade de NF-e com diferen�a na Chave de Acesso [chNFe: 99999999999999999999999999999999999999999999][nRec:99999999'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '540',
                        'rejeicao: CPF do Local de Retirada inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '541',
                        'rejeicao: CPF do Local de Entrega inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '542',
                        'rejeicao: CNPJ do Transportador inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '543',
                        'rejeicao: CPF do Transportador inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '544',
                        'rejeicao: IE do Transportador inv�lida'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '545',
                        'rejeicao: Falha no schema XML ? vers�o informada na versaoDados do SOAPHeader diverge da vers�o da mensagem'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '546',
                        'rejeicao: Erro na Chave de Acesso ? Campo Id ? falta a literal NFe'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '547',
                        'rejeicao: D�gito Verificador da Chave de Acesso da NF-e Referenciada inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '548',
                        'rejeicao: CNPJ da NF referenciada inv�lido.'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '549',
                        'rejeicao: CNPJ da NF referenciada de produtor inv�lido.'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '550',
                        'rejeicao: CPF da NF referenciada de produtor inv�lido.'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '551',
                        'rejeicao: IE da NF referenciada de produtor inv�lido.'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '552',
                        'rejeicao: D�gito Verificador da Chave de Acesso do CT-e Referenciado inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '553',
                        'rejeicao: Tipo autorizador do recibo diverge do �rg�o Autorizador.'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '554',
                        'rejeicao: S�rie difere da faixa 0-899'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '555',
                        'rejeicao: Tipo autorizador do protocolo diverge do �rg�o Autorizador.'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '556',
                        'rejeicao: Justificativa de entrada em conting�ncia n�o deve ser informada para tipo de emiss�o normal.'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '557',
                        'rejeicao: A Justificativa de entrada em conting�ncia deve ser informada.'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '558',
                        'rejeicao: Data de entrada em conting�ncia posterior a data de recebimento.'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '559',
                        'rejeicao: UF do Transportador n�o informada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '560',
                        'rejeicao: CNPJ base do emitente difere do CNPJ base da primeira NF-e do lote recebido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '561',
                        'rejeicao: M�s de Emiss�o informado na Chave de Acesso difere do M�s de Emiss�o da NF-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '562',
                        'rejeicao: C�digo Num�rico informado na Chave de Acesso difere do C�digo Num�rico da NF-e [chNFe:999999999999999999999999'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '563',
                        'rejeicao: J� existe pedido de Inutiliza��o com a mesma faixa de inutiliza��o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '564',
                        'rejeicao: Total do Produto / Servi�o difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '565',
                        'rejeicao: Falha no schema XML ? inexiste a tag raiz esperada para o lote de NF-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '567',
                        'rejeicao: Falha no schema XML ? vers�o informada na versaoDados do SOAPHeader diverge da vers�o do lote de NF-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '568',
                        'rejeicao: Falha no schema XML ? inexiste atributo versao na tag raiz do lote de NF-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '569',
                        'rejeicao: Data de entrada em conting�ncia muito atrasada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '570',
                        'rejeicao: Tipo de Emiss�o 3  6 ou 7 s� � v�lido nas conting�ncias SCAN/SVC'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '571',
                        'rejeicao: O tpEmis informado diferente de 3 para conting�ncia SCAN'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '572',
                        'rejeicao: Erro Atributo ID do evento n�o corresponde a concatena��o dos campos  ?ID? + tpEvento + chNFe + nSeqEvento'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '573',
                        'rejeicao: Duplicidade de Evento'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '574',
                        'rejeicao: O autor do evento diverge do emissor da NF-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '575',
                        'rejeicao: O autor do evento diverge do destinat�rio da NF-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '576',
                        'rejeicao: O autor do evento n�o � um �rg�o autorizado a gerar o evento'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '577',
                        'rejeicao: A data do evento n�o pode ser menor que a data de emiss�o da NF-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '578',
                        'rejeicao: A data do evento n�o pode ser maior que a data do processamento'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '579',
                        'rejeicao: A data do evento n�o pode ser menor que a data de autoriza��o para NF-e n�o emitida em conting�ncia'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '580',
                        'rejeicao: O evento exige uma NF-e autorizada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '587',
                        'rejeicao: Usar somente o namespace padr�o da NF-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '588',
                        'rejeicao: N�o � permitida a presen�a de caracteres de edi��o no in�cio/fim da mensagem ou entre as tags da mensagem'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '589',
                        'rejeicao: N�mero do NSU informado superior ao maior NSU da base de dados da SEFAZ'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '590',
                        'rejeicao: Informado CST para emissor do Simples Nacional  CRT=1'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '591',
                        'rejeicao: Informado CSOSN para emissor que n�o � do Simples Nacional  CRT diferente de 1'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '592',
                        'rejeicao: A NF-e deve ter pelo menos um item de produto sujeito ao ICMS'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '593',
                        'rejeicao: CNPJ-Base consultado difere do CNPJ-Base do Certificado Digital'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '594',
                        'rejeicao: O n�mero de sequencia do evento informado � maior que o permitido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '595',
                        'rejeicao: Obrigat�ria a informa��o da justificativa do evento.'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '596',
                        'rejeicao: Evento apresentado fora do prazo: [prazo vigente]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '597',
                        'rejeicao: CFOP de Importa��o e n�o informado dados de IPI'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '598',
                        'rejeicao: NF-e emitida em ambiente de homologa��o com Raz�o Social do destinat�rio diferente de NF-E EMITIDA EM AMBIENTE'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '599',
                        'rejeicao: CFOP de Importa��o e n�o informado dados de II'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '601',
                        'rejeicao: Total do II difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '602',
                        'rejeicao: Total do PIS difere do somat�rio dos itens sujeitos ao ICMS'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '603',
                        'rejeicao: Total do COFINS difere do somat�rio dos itens sujeitos ao ICMS'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '604',
                        'rejeicao: Total do vOutro difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '605',
                        'rejeicao: Total do vISS difere do somat�rio do vProd dos itens sujeitos ao ISSQN'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '606',
                        'rejeicao: Total do vBC do ISS difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '607',
                        'rejeicao: Total do ISS difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '608',
                        'rejeicao: Total do PIS difere do somat�rio dos itens sujeitos ao ISSQN'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '609',
                        'rejeicao: Total do COFINS difere do somat�rio dos itens sujeitos ao ISSQN'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '610',
                        'rejeicao: Total da NF difere do somat�rio dos Valores comp�e o valor Total da NF.'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '611',
                        'rejeicao: cEAN inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '612',
                        'rejeicao: cEANTrib inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '613',
                        'rejeicao: Chave de Acesso difere da existente em BD'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '614',
                        'rejeicao: Chave de Acesso inv�lida  C�digo UF inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '615',
                        'rejeicao: Chave de Acesso inv�lida  Ano menor que 06 ou Ano maior que Ano corrente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '616',
                        'rejeicao: Chave de Acesso inv�lida  M�s menor que 1 ou M�s maior que 12'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '617',
                        'rejeicao: Chave de Acesso inv�lida  CNPJ zerado ou d�gito inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '618',
                        'rejeicao: Chave de Acesso inv�lida  modelo diferente de 55 e 65'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '619',
                        'rejeicao: Chave de Acesso inv�lida  n�mero NF = 0'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '620',
                        'rejeicao: Chave de Acesso difere da existente em BD'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '621',
                        'rejeicao: CPF Emitente n�o cadastrado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '622',
                        'rejeicao: IE emitente n�o vinculada ao CPF'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '623',
                        'rejeicao: CPF Destinat�rio n�o cadastrado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '624',
                        'rejeicao: IE Destinat�rio n�o vinculada ao CPF'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '625',
                        'rejeicao: Inscri��o SUFRAMA deve ser informada na venda com isen��o para ZFM'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '626',
                        'rejeicao: CFOP de opera��o isenta para ZFM diferente do previsto'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '627',
                        'rejeicao: O valor do ICMS desonerado deve ser informado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '628',
                        'rejeicao: Total da NF superior ao valor limite estabelecido pela SEFAZ [Limite]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '629',
                        'rejeicao: Valor do Produto difere do produto Valor Unit�rio de Comercializa��o e Quantidade Comercial'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '630',
                        'rejeicao: Valor do Produto difere do produto Valor Unit�rio de Tributa��o e Quantidade Tribut�vel'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '631',
                        'rejeicao: CNPJ-Base do Destinat�rio difere do CNPJ-Base do Certificado Digital'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '632',
                        'rejeicao: Solicita��o fora de prazo  a NF-e n�o est� mais dispon�vel para download'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '633',
                        'rejeicao: NF-e indispon�vel para download devido a aus�ncia de Manifesta��o do Destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '634',
                        'rejeicao: Destinat�rio da NF-e n�o tem o mesmo CNPJ raiz do solicitante do download'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '635',
                        'rejeicao: NF-e com mesmo n�mero e s�rie j� transmitida e aguardando processamento'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '642',
                        'Falha na Consulta do Reg de Passagem  tente apos 5 minutos'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '650',
                        'rejeicao: Evento de ?Ci�ncia da Emiss�o? para NF-e Cancelada ou Denegada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '651',
                        'rejeicao: Evento de ?Desconhecimento da Opera��o? para NF-e Cancelada ou Denegada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '653',
                        'rejeicao: NF-e Cancelada  arquivo indispon�vel para download'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '654',
                        'rejeicao: NF-e Denegada  arquivo indispon�vel para download'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '655',
                        'rejeicao: Evento de Ci�ncia da Emiss�o informado ap�s a manifesta��o final do destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '656',
                        'rejeicao: Consumo Indevido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '657',
                        'rejeicao: C�digo do �rg�o diverge do �rg�o autorizador'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '658',
                        'rejeicao: UF do destinat�rio da Chave de Acesso diverge da UF autorizadora'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '660',
                        'rejeicao: CFOP de Combust�vel e n�o informado grupo de combust�vel [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '661',
                        'rejeicao: NF-e j� existente para o n�mero do EPEC informado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '662',
                        'rejeicao: Numera��o do EPEC est� inutilizada na Base de Dados da SEFAZ'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '663',
                        'rejeicao: Al�quota do ICMS com valor superior a 4 por cento na opera��o de sa�da interestadual com produtos importados ['
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '678',
                        'rejeicao: NF referenciada com UF diferente da NF-e complementar'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '679',
                        'rejeicao: Modelo de DF-e referenciado inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '680',
                        'rejeicao: Duplicidade de NF-e referenciada  Chave de Acesso referenciada mais de uma vez'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '681',
                        'rejeicao: Duplicidade de NF Modelo 1 referenciada  CNPJ  Modelo  S�rie e N�mero'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '682',
                        'rejeicao: Duplicidade de NF de Produtor referenciada  IE  Modelo  S�rie e N�mero'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '683',
                        'rejeicao: Modelo do CT-e referenciado diferente de 57'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '684',
                        'rejeicao: Duplicidade de Cupom Fiscal referenciado  Modelo  N�mero de Ordem e COO'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '685',
                        'rejeicao: Total do Valor Aproximado dos Tributos difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '686',
                        'rejeicao: NF Complementar referencia uma NF-e cancelada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '687',
                        'rejeicao: NF Complementar referencia uma NF-e denegada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '688',
                        'rejeicao: NF referenciada de Produtor com IE inexistente [nRef: xxx]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '689',
                        'rejeicao: NF referenciada de Produtor com IE n�o vinculada ao CNPJ/CPF informado [nRef: xxx]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '690',
                        'rejeicao: Pedido de Cancelamento para NF-e com CT-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '701',
                        'rejeicao: N�o informado Nota Fiscal referenciada  CFOP de Exporta��o Indireta'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '702',
                        'rejeicao: NFC-e n�o � aceita pela UF do Emitente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '703',
                        'rejeicao: Data-Hora de Emiss�o posterior ao hor�rio de recebimento'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '704',
                        'rejeicao: NFC-e com Data-Hora de emiss�o atrasada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '705',
                        'rejeicao: NFC-e com data de entrada/sa�da'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '706',
                        'rejeicao: NFC-e para opera��o de entrada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '707',
                        'rejeicao: NFC-e para opera��o interestadual ou com o exterior'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '708',
                        'rejeicao: NFC-e n�o pode referenciar documento fiscal'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '709',
                        'rejeicao: NFC-e com formato de DANFE inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '710',
                        'rejeicao: NF-e com formato de DANFE inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '711',
                        'rejeicao: NF-e com conting�ncia off-line'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '712',
                        'rejeicao: NFC-e com conting�ncia off-line para a UF'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '713',
                        'rejeicao: Tipo de Emiss�o diferente de 6 ou 7 para conting�ncia da SVC acessada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '714',
                        'rejeicao: NFC-e com op��o de conting�ncia inv�lida  tpEmis=2  4  a crit�rio da UF  ou 5'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '715',
                        'rejeicao: NFC-e com finalidade inv�lida'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '716',
                        'rejeicao: NFC-e em opera��o n�o destinada a consumidor final'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '717',
                        'rejeicao: NFC-e em opera��o n�o presencial'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '718',
                        'rejeicao: NFC-e n�o deve informar IE de Substituto Tribut�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '719',
                        'rejeicao: NF-e sem a identifica��o do destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '720',
                        'rejeicao: Na opera��o com Exterior deve ser informada tag idEstrangeiro'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '721',
                        'rejeicao: Opera��o interestadual deve informar CNPJ ou CPF'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '722',
                        'Operacao interna com idEstrangeiro informado deve ser presencial'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '723',
                        'rejeicao: Opera��o interna com idEstrangeiro informado deve ser para consumidor final'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '724',
                        'rejeicao: NF-e sem o nome do destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '725',
                        'rejeicao: NFC-e com CFOP inv�lido [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '726',
                        'rejeicao: NF-e sem a informa��o de endere�o do destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '727',
                        'rejeicao: Opera��o com Exterior e UF diferente de EX'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '728',
                        'rejeicao: NF-e sem informa��o da IE do destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '729',
                        'rejeicao: NFC-e com informa��o da IE do destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '730',
                        'rejeicao: NFC-e com Inscri��o Suframa'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '731',
                        'rejeicao: CFOP de opera��o com Exterior e idDest <> 3'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '732',
                        'rejeicao: CFOP de opera��o interestadual e idDest <> 2'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '733',
                        'rejeicao: CFOP de opera��o interna e idDest <> 1'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '734',
                        'rejeicao: NFC-e com Unidade de Comercializa��o inv�lida'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '735',
                        'rejeicao: NFC-e com Unidade de Tributa��o inv�lida'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '736',
                        'rejeicao: NFC-e com grupo de Ve�culos novos'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '736',
                        'NFC-e com grupo de medicamentos'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '738',
                        'rejeicao: NFC-e com grupo de Armamentos'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '739',
                        'NFC-e com grupo de combustiveis'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '740',
                        'rejeicao: Item com Repasse de ICMS retido por Substituto Tribut�rio [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '741',
                        'rejeicao: NFC-e com Partilha de ICMS entre UF'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '742',
                        'rejeicao: NFC-e com grupo do IPI'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '743',
                        'rejeicao: NFC-e com grupo do II'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '745',
                        'rejeicao: NF-e sem grupo do PIS'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '746',
                        'rejeicao: NFC-e com grupo do PIS-ST'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '748',
                        'rejeicao: NF-e sem grupo da COFINS'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '749',
                        'rejeicao: NFC-e com grupo da COFINS-ST'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '750',
                        'rejeicao: NFC-e com valor total superior ao permitido para destinat�rio n�o identificado  C�digo  [Limite]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '751',
                        'rejeicao: NFC-e com valor total superior ao permitido para destinat�rio n�o identificado  Nome  [Limite]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '752',
                        'rejeicao: NFC-e com valor total superior ao permitido para destinat�rio n�o identificado  Endere�o  [Limite]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '753',
                        'rejeicao: NFC-e com Frete'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '754',
                        'rejeicao: NFC-e com dados do Transportador'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '755',
                        'rejeicao: NFC-e com dados de Reten��o do ICMS no Transporte'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '756',
                        'rejeicao: NFC-e com dados do ve�culo de Transporte'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '757',
                        'rejeicao: NFC-e com dados de Reboque do ve�culo de Transporte'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '758',
                        'rejeicao: NFC-e com dados do Vag�o de Transporte'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '759',
                        'rejeicao: NFC-e com dados da Balsa de Transporte'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '760',
                        'rejeicao: NFC-e com dados de cobran�a  Fatura  Duplicata'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '762',
                        'rejeicao: NFC-e com dados de compras  Empenho  Pedido  Contrato'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '763',
                        'rejeicao: NFC-e com dados de aquisi��o de Cana'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '765',
                        'rejeicao: Lote s� poder� conter NF-e ou NFC-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '766',
                        'rejeicao: Item com CST indevido [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '767',
                        'rejeicao: NFC-e com somat�rio dos pagamentos diferente do total da Nota Fiscal'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '768',
                        'rejeicao: NF-e n�o deve possuir o grupo de Formas de Pagamento'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '769',
                        'rejeicao: A crit�rio da UF NFC-e deve possuir o grupo de Formas de Pagamento'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '771',
                        'rejeicao: Opera��o Interestadual e UF de destino com EX'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '772',
                        'rejeicao: Opera��o Interestadual e UF de destino igual � UF do emitente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '773',
                        'rejeicao: Opera��o Interna e UF de destino difere da UF do emitente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '774',
                        'rejeicao: NFC-e com indicador de item n�o participante do total'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '775',
                        'rejeicao: Modelo da NFC-e diferente de 65'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '777',
                        'rejeicao: Obrigat�ria a informa��o do NCM completo'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '778',
                        'rejeicao: Informado NCM inexistente [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '779',
                        'rejeicao: NFC-e com NCM incompat�vel'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '780',
                        'rejeicao: Total da NFC-e superior ao valor limite estabelecido pela SEFAZ [Limite]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '781',
                        'rejeicao: Emissor n�o habilitado para emiss�o da NFC-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '782',
                        'rejeicao: NFC-e n�o � autorizada pelo SCAN'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '783',
                        'rejeicao: NFC-e n�o � autorizada pela SVC'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '784',
                        'rejeicao: NFC-e n�o permite o evento de Carta de Corre��o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '785',
                        'rejeicao: NFC-e com entrega a domic�lio n�o permitida pela UF'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '786',
                        'rejeicao: NFC-e de entrega a domic�lio sem dados do Transportador'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '787',
                        'rejeicao: NFC-e de entrega a domic�lio sem a identifica��o do destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '788',
                        'rejeicao: NFC-e de entrega a domic�lio sem o endere�o do destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '789',
                        'rejeicao: NFC-e para destinat�rio contribuinte de ICMS'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '790',
                        'rejeicao: Opera��o com Exterior para destinat�rio Contribuinte de ICMS'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '791',
                        'rejeicao: NF-e com indica��o de destinat�rio isento de IE  com a informa��o da IE do destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '791',
                        'Informado capitulo NCM inexiste ** esta em duplicidade codigo de erro 791  pagina 78n e 80 da N.T. 2013.005'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '792',
                        'rejeicao: Informada a IE do destinat�rio para opera��o com destinat�rio no Exterior'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '999',
                        'rejeicao: Erro n�o catalogado  informar a mensagem de erro capturado no tratamento da exce��o'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '124',
                        'EPEC Autorizado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '142',
                        'Ambiente de Conting�ncia EPEC bloqueado para o Emitente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '304',
                        'rejeicao: Pedido de Cancelamento para NF-e com evento da Suframa'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '315',
                        'rejeicao: Data de Emiss�o anterior ao in�cio da autoriza��o de Nota Fiscal na UF'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '316',
                        'rejeicao: Nota Fiscal referenciada com a mesma Chave de Acesso da Nota Fiscal atual'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '317',
                        'rejeicao: NF modelo 1 referenciada com data de emiss�o inv�lida'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '318',
                        'rejeicao: Contranota de Produtor sem Nota Fiscal referenciada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '319',
                        'rejeicao: Contranota de Produtor n�o pode referenciar somente Nota Fiscal de entrada'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '320',
                        'rejeicao: Contranota de Produtor referencia somente NF de outro emitente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '359',
                        'rejeicao: NF-e de venda a �rg�o P�blico sem informar a Nota de Empenho'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '360',
                        'rejeicao: NF-e com Nota de Empenho inv�lida para a UF.'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '361',
                        'rejeicao: NF-e com Nota de Empenho inexistente na UF.'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '362',
                        'rejeicao: Venda de combust�vel sem informa��o do Transportador'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '364',
                        'rejeicao: Total do valor da dedu��o do ISS difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '365',
                        'rejeicao: Total de outras reten��es difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '366',
                        'rejeicao: Total do desconto incondicionado ISS difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '367',
                        'rejeicao: Total do desconto condicionado ISS difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '368',
                        'rejeicao: Total de ISS retido difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '369',
                        'rejeicao: N�o informado o grupo avulsa na emiss�o pelo Fisco'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '370',
                        'rejeicao: Nota Fiscal Avulsa com tipo de emiss�o inv�lido'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '372',
                        'rejeicao: Destinat�rio com identifica��o de estrangeiro com caracteres inv�lidos'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '373',
                        'rejeicao: Descri��o do primeiro item diferente de NOTA FISCAL EMITIDA EM AMBIENTE DE HOMOLOGACAO  SEM VALOR FISCAL'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '374',
                        'rejeicao: CFOP incompat�vel com o grupo de tributa��o [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '375',
                        'rejeicao: NF-e com CFOP 5929  Lan�amento relativo a Cupom Fiscal  referencia uma NFC-e [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '376',
                        'rejeicao: Data do Desembara�o Aduaneiro inv�lida [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '378',
                        'rejeicao: Grupo de Combust�vel sem a informa��o de Encerrante [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '379',
                        'rejeicao: Grupo de Encerrante na NF-e  modelo 55  para CFOP diferente de venda de combust�vel para consumidor final [nIt'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '380',
                        'rejeicao: Valor do Encerrante final n�o � superior ao Encerrante inicial [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '381',
                        'rejeicao:Grupo de tributa��o ICMS90  informando dados do ICMS-ST [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '382',
                        'rejeicao:CFOP n�o permitido para o CST informado [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '383',
                        'rejeicao: Item com CSOSN indevido [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '384',
                        'rejeicao: CSOSN n�o permitido para a UF [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '385',
                        'rejeicao:Grupo de tributa��o ICMS900  informando dados do ICMS-ST [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '386',
                        'rejeicao: CFOP n�o permitido para o CSOSN informado [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '387',
                        'rejeicao: C�digo de Enquadramento Legal do IPI inv�lido [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '388',
                        'rejeicao: C�digo de Situa��o Tribut�ria do IPI incompat�vel com o C�digo de Enquadramento Legal do IPI [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '389',
                        'rejeicao: C�digo Munic�pio ISSQN inexistente [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '390',
                        'rejeicao: Nota Fiscal com grupo de devolu��o de tributos [nItem:nnn]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '391',
                        'rejeicao: N�o informados os dados do cart�o de cr�dito / d�bito nas Formas de Pagamento da Nota Fiscal'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '392',
                        'rejeicao: N�o informados os dados da opera��o de pagamento por cart�o de cr�dito / d�bito'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '393',
                        'rejeicao: NF-e com o grupo de Informa��es Suplementares'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '394',
                        'rejeicao: Nota Fiscal sem a informa��o do QR-Code'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '395',
                        'rejeicao: Endere�o do site da UF da Consulta via QRCode diverge do previsto'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '396',
                        'rejeicao: Par�metro do QR-Code inexistente  chAcesso'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '397',
                        'rejeicao: Par�metro do QR-Code divergente da Nota Fiscal  chAcesso'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '398',
                        'rejeicao: Par�metro nVersao do QR-Code difere do previsto'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '399',
                        'rejeicao: Par�metro de Identifica��o do destinat�rio no QR-Code para Nota Fiscal sem identifica��o do destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '400',
                        'rejeicao: Par�metro do QR-Code n�o est� no formato hexadecimal  dhEmi'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '408',
                        'rejeicao: Evento n�o dispon�vel para Autor pessoa f�sica'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '455',
                        'rejeicao: �rg�o Autor do evento diferente da UF da Chave de Acesso'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '462',
                        'rejeicao:C�digo Identificador do CSC no QR-Code n�o cadastrado na SEFAZ'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '463',
                        'rejeicao:C�digo Identificador do CSC no QR-Code foi revogado pela empresa'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '464',
                        'rejeicao: C�digo de Hash no QR-Code difere do calculado'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '466',
                        'rejeicao: Evento com Tipo de Autor incompat�vel'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '467',
                        'rejeicao: Dados da NF-e divergentes do EPEC'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '468',
                        'rejeicao: NF-e com Tipo Emiss�o = 4  sem EPEC correspondente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '471',
                        'rejeicao: Informado NCM=00 indevidamente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '476',
                        'rejeicao: C�digo da UF diverge da UF da primeira NF-e do Lote'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '477',
                        'rejeicao: C�digo do �rg�o diverge do �rg�o do primeiro evento do Lote'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '496',
                        'rejeicao: N�o informado o tipo de integra��o no pagamento com cart�o de cr�dito / d�bito'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '600',
                        'rejeicao: CSOSN incompat�vel na opera��o com N�o Contribuinte [nItem:999]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '691',
                        'rejeicao: Chave de Acesso da NF-e diverge da Chave de Acesso do EPEC'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '693',
                        'rejeicao: Al�quota de ICMS superior a definida para a opera��o interestadual [nItem:999]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '694',
                        'rejeicao: N�o informado o grupo de ICMS para a UF de destino [nItem:999]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '695',
                        'rejeicao: Informado indevidamente o grupo de ICMS para a UF de destino [nItem:999]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '697',
                        'rejeicao: Al�quota interestadual do ICMS com origem diferente do previsto [nItem:999]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '698',
                        'rejeicao: Al�quota interestadual do ICMS incompat�vel com as UF envolvidas na opera��o [nItem:999]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '699',
                        'rejeicao: Percentual do ICMS Interestadual para a UF de destino difere do previsto para o ano da Data de Emiss�o [nItem:'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '700',
                        'rejeicao: Mensagem de Lote vers�o 3.xx. Enviar para o Web Service nfeAutorizacao'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '737',
                        'rejeicao: NFC-e com grupo de Medicamentos'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '761',
                        'rejeicao: C�digo de Produtos ANP inexistente'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '764',
                        'rejeicao: Solicitada resposta s�ncrona para Lote com mais de uma NF-e  indSinc=1'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '770',
                        'rejeicao: NFC-e autorizada h� mais de 24 horas.'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '776',
                        'rejeicao: Solicitada resposta s�ncrona para UF que n�o disponibiliza este atendimento  indSinc=1'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '793',
                        'rejeicao: Valor do ICMS relativo ao Fundo de Combate � Pobreza na UF de destino difere do calculado [nItem:999]'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '794',
                        'rejeicao: NF-e com indicativo de NFC-e com entrega a domic�lio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '795',
                        'rejeicao: Total do ICMS desonerado difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '796',
                        'rejeicao: Empresa sem Chave de Seguran�a para o QR-Code'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '798',
                        'rejeicao: Valor total do ICMS relativo Fundo de Combate � Pobreza  FCP  da UF de destino difere do somat�rio do valor do'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '799',
                        'rejeicao: Valor total do ICMS Interestadual da UF de destino difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '800',
                        'rejeicao: Valor total do ICMS Interestadual da UF do remetente difere do somat�rio dos itens'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '805',
                        'rejeicao: A SEFAZ do destinat�rio n�o permite Contribuinte Isento de Inscri��o Estadual'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '806',
                        'rejeicao: Opera��o com ICMS-ST sem informa��o do CEST'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '807',
                        'rejeicao: NFC-e com grupo de ICMS para a UF do destinat�rio'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '306',
                        'Rejeicao: IE do destinatario nao esta ativa na UF'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '811',
                        'Rejeicao: Pedido de Prorrogacao deferido impede o cancelamento da NF-e'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '812',
                        'Rejeicao: Regime Tributario SN'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '813',
                        'Rejeicao: QR-Code com sequencia de escape para o e-comercial. Usar CDATA'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '814',
                        'Rejeicao: Nota Fiscal com grupo de comercio exterior'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '815',
                        'Rejeicao: Valor do ICMS Interestadual para UF de Destino difere do calculado [nItem: 999]  Valor Informado: XXX'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '816',
                        'Rejeicao: Valor do ICMS Interestadual para UF do Remetente difere do calculado [nItem: 999]  Valor Informado: XXX'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '817',
                        'Rejeicao: Unidade Tributavel incompativel com o NCM informado na operacao com Comercio Exterior  nItem: 999'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '827',
                        'Rejeicao: Obrigatorio informar o tipo de autorizacao'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '828',
                        'Rejeicao: Nao permitido informar o campo tipo de autorizacao'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '829',
                        'Rejeicao: Condicao de uso nao informado para o tipo de autorizacao de uso'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '830',
                        'Rejeicao: Nao permitido preencher o campo Condicao de Uso'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '850',
                        'Rejeicao: Data de vencimento da parcela nao informada ou menor que a Data de vencimento da parcela anterior  nOcor: 999'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '851',
                        'Rejeicao: Soma do valor das parcelas difere do Valor Liquido da Fatura'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '852',
                        'Rejeicao: Numero da parcela invalido ou nao informado  nOcor: 999'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '854',
                        'Rejeicao: Unidade Tributavel  tag:uTrib  incompativel com produto informado  nItem: 999'
                    );

INSERT INTO nfecret (
                        CODIGO,
                        DESCRICAO
                    )
                    VALUES (
                        '855',
                        '......'
                    );


-- Table: sintcert
DROP TABLE IF EXISTS sintcert;

CREATE TABLE IF NOT EXISTS sintcert (
    cnpj       TEXT (20) NOT NULL,
    ie         TEXT (20) NOT NULL,
    ccm        TEXT (20) NOT NULL,
    uf         TEXT (2)  NOT NULL,
    cidade     TEXT (35) NOT NULL,
    cnpjok     TEXT (1)  NOT NULL,
    ieok       TEXT (1)  NOT NULL,
    ccmok      TEXT (1)  NOT NULL,
    razao      TEXT (60) NOT NULL,
    ori        TEXT (10) NOT NULL,
    dig3ok     TEXT (1)  NOT NULL,
    obs        TEXT (60) NOT NULL,
    cep        TEXT (8)  NOT NULL,
    ddd        TEXT (2)  NOT NULL,
    suframa    TEXT (9)  NOT NULL,
    cnae       TEXT (7)  NOT NULL,
    email      TEXT (60) NOT NULL,
    telefone   TEXT (15) NOT NULL,
    csit       TEXT (1)  NOT NULL,
    indcrednfe TEXT (1)  NOT NULL,
    indcredcte TEXT (1)  NOT NULL,
    xregapur   TEXT (7)  NOT NULL,
    diniativ   TEXT (10) NOT NULL,
    dultsit    TEXT (10) NOT NULL,
    bairro     TEXT (35) NOT NULL,
    codibge    TEXT (7)  NOT NULL,
    endereco   TEXT (60) NOT NULL,
    numend     TEXT (15) NOT NULL,
    complem    TEXT (30) NOT NULL,
    ultimaimp  SHORTDATE NOT NULL,
    endtip     TEXT (10) NOT NULL
);


-- Table: sintcertfec
DROP TABLE IF EXISTS sintcertfec;

CREATE TABLE IF NOT EXISTS sintcertfec (
    cnpj       TEXT (20) NOT NULL,
    ie         TEXT (20) NOT NULL,
    ccm        TEXT (20) NOT NULL,
    uf         TEXT (2)  NOT NULL,
    cidade     TEXT (35) NOT NULL,
    cnpjok     TEXT (1)  NOT NULL,
    ieok       TEXT (1)  NOT NULL,
    ccmok      TEXT (1)  NOT NULL,
    razao      TEXT (60) NOT NULL,
    ori        TEXT (10) NOT NULL,
    dig3ok     TEXT (1)  NOT NULL,
    obs        TEXT (60) NOT NULL,
    cep        TEXT (8)  NOT NULL,
    ddd        TEXT (2)  NOT NULL,
    suframa    TEXT (9)  NOT NULL,
    cnae       TEXT (7)  NOT NULL,
    email      TEXT (60) NOT NULL,
    telefone   TEXT (15) NOT NULL,
    csit       TEXT (1)  NOT NULL,
    indcrednfe TEXT (1)  NOT NULL,
    indcredcte TEXT (1)  NOT NULL,
    xregapur   TEXT (7)  NOT NULL,
    diniativ   TEXT (10) NOT NULL,
    dultsit    TEXT (10) NOT NULL,
    bairro     TEXT (35) NOT NULL,
    codibge    TEXT (7)  NOT NULL,
    endereco   TEXT (60) NOT NULL,
    numend     TEXT (15) NOT NULL,
    complem    TEXT (30) NOT NULL,
    ultimaimp  SHORTDATE NOT NULL,
    endtip     TEXT (10) NOT NULL
);


-- Table: sintpend
DROP TABLE IF EXISTS sintpend;

CREATE TABLE IF NOT EXISTS sintpend (
    cnpj   TEXT (20) NOT NULL,
    ie     TEXT (20) NOT NULL,
    ccm    TEXT (20) NOT NULL,
    uf     TEXT (2)  NOT NULL,
    cidade TEXT (35) NOT NULL,
    cnpjok TEXT (1)  NOT NULL,
    ieok   TEXT (1)  NOT NULL,
    ccmok  TEXT (1)  NOT NULL,
    razao  TEXT (60) NOT NULL,
    ori    TEXT (10) NOT NULL,
    dig3ok TEXT (1)  NOT NULL,
    obs    TEXT (60) NOT NULL,
    cep    TEXT (8)  NOT NULL,
    ddd    TEXT (2)  NOT NULL
);


-- Table: xmlpend
DROP TABLE IF EXISTS xmlpend;

CREATE TABLE IF NOT EXISTS xmlpend (
    id TEXT (44) NOT NULL
);


-- Index: idx_cnpjxml_cnpjxml1
DROP INDEX IF EXISTS idx_cnpjxml_cnpjxml1;

CREATE INDEX IF NOT EXISTS idx_cnpjxml_cnpjxml1 ON cnpjxml (
    cnpj
);


-- Index: idx_cnpjxml_cnpjxml2
DROP INDEX IF EXISTS idx_cnpjxml_cnpjxml2;

CREATE INDEX IF NOT EXISTS idx_cnpjxml_cnpjxml2 ON cnpjxml (
    ie
);


-- Index: idx_cnpjxml_cnpjxml3
DROP INDEX IF EXISTS idx_cnpjxml_cnpjxml3;

CREATE INDEX IF NOT EXISTS idx_cnpjxml_cnpjxml3 ON cnpjxml (
    codpart
);


-- Index: idx_cnpjxml_cnpjxml4
DROP INDEX IF EXISTS idx_cnpjxml_cnpjxml4;

CREATE INDEX IF NOT EXISTS idx_cnpjxml_cnpjxml4 ON cnpjxml (
    uf,
    cidade
);


-- Index: idx_cnpjxmlfec_cnpjxml1
DROP INDEX IF EXISTS idx_cnpjxmlfec_cnpjxml1;

CREATE INDEX IF NOT EXISTS idx_cnpjxmlfec_cnpjxml1 ON cnpjxmlfec (
    cnpj
);


-- Index: idx_cnpjxmlfec_cnpjxml2
DROP INDEX IF EXISTS idx_cnpjxmlfec_cnpjxml2;

CREATE INDEX IF NOT EXISTS idx_cnpjxmlfec_cnpjxml2 ON cnpjxmlfec (
    ie
);


-- Index: idx_cnpjxmlfec_cnpjxml3
DROP INDEX IF EXISTS idx_cnpjxmlfec_cnpjxml3;

CREATE INDEX IF NOT EXISTS idx_cnpjxmlfec_cnpjxml3 ON cnpjxmlfec (
    codpart
);


-- Index: idx_cnpjxmlfec_cnpjxml4
DROP INDEX IF EXISTS idx_cnpjxmlfec_cnpjxml4;

CREATE INDEX IF NOT EXISTS idx_cnpjxmlfec_cnpjxml4 ON cnpjxmlfec (
    uf,
    cidade
);


-- Index: idx_danfe2_danfe2
DROP INDEX IF EXISTS idx_danfe2_danfe2;

CREATE INDEX IF NOT EXISTS idx_danfe2_danfe2 ON danfe2 (
    id
);


-- Index: idx_danfe2_danfe2-2
DROP INDEX IF EXISTS [idx_danfe2_danfe2-2];

CREATE INDEX IF NOT EXISTS [idx_danfe2_danfe2-2] ON danfe2 (
    cnpj,
    nnf
);


-- Index: idx_danfe2_danfe2-3
DROP INDEX IF EXISTS [idx_danfe2_danfe2-3];

CREATE INDEX IF NOT EXISTS [idx_danfe2_danfe2-3] ON danfe2 (
    nnf
);


-- Index: idx_danfe2fec_danfe2
DROP INDEX IF EXISTS idx_danfe2fec_danfe2;

CREATE INDEX IF NOT EXISTS idx_danfe2fec_danfe2 ON danfe2fec (
    id
);


-- Index: idx_danfe2fec_danfe2-2
DROP INDEX IF EXISTS [idx_danfe2fec_danfe2-2];

CREATE INDEX IF NOT EXISTS [idx_danfe2fec_danfe2-2] ON danfe2fec (
    cnpj,
    nnf
);


-- Index: idx_danfe2fec_danfe2-3
DROP INDEX IF EXISTS [idx_danfe2fec_danfe2-3];

CREATE INDEX IF NOT EXISTS [idx_danfe2fec_danfe2-3] ON danfe2fec (
    nnf
);


-- Index: idx_danfe_danfe
DROP INDEX IF EXISTS idx_danfe_danfe;

CREATE INDEX IF NOT EXISTS idx_danfe_danfe ON danfe (
    id,
    cprod
);


-- Index: idx_nfe_nfe
DROP INDEX IF EXISTS idx_nfe_nfe;

CREATE INDEX IF NOT EXISTS idx_nfe_nfe ON nfe (
    empresa
);


-- Index: idx_sintcert_sintce01
DROP INDEX IF EXISTS idx_sintcert_sintce01;

CREATE INDEX IF NOT EXISTS idx_sintcert_sintce01 ON sintcert (
    cnpj
);


-- Index: idx_sintcert_sintce02
DROP INDEX IF EXISTS idx_sintcert_sintce02;

CREATE INDEX IF NOT EXISTS idx_sintcert_sintce02 ON sintcert (
    ie
);


-- Index: idx_sintcert_sintce03
DROP INDEX IF EXISTS idx_sintcert_sintce03;

CREATE INDEX IF NOT EXISTS idx_sintcert_sintce03 ON sintcert (
    razao
);


-- Index: idx_sintcert_sintce04
DROP INDEX IF EXISTS idx_sintcert_sintce04;

CREATE INDEX IF NOT EXISTS idx_sintcert_sintce04 ON sintcert (
    uf,
    cidade
);


-- Index: idx_sintcertfec_sintce01
DROP INDEX IF EXISTS idx_sintcertfec_sintce01;

CREATE INDEX IF NOT EXISTS idx_sintcertfec_sintce01 ON sintcertfec (
    cnpj
);


-- Index: idx_sintcertfec_sintce02
DROP INDEX IF EXISTS idx_sintcertfec_sintce02;

CREATE INDEX IF NOT EXISTS idx_sintcertfec_sintce02 ON sintcertfec (
    ie
);


-- Index: idx_sintcertfec_sintce03
DROP INDEX IF EXISTS idx_sintcertfec_sintce03;

CREATE INDEX IF NOT EXISTS idx_sintcertfec_sintce03 ON sintcertfec (
    razao
);


-- Index: idx_sintcertfec_sintce04
DROP INDEX IF EXISTS idx_sintcertfec_sintce04;

CREATE INDEX IF NOT EXISTS idx_sintcertfec_sintce04 ON sintcertfec (
    uf,
    cidade
);


-- Index: idx_sintpend_sintpe01
DROP INDEX IF EXISTS idx_sintpend_sintpe01;

CREATE INDEX IF NOT EXISTS idx_sintpend_sintpe01 ON sintpend (
    cnpj
);


-- Index: idx_sintpend_sintpe02
DROP INDEX IF EXISTS idx_sintpend_sintpe02;

CREATE INDEX IF NOT EXISTS idx_sintpend_sintpe02 ON sintpend (
    ie
);


-- Index: idx_sintpend_sintpe03
DROP INDEX IF EXISTS idx_sintpend_sintpe03;

CREATE INDEX IF NOT EXISTS idx_sintpend_sintpe03 ON sintpend (
    razao
);


-- Index: idx_sintpend_sintpe04
DROP INDEX IF EXISTS idx_sintpend_sintpe04;

CREATE INDEX IF NOT EXISTS idx_sintpend_sintpe04 ON sintpend (
    uf,
    cidade
);


-- Index: idx_xmlpend
DROP INDEX IF EXISTS idx_xmlpend;

CREATE INDEX IF NOT EXISTS idx_xmlpend ON xmlpend (
    id
);


-- Index: NFECORRE
DROP INDEX IF EXISTS NFECORRE;

CREATE INDEX IF NOT EXISTS NFECORRE ON nfecorrecao (
    CODIGO
);


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
