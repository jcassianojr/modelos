--
-- Arquivo gerado com SQLiteStudio v3.4.4 em qui ago 1 21:00:03 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: cnpjxml
CREATE TABLE IF NOT EXISTS [cnpjxml] ([cnpj] TEXT(14) NOT NULL, [ie] TEXT(14) NOT NULL, [nome] TEXT(60) NOT NULL, [endereco] TEXT(60) NOT NULL, [cidade] TEXT(35) NOT NULL, [cep] TEXT(8) NOT NULL, [telefone] TEXT(14) NOT NULL, [ddd] TEXT(2) NOT NULL, [uf] TEXT(2) NOT NULL, [iesubst] TEXT(14) NOT NULL, [imunicipal] TEXT(15) NOT NULL, [cognome] TEXT(60) NOT NULL, [email] TEXT(60) NOT NULL, [numend] TEXT(15) NOT NULL, [complem] TEXT(30) NOT NULL, [bairro] TEXT(35) NOT NULL, [bacen] TEXT(5) NOT NULL, [pais] TEXT(10) NOT NULL, [cnae] TEXT(7) NOT NULL, [suframa] TEXT(9) NOT NULL, [codibge] TEXT(7) NOT NULL, [ultimaimp] SHORTDATE NOT NULL, [codpart] TEXT(20) NOT NULL, [csit] TEXT(1) NOT NULL, [indcrednfe] TEXT(1) NOT NULL, [indcredcte] TEXT(1) NOT NULL, [xregapur] TEXT(7) NOT NULL, [diniativ] TEXT(10) NOT NULL, [dultsit] TEXT(10) NOT NULL, [dinixml] SHORTDATE NOT NULL, [endtip] TEXT(10) NOT NULL);

-- Tabela: cnpjxmlfec
CREATE TABLE IF NOT EXISTS [cnpjxmlfec] ([cnpj] TEXT(14) NOT NULL, [ie] TEXT(14) NOT NULL, [nome] TEXT(60) NOT NULL, [endereco] TEXT(60) NOT NULL, [cidade] TEXT(35) NOT NULL, [cep] TEXT(8) NOT NULL, [telefone] TEXT(14) NOT NULL, [ddd] TEXT(2) NOT NULL, [uf] TEXT(2) NOT NULL, [iesubst] TEXT(14) NOT NULL, [imunicipal] TEXT(15) NOT NULL, [cognome] TEXT(60) NOT NULL, [email] TEXT(60) NOT NULL, [numend] TEXT(15) NOT NULL, [complem] TEXT(30) NOT NULL, [bairro] TEXT(35) NOT NULL, [bacen] TEXT(5) NOT NULL, [pais] TEXT(10) NOT NULL, [cnae] TEXT(7) NOT NULL, [suframa] TEXT(9) NOT NULL, [codibge] TEXT(7) NOT NULL, [ultimaimp] SHORTDATE NOT NULL, [codpart] TEXT(20) NOT NULL, [csit] TEXT(1) NOT NULL, [indcrednfe] TEXT(1) NOT NULL, [indcredcte] TEXT(1) NOT NULL, [xregapur] TEXT(7) NOT NULL, [diniativ] TEXT(10) NOT NULL, [dultsit] TEXT(10) NOT NULL, [dinixml] SHORTDATE NOT NULL, [endtip] TEXT(10) NOT NULL);

-- Tabela: danfe
CREATE TABLE IF NOT EXISTS [danfe] ([id] TEXT(44) NOT NULL, [cprod] TEXT(16) NOT NULL, [xprod] TEXT(60) NOT NULL, [qcom] REAL NOT NULL, [vuncom] REAL NOT NULL, [ucom] TEXT(4) NOT NULL, [cfop] TEXT(4) NOT NULL, [ncm] TEXT(10) NOT NULL, [csticms] TEXT(4) NOT NULL, [cstipi] TEXT(4) NOT NULL, [cstpis] TEXT(4) NOT NULL, [cstcofins] TEXT(4) NOT NULL, [vicms] REAL NOT NULL, [vpis] REAL NOT NULL, [vipi] REAL NOT NULL, [vcofins] REAL NOT NULL, [vbcicms] REAL NOT NULL, [vbcpis] REAL NOT NULL, [vbcipi] REAL NOT NULL, [vbccofins] REAL NOT NULL, [picms] REAL NOT NULL, [ppis] REAL NOT NULL, [pipi] REAL NOT NULL, [pcofins] REAL NOT NULL);

-- Tabela: danfe2
CREATE TABLE IF NOT EXISTS [danfe2] ([id] TEXT(44) NOT NULL, [cnpj] TEXT(14) NOT NULL, [cnpjdest] TEXT(14) NOT NULL, [nnf] TEXT(9) NOT NULL, [serie] TEXT(3) NOT NULL, [emissao] TEXT(10) NOT NULL, [cancelada] TEXT(1) NOT NULL, [avb] TEXT(1) NOT NULL, [xml] TEXT(1) NOT NULL, [danfeview] TEXT(1) NOT NULL, [cstatus] TEXT(3) NOT NULL, [logixsup] TEXT(1) NOT NULL, [protocolo] TEXT(20) NOT NULL);

-- Tabela: danfe2fec
CREATE TABLE IF NOT EXISTS [danfe2fec] ([id] TEXT(44) NOT NULL, [cnpj] TEXT(14) NOT NULL, [cnpjdest] TEXT(14) NOT NULL, [nnf] TEXT(9) NOT NULL, [serie] TEXT(3) NOT NULL, [emissao] TEXT(10) NOT NULL, [cancelada] TEXT(1) NOT NULL, [avb] TEXT(1) NOT NULL, [xml] TEXT(1) NOT NULL, [danfeview] TEXT(1) NOT NULL, [cstatus] TEXT(3) NOT NULL, [logixsup] TEXT(1) NOT NULL, [protocolo] TEXT(20) NOT NULL);

-- Tabela: nfe
CREATE TABLE IF NOT EXISTS [nfe] ([empresa] TEXT(2) NOT NULL, [sintel] SHORTDATE NOT NULL, [nfs] REAL NOT NULL, [gmprotrec] REAL NOT NULL, [danfevrec] REAL NOT NULL, [statusrec] REAL NOT NULL, [chavesup] REAL NOT NULL);

-- Tabela: nfecret
CREATE TABLE IF NOT EXISTS [nfecret] ([codigo] TEXT(3) NOT NULL, [descricao] TEXT(120) NOT NULL);

-- Tabela: sintcert
CREATE TABLE IF NOT EXISTS [sintcert] ([cnpj] TEXT(20) NOT NULL, [ie] TEXT(20) NOT NULL, [ccm] TEXT(20) NOT NULL, [uf] TEXT(2) NOT NULL, [cidade] TEXT(35) NOT NULL, [cnpjok] TEXT(1) NOT NULL, [ieok] TEXT(1) NOT NULL, [ccmok] TEXT(1) NOT NULL, [razao] TEXT(60) NOT NULL, [ori] TEXT(10) NOT NULL, [dig3ok] TEXT(1) NOT NULL, [obs] TEXT(60) NOT NULL, [cep] TEXT(8) NOT NULL, [ddd] TEXT(2) NOT NULL, [suframa] TEXT(9) NOT NULL, [cnae] TEXT(7) NOT NULL, [email] TEXT(60) NOT NULL, [telefone] TEXT(15) NOT NULL, [csit] TEXT(1) NOT NULL, [indcrednfe] TEXT(1) NOT NULL, [indcredcte] TEXT(1) NOT NULL, [xregapur] TEXT(7) NOT NULL, [diniativ] TEXT(10) NOT NULL, [dultsit] TEXT(10) NOT NULL, [bairro] TEXT(35) NOT NULL, [codibge] TEXT(7) NOT NULL, [endereco] TEXT(60) NOT NULL, [numend] TEXT(15) NOT NULL, [complem] TEXT(30) NOT NULL, [ultimaimp] SHORTDATE NOT NULL, [endtip] TEXT(10) NOT NULL);

-- Tabela: sintcertfec
CREATE TABLE IF NOT EXISTS [sintcertfec] ([cnpj] TEXT(20) NOT NULL, [ie] TEXT(20) NOT NULL, [ccm] TEXT(20) NOT NULL, [uf] TEXT(2) NOT NULL, [cidade] TEXT(35) NOT NULL, [cnpjok] TEXT(1) NOT NULL, [ieok] TEXT(1) NOT NULL, [ccmok] TEXT(1) NOT NULL, [razao] TEXT(60) NOT NULL, [ori] TEXT(10) NOT NULL, [dig3ok] TEXT(1) NOT NULL, [obs] TEXT(60) NOT NULL, [cep] TEXT(8) NOT NULL, [ddd] TEXT(2) NOT NULL, [suframa] TEXT(9) NOT NULL, [cnae] TEXT(7) NOT NULL, [email] TEXT(60) NOT NULL, [telefone] TEXT(15) NOT NULL, [csit] TEXT(1) NOT NULL, [indcrednfe] TEXT(1) NOT NULL, [indcredcte] TEXT(1) NOT NULL, [xregapur] TEXT(7) NOT NULL, [diniativ] TEXT(10) NOT NULL, [dultsit] TEXT(10) NOT NULL, [bairro] TEXT(35) NOT NULL, [codibge] TEXT(7) NOT NULL, [endereco] TEXT(60) NOT NULL, [numend] TEXT(15) NOT NULL, [complem] TEXT(30) NOT NULL, [ultimaimp] SHORTDATE NOT NULL, [endtip] TEXT(10) NOT NULL);

-- Tabela: sintpend
CREATE TABLE IF NOT EXISTS [sintpend] ([cnpj] TEXT(20) NOT NULL, [ie] TEXT(20) NOT NULL, [ccm] TEXT(20) NOT NULL, [uf] TEXT(2) NOT NULL, [cidade] TEXT(35) NOT NULL, [cnpjok] TEXT(1) NOT NULL, [ieok] TEXT(1) NOT NULL, [ccmok] TEXT(1) NOT NULL, [razao] TEXT(60) NOT NULL, [ori] TEXT(10) NOT NULL, [dig3ok] TEXT(1) NOT NULL, [obs] TEXT(60) NOT NULL, [cep] TEXT(8) NOT NULL, [ddd] TEXT(2) NOT NULL);

-- Tabela: xmlpend
CREATE TABLE IF NOT EXISTS [xmlpend] ([id] TEXT(44) NOT NULL);

-- �ndice: idx_cnpjxml_cnpjxml1
CREATE INDEX IF NOT EXISTS [idx_cnpjxml_cnpjxml1] ON [cnpjxml] ([cnpj]);

-- �ndice: idx_cnpjxml_cnpjxml2
CREATE INDEX IF NOT EXISTS [idx_cnpjxml_cnpjxml2] ON [cnpjxml] ([ie]);

-- �ndice: idx_cnpjxml_cnpjxml3
CREATE INDEX IF NOT EXISTS [idx_cnpjxml_cnpjxml3] ON [cnpjxml] ([codpart]);

-- �ndice: idx_cnpjxml_cnpjxml4
CREATE INDEX IF NOT EXISTS [idx_cnpjxml_cnpjxml4] ON [cnpjxml] ([uf], [cidade]);

-- �ndice: idx_cnpjxmlfec_cnpjxml1
CREATE INDEX IF NOT EXISTS [idx_cnpjxmlfec_cnpjxml1] ON [cnpjxmlfec] ([cnpj]);

-- �ndice: idx_cnpjxmlfec_cnpjxml2
CREATE INDEX IF NOT EXISTS [idx_cnpjxmlfec_cnpjxml2] ON [cnpjxmlfec] ([ie]);

-- �ndice: idx_cnpjxmlfec_cnpjxml3
CREATE INDEX IF NOT EXISTS [idx_cnpjxmlfec_cnpjxml3] ON [cnpjxmlfec] ([codpart]);

-- �ndice: idx_cnpjxmlfec_cnpjxml4
CREATE INDEX IF NOT EXISTS [idx_cnpjxmlfec_cnpjxml4] ON [cnpjxmlfec] ([uf], [cidade]);

-- �ndice: idx_danfe2_danfe2
CREATE INDEX IF NOT EXISTS [idx_danfe2_danfe2] ON [danfe2] ([id]);

-- �ndice: idx_danfe2_danfe2-2
CREATE INDEX IF NOT EXISTS [idx_danfe2_danfe2-2] ON [danfe2] ([cnpj], [nnf]);

-- �ndice: idx_danfe2_danfe2-3
CREATE INDEX IF NOT EXISTS [idx_danfe2_danfe2-3] ON [danfe2] ([nnf]);

-- �ndice: idx_danfe2fec_danfe2
CREATE INDEX IF NOT EXISTS [idx_danfe2fec_danfe2] ON [danfe2fec] ([id]);

-- �ndice: idx_danfe2fec_danfe2-2
CREATE INDEX IF NOT EXISTS [idx_danfe2fec_danfe2-2] ON [danfe2fec] ([cnpj], [nnf]);

-- �ndice: idx_danfe2fec_danfe2-3
CREATE INDEX IF NOT EXISTS [idx_danfe2fec_danfe2-3] ON [danfe2fec] ([nnf]);

-- �ndice: idx_danfe_danfe
CREATE INDEX IF NOT EXISTS [idx_danfe_danfe] ON [danfe] ([id], [cprod]);

-- �ndice: idx_nfe_nfe
CREATE INDEX IF NOT EXISTS [idx_nfe_nfe] ON [nfe] ([empresa]);

-- �ndice: idx_nfecret_nfecret
CREATE INDEX IF NOT EXISTS [idx_nfecret_nfecret] ON [nfecret] ([codigo]);

-- �ndice: idx_sintcert_sintce01
CREATE INDEX IF NOT EXISTS [idx_sintcert_sintce01] ON [sintcert] ([cnpj]);

-- �ndice: idx_sintcert_sintce02
CREATE INDEX IF NOT EXISTS [idx_sintcert_sintce02] ON [sintcert] ([ie]);

-- �ndice: idx_sintcert_sintce03
CREATE INDEX IF NOT EXISTS [idx_sintcert_sintce03] ON [sintcert] ([razao]);

-- �ndice: idx_sintcert_sintce04
CREATE INDEX IF NOT EXISTS [idx_sintcert_sintce04] ON [sintcert] ([uf], [cidade]);

-- �ndice: idx_sintcertfec_sintce01
CREATE INDEX IF NOT EXISTS [idx_sintcertfec_sintce01] ON [sintcertfec] ([cnpj]);

-- �ndice: idx_sintcertfec_sintce02
CREATE INDEX IF NOT EXISTS [idx_sintcertfec_sintce02] ON [sintcertfec] ([ie]);

-- �ndice: idx_sintcertfec_sintce03
CREATE INDEX IF NOT EXISTS [idx_sintcertfec_sintce03] ON [sintcertfec] ([razao]);

-- �ndice: idx_sintcertfec_sintce04
CREATE INDEX IF NOT EXISTS [idx_sintcertfec_sintce04] ON [sintcertfec] ([uf], [cidade]);

-- �ndice: idx_sintpend_sintpe01
CREATE INDEX IF NOT EXISTS [idx_sintpend_sintpe01] ON [sintpend] ([cnpj]);

-- �ndice: idx_sintpend_sintpe02
CREATE INDEX IF NOT EXISTS [idx_sintpend_sintpe02] ON [sintpend] ([ie]);

-- �ndice: idx_sintpend_sintpe03
CREATE INDEX IF NOT EXISTS [idx_sintpend_sintpe03] ON [sintpend] ([razao]);

-- �ndice: idx_sintpend_sintpe04
CREATE INDEX IF NOT EXISTS [idx_sintpend_sintpe04] ON [sintpend] ([uf], [cidade]);

-- �ndice: idx_xmlpend
CREATE INDEX IF NOT EXISTS [idx_xmlpend] ON [xmlpend] ([id]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
