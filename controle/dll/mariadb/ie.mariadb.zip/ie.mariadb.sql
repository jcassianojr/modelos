#
# DUMP FILE
#
# Database is ported from MS Access
#------------------------------------------------------------------
# Created using "MS Access to MySQL" form http://www.bullzip.com
# Program Version 5.5.282
#
# OPTIONS:
#   sourcefilename=C:/temp/ie.mdb
#   sourceusername=
#   sourcepassword=
#   sourcesystemdatabase=
#   destinationdatabase=ie
#   storageengine=InnoDB
#   dropdatabase=0
#   createtables=1
#   unicode=0
#   autocommit=1
#   transferdefaultvalues=1
#   transferindexes=1
#   transferautonumbers=1
#   transferrecords=0
#   columnlist=1
#   tableprefix=
#   negativeboolean=0
#   ignorelargeblobs=0
#   memotype=LONGTEXT
#   datetimetype=DATETIME
#

CREATE DATABASE IF NOT EXISTS `ie`;
USE `ie`;

#
# Table structure for table 'IE'
#

DROP TABLE IF EXISTS `IE`;

CREATE TABLE `IE` (
  `PF` DOUBLE NOT NULL DEFAULT 0, 
  `DETALHE` LONGTEXT, 
  `TIPO` LONGTEXT, 
  `FECHA` LONGTEXT, 
  `NPED` DOUBLE NULL DEFAULT 0, 
  `IDENT` LONGTEXT, 
  `PROTE` LONGTEXT, 
  `QML` DOUBLE NULL DEFAULT 0, 
  `COM` DOUBLE NULL DEFAULT 0, 
  `LAR` DOUBLE NULL DEFAULT 0, 
  `ALT` DOUBLE NULL DEFAULT 0, 
  `UND` DOUBLE NULL DEFAULT 0, 
  `TOTL` DOUBLE NULL DEFAULT 0, 
  `TARA` DOUBLE NULL DEFAULT 0, 
  `BRUTO` DOUBLE NULL DEFAULT 0, 
  `METODO` LONGTEXT, 
  `OBS` LONGTEXT, 
  `IMAGEM` LONGBLOB, 
  `DATA` DATETIME, 
  `REVISAO` DOUBLE NULL DEFAULT 0, 
  `LOCAL` LONGTEXT, 
  `CODMR01` VARCHAR(10), 
  `NOMMR01` VARCHAR(100), 
  `DATAREV` DATETIME, 
  `FOTOESQ` LONGBLOB, 
  `FOTODIR` LONGBLOB, 
  `CODDIR` VARCHAR(50), 
  `CODESQ` VARCHAR(50), 
  `CODIGOINT` VARCHAR(50), 
  `codigocli` VARCHAR(50), 
  `elaborador` VARCHAR(40), 
  PRIMARY KEY (`PF`)
) ENGINE=innodb;

