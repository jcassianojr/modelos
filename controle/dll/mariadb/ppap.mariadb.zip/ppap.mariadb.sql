#
# DUMP FILE
#
# Database is ported from MS Access
#------------------------------------------------------------------
# Created using "MS Access to MySQL" form http://www.bullzip.com
# Program Version 5.5.282
#
# OPTIONS:
#   sourcefilename=C:/temp/ppap.mdb
#   sourceusername=
#   sourcepassword=
#   sourcesystemdatabase=
#   destinationdatabase=ppap
#   storageengine=InnoDB
#   dropdatabase=0
#   createtables=1
#   unicode=0
#   autocommit=1
#   transferdefaultvalues=1
#   transferindexes=1
#   transferautonumbers=1
#   transferrecords=0
#   columnlist=1
#   tableprefix=
#   negativeboolean=0
#   ignorelargeblobs=0
#   memotype=LONGTEXT
#   datetimetype=DATETIME
#

CREATE DATABASE IF NOT EXISTS `ppap`;
USE `ppap`;

#
# Table structure for table 'PPAF'
#

DROP TABLE IF EXISTS `PPAF`;

CREATE TABLE `PPAF` (
  `CLIENTE` INTEGER, 
  `CLINOME` VARCHAR(50), 
  `COMPRADOR` VARCHAR(5), 
  `COMNOME` VARCHAR(40), 
  `CODIGO` VARCHAR(24), 
  `NOME` VARCHAR(40), 
  `DATAALT` DATETIME, 
  `ITEM` TINYINT(1), 
  `PESO` DOUBLE NULL, 
  `OBSADC01` VARCHAR(80), 
  `OBSADC02` VARCHAR(80), 
  `SUB01` TINYINT(1), 
  `SUB02` TINYINT(1), 
  `SUB03` TINYINT(1), 
  `SUB04` TINYINT(1), 
  `SUB05` TINYINT(1), 
  `SUB06` TINYINT(1), 
  `SUB07` TINYINT(1), 
  `SUB08` TINYINT(1), 
  `SUB09` TINYINT(1), 
  `NIVEL` VARCHAR(1), 
  `RES01` TINYINT(1), 
  `RES02` TINYINT(1), 
  `RES03` TINYINT(1), 
  `RES04` TINYINT(1), 
  `APLIC` TINYINT(1), 
  `SUB10` TINYINT(1), 
  `DESENHO` VARCHAR(80), 
  `NOT01` TINYINT(1), 
  `NOT02` TINYINT(1), 
  `INF01` TINYINT(1), 
  `INF02` TINYINT(1), 
  `INF03` TINYINT(1), 
  `EXPOSTO` VARCHAR(80), 
  `PEDOM` VARCHAR(80), 
  `AUXILIAR` VARCHAR(80), 
  `NIVELALT` VARCHAR(80), 
  `NIVELDAT` DATETIME, 
  `DIVISAO` VARCHAR(80), 
  `APLICACAO` VARCHAR(80), 
  `DATA` DATETIME, 
  `MOLDE` VARCHAR(50), 
  `DISPO` VARCHAR(1), 
  `APRO` VARCHAR(1), 
  `RESNOME` VARCHAR(50), 
  `RESCARGO` VARCHAR(50), 
  `EXP01` VARCHAR(150), 
  `EXP02` VARCHAR(150), 
  `TIPCOM` VARCHAR(1), 
  `CODCOM` VARCHAR(24), 
  `NOMCOM` VARCHAR(50), 
  `FORNECEDOR` INTEGER, 
  `FORNOM` VARCHAR(50), 
  `PPAP` INTEGER AUTO_INCREMENT, 
  `COMPRAS` INTEGER, 
  `COMITEM` INTEGER, 
  `PRGENT` INTEGER, 
  `INATIVO` TINYINT(1), 
  `SITUACAO` VARCHAR(1), 
  `PF` INTEGER, 
  INDEX (`PPAP`)
) ENGINE=innodb;

#
# Table structure for table 'PPAFC'
#

DROP TABLE IF EXISTS `PPAFC`;

CREATE TABLE `PPAFC` (
  `PPAP` INTEGER, 
  `DATA` DATETIME, 
  `PREVISTO` DATETIME, 
  `EFETUADO` DATETIME, 
  `OBS` LONGTEXT, 
  `DISPO` VARCHAR(1), 
  `CODIGO` VARCHAR(50), 
  `ITEM` INTEGER AUTO_INCREMENT, 
  INDEX (`PPAP`), 
  INDEX (`ITEM`)
) ENGINE=innodb;

#
# Table structure for table 'PPAFI'
#

DROP TABLE IF EXISTS `PPAFI`;

CREATE TABLE `PPAFI` (
  `DATA` DATETIME, 
  `OBS` LONGTEXT, 
  `DISPO` VARCHAR(1), 
  `ITEM` DOUBLE NULL, 
  `PPAP` INTEGER, 
  `PRAZO` DATETIME, 
  `APROVADO` DATETIME, 
  `dispnome` VARCHAR(40), 
  `dispdate` DATETIME, 
  `dispnum` INTEGER, 
  INDEX (`PPAP`)
) ENGINE=innodb;

#
# Table structure for table 'PPAFP'
#

DROP TABLE IF EXISTS `PPAFP`;

CREATE TABLE `PPAFP` (
  `PPAP` INTEGER, 
  `CODIGO` VARCHAR(50), 
  `PF` INTEGER, 
  INDEX (`PPAP`)
) ENGINE=innodb;

#
# Table structure for table 'PPAG'
#

DROP TABLE IF EXISTS `PPAG`;

CREATE TABLE `PPAG` (
  `CLIENTE` INTEGER, 
  `CLINOME` VARCHAR(50), 
  `COMPRADOR` VARCHAR(5), 
  `COMNOME` VARCHAR(40), 
  `CODIGO` VARCHAR(24), 
  `NOME` VARCHAR(40), 
  `DATAALT` DATETIME, 
  `ITEM` TINYINT(1), 
  `PESO` DOUBLE NULL, 
  `OBSADC01` VARCHAR(80), 
  `OBSADC02` VARCHAR(80), 
  `SUB01` TINYINT(1), 
  `SUB02` TINYINT(1), 
  `SUB03` TINYINT(1), 
  `SUB04` TINYINT(1), 
  `SUB05` TINYINT(1), 
  `SUB06` TINYINT(1), 
  `SUB07` TINYINT(1), 
  `SUB08` TINYINT(1), 
  `SUB09` TINYINT(1), 
  `NIVEL` VARCHAR(1), 
  `RES01` TINYINT(1), 
  `RES02` TINYINT(1), 
  `RES03` TINYINT(1), 
  `RES04` TINYINT(1), 
  `APLIC` TINYINT(1), 
  `SUB10` TINYINT(1), 
  `DESENHO` VARCHAR(80), 
  `NOT01` TINYINT(1), 
  `NOT02` TINYINT(1), 
  `INF01` TINYINT(1), 
  `INF02` TINYINT(1), 
  `INF03` TINYINT(1), 
  `EXPOSTO` VARCHAR(80), 
  `PEDOM` VARCHAR(80), 
  `AUXILIAR` VARCHAR(80), 
  `NIVELALT` VARCHAR(80), 
  `NIVELDAT` DATETIME, 
  `DIVISAO` VARCHAR(80), 
  `APLICACAO` VARCHAR(80), 
  `DATA` DATETIME, 
  `MOLDE` VARCHAR(50), 
  `DISPO` VARCHAR(1), 
  `APRO` VARCHAR(1), 
  `RESNOME` VARCHAR(50), 
  `RESCARGO` VARCHAR(50), 
  `EXP01` VARCHAR(150), 
  `EXP02` VARCHAR(150), 
  `TIPCOM` VARCHAR(1), 
  `CODCOM` VARCHAR(24), 
  `NOMCOM` VARCHAR(50), 
  `FORNECEDOR` INTEGER, 
  `FORNOM` VARCHAR(50), 
  `COMPRAS` INTEGER, 
  `COMITEM` INTEGER, 
  `PRGENT` INTEGER, 
  `INATIVO` TINYINT(1), 
  `SITUACAO` VARCHAR(1), 
  `PF` INTEGER, 
  `PPAP` INTEGER AUTO_INCREMENT, 
  `SSMT` VARCHAR(50), 
  INDEX (`PPAP`)
) ENGINE=innodb;

#
# Table structure for table 'PPAGC'
#

DROP TABLE IF EXISTS `PPAGC`;

CREATE TABLE `PPAGC` (
  `PPAP` INTEGER, 
  `DATA` DATETIME, 
  `PREVISTO` DATETIME, 
  `EFETUADO` DATETIME, 
  `OBS` LONGTEXT, 
  `DISPO` VARCHAR(1), 
  `CODIGO` VARCHAR(50), 
  `ITEM` INTEGER AUTO_INCREMENT, 
  INDEX (`PPAP`), 
  INDEX (`ITEM`)
) ENGINE=innodb;

#
# Table structure for table 'PPAGI'
#

DROP TABLE IF EXISTS `PPAGI`;

CREATE TABLE `PPAGI` (
  `DATA` DATETIME, 
  `OBS` LONGTEXT, 
  `DISPO` VARCHAR(1), 
  `ITEM` DOUBLE NULL, 
  `PPAP` INTEGER, 
  `PRAZO` DATETIME, 
  `APROVADO` DATETIME, 
  `dispnome` VARCHAR(40), 
  `dispdate` DATETIME, 
  `dispnum` INTEGER, 
  INDEX (`PPAP`)
) ENGINE=innodb;

#
# Table structure for table 'PPAGP'
#

DROP TABLE IF EXISTS `PPAGP`;

CREATE TABLE `PPAGP` (
  `PPAP` INTEGER, 
  `CODIGO` VARCHAR(50), 
  `PF` INTEGER, 
  INDEX (`PPAP`)
) ENGINE=innodb;

#
# Table structure for table 'PPAP'
#

DROP TABLE IF EXISTS `PPAP`;

CREATE TABLE `PPAP` (
  `CLIENTE` INTEGER, 
  `CLINOME` VARCHAR(50), 
  `COMPRADOR` VARCHAR(5), 
  `COMNOME` VARCHAR(40), 
  `CODIGO` VARCHAR(24), 
  `NOME` VARCHAR(40), 
  `DATAALT` DATETIME, 
  `ITEM` TINYINT(1), 
  `PESO` DOUBLE NULL, 
  `OBSADC01` VARCHAR(80), 
  `OBSADC02` VARCHAR(80), 
  `SUB01` TINYINT(1), 
  `SUB02` TINYINT(1), 
  `SUB03` TINYINT(1), 
  `SUB04` TINYINT(1), 
  `SUB05` TINYINT(1), 
  `SUB06` TINYINT(1), 
  `SUB07` TINYINT(1), 
  `SUB08` TINYINT(1), 
  `SUB09` TINYINT(1), 
  `NIVEL` VARCHAR(1), 
  `RES01` TINYINT(1), 
  `RES02` TINYINT(1), 
  `RES03` TINYINT(1), 
  `RES04` TINYINT(1), 
  `APLIC` TINYINT(1), 
  `SUB10` TINYINT(1), 
  `DESENHO` VARCHAR(80), 
  `NOT01` TINYINT(1), 
  `NOT02` TINYINT(1), 
  `INF01` TINYINT(1), 
  `INF02` TINYINT(1), 
  `INF03` TINYINT(1), 
  `EXPOSTO` VARCHAR(80), 
  `PEDOM` VARCHAR(80), 
  `AUXILIAR` VARCHAR(80), 
  `NIVELALT` VARCHAR(80), 
  `NIVELDAT` DATETIME, 
  `DIVISAO` VARCHAR(80), 
  `APLICACAO` VARCHAR(80), 
  `DATA` DATETIME, 
  `MOLDE` VARCHAR(50), 
  `DISPO` VARCHAR(1), 
  `APRO` VARCHAR(1), 
  `RESNOME` VARCHAR(50), 
  `RESCARGO` VARCHAR(50), 
  `EXP01` VARCHAR(150), 
  `EXP02` VARCHAR(150), 
  `PPAP` INTEGER AUTO_INCREMENT, 
  `TIPCOM` VARCHAR(1), 
  `CODCOM` VARCHAR(24), 
  `NOMCOM` VARCHAR(50), 
  `FORNECEDOR` INTEGER, 
  `FORNOM` VARCHAR(50), 
  `COMPRAS` INTEGER, 
  `COMITEM` INTEGER, 
  `PRGENT` INTEGER, 
  `INATIVO` TINYINT(1), 
  `SITUACOA` VARCHAR(1), 
  `PF` INTEGER, 
  INDEX (`PPAP`)
) ENGINE=innodb;

#
# Table structure for table 'PPAPC'
#

DROP TABLE IF EXISTS `PPAPC`;

CREATE TABLE `PPAPC` (
  `PPAP` INTEGER, 
  `DATA` DATETIME, 
  `PREVISTO` DATETIME, 
  `EFETUADO` DATETIME, 
  `OBS` LONGTEXT, 
  `DISPO` VARCHAR(1), 
  `CODIGO` VARCHAR(50), 
  `item` INTEGER AUTO_INCREMENT, 
  INDEX (`PPAP`), 
  INDEX (`item`)
) ENGINE=innodb;

#
# Table structure for table 'PPAPI'
#

DROP TABLE IF EXISTS `PPAPI`;

CREATE TABLE `PPAPI` (
  `DATA` DATETIME, 
  `OBS` LONGTEXT, 
  `PPAP` INTEGER, 
  `DISPO` VARCHAR(1), 
  `ITEM` DOUBLE NULL, 
  `PRAZO` DATETIME, 
  `APROVADO` DATETIME, 
  `dispnome` VARCHAR(40), 
  `dispdate` DATETIME, 
  `dispnum` INTEGER, 
  INDEX (`PPAP`)
) ENGINE=innodb;

#
# Table structure for table 'PPAPP'
#

DROP TABLE IF EXISTS `PPAPP`;

CREATE TABLE `PPAPP` (
  `PPAP` INTEGER, 
  `CODIGO` VARCHAR(50), 
  `PF` INTEGER, 
  INDEX (`PPAP`)
) ENGINE=innodb;

