#
# DUMP FILE
#
# Database is ported from MS Access
#------------------------------------------------------------------
# Created using "MS Access to MySQL" form http://www.bullzip.com
# Program Version 5.5.282
#
# OPTIONS:
#   sourcefilename=C:/temp/poa.mdb
#   sourceusername=
#   sourcepassword=
#   sourcesystemdatabase=
#   destinationdatabase=poa
#   storageengine=InnoDB
#   dropdatabase=0
#   createtables=1
#   unicode=0
#   autocommit=1
#   transferdefaultvalues=1
#   transferindexes=1
#   transferautonumbers=1
#   transferrecords=0
#   columnlist=1
#   tableprefix=
#   negativeboolean=0
#   ignorelargeblobs=0
#   memotype=LONGTEXT
#   datetimetype=DATETIME
#

CREATE DATABASE IF NOT EXISTS `poa`;
USE `poa`;

#
# Table structure for table 'DISPO'
#

DROP TABLE IF EXISTS `DISPO`;

CREATE TABLE `DISPO` (
  `NUMERO` INTEGER, 
  `pf` DOUBLE NULL, 
  `seq` DOUBLE NULL, 
  `ssq` DOUBLE NULL, 
  `RESDAT` DATETIME, 
  `RESNUM` INTEGER, 
  `RESNOM` VARCHAR(60), 
  `ELANOM` VARCHAR(60), 
  `ELADAT` DATETIME, 
  `ELANUM` INTEGER, 
  `CODIGO` VARCHAR(24), 
  `CODIGOINT` VARCHAR(24), 
  `NOME` VARCHAR(50), 
  `revisao` INTEGER, 
  `datarev` DATETIME, 
  `item` INTEGER, 
  INDEX (`NUMERO`), 
  INDEX (`pf`, `seq`, `ssq`)
) ENGINE=innodb;

#
# Table structure for table 'DISPOI'
#

DROP TABLE IF EXISTS `DISPOI`;

CREATE TABLE `DISPOI` (
  `NUMERO` INTEGER, 
  `ITEM` DOUBLE NULL, 
  `DESCRICAO` VARCHAR(255), 
  `imagem` LONGBLOB, 
  INDEX (`NUMERO`, `ITEM`)
) ENGINE=innodb;

#
# Table structure for table 'POA'
#

DROP TABLE IF EXISTS `POA`;

CREATE TABLE `POA` (
  `NUMERO` INTEGER, 
  `CODIGO` VARCHAR(24), 
  `NOME` VARCHAR(50), 
  `PROBLEMA` LONGTEXT, 
  `NUMFUN` INTEGER, 
  `NOMFUN` VARCHAR(50), 
  `ANALISE` LONGTEXT, 
  `SAC` INTEGER, 
  `DATASAC` DATETIME, 
  `FOTO` LONGBLOB, 
  `SACSN` VARCHAR(1), 
  `pf` DOUBLE NULL, 
  `seq` DOUBLE NULL, 
  `ssq` DOUBLE NULL, 
  `RESDAT` DATETIME, 
  `RESNUM` INTEGER, 
  `RESNOM` VARCHAR(60), 
  `ELANOM` VARCHAR(60), 
  `ELADAT` DATETIME, 
  `ELANUM` INTEGER, 
  `item` INTEGER, 
  INDEX (`CODIGO`), 
  INDEX (`NUMERO`), 
  INDEX (`pf`, `seq`, `ssq`)
) ENGINE=innodb;

#
# Table structure for table 'POKA'
#

DROP TABLE IF EXISTS `POKA`;

CREATE TABLE `POKA` (
  `NUMERO` INTEGER, 
  `PASSO01` LONGTEXT, 
  `PASSO02` LONGTEXT, 
  `PASSO03` LONGTEXT, 
  `PASSO04` LONGTEXT, 
  `OBSPASSO01` LONGTEXT, 
  `OBSPASSO02` LONGTEXT, 
  `OBSPASSO03` LONGTEXT, 
  `OBSPASSO04` LONGTEXT, 
  `5SOQUE` VARCHAR(255), 
  `5SCOMO` VARCHAR(255), 
  `5SPORQUE` VARCHAR(255), 
  `5SONDE` VARCHAR(255), 
  `FOTOPASSO01` LONGBLOB, 
  `FOTOPASSO02` LONGBLOB, 
  `FOTOPASSO03` LONGBLOB, 
  `FOTOPASSO04` LONGBLOB, 
  `pf` DOUBLE NULL, 
  `seq` DOUBLE NULL, 
  `ssq` DOUBLE NULL, 
  `RESDAT` DATETIME, 
  `RESNUM` INTEGER, 
  `RESNOM` VARCHAR(60), 
  `ELANOM` VARCHAR(60), 
  `ELADAT` DATETIME, 
  `ELANUM` INTEGER, 
  `CODIGO` VARCHAR(24), 
  `NOME` VARCHAR(50), 
  `5SOQUEm` VARCHAR(255), 
  `revisao` INTEGER, 
  `datarev` DATETIME, 
  `item` INTEGER, 
  INDEX (`NUMERO`), 
  INDEX (`pf`, `seq`, `ssq`)
) ENGINE=innodb;

