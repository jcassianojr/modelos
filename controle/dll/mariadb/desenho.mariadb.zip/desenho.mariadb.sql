#
# DUMP FILE
#
# Database is ported from MS Access
#------------------------------------------------------------------
# Created using "MS Access to MySQL" form http://www.bullzip.com
# Program Version 5.5.282
#
# OPTIONS:
#   sourcefilename=C:/temp/desenho.mdb
#   sourceusername=
#   sourcepassword=
#   sourcesystemdatabase=
#   destinationdatabase=desenho
#   storageengine=InnoDB
#   dropdatabase=0
#   createtables=1
#   unicode=0
#   autocommit=1
#   transferdefaultvalues=1
#   transferindexes=1
#   transferautonumbers=1
#   transferrecords=0
#   columnlist=1
#   tableprefix=
#   negativeboolean=0
#   ignorelargeblobs=0
#   memotype=LONGTEXT
#   datetimetype=DATETIME
#

CREATE DATABASE IF NOT EXISTS `desenho`;
USE `desenho`;

#
# Table structure for table 'atual'
#

DROP TABLE IF EXISTS `atual`;

CREATE TABLE `atual` (
  `conjunto` VARCHAR(50), 
  `desenho` VARCHAR(50), 
  `descricao` VARCHAR(200), 
  `rev` INTEGER, 
  `data` DATETIME, 
  `recebido` DATETIME, 
  `obs` LONGTEXT, 
  `padronizado` TINYINT(1), 
  `fitadat` INTEGER, 
  `cdrom` INTEGER, 
  `revc` VARCHAR(2), 
  INDEX (`conjunto`), 
  INDEX (`conjunto`, `desenho`)
) ENGINE=innodb;

#
# Table structure for table 'baixado'
#

DROP TABLE IF EXISTS `baixado`;

CREATE TABLE `baixado` (
  `conjunto` VARCHAR(50), 
  `desenho` VARCHAR(50), 
  `descricao` VARCHAR(200), 
  `rev` INTEGER, 
  `data` DATETIME, 
  `recebido` DATETIME, 
  `obs` LONGTEXT, 
  `padronizado` TINYINT(1), 
  `fitadat` INTEGER, 
  `cdrom` INTEGER, 
  `revc` VARCHAR(2), 
  INDEX (`conjunto`), 
  INDEX (`conjunto`, `desenho`)
) ENGINE=innodb;

#
# Table structure for table 'CLIENTE'
#

DROP TABLE IF EXISTS `CLIENTE`;

CREATE TABLE `CLIENTE` (
  `CLIENTE` INTEGER, 
  `CLINOME` VARCHAR(50), 
  INDEX (`CLIENTE`)
) ENGINE=innodb;

#
# Table structure for table 'conjunto'
#

DROP TABLE IF EXISTS `conjunto`;

CREATE TABLE `conjunto` (
  `conjunto` VARCHAR(50), 
  `cliente` INTEGER, 
  `clinome` VARCHAR(50), 
  `descricao` VARCHAR(200), 
  INDEX (`conjunto`)
) ENGINE=innodb;

#
# Table structure for table 'PRODENG'
#

DROP TABLE IF EXISTS `PRODENG`;

CREATE TABLE `PRODENG` (
  `TIPO` VARCHAR(1), 
  `NUMERO` INTEGER, 
  `PRODUTO` VARCHAR(50), 
  `NOME` VARCHAR(200), 
  `DATA` DATETIME, 
  `REVISAO` VARCHAR(10), 
  `RESCLI` VARCHAR(15), 
  INDEX (`PRODUTO`), 
  INDEX (`TIPO`, `NUMERO`)
) ENGINE=innodb;

#
# Table structure for table 'PRODUTO'
#

DROP TABLE IF EXISTS `PRODUTO`;

CREATE TABLE `PRODUTO` (
  `CLIENTE` INTEGER, 
  `NUMERO` INTEGER, 
  `CODIGO` VARCHAR(50), 
  `NOME` VARCHAR(50), 
  `INATIVO` TINYINT(1), 
  `ITEM` INTEGER, 
  INDEX (`CLIENTE`)
) ENGINE=innodb;

#
# Table structure for table 'PROTO'
#

DROP TABLE IF EXISTS `PROTO`;

CREATE TABLE `PROTO` (
  `CLIENTE` INTEGER, 
  `CLINOME` VARCHAR(50), 
  `PARTNUMBER` VARCHAR(50), 
  `PROJETO` VARCHAR(50), 
  `NOME` VARCHAR(50), 
  `COTACAO` TINYINT(1), 
  `ENGENHEIRO` VARCHAR(50), 
  `COTDATA` DATETIME, 
  `COTVAL` DOUBLE NULL, 
  `ENGRAMAL` VARCHAR(50), 
  INDEX (`PARTNUMBER`)
) ENGINE=innodb;

#
# Table structure for table 'PROTOI'
#

DROP TABLE IF EXISTS `PROTOI`;

CREATE TABLE `PROTOI` (
  `PARTNUMBER` VARCHAR(50), 
  `PEDDATA` DATETIME, 
  `PEDIDO` VARCHAR(50), 
  `PEDENTR` DATETIME, 
  `QTDDE` INTEGER, 
  `VALOR` DOUBLE NULL, 
  `SSMT` VARCHAR(50), 
  `SSMTDAT` DATETIME, 
  `FASE` VARCHAR(50), 
  `DESENHO` VARCHAR(50), 
  `SSMTREQ` DATETIME, 
  `COMPRADOR` VARCHAR(50), 
  `GP11` TINYINT(1), 
  `GP11DAPR` DATETIME, 
  `TELEFONE` VARCHAR(50), 
  `GP11DFIN` VARCHAR(50), 
  `NFNUMERO` VARCHAR(50), 
  `ENTRDATA` DATETIME, 
  `NFTIPO` VARCHAR(1), 
  `ENTREGA` VARCHAR(50), 
  `NFDATA` DATETIME, 
  `OBS` LONGTEXT, 
  `DESENH2` VARCHAR(50), 
  `PPAP` INTEGER, 
  `DESENH3` VARCHAR(50), 
  `REV` VARCHAR(50), 
  `RE2` VARCHAR(50), 
  `RE3` VARCHAR(50), 
  INDEX (`PARTNUMBER`)
) ENGINE=innodb;

