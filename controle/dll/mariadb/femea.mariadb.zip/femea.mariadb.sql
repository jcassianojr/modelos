#
# DUMP FILE
#
# Database is ported from MS Access
#------------------------------------------------------------------
# Created using "MS Access to MySQL" form http://www.bullzip.com
# Program Version 5.5.282
#
# OPTIONS:
#   sourcefilename=C:/temp/femea.mdb
#   sourceusername=
#   sourcepassword=
#   sourcesystemdatabase=
#   destinationdatabase=femea
#   storageengine=InnoDB
#   dropdatabase=0
#   createtables=1
#   unicode=0
#   autocommit=1
#   transferdefaultvalues=1
#   transferindexes=1
#   transferautonumbers=1
#   transferrecords=0
#   columnlist=1
#   tableprefix=
#   negativeboolean=0
#   ignorelargeblobs=0
#   memotype=LONGTEXT
#   datetimetype=DATETIME
#

CREATE DATABASE IF NOT EXISTS `femea`;
USE `femea`;

#
# Table structure for table 'FEMADC'
#

DROP TABLE IF EXISTS `FEMADC`;

CREATE TABLE `FEMADC` (
  `FALTIP` LONGTEXT, 
  `FALEFE` LONGTEXT, 
  `FALCAU` LONGTEXT, 
  `CRTATU` LONGTEXT, 
  `INDOCO` DOUBLE NULL, 
  `INDSEV` DOUBLE NULL, 
  `INDDET` DOUBLE NULL, 
  `INDRIS` DOUBLE NULL, 
  `TITULO` VARCHAR(50), 
  `SEGGRA` INTEGER, 
  `CARAPREV` LONGTEXT, 
  `ACAREC` LONGTEXT, 
  `ACATOM` LONGTEXT, 
  `RINDSER` DOUBLE NULL, 
  `RINDOCO` DOUBLE NULL, 
  `RINDDET` DOUBLE NULL, 
  `RINDRIS` DOUBLE NULL, 
  `CRATU` LONGTEXT, 
  `SITUACAO` VARCHAR(1), 
  `ACAO` TINYINT(1), 
  `ACADAT` DATETIME, 
  `SIGI` VARCHAR(1), 
  `RESCOD` INTEGER, 
  `RESCOD3` INTEGER, 
  `RESNOM` VARCHAR(40), 
  `RESNOM2` VARCHAR(40), 
  `RESNOM3` VARCHAR(40), 
  `RESDAT` DATETIME, 
  `RESDAT2` DATETIME, 
  `RESDAT3` DATETIME, 
  `RESCOD2` INTEGER, 
  `PRONUM` INTEGER, 
  `FALNUM` INTEGER, 
  `EFENUM` INTEGER, 
  `CAUNUM` INTEGER, 
  `PROCESSO` VARCHAR(255), 
  `ITEM` INTEGER, 
  `EXCRPN` TINYINT(1), 
  `ALTMAN` TINYINT(1), 
  `MUDPAD` TINYINT(1), 
  `PF` DOUBLE NULL, 
  `PSA` VARCHAR(20), 
  `FXSEQ` INTEGER, 
  `FXSSQ` INTEGER, 
  `FXITEM` INTEGER, 
  `BLOQUEADO` TINYINT(1), 
  `TIPOAPU` VARCHAR(1), 
  `SIG2` VARCHAR(1), 
  `SIG3` VARCHAR(1), 
  `subtipo` VARCHAR(1), 
  `fxitems` INTEGER, 
  `FEMEAREV` DOUBLE NULL, 
  `elemento` VARCHAR(200), 
  `estacao` VARCHAR(200), 
  `trabalho` VARCHAR(200), 
  `funcaoitem` VARCHAR(200), 
  `funcaoetapa` VARCHAR(200), 
  `funcaoelemento` VARCHAR(200), 
  `pafemea` VARCHAR(1), 
  `caraespecial` VARCHAR(1), 
  `filtroespecial` VARCHAR(1), 
  `acaoprev` VARCHAR(200), 
  `acaodet` VARCHAR(200), 
  `rpafemea` VARCHAR(1), 
  `observacao` VARCHAR(200), 
  INDEX (`PF`)
) ENGINE=innodb;

#
# Table structure for table 'FEMAVU'
#

DROP TABLE IF EXISTS `FEMAVU`;

CREATE TABLE `FEMAVU` (
  `FALTIP` LONGTEXT, 
  `FALEFE` LONGTEXT, 
  `FALCAU` LONGTEXT, 
  `CRTATU` LONGTEXT, 
  `INDOCO` DOUBLE NULL, 
  `INDSEV` DOUBLE NULL, 
  `INDDET` DOUBLE NULL, 
  `INDRIS` DOUBLE NULL, 
  `TITULO` VARCHAR(50), 
  `SEGGRA` INTEGER, 
  `CARAPREV` LONGTEXT, 
  `ACAREC` LONGTEXT, 
  `ACATOM` LONGTEXT, 
  `RINDSER` DOUBLE NULL, 
  `RINDOCO` DOUBLE NULL, 
  `RINDDET` DOUBLE NULL, 
  `RINDRIS` DOUBLE NULL, 
  `CRATU` LONGTEXT, 
  `SITUACAO` VARCHAR(1), 
  `ACAO` TINYINT(1), 
  `ACADAT` DATETIME, 
  `SIGI` VARCHAR(1), 
  `RESCOD` INTEGER, 
  `RESCOD3` INTEGER, 
  `RESNOM` VARCHAR(40), 
  `RESNOM2` VARCHAR(40), 
  `RESNOM3` VARCHAR(40), 
  `RESDAT` DATETIME, 
  `RESDAT2` DATETIME, 
  `RESDAT3` DATETIME, 
  `RESCOD2` INTEGER, 
  `PRONUM` INTEGER, 
  `FALNUM` INTEGER, 
  `EFENUM` INTEGER, 
  `CAUNUM` INTEGER, 
  `PROCESSO` VARCHAR(255), 
  `ITEM` INTEGER, 
  `EXCRPN` TINYINT(1), 
  `ALTMAN` TINYINT(1), 
  `MUDPAD` TINYINT(1), 
  `PF` DOUBLE NULL, 
  `PSA` VARCHAR(20), 
  `FXSEQ` INTEGER, 
  `FXSSQ` INTEGER, 
  `FXITEM` INTEGER, 
  `BLOQUEADO` TINYINT(1), 
  `TIPOAPU` VARCHAR(1), 
  `SIG2` VARCHAR(1), 
  `SIG3` VARCHAR(1), 
  `subtipo` VARCHAR(1), 
  `fxitems` INTEGER, 
  `FEMEAREV` DOUBLE NULL, 
  `elemento` VARCHAR(200), 
  `estacao` VARCHAR(200), 
  `trabalho` VARCHAR(200), 
  `funcaoitem` VARCHAR(200), 
  `funcaoetapa` VARCHAR(200), 
  `funcaoelemento` VARCHAR(200), 
  `pafemea` VARCHAR(1), 
  `caraespecial` VARCHAR(1), 
  `filtroespecial` VARCHAR(1), 
  `acaoprev` VARCHAR(200), 
  `acaodet` VARCHAR(200), 
  `rpafemea` VARCHAR(1), 
  `observacao` VARCHAR(200), 
  INDEX (`PRONUM`, `FALNUM`, `EFENUM`, `CAUNUM`), 
  INDEX (`PF`), 
  INDEX (`PRONUM`)
) ENGINE=innodb;

#
# Table structure for table 'FEMCAU'
#

DROP TABLE IF EXISTS `FEMCAU`;

CREATE TABLE `FEMCAU` (
  `FALTIP` LONGTEXT, 
  `FALEFE` LONGTEXT, 
  `FALCAU` LONGTEXT, 
  `CRTATU` LONGTEXT, 
  `INDOCO` DOUBLE NULL, 
  `INDSEV` DOUBLE NULL, 
  `INDDET` DOUBLE NULL, 
  `INDRIS` DOUBLE NULL, 
  `TITULO` VARCHAR(50), 
  `SEGGRA` INTEGER AUTO_INCREMENT, 
  `CARAPREV` LONGTEXT, 
  `ACAREC` LONGTEXT, 
  `ACATOM` LONGTEXT, 
  `RINDSER` DOUBLE NULL, 
  `RINDOCO` DOUBLE NULL, 
  `RINDDET` DOUBLE NULL, 
  `RINDRIS` DOUBLE NULL, 
  `CRATU` LONGTEXT, 
  `SITUACAO` VARCHAR(1), 
  `ACAO` TINYINT(1), 
  `ACADAT` DATETIME, 
  `SIGI` VARCHAR(1), 
  `RESCOD` INTEGER, 
  `RESCOD3` INTEGER, 
  `RESNOM` VARCHAR(40), 
  `RESNOM2` VARCHAR(40), 
  `RESNOM3` VARCHAR(40), 
  `RESDAT` DATETIME, 
  `RESDAT2` DATETIME, 
  `RESDAT3` DATETIME, 
  `RESCOD2` INTEGER, 
  `PRONUM` INTEGER, 
  `FALNUM` INTEGER, 
  `EFENUM` INTEGER, 
  `CAUNUM` INTEGER, 
  `PROCESSO` VARCHAR(255), 
  `EXCRPN` TINYINT(1), 
  `ITEM` INTEGER, 
  `ALTMAN` TINYINT(1), 
  `MUDPAD` TINYINT(1), 
  `PF` DOUBLE NULL, 
  `PSA` VARCHAR(20), 
  `FXSEQ` INTEGER, 
  `FXSSQ` INTEGER, 
  `FXITEM` INTEGER, 
  `BLOQUEADO` TINYINT(1), 
  `TIPOAPU` VARCHAR(1), 
  `SIG2` VARCHAR(1), 
  `SIG3` VARCHAR(1), 
  `subtipo` VARCHAR(1), 
  `fxitems` INTEGER, 
  `FEMEAREV` DOUBLE NULL, 
  `elemento` VARCHAR(200), 
  `estacao` VARCHAR(200), 
  `trabalho` VARCHAR(200), 
  `funcaoitem` VARCHAR(200), 
  `funcaoetapa` VARCHAR(200), 
  `funcaoelemento` VARCHAR(200), 
  `pafemea` VARCHAR(1), 
  `caraespecial` VARCHAR(1), 
  `filtroespecial` VARCHAR(1), 
  `acaoprev` VARCHAR(200), 
  `acaodet` VARCHAR(200), 
  `rpafemea` VARCHAR(1), 
  `observacao` VARCHAR(200), 
  INDEX (`PRONUM`, `FALNUM`, `EFENUM`, `CAUNUM`), 
  INDEX (`PRONUM`), 
  INDEX (`SEGGRA`)
) ENGINE=innodb;

#
# Table structure for table 'FEMCAUREV'
#

DROP TABLE IF EXISTS `FEMCAUREV`;

CREATE TABLE `FEMCAUREV` (
  `FALTIP` LONGTEXT, 
  `FALEFE` LONGTEXT, 
  `FALCAU` LONGTEXT, 
  `CRTATU` LONGTEXT, 
  `INDOCO` DOUBLE NULL, 
  `INDSEV` DOUBLE NULL, 
  `INDDET` DOUBLE NULL, 
  `INDRIS` DOUBLE NULL, 
  `TITULO` VARCHAR(50), 
  `SEGGRA` INTEGER, 
  `CARAPREV` LONGTEXT, 
  `ACAREC` LONGTEXT, 
  `ACATOM` LONGTEXT, 
  `RINDSER` DOUBLE NULL, 
  `RINDOCO` DOUBLE NULL, 
  `RINDDET` DOUBLE NULL, 
  `RINDRIS` DOUBLE NULL, 
  `CRATU` LONGTEXT, 
  `SITUACAO` VARCHAR(1), 
  `ACAO` TINYINT(1), 
  `ACADAT` DATETIME, 
  `SIGI` VARCHAR(1), 
  `RESCOD` INTEGER, 
  `RESCOD3` INTEGER, 
  `RESNOM` VARCHAR(40), 
  `RESNOM2` VARCHAR(40), 
  `RESNOM3` VARCHAR(40), 
  `RESDAT` DATETIME, 
  `RESDAT2` DATETIME, 
  `RESDAT3` DATETIME, 
  `RESCOD2` INTEGER, 
  `PRONUM` INTEGER, 
  `FALNUM` INTEGER, 
  `EFENUM` INTEGER, 
  `CAUNUM` INTEGER, 
  `PROCESSO` VARCHAR(255), 
  `ITEM` INTEGER, 
  `EXCRPN` TINYINT(1), 
  `ALTMAN` TINYINT(1), 
  `MUDPAD` TINYINT(1), 
  `PF` DOUBLE NULL, 
  `PSA` VARCHAR(20), 
  `FXSEQ` INTEGER, 
  `FXSSQ` INTEGER, 
  `FXITEM` INTEGER, 
  `SIG2` VARCHAR(1), 
  `SIG3` VARCHAR(1), 
  `subtipo` VARCHAR(1), 
  `FEMEAREV` DOUBLE NULL, 
  `estacao` VARCHAR(200), 
  `trabalho` VARCHAR(200), 
  `funcaoitem` VARCHAR(200), 
  `funcaoetapa` VARCHAR(200), 
  `funcaoelemento` VARCHAR(200), 
  `pafemea` VARCHAR(1), 
  `caraespecial` VARCHAR(1), 
  `filtroespecial` VARCHAR(1), 
  `acaoprev` VARCHAR(200), 
  `acaodet` VARCHAR(200), 
  `rpafemea` VARCHAR(1), 
  `observacao` VARCHAR(200), 
  `elemento` VARCHAR(200), 
  INDEX (`PRONUM`, `FALNUM`, `EFENUM`, `CAUNUM`), 
  INDEX (`PF`), 
  INDEX (`PRONUM`)
) ENGINE=innodb;

#
# Table structure for table 'FEMEA'
#

DROP TABLE IF EXISTS `FEMEA`;

CREATE TABLE `FEMEA` (
  `FALTIP` LONGTEXT, 
  `FALEFE` LONGTEXT, 
  `FALCAU` LONGTEXT, 
  `CRTATU` LONGTEXT, 
  `INDOCO` DOUBLE NULL, 
  `INDSEV` DOUBLE NULL, 
  `INDDET` DOUBLE NULL, 
  `INDRIS` DOUBLE NULL, 
  `TITULO` VARCHAR(50), 
  `SEGGRA` INTEGER, 
  `CARAPREV` LONGTEXT, 
  `ACAREC` LONGTEXT, 
  `ACATOM` LONGTEXT, 
  `RINDSER` DOUBLE NULL, 
  `RINDOCO` DOUBLE NULL, 
  `RINDDET` DOUBLE NULL, 
  `RINDRIS` DOUBLE NULL, 
  `CRATU` LONGTEXT, 
  `SITUACAO` VARCHAR(1), 
  `ACAO` TINYINT(1), 
  `ACADAT` DATETIME, 
  `SIGI` VARCHAR(1), 
  `RESCOD` INTEGER, 
  `RESCOD3` INTEGER, 
  `RESNOM` VARCHAR(40), 
  `RESNOM2` VARCHAR(40), 
  `RESNOM3` VARCHAR(40), 
  `RESDAT` DATETIME, 
  `RESDAT2` DATETIME, 
  `RESDAT3` DATETIME, 
  `RESCOD2` INTEGER, 
  `PRONUM` INTEGER, 
  `FALNUM` INTEGER, 
  `EFENUM` INTEGER, 
  `CAUNUM` INTEGER, 
  `PROCESSO` LONGTEXT, 
  `ITEM` INTEGER, 
  `EXCRPN` TINYINT(1), 
  `ALTMAN` TINYINT(1), 
  `MUDPAD` TINYINT(1), 
  `PF` DOUBLE NULL, 
  `PSA` VARCHAR(10), 
  `FXITEM` INTEGER, 
  `FXSEQ` INTEGER, 
  `FXSSQ` INTEGER, 
  `BLOQUEADO` TINYINT(1), 
  `TIPOAPU` VARCHAR(1), 
  `SIG2` VARCHAR(1), 
  `SIG3` VARCHAR(1), 
  `subtipo` VARCHAR(1), 
  `fxitems` INTEGER, 
  `FEMEAREV` DOUBLE NULL, 
  `elemento` VARCHAR(200), 
  `estacao` VARCHAR(200), 
  `trabalho` VARCHAR(200), 
  `funcaoitem` VARCHAR(200), 
  `funcaoetapa` VARCHAR(200), 
  `funcaoelemento` VARCHAR(200), 
  `pafemea` VARCHAR(1), 
  `caraespecial` VARCHAR(1), 
  `filtroespecial` VARCHAR(1), 
  `acaoprev` VARCHAR(200), 
  `acaodet` VARCHAR(200), 
  `rpafemea` VARCHAR(1), 
  `observacao` VARCHAR(200), 
  INDEX (`PRONUM`, `FALNUM`, `EFENUM`, `CAUNUM`), 
  INDEX (`PRONUM`, `FALNUM`, `EFENUM`, `CAUNUM`, `PF`), 
  INDEX (`INDRIS`), 
  INDEX (`ITEM`), 
  INDEX (`PF`), 
  INDEX (`PF`, `ITEM`), 
  INDEX (`PRONUM`)
) ENGINE=innodb;

#
# Table structure for table 'FEMEAPAD'
#

DROP TABLE IF EXISTS `FEMEAPAD`;

CREATE TABLE `FEMEAPAD` (
  `FALTIP` LONGTEXT, 
  `FALEFE` LONGTEXT, 
  `FALCAU` LONGTEXT, 
  `CRTATU` LONGTEXT, 
  `INDOCO` DOUBLE NULL, 
  `INDSEV` DOUBLE NULL, 
  `INDDET` DOUBLE NULL, 
  `INDRIS` DOUBLE NULL, 
  `TITULO` VARCHAR(50), 
  `SEGGRA` INTEGER, 
  `CARAPREV` LONGTEXT, 
  `ACAREC` LONGTEXT, 
  `ACATOM` LONGTEXT, 
  `RINDSER` DOUBLE NULL, 
  `RINDOCO` DOUBLE NULL, 
  `RINDDET` DOUBLE NULL, 
  `RINDRIS` DOUBLE NULL, 
  `CRATU` LONGTEXT, 
  `SITUACAO` VARCHAR(1), 
  `ACAO` TINYINT(1), 
  `ACADAT` DATETIME, 
  `SIGI` VARCHAR(1), 
  `RESCOD` INTEGER, 
  `RESCOD3` INTEGER, 
  `RESNOM` VARCHAR(40), 
  `RESNOM2` VARCHAR(40), 
  `RESNOM3` VARCHAR(40), 
  `RESDAT` DATETIME, 
  `RESDAT2` DATETIME, 
  `RESDAT3` DATETIME, 
  `RESCOD2` INTEGER, 
  `PRONUM` INTEGER, 
  `FALNUM` INTEGER, 
  `EFENUM` INTEGER, 
  `CAUNUM` INTEGER, 
  `PROCESSO` LONGTEXT, 
  `ITEM` INTEGER, 
  `EXCRPN` TINYINT(1), 
  `ALTMAN` TINYINT(1), 
  `MUDPAD` TINYINT(1), 
  `PF` DOUBLE NULL, 
  `PSA` VARCHAR(10), 
  `FXITEM` INTEGER, 
  `FXSEQ` INTEGER, 
  `FXSSQ` INTEGER, 
  `BLOQUEADO` TINYINT(1), 
  `TIPOAPU` VARCHAR(1), 
  `SIG2` VARCHAR(1), 
  `SIG3` VARCHAR(1), 
  `subtipo` VARCHAR(1), 
  `fxitems` INTEGER, 
  `FEMEAREV` DOUBLE NULL, 
  `elemento` VARCHAR(200), 
  `estacao` VARCHAR(200), 
  `trabalho` VARCHAR(200), 
  `funcaoitem` VARCHAR(200), 
  `funcaoetapa` VARCHAR(200), 
  `funcaoelemento` VARCHAR(200), 
  `pafemea` VARCHAR(1), 
  `caraespecial` VARCHAR(1), 
  `filtroespecial` VARCHAR(1), 
  `acaoprev` VARCHAR(200), 
  `acaodet` VARCHAR(200), 
  `rpafemea` VARCHAR(1), 
  `observacao` VARCHAR(200), 
  INDEX (`PRONUM`, `FALNUM`, `EFENUM`, `CAUNUM`), 
  INDEX (`PRONUM`, `FALNUM`, `EFENUM`, `CAUNUM`, `PF`), 
  INDEX (`INDRIS`), 
  INDEX (`PF`), 
  INDEX (`PRONUM`)
) ENGINE=innodb;

#
# Table structure for table 'femearpn'
#

DROP TABLE IF EXISTS `femearpn`;

CREATE TABLE `femearpn` (
  `SEQ` INTEGER, 
  `DIAFIM` DATETIME, 
  `DIAINI` DATETIME, 
  `MES` INTEGER, 
  `ANO` INTEGER, 
  `ANUAL` TINYINT(1), 
  `DESCRI` VARCHAR(30), 
  `FX01` DOUBLE NULL, 
  `FX02` DOUBLE NULL, 
  `FX03` DOUBLE NULL, 
  `FX04` DOUBLE NULL, 
  `FX05` DOUBLE NULL, 
  `FX06` DOUBLE NULL, 
  `FX07` DOUBLE NULL, 
  `FX08` DOUBLE NULL, 
  `apurado` TINYINT(1), 
  `apudata` DATETIME, 
  `SEMES` TINYINT(1), 
  INDEX (`SEQ`), 
  INDEX (`SEQ`, `MES`, `ANO`)
) ENGINE=innodb;

#
# Table structure for table 'femearpni'
#

DROP TABLE IF EXISTS `femearpni`;

CREATE TABLE `femearpni` (
  `seq` INTEGER, 
  `ano` INTEGER, 
  `mes` INTEGER, 
  `cliente` INTEGER, 
  `cognome` VARCHAR(12), 
  `grupoemp` VARCHAR(12), 
  `qtdesac` INTEGER, 
  `qtderdp` INTEGER, 
  `qtdetot` INTEGER, 
  `CODIGO` VARCHAR(24), 
  `clinome` VARCHAR(50), 
  INDEX (`seq`)
) ENGINE=innodb;

#
# Table structure for table 'FEMEFE'
#

DROP TABLE IF EXISTS `FEMEFE`;

CREATE TABLE `FEMEFE` (
  `PRONUM` INTEGER, 
  `FALNUM` INTEGER, 
  `EFENUM` INTEGER, 
  `FALEFE` LONGTEXT, 
  INDEX (`EFENUM`), 
  INDEX (`FALNUM`, `EFENUM`), 
  INDEX (`FALNUM`), 
  INDEX (`PRONUM`)
) ENGINE=innodb;

#
# Table structure for table 'FEMFAL'
#

DROP TABLE IF EXISTS `FEMFAL`;

CREATE TABLE `FEMFAL` (
  `PRONUM` INTEGER, 
  `FALNUM` INTEGER, 
  `FALTIP` LONGTEXT, 
  `FALTIPO` LONGTEXT, 
  INDEX (`FALNUM`), 
  INDEX (`PRONUM`)
) ENGINE=innodb;

#
# Table structure for table 'FEMHIS'
#

DROP TABLE IF EXISTS `FEMHIS`;

CREATE TABLE `FEMHIS` (
  `FALTIP` LONGTEXT, 
  `FALEFE` LONGTEXT, 
  `FALCAU` LONGTEXT, 
  `CRTATU` LONGTEXT, 
  `INDOCO` DOUBLE NULL, 
  `INDSEV` DOUBLE NULL, 
  `INDDET` DOUBLE NULL, 
  `INDRIS` DOUBLE NULL, 
  `TITULO` VARCHAR(50), 
  `SEGGRA` INTEGER, 
  `CARAPREV` LONGTEXT, 
  `ACAREC` LONGTEXT, 
  `ACATOM` LONGTEXT, 
  `RINDSER` DOUBLE NULL, 
  `RINDOCO` DOUBLE NULL, 
  `RINDDET` DOUBLE NULL, 
  `RINDRIS` DOUBLE NULL, 
  `CRATU` LONGTEXT, 
  `SITUACAO` VARCHAR(1), 
  `ACAO` TINYINT(1), 
  `ACADAT` DATETIME, 
  `SIGI` VARCHAR(1), 
  `RESCOD` INTEGER, 
  `RESCOD3` INTEGER, 
  `RESNOM` VARCHAR(40), 
  `RESNOM2` VARCHAR(40), 
  `RESNOM3` VARCHAR(40), 
  `RESDAT` DATETIME, 
  `RESDAT2` DATETIME, 
  `RESDAT3` DATETIME, 
  `RESCOD2` INTEGER, 
  `PRONUM` INTEGER, 
  `FALNUM` INTEGER, 
  `EFENUM` INTEGER, 
  `CAUNUM` INTEGER, 
  `PROCESSO` VARCHAR(255), 
  `ITEM` INTEGER, 
  `EXCRPN` TINYINT(1), 
  `ALTMAN` TINYINT(1), 
  `MUDPAD` TINYINT(1), 
  `PF` DOUBLE NULL, 
  `PSA` VARCHAR(20), 
  `FXSEQ` INTEGER, 
  `FXSSQ` INTEGER, 
  `FXITEM` INTEGER, 
  `BLOQUEADO` TINYINT(1), 
  `TIPOAPU` VARCHAR(1), 
  `SIG2` VARCHAR(1), 
  `SIG3` VARCHAR(1), 
  `subtipo` VARCHAR(1), 
  `fxitems` INTEGER, 
  `FEMEAREV` DOUBLE NULL, 
  `elemento` VARCHAR(200), 
  `estacao` VARCHAR(200), 
  `trabalho` VARCHAR(200), 
  `funcaoitem` VARCHAR(200), 
  `funcaoetapa` VARCHAR(200), 
  `funcaoelemento` VARCHAR(200), 
  `pafemea` VARCHAR(1), 
  `caraespecial` VARCHAR(1), 
  `filtroespecial` VARCHAR(1), 
  `acaoprev` VARCHAR(200), 
  `acaodet` VARCHAR(200), 
  `rpafemea` VARCHAR(1), 
  `observacao` VARCHAR(200), 
  INDEX (`PRONUM`, `FALNUM`, `EFENUM`, `CAUNUM`), 
  INDEX (`PF`), 
  INDEX (`PRONUM`)
) ENGINE=innodb;

#
# Table structure for table 'FEMMAQ'
#

DROP TABLE IF EXISTS `FEMMAQ`;

CREATE TABLE `FEMMAQ` (
  `FALTIP` LONGTEXT, 
  `FALEFE` LONGTEXT, 
  `FALCAU` LONGTEXT, 
  `CRTATU` LONGTEXT, 
  `INDOCO` DOUBLE NULL, 
  `INDSEV` DOUBLE NULL, 
  `INDDET` DOUBLE NULL, 
  `INDRIS` DOUBLE NULL, 
  `TITULO` VARCHAR(50), 
  `SEGGRA` INTEGER, 
  `CARAPREV` LONGTEXT, 
  `ACAREC` LONGTEXT, 
  `ACATOM` LONGTEXT, 
  `RINDSER` DOUBLE NULL, 
  `RINDOCO` DOUBLE NULL, 
  `RINDDET` DOUBLE NULL, 
  `RINDRIS` DOUBLE NULL, 
  `CRATU` LONGTEXT, 
  `SITUACAO` VARCHAR(1), 
  `ACAO` TINYINT(1), 
  `ACADAT` DATETIME, 
  `SIGI` VARCHAR(1), 
  `RESCOD` INTEGER, 
  `RESCOD3` INTEGER, 
  `RESNOM` VARCHAR(40), 
  `RESNOM2` VARCHAR(40), 
  `RESNOM3` VARCHAR(40), 
  `RESDAT` DATETIME, 
  `RESDAT2` DATETIME, 
  `RESDAT3` DATETIME, 
  `RESCOD2` INTEGER, 
  `PRONUM` INTEGER, 
  `FALNUM` INTEGER, 
  `EFENUM` INTEGER, 
  `CAUNUM` INTEGER, 
  `PROCESSO` VARCHAR(255), 
  `ITEM` INTEGER, 
  `EXCRPN` TINYINT(1), 
  `ALTMAN` TINYINT(1), 
  `MUDPAD` TINYINT(1), 
  `PF` DOUBLE NULL, 
  `PSA` VARCHAR(20), 
  `FXSEQ` INTEGER, 
  `FXSSQ` INTEGER, 
  `FXITEM` INTEGER, 
  `BLOQUEADO` TINYINT(1), 
  `TIPOAPU` VARCHAR(1), 
  `SIG2` VARCHAR(1), 
  `SIG3` VARCHAR(1), 
  `subtipo` VARCHAR(1), 
  `fxitems` INTEGER, 
  `FEMEAREV` DOUBLE NULL, 
  `elemento` VARCHAR(200), 
  `estacao` VARCHAR(200), 
  `trabalho` VARCHAR(200), 
  `funcaoitem` VARCHAR(200), 
  `funcaoetapa` VARCHAR(200), 
  `funcaoelemento` VARCHAR(200), 
  `pafemea` VARCHAR(1), 
  `caraespecial` VARCHAR(1), 
  `filtroespecial` VARCHAR(1), 
  `acaoprev` VARCHAR(200), 
  `acaodet` VARCHAR(200), 
  `rpafemea` VARCHAR(1), 
  `observacao` VARCHAR(200), 
  INDEX (`PF`)
) ENGINE=innodb;

#
# Table structure for table 'FEMPF'
#

DROP TABLE IF EXISTS `FEMPF`;

CREATE TABLE `FEMPF` (
  `PRONUM` INTEGER, 
  `FALNUM` INTEGER, 
  `PF` INTEGER, 
  INDEX (`PF`, `PRONUM`, `FALNUM`), 
  INDEX (`PF`), 
  INDEX (`PRONUM`, `FALNUM`)
) ENGINE=innodb;

#
# Table structure for table 'FEMPFHIS'
#

DROP TABLE IF EXISTS `FEMPFHIS`;

CREATE TABLE `FEMPFHIS` (
  `PRONUM` INTEGER, 
  `FALNUM` INTEGER, 
  `PF` INTEGER, 
  INDEX (`PF`, `PRONUM`, `FALNUM`), 
  INDEX (`PF`), 
  INDEX (`PRONUM`, `FALNUM`)
) ENGINE=innodb;

#
# Table structure for table 'FEMPRE'
#

DROP TABLE IF EXISTS `FEMPRE`;

CREATE TABLE `FEMPRE` (
  `FALTIP` LONGTEXT, 
  `FALEFE` LONGTEXT, 
  `FALCAU` LONGTEXT, 
  `CRTATU` LONGTEXT, 
  `INDOCO` DOUBLE NULL, 
  `INDSEV` DOUBLE NULL, 
  `INDDET` DOUBLE NULL, 
  `INDRIS` DOUBLE NULL, 
  `TITULO` VARCHAR(50), 
  `SEGGRA` INTEGER AUTO_INCREMENT, 
  `CARAPREV` LONGTEXT, 
  `ACAREC` LONGTEXT, 
  `ACATOM` LONGTEXT, 
  `RINDSER` DOUBLE NULL, 
  `RINDOCO` DOUBLE NULL, 
  `RINDDET` DOUBLE NULL, 
  `RINDRIS` DOUBLE NULL, 
  `SITUACAO` VARCHAR(1), 
  `ACAO` TINYINT(1), 
  `ACADAT` DATETIME, 
  `SIGI` VARCHAR(1), 
  `RESCOD` INTEGER, 
  `RESCOD3` INTEGER, 
  `RESNOM` VARCHAR(40), 
  `RESNOM2` VARCHAR(40), 
  `RESNOM3` VARCHAR(40), 
  `RESDAT` DATETIME, 
  `RESDAT2` DATETIME, 
  `RESDAT3` DATETIME, 
  `RESCOD2` INTEGER, 
  `EXCRPN` TINYINT(1), 
  `PF` DOUBLE NULL, 
  `ITEM` DOUBLE NULL, 
  `PROCESSO` VARCHAR(255), 
  `ALTMAN` TINYINT(1), 
  `MUDPAD` TINYINT(1), 
  `PSA` VARCHAR(20), 
  `FXSEQ` INTEGER, 
  `FXSSQ` INTEGER, 
  `FXITEM` INTEGER, 
  `PRONUM` INTEGER, 
  `EFENUM` INTEGER, 
  `FALNUM` INTEGER, 
  `CAUNUM` INTEGER, 
  `CRATU` LONGTEXT, 
  `bloqueado` TINYINT(1), 
  `tipoapu` VARCHAR(1), 
  `SIG2` VARCHAR(1), 
  `SIG3` VARCHAR(1), 
  `subtipo` VARCHAR(1), 
  `fxitems` INTEGER, 
  `FEMEAREV` DOUBLE NULL, 
  `suptipo` VARCHAR(1), 
  `elemento` VARCHAR(200), 
  `estacao` VARCHAR(200), 
  `trabalho` VARCHAR(200), 
  `funcaoitem` VARCHAR(200), 
  `funcaoetapa` VARCHAR(200), 
  `funcaoelemento` VARCHAR(200), 
  `pafemea` VARCHAR(1), 
  `caraespecial` VARCHAR(1), 
  `filtroespecial` VARCHAR(1), 
  `acaoprev` VARCHAR(200), 
  `acaodet` VARCHAR(200), 
  `rpafemea` VARCHAR(1), 
  `observacao` VARCHAR(200), 
  INDEX (`SEGGRA`), 
  INDEX (`TITULO`)
) ENGINE=innodb;

#
# Table structure for table 'FEMPRO'
#

DROP TABLE IF EXISTS `FEMPRO`;

CREATE TABLE `FEMPRO` (
  `PROCESSO` VARCHAR(255), 
  `PRONUM` INTEGER, 
  INDEX (`PRONUM`)
) ENGINE=innodb;

#
# Table structure for table 'femrevi'
#

DROP TABLE IF EXISTS `femrevi`;

CREATE TABLE `femrevi` (
  `FALTIP` LONGTEXT, 
  `FALEFE` LONGTEXT, 
  `FALCAU` LONGTEXT, 
  `CRTATU` LONGTEXT, 
  `INDOCO` DOUBLE NULL, 
  `INDSEV` DOUBLE NULL, 
  `INDDET` DOUBLE NULL, 
  `INDRIS` DOUBLE NULL, 
  `TITULO` VARCHAR(50), 
  `SEGGRA` INTEGER, 
  `CARAPREV` LONGTEXT, 
  `ACAREC` LONGTEXT, 
  `ACATOM` LONGTEXT, 
  `RINDSER` DOUBLE NULL, 
  `RINDOCO` DOUBLE NULL, 
  `RINDDET` DOUBLE NULL, 
  `RINDRIS` DOUBLE NULL, 
  `CRATU` LONGTEXT, 
  `SITUACAO` VARCHAR(1), 
  `ACAO` TINYINT(1), 
  `ACADAT` DATETIME, 
  `SIGI` VARCHAR(1), 
  `RESCOD` INTEGER, 
  `RESCOD3` INTEGER, 
  `RESNOM` VARCHAR(40), 
  `RESNOM2` VARCHAR(40), 
  `RESNOM3` VARCHAR(40), 
  `RESDAT` DATETIME, 
  `RESDAT2` DATETIME, 
  `RESDAT3` DATETIME, 
  `RESCOD2` INTEGER, 
  `PRONUM` INTEGER, 
  `FALNUM` INTEGER, 
  `EFENUM` INTEGER, 
  `CAUNUM` INTEGER, 
  `PROCESSO` VARCHAR(255), 
  `ITEM` INTEGER, 
  `EXCRPN` TINYINT(1), 
  `ALTMAN` TINYINT(1), 
  `MUDPAD` TINYINT(1), 
  `PF` DOUBLE NULL, 
  `PSA` VARCHAR(20), 
  `FXSEQ` INTEGER, 
  `FXSSQ` INTEGER, 
  `FXITEM` INTEGER, 
  `TIPOAPU` VARCHAR(1), 
  `SIG2` VARCHAR(1), 
  `SIG3` VARCHAR(1), 
  `subtipo` VARCHAR(1), 
  `fxitems` INTEGER, 
  `FEMEAREV` DOUBLE NULL, 
  `elemento` VARCHAR(200), 
  `estacao` VARCHAR(200), 
  `trabalho` VARCHAR(200), 
  `funcaoitem` VARCHAR(200), 
  `funcaoetapa` VARCHAR(200), 
  `funcaoelemento` VARCHAR(200), 
  `pafemea` VARCHAR(1), 
  `caraespecial` VARCHAR(1), 
  `filtroespecial` VARCHAR(1), 
  `acaoprev` VARCHAR(200), 
  `acaodet` VARCHAR(200), 
  `rpafemea` VARCHAR(1), 
  `observacao` VARCHAR(200), 
  INDEX (`PRONUM`, `FALNUM`, `EFENUM`, `CAUNUM`), 
  INDEX (`PRONUM`, `FALNUM`, `EFENUM`, `CAUNUM`, `PF`), 
  INDEX (`PF`), 
  INDEX (`PRONUM`)
) ENGINE=innodb;

#
# Table structure for table 'femrpng'
#

DROP TABLE IF EXISTS `femrpng`;

CREATE TABLE `femrpng` (
  `ANO` INTEGER, 
  `MES` INTEGER, 
  `PF` DOUBLE NULL, 
  `FX01` INTEGER, 
  `FX02` INTEGER, 
  `FX03` INTEGER, 
  `ANODIZ` INTEGER, 
  `MESDIZ` INTEGER, 
  INDEX (`ANO`, `MES`)
) ENGINE=innodb;

#
# Table structure for table 'FEMRPNO'
#

DROP TABLE IF EXISTS `FEMRPNO`;

CREATE TABLE `FEMRPNO` (
  `PF` DOUBLE NULL, 
  `SEQ` INTEGER, 
  `MES` INTEGER, 
  `ANO` INTEGER, 
  `PRONUM` INTEGER, 
  `TOTCAU` INTEGER, 
  `TOTM40` INTEGER, 
  `MAIRPN` INTEGER, 
  `TOTRPN` INTEGER, 
  `TOTRPN01` INTEGER, 
  `TOTRPN02` INTEGER, 
  `TOTRPN03` INTEGER, 
  `TOTFX01` INTEGER, 
  `TOTFX02` INTEGER, 
  `TOTFX03` INTEGER, 
  `TOTFXA1` INTEGER, 
  `TOTFXB1` INTEGER, 
  `TOTFXC1` INTEGER, 
  `TOTFXA2` INTEGER, 
  `TOTFXB2` INTEGER, 
  `TOTFXC2` INTEGER, 
  `TOTFXC3` INTEGER, 
  `TOTFXB3` INTEGER, 
  `TOTFXA3` INTEGER, 
  INDEX (`ANO`, `MES`), 
  INDEX (`PF`), 
  INDEX (`SEQ`)
) ENGINE=innodb;

#
# Table structure for table 'femrpnt'
#

DROP TABLE IF EXISTS `femrpnt`;

CREATE TABLE `femrpnt` (
  `FALTIP` LONGTEXT, 
  `FALEFE` LONGTEXT, 
  `FALCAU` LONGTEXT, 
  `CRTATU` LONGTEXT, 
  `INDOCO` DOUBLE NULL, 
  `INDSEV` DOUBLE NULL, 
  `INDDET` DOUBLE NULL, 
  `INDRIS` DOUBLE NULL, 
  `TITULO` VARCHAR(50), 
  `SEGGRA` INTEGER, 
  `CARAPREV` LONGTEXT, 
  `ACAREC` LONGTEXT, 
  `ACATOM` LONGTEXT, 
  `RINDSER` DOUBLE NULL, 
  `RINDOCO` DOUBLE NULL, 
  `RINDDET` DOUBLE NULL, 
  `RINDRIS` DOUBLE NULL, 
  `CRATU` LONGTEXT, 
  `SITUACAO` VARCHAR(1), 
  `ACAO` TINYINT(1), 
  `ACADAT` DATETIME, 
  `SIGI` VARCHAR(1), 
  `RESCOD` INTEGER, 
  `RESCOD3` INTEGER, 
  `RESNOM` VARCHAR(40), 
  `RESNOM2` VARCHAR(40), 
  `RESNOM3` VARCHAR(40), 
  `RESDAT` DATETIME, 
  `RESDAT2` DATETIME, 
  `RESDAT3` DATETIME, 
  `RESCOD2` INTEGER, 
  `PRONUM` INTEGER, 
  `FALNUM` INTEGER, 
  `EFENUM` INTEGER, 
  `CAUNUM` INTEGER, 
  `PROCESSO` VARCHAR(255), 
  `ITEM` INTEGER, 
  `EXCRPN` TINYINT(1), 
  `ALTMAN` TINYINT(1), 
  `MUDPAD` TINYINT(1), 
  `PF` DOUBLE NULL, 
  `SEQ` INTEGER, 
  `MES` INTEGER, 
  `ANO` INTEGER, 
  `PSA` VARCHAR(20), 
  `FXSEQ` INTEGER, 
  `FXSSQ` INTEGER, 
  `FXITEM` INTEGER, 
  `TIPOAPU` VARCHAR(1), 
  `SIG2` VARCHAR(1), 
  `SIG3` VARCHAR(1), 
  `subtipo` VARCHAR(1), 
  `FEMEAREV` DOUBLE NULL, 
  `elemento` VARCHAR(200), 
  `estacao` VARCHAR(200), 
  `trabalho` VARCHAR(200), 
  `funcaoitem` VARCHAR(200), 
  `funcaoetapa` VARCHAR(200), 
  `funcaoelemento` VARCHAR(200), 
  `pafemea` VARCHAR(1), 
  `caraespecial` VARCHAR(1), 
  `filtroespecial` VARCHAR(1), 
  `acaoprev` VARCHAR(200), 
  `acaodet` VARCHAR(200), 
  `rpafemea` VARCHAR(1), 
  `observacao` VARCHAR(200), 
  INDEX (`SEQ`)
) ENGINE=innodb;

