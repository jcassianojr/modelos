--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 17:24:44 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: IE
CREATE TABLE IF NOT EXISTS [IE] (
	[PF] double DEFAULT 0 PRIMARY KEY, 
	[DETALHE] longtext, 
	[TIPO] longtext, 
	[FECHA] longtext, 
	[NPED] double DEFAULT 0, 
	[IDENT] longtext, 
	[PROTE] longtext, 
	[QML] double DEFAULT 0, 
	[COM] double DEFAULT 0, 
	[LAR] double DEFAULT 0, 
	[ALT] double DEFAULT 0, 
	[UND] double DEFAULT 0, 
	[TOTL] double DEFAULT 0, 
	[TARA] double DEFAULT 0, 
	[BRUTO] double DEFAULT 0, 
	[METODO] longtext, 
	[OBS] longtext, 
	[DATA] datetime, 
	[REVISAO] double DEFAULT 0, 
	[LOCAL] longtext, 
	[CODMR01] varchar(10), 
	[NOMMR01] varchar(100), 
	[DATAREV] datetime, 
	[CODDIR] varchar(50), 
	[CODESQ] varchar(50), 
	[CODIGOINT] varchar(50), 
	[codigocli] varchar(50), 
	[elaborador] varchar(40)
);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
