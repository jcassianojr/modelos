--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 17:24:22 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: atual
CREATE TABLE IF NOT EXISTS [atual] (
	[conjunto] varchar(50), 
	[desenho] varchar(50), 
	[descricao] varchar(200), 
	[rev] int, 
	[data] datetime, 
	[recebido] datetime, 
	[obs] longtext, 
	[padronizado] boolean NOT NULL, 
	[fitadat] int, 
	[cdrom] int, 
	[revc] varchar(2)
);

-- Tabela: baixado
CREATE TABLE IF NOT EXISTS [baixado] (
	[conjunto] varchar(50), 
	[desenho] varchar(50), 
	[descricao] varchar(200), 
	[rev] int, 
	[data] datetime, 
	[recebido] datetime, 
	[obs] longtext, 
	[padronizado] boolean NOT NULL, 
	[fitadat] int, 
	[cdrom] int, 
	[revc] varchar(2)
);

-- Tabela: CLIENTE
CREATE TABLE IF NOT EXISTS [CLIENTE] (
	[CLIENTE] int, 
	[CLINOME] varchar(50)
);

-- Tabela: conjunto
CREATE TABLE IF NOT EXISTS [conjunto] (
	[conjunto] varchar(50), 
	[cliente] int, 
	[clinome] varchar(50), 
	[descricao] varchar(200)
);

-- Tabela: PRODENG
CREATE TABLE IF NOT EXISTS [PRODENG] (
	[TIPO] varchar(1), 
	[NUMERO] int, 
	[PRODUTO] varchar(50), 
	[NOME] varchar(200), 
	[DATA] datetime, 
	[REVISAO] varchar(10), 
	[RESCLI] varchar(15)
);

-- Tabela: PRODUTO
CREATE TABLE IF NOT EXISTS [PRODUTO] (
	[CLIENTE] int, 
	[NUMERO] int, 
	[CODIGO] varchar(50), 
	[NOME] varchar(50), 
	[INATIVO] boolean NOT NULL, 
	[ITEM] int
);

-- Tabela: PROTO
CREATE TABLE IF NOT EXISTS [PROTO] (
	[CLIENTE] int, 
	[CLINOME] varchar(50), 
	[PARTNUMBER] varchar(50), 
	[PROJETO] varchar(50), 
	[NOME] varchar(50), 
	[COTACAO] boolean NOT NULL, 
	[ENGENHEIRO] varchar(50), 
	[COTDATA] datetime, 
	[COTVAL] double, 
	[ENGRAMAL] varchar(50)
);

-- Tabela: PROTOI
CREATE TABLE IF NOT EXISTS [PROTOI] (
	[PARTNUMBER] varchar(50), 
	[PEDDATA] datetime, 
	[PEDIDO] varchar(50), 
	[PEDENTR] datetime, 
	[QTDDE] int, 
	[VALOR] double, 
	[SSMT] varchar(50), 
	[SSMTDAT] datetime, 
	[FASE] varchar(50), 
	[DESENHO] varchar(50), 
	[SSMTREQ] datetime, 
	[COMPRADOR] varchar(50), 
	[GP11] boolean NOT NULL, 
	[GP11DAPR] datetime, 
	[TELEFONE] varchar(50), 
	[GP11DFIN] varchar(50), 
	[NFNUMERO] varchar(50), 
	[ENTRDATA] datetime, 
	[NFTIPO] varchar(1), 
	[ENTREGA] varchar(50), 
	[NFDATA] datetime, 
	[OBS] longtext, 
	[DESENH2] varchar(50), 
	[PPAP] int, 
	[DESENH3] varchar(50), 
	[REV] varchar(50), 
	[RE2] varchar(50), 
	[RE3] varchar(50)
);

-- �ndice: IDXatual_conjunto
CREATE INDEX IF NOT EXISTS [IDXatual_conjunto]
	ON [atual] ([conjunto]);

-- �ndice: IDXatual_conjunto_desenho
CREATE INDEX IF NOT EXISTS [IDXatual_conjunto_desenho]
	ON [atual] ([conjunto], [desenho]);

-- �ndice: IDXbaixado_conjunto
CREATE INDEX IF NOT EXISTS [IDXbaixado_conjunto]
	ON [baixado] ([conjunto]);

-- �ndice: IDXbaixado_conjunto_desenho
CREATE INDEX IF NOT EXISTS [IDXbaixado_conjunto_desenho]
	ON [baixado] ([conjunto], [desenho]);

-- �ndice: IDXCLIENTE_CLIENTE
CREATE INDEX IF NOT EXISTS [IDXCLIENTE_CLIENTE]
	ON [CLIENTE] ([CLIENTE]);

-- �ndice: IDXconjunto_conjunto
CREATE INDEX IF NOT EXISTS [IDXconjunto_conjunto]
	ON [conjunto] ([conjunto]);

-- �ndice: IDXPRODENG_PRODUTO
CREATE INDEX IF NOT EXISTS [IDXPRODENG_PRODUTO]
	ON [PRODENG] ([PRODUTO]);

-- �ndice: IDXPRODENG_TIPO_NUMERO
CREATE INDEX IF NOT EXISTS [IDXPRODENG_TIPO_NUMERO]
	ON [PRODENG] ([TIPO], [NUMERO]);

-- �ndice: IDXPRODUTO_CLIENTE
CREATE INDEX IF NOT EXISTS [IDXPRODUTO_CLIENTE]
	ON [PRODUTO] ([CLIENTE]);

-- �ndice: IDXPROTO_PARTNUMBER
CREATE INDEX IF NOT EXISTS [IDXPROTO_PARTNUMBER]
	ON [PROTO] ([PARTNUMBER]);

-- �ndice: IDXPROTOI_PARTNUMBER
CREATE INDEX IF NOT EXISTS [IDXPROTOI_PARTNUMBER]
	ON [PROTOI] ([PARTNUMBER]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
