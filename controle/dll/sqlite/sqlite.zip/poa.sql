BEGIN TRANSACTION;
CREATE TABLE [DISPO] (
	[NUMERO] int, 
	[pf] double, 
	[seq] double, 
	[ssq] double, 
	[RESDAT] datetime, 
	[RESNUM] int, 
	[RESNOM] varchar(60), 
	[ELANOM] varchar(60), 
	[ELADAT] datetime, 
	[ELANUM] int, 
	[CODIGO] varchar(24), 
	[CODIGOINT] varchar(24), 
	[NOME] varchar(50), 
	[revisao] int, 
	[datarev] datetime, 
	[item] int
);
CREATE INDEX [IDXDISPO_pf_seq_ssq]
	ON [DISPO] ([pf], [seq], [ssq]);
CREATE INDEX [IDXDISPO_NUMERO]
	ON [DISPO] ([NUMERO]);

CREATE TABLE [DISPOI] (
	[NUMERO] int, 
	[ITEM] double, 
	[DESCRICAO] varchar(255)
, [imagem] BLOB);
CREATE INDEX [IDXDISPOI_NUMERO_ITEM]
	ON [DISPOI] ([NUMERO], [ITEM]);

CREATE TABLE [POA] (
	[NUMERO] int, 
	[CODIGO] varchar(24), 
	[NOME] varchar(50), 
	[PROBLEMA] longtext, 
	[NUMFUN] int, 
	[NOMFUN] varchar(50), 
	[ANALISE] longtext, 
	[SAC] int, 
	[DATASAC] datetime, 
	[SACSN] varchar(1), 
	[pf] double, 
	[seq] double, 
	[ssq] double, 
	[RESDAT] datetime, 
	[RESNUM] int, 
	[RESNOM] varchar(60), 
	[ELANOM] varchar(60), 
	[ELADAT] datetime, 
	[ELANUM] int, 
	[item] int
, [FOTO] BLOB);
CREATE INDEX [IDXPOA_pf_seq_ssq]
	ON [POA] ([pf], [seq], [ssq]);
CREATE INDEX [IDXPOA_NUMERO]
	ON [POA] ([NUMERO]);
CREATE INDEX [IDXPOA_CODIGO]
	ON [POA] ([CODIGO]);

CREATE TABLE [POKA] (
	[NUMERO] int, 
	[PASSO01] longtext, 
	[PASSO02] longtext, 
	[PASSO03] longtext, 
	[PASSO04] longtext, 
	[OBSPASSO01] longtext, 
	[OBSPASSO02] longtext, 
	[OBSPASSO03] longtext, 
	[OBSPASSO04] longtext, 
	[5SOQUE] varchar(255), 
	[5SCOMO] varchar(255), 
	[5SPORQUE] varchar(255), 
	[5SONDE] varchar(255), 
	[pf] double, 
	[seq] double, 
	[ssq] double, 
	[RESDAT] datetime, 
	[RESNUM] int, 
	[RESNOM] varchar(60), 
	[ELANOM] varchar(60), 
	[ELADAT] datetime, 
	[ELANUM] int, 
	[CODIGO] varchar(24), 
	[NOME] varchar(50), 
	[5SOQUEm] varchar(255), 
	[revisao] int, 
	[datarev] datetime, 
	[item] int
, [FOTOPASSO02] BLOB, [FOTOPASSO03] BLOB, [FOTOPASSO04] BLOB, [FOTOPASSO01] BLOB);
CREATE INDEX [IDXPOKA_pf_seq_ssq]
	ON [POKA] ([pf], [seq], [ssq]);
CREATE INDEX [IDXPOKA_NUMERO]
	ON [POKA] ([NUMERO]);

COMMIT TRANSACTION;
