BEGIN TRANSACTION;
CREATE TABLE [PPAF] (
	[CLIENTE] int, 
	[CLINOME] varchar(50), 
	[COMPRADOR] varchar(5), 
	[COMNOME] varchar(40), 
	[CODIGO] varchar(24), 
	[NOME] varchar(40), 
	[DATAALT] datetime, 
	[ITEM] boolean NOT NULL, 
	[PESO] double, 
	[OBSADC01] varchar(80), 
	[OBSADC02] varchar(80), 
	[SUB01] boolean NOT NULL, 
	[SUB02] boolean NOT NULL, 
	[SUB03] boolean NOT NULL, 
	[SUB04] boolean NOT NULL, 
	[SUB05] boolean NOT NULL, 
	[SUB06] boolean NOT NULL, 
	[SUB07] boolean NOT NULL, 
	[SUB08] boolean NOT NULL, 
	[SUB09] boolean NOT NULL, 
	[NIVEL] varchar(1), 
	[RES01] boolean NOT NULL, 
	[RES02] boolean NOT NULL, 
	[RES03] boolean NOT NULL, 
	[RES04] boolean NOT NULL, 
	[APLIC] boolean NOT NULL, 
	[SUB10] boolean NOT NULL, 
	[DESENHO] varchar(80), 
	[NOT01] boolean NOT NULL, 
	[NOT02] boolean NOT NULL, 
	[INF01] boolean NOT NULL, 
	[INF02] boolean NOT NULL, 
	[INF03] boolean NOT NULL, 
	[EXPOSTO] varchar(80), 
	[PEDOM] varchar(80), 
	[AUXILIAR] varchar(80), 
	[NIVELALT] varchar(80), 
	[NIVELDAT] datetime, 
	[DIVISAO] varchar(80), 
	[APLICACAO] varchar(80), 
	[DATA] datetime, 
	[MOLDE] varchar(50), 
	[DISPO] varchar(1), 
	[APRO] varchar(1), 
	[RESNOME] varchar(50), 
	[RESCARGO] varchar(50), 
	[EXP01] varchar(150), 
	[EXP02] varchar(150), 
	[TIPCOM] varchar(1), 
	[CODCOM] varchar(24), 
	[NOMCOM] varchar(50), 
	[FORNECEDOR] int, 
	[FORNOM] varchar(50), 
	[PPAP] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[COMPRAS] int, 
	[COMITEM] int, 
	[PRGENT] int, 
	[INATIVO] boolean NOT NULL, 
	[SITUACAO] varchar(1), 
	[PF] int
);
CREATE INDEX [IDXPPAF_PPAP]
	ON [PPAF] ([PPAP]);

CREATE TABLE [PPAFC] (
	[PPAP] int, 
	[DATA] datetime, 
	[PREVISTO] datetime, 
	[EFETUADO] datetime, 
	[OBS] longtext, 
	[DISPO] varchar(1), 
	[CODIGO] varchar(50), 
	[ITEM] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXPPAFC_PPAP]
	ON [PPAFC] ([PPAP]);

CREATE TABLE [PPAFI] (
	[DATA] datetime, 
	[OBS] longtext, 
	[DISPO] varchar(1), 
	[ITEM] double, 
	[PPAP] int, 
	[PRAZO] datetime, 
	[APROVADO] datetime, 
	[dispnome] varchar(40), 
	[dispdate] datetime, 
	[dispnum] int
);
CREATE INDEX [IDXPPAFI_PPAP]
	ON [PPAFI] ([PPAP]);

CREATE TABLE [PPAFP] (
	[PPAP] int, 
	[CODIGO] varchar(50), 
	[PF] int
);
CREATE INDEX [IDXPPAFP_PPAP]
	ON [PPAFP] ([PPAP]);

CREATE TABLE [PPAG] (
	[CLIENTE] int, 
	[CLINOME] varchar(50), 
	[COMPRADOR] varchar(5), 
	[COMNOME] varchar(40), 
	[CODIGO] varchar(24), 
	[NOME] varchar(40), 
	[DATAALT] datetime, 
	[ITEM] boolean NOT NULL, 
	[PESO] double, 
	[OBSADC01] varchar(80), 
	[OBSADC02] varchar(80), 
	[SUB01] boolean NOT NULL, 
	[SUB02] boolean NOT NULL, 
	[SUB03] boolean NOT NULL, 
	[SUB04] boolean NOT NULL, 
	[SUB05] boolean NOT NULL, 
	[SUB06] boolean NOT NULL, 
	[SUB07] boolean NOT NULL, 
	[SUB08] boolean NOT NULL, 
	[SUB09] boolean NOT NULL, 
	[NIVEL] varchar(1), 
	[RES01] boolean NOT NULL, 
	[RES02] boolean NOT NULL, 
	[RES03] boolean NOT NULL, 
	[RES04] boolean NOT NULL, 
	[APLIC] boolean NOT NULL, 
	[SUB10] boolean NOT NULL, 
	[DESENHO] varchar(80), 
	[NOT01] boolean NOT NULL, 
	[NOT02] boolean NOT NULL, 
	[INF01] boolean NOT NULL, 
	[INF02] boolean NOT NULL, 
	[INF03] boolean NOT NULL, 
	[EXPOSTO] varchar(80), 
	[PEDOM] varchar(80), 
	[AUXILIAR] varchar(80), 
	[NIVELALT] varchar(80), 
	[NIVELDAT] datetime, 
	[DIVISAO] varchar(80), 
	[APLICACAO] varchar(80), 
	[DATA] datetime, 
	[MOLDE] varchar(50), 
	[DISPO] varchar(1), 
	[APRO] varchar(1), 
	[RESNOME] varchar(50), 
	[RESCARGO] varchar(50), 
	[EXP01] varchar(150), 
	[EXP02] varchar(150), 
	[TIPCOM] varchar(1), 
	[CODCOM] varchar(24), 
	[NOMCOM] varchar(50), 
	[FORNECEDOR] int, 
	[FORNOM] varchar(50), 
	[COMPRAS] int, 
	[COMITEM] int, 
	[PRGENT] int, 
	[INATIVO] boolean NOT NULL, 
	[SITUACAO] varchar(1), 
	[PF] int, 
	[PPAP] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[SSMT] varchar(50)
);
CREATE INDEX [IDXPPAG_PPAP]
	ON [PPAG] ([PPAP]);

CREATE TABLE [PPAGC] (
	[PPAP] int, 
	[DATA] datetime, 
	[PREVISTO] datetime, 
	[EFETUADO] datetime, 
	[OBS] longtext, 
	[DISPO] varchar(1), 
	[CODIGO] varchar(50), 
	[ITEM] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXPPAGC_PPAP]
	ON [PPAGC] ([PPAP]);

CREATE TABLE [PPAGI] (
	[DATA] datetime, 
	[OBS] longtext, 
	[DISPO] varchar(1), 
	[ITEM] double, 
	[PPAP] int, 
	[PRAZO] datetime, 
	[APROVADO] datetime, 
	[dispnome] varchar(40), 
	[dispdate] datetime, 
	[dispnum] int
);
CREATE INDEX [IDXPPAGI_PPAP]
	ON [PPAGI] ([PPAP]);

CREATE TABLE [PPAGP] (
	[PPAP] int, 
	[CODIGO] varchar(50), 
	[PF] int
);
CREATE INDEX [IDXPPAGP_PPAP]
	ON [PPAGP] ([PPAP]);

CREATE TABLE [PPAP] (
	[CLIENTE] int, 
	[CLINOME] varchar(50), 
	[COMPRADOR] varchar(5), 
	[COMNOME] varchar(40), 
	[CODIGO] varchar(24), 
	[NOME] varchar(40), 
	[DATAALT] datetime, 
	[ITEM] boolean NOT NULL, 
	[PESO] double, 
	[OBSADC01] varchar(80), 
	[OBSADC02] varchar(80), 
	[SUB01] boolean NOT NULL, 
	[SUB02] boolean NOT NULL, 
	[SUB03] boolean NOT NULL, 
	[SUB04] boolean NOT NULL, 
	[SUB05] boolean NOT NULL, 
	[SUB06] boolean NOT NULL, 
	[SUB07] boolean NOT NULL, 
	[SUB08] boolean NOT NULL, 
	[SUB09] boolean NOT NULL, 
	[NIVEL] varchar(1), 
	[RES01] boolean NOT NULL, 
	[RES02] boolean NOT NULL, 
	[RES03] boolean NOT NULL, 
	[RES04] boolean NOT NULL, 
	[APLIC] boolean NOT NULL, 
	[SUB10] boolean NOT NULL, 
	[DESENHO] varchar(80), 
	[NOT01] boolean NOT NULL, 
	[NOT02] boolean NOT NULL, 
	[INF01] boolean NOT NULL, 
	[INF02] boolean NOT NULL, 
	[INF03] boolean NOT NULL, 
	[EXPOSTO] varchar(80), 
	[PEDOM] varchar(80), 
	[AUXILIAR] varchar(80), 
	[NIVELALT] varchar(80), 
	[NIVELDAT] datetime, 
	[DIVISAO] varchar(80), 
	[APLICACAO] varchar(80), 
	[DATA] datetime, 
	[MOLDE] varchar(50), 
	[DISPO] varchar(1), 
	[APRO] varchar(1), 
	[RESNOME] varchar(50), 
	[RESCARGO] varchar(50), 
	[EXP01] varchar(150), 
	[EXP02] varchar(150), 
	[PPAP] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[TIPCOM] varchar(1), 
	[CODCOM] varchar(24), 
	[NOMCOM] varchar(50), 
	[FORNECEDOR] int, 
	[FORNOM] varchar(50), 
	[COMPRAS] int, 
	[COMITEM] int, 
	[PRGENT] int, 
	[INATIVO] boolean NOT NULL, 
	[SITUACOA] varchar(1), 
	[PF] int
);
CREATE INDEX [IDXPPAP_PPAP]
	ON [PPAP] ([PPAP]);

CREATE TABLE [PPAPC] (
	[PPAP] int, 
	[DATA] datetime, 
	[PREVISTO] datetime, 
	[EFETUADO] datetime, 
	[OBS] longtext, 
	[DISPO] varchar(1), 
	[CODIGO] varchar(50), 
	[item] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXPPAPC_PPAP]
	ON [PPAPC] ([PPAP]);

CREATE TABLE [PPAPI] (
	[DATA] datetime, 
	[OBS] longtext, 
	[PPAP] int, 
	[DISPO] varchar(1), 
	[ITEM] double, 
	[PRAZO] datetime, 
	[APROVADO] datetime, 
	[dispnome] varchar(40), 
	[dispdate] datetime, 
	[dispnum] int
);
CREATE INDEX [IDXPPAPI_PPAP]
	ON [PPAPI] ([PPAP]);

CREATE TABLE [PPAPP] (
	[PPAP] int, 
	[CODIGO] varchar(50), 
	[PF] int
);
CREATE INDEX [IDXPPAPP_PPAP]
	ON [PPAPP] ([PPAP]);

COMMIT TRANSACTION;
