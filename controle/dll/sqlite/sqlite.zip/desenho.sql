BEGIN TRANSACTION;
CREATE TABLE [atual] (
	[conjunto] varchar(50), 
	[desenho] varchar(50), 
	[descricao] varchar(200), 
	[rev] int, 
	[data] datetime, 
	[recebido] datetime, 
	[obs] longtext, 
	[padronizado] boolean NOT NULL, 
	[fitadat] int, 
	[cdrom] int, 
	[revc] varchar(2)
);
CREATE INDEX [IDXatual_conjunto]
	ON [atual] ([conjunto]);
CREATE INDEX [IDXatual_conjunto_desenho]
	ON [atual] ([conjunto], [desenho]);

CREATE TABLE [baixado] (
	[conjunto] varchar(50), 
	[desenho] varchar(50), 
	[descricao] varchar(200), 
	[rev] int, 
	[data] datetime, 
	[recebido] datetime, 
	[obs] longtext, 
	[padronizado] boolean NOT NULL, 
	[fitadat] int, 
	[cdrom] int, 
	[revc] varchar(2)
);
CREATE INDEX [IDXbaixado_conjunto]
	ON [baixado] ([conjunto]);
CREATE INDEX [IDXbaixado_conjunto_desenho]
	ON [baixado] ([conjunto], [desenho]);

CREATE TABLE [CLIENTE] (
	[CLIENTE] int, 
	[CLINOME] varchar(50)
);
CREATE INDEX [IDXCLIENTE_CLIENTE]
	ON [CLIENTE] ([CLIENTE]);

CREATE TABLE [conjunto] (
	[conjunto] varchar(50), 
	[cliente] int, 
	[clinome] varchar(50), 
	[descricao] varchar(200)
);
CREATE INDEX [IDXconjunto_conjunto]
	ON [conjunto] ([conjunto]);

CREATE TABLE [PRODENG] (
	[TIPO] varchar(1), 
	[NUMERO] int, 
	[PRODUTO] varchar(50), 
	[NOME] varchar(200), 
	[DATA] datetime, 
	[REVISAO] varchar(10), 
	[RESCLI] varchar(15)
);
CREATE INDEX [IDXPRODENG_TIPO_NUMERO]
	ON [PRODENG] ([TIPO], [NUMERO]);
CREATE INDEX [IDXPRODENG_PRODUTO]
	ON [PRODENG] ([PRODUTO]);

CREATE TABLE [PRODUTO] (
	[CLIENTE] int, 
	[NUMERO] int, 
	[CODIGO] varchar(50), 
	[NOME] varchar(50), 
	[INATIVO] boolean NOT NULL, 
	[ITEM] int
);
CREATE INDEX [IDXPRODUTO_CLIENTE]
	ON [PRODUTO] ([CLIENTE]);

CREATE TABLE [PROTO] (
	[CLIENTE] int, 
	[CLINOME] varchar(50), 
	[PARTNUMBER] varchar(50), 
	[PROJETO] varchar(50), 
	[NOME] varchar(50), 
	[COTACAO] boolean NOT NULL, 
	[ENGENHEIRO] varchar(50), 
	[COTDATA] datetime, 
	[COTVAL] double, 
	[ENGRAMAL] varchar(50)
);
CREATE INDEX [IDXPROTO_PARTNUMBER]
	ON [PROTO] ([PARTNUMBER]);

CREATE TABLE [PROTOI] (
	[PARTNUMBER] varchar(50), 
	[PEDDATA] datetime, 
	[PEDIDO] varchar(50), 
	[PEDENTR] datetime, 
	[QTDDE] int, 
	[VALOR] double, 
	[SSMT] varchar(50), 
	[SSMTDAT] datetime, 
	[FASE] varchar(50), 
	[DESENHO] varchar(50), 
	[SSMTREQ] datetime, 
	[COMPRADOR] varchar(50), 
	[GP11] boolean NOT NULL, 
	[GP11DAPR] datetime, 
	[TELEFONE] varchar(50), 
	[GP11DFIN] varchar(50), 
	[NFNUMERO] varchar(50), 
	[ENTRDATA] datetime, 
	[NFTIPO] varchar(1), 
	[ENTREGA] varchar(50), 
	[NFDATA] datetime, 
	[OBS] longtext, 
	[DESENH2] varchar(50), 
	[PPAP] int, 
	[DESENH3] varchar(50), 
	[REV] varchar(50), 
	[RE2] varchar(50), 
	[RE3] varchar(50)
);
CREATE INDEX [IDXPROTOI_PARTNUMBER]
	ON [PROTOI] ([PARTNUMBER]);

COMMIT TRANSACTION;
