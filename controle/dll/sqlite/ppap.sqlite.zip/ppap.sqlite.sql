--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 17:27:56 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: PPAF
CREATE TABLE IF NOT EXISTS [PPAF] (
	[CLIENTE] int, 
	[CLINOME] varchar(50), 
	[COMPRADOR] varchar(5), 
	[COMNOME] varchar(40), 
	[CODIGO] varchar(24), 
	[NOME] varchar(40), 
	[DATAALT] datetime, 
	[ITEM] boolean NOT NULL, 
	[PESO] double, 
	[OBSADC01] varchar(80), 
	[OBSADC02] varchar(80), 
	[SUB01] boolean NOT NULL, 
	[SUB02] boolean NOT NULL, 
	[SUB03] boolean NOT NULL, 
	[SUB04] boolean NOT NULL, 
	[SUB05] boolean NOT NULL, 
	[SUB06] boolean NOT NULL, 
	[SUB07] boolean NOT NULL, 
	[SUB08] boolean NOT NULL, 
	[SUB09] boolean NOT NULL, 
	[NIVEL] varchar(1), 
	[RES01] boolean NOT NULL, 
	[RES02] boolean NOT NULL, 
	[RES03] boolean NOT NULL, 
	[RES04] boolean NOT NULL, 
	[APLIC] boolean NOT NULL, 
	[SUB10] boolean NOT NULL, 
	[DESENHO] varchar(80), 
	[NOT01] boolean NOT NULL, 
	[NOT02] boolean NOT NULL, 
	[INF01] boolean NOT NULL, 
	[INF02] boolean NOT NULL, 
	[INF03] boolean NOT NULL, 
	[EXPOSTO] varchar(80), 
	[PEDOM] varchar(80), 
	[AUXILIAR] varchar(80), 
	[NIVELALT] varchar(80), 
	[NIVELDAT] datetime, 
	[DIVISAO] varchar(80), 
	[APLICACAO] varchar(80), 
	[DATA] datetime, 
	[MOLDE] varchar(50), 
	[DISPO] varchar(1), 
	[APRO] varchar(1), 
	[RESNOME] varchar(50), 
	[RESCARGO] varchar(50), 
	[EXP01] varchar(150), 
	[EXP02] varchar(150), 
	[TIPCOM] varchar(1), 
	[CODCOM] varchar(24), 
	[NOMCOM] varchar(50), 
	[FORNECEDOR] int, 
	[FORNOM] varchar(50), 
	[PPAP] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[COMPRAS] int, 
	[COMITEM] int, 
	[PRGENT] int, 
	[INATIVO] boolean NOT NULL, 
	[SITUACAO] varchar(1), 
	[PF] int
);

-- Tabela: PPAFC
CREATE TABLE IF NOT EXISTS [PPAFC] (
	[PPAP] int, 
	[DATA] datetime, 
	[PREVISTO] datetime, 
	[EFETUADO] datetime, 
	[OBS] longtext, 
	[DISPO] varchar(1), 
	[CODIGO] varchar(50), 
	[ITEM] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: PPAFI
CREATE TABLE IF NOT EXISTS [PPAFI] (
	[DATA] datetime, 
	[OBS] longtext, 
	[DISPO] varchar(1), 
	[ITEM] double, 
	[PPAP] int, 
	[PRAZO] datetime, 
	[APROVADO] datetime, 
	[dispnome] varchar(40), 
	[dispdate] datetime, 
	[dispnum] int
);

-- Tabela: PPAFP
CREATE TABLE IF NOT EXISTS [PPAFP] (
	[PPAP] int, 
	[CODIGO] varchar(50), 
	[PF] int
);

-- Tabela: PPAG
CREATE TABLE IF NOT EXISTS [PPAG] (
	[CLIENTE] int, 
	[CLINOME] varchar(50), 
	[COMPRADOR] varchar(5), 
	[COMNOME] varchar(40), 
	[CODIGO] varchar(24), 
	[NOME] varchar(40), 
	[DATAALT] datetime, 
	[ITEM] boolean NOT NULL, 
	[PESO] double, 
	[OBSADC01] varchar(80), 
	[OBSADC02] varchar(80), 
	[SUB01] boolean NOT NULL, 
	[SUB02] boolean NOT NULL, 
	[SUB03] boolean NOT NULL, 
	[SUB04] boolean NOT NULL, 
	[SUB05] boolean NOT NULL, 
	[SUB06] boolean NOT NULL, 
	[SUB07] boolean NOT NULL, 
	[SUB08] boolean NOT NULL, 
	[SUB09] boolean NOT NULL, 
	[NIVEL] varchar(1), 
	[RES01] boolean NOT NULL, 
	[RES02] boolean NOT NULL, 
	[RES03] boolean NOT NULL, 
	[RES04] boolean NOT NULL, 
	[APLIC] boolean NOT NULL, 
	[SUB10] boolean NOT NULL, 
	[DESENHO] varchar(80), 
	[NOT01] boolean NOT NULL, 
	[NOT02] boolean NOT NULL, 
	[INF01] boolean NOT NULL, 
	[INF02] boolean NOT NULL, 
	[INF03] boolean NOT NULL, 
	[EXPOSTO] varchar(80), 
	[PEDOM] varchar(80), 
	[AUXILIAR] varchar(80), 
	[NIVELALT] varchar(80), 
	[NIVELDAT] datetime, 
	[DIVISAO] varchar(80), 
	[APLICACAO] varchar(80), 
	[DATA] datetime, 
	[MOLDE] varchar(50), 
	[DISPO] varchar(1), 
	[APRO] varchar(1), 
	[RESNOME] varchar(50), 
	[RESCARGO] varchar(50), 
	[EXP01] varchar(150), 
	[EXP02] varchar(150), 
	[TIPCOM] varchar(1), 
	[CODCOM] varchar(24), 
	[NOMCOM] varchar(50), 
	[FORNECEDOR] int, 
	[FORNOM] varchar(50), 
	[COMPRAS] int, 
	[COMITEM] int, 
	[PRGENT] int, 
	[INATIVO] boolean NOT NULL, 
	[SITUACAO] varchar(1), 
	[PF] int, 
	[PPAP] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[SSMT] varchar(50)
);

-- Tabela: PPAGC
CREATE TABLE IF NOT EXISTS [PPAGC] (
	[PPAP] int, 
	[DATA] datetime, 
	[PREVISTO] datetime, 
	[EFETUADO] datetime, 
	[OBS] longtext, 
	[DISPO] varchar(1), 
	[CODIGO] varchar(50), 
	[ITEM] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: PPAGI
CREATE TABLE IF NOT EXISTS [PPAGI] (
	[DATA] datetime, 
	[OBS] longtext, 
	[DISPO] varchar(1), 
	[ITEM] double, 
	[PPAP] int, 
	[PRAZO] datetime, 
	[APROVADO] datetime, 
	[dispnome] varchar(40), 
	[dispdate] datetime, 
	[dispnum] int
);

-- Tabela: PPAGP
CREATE TABLE IF NOT EXISTS [PPAGP] (
	[PPAP] int, 
	[CODIGO] varchar(50), 
	[PF] int
);

-- Tabela: PPAP
CREATE TABLE IF NOT EXISTS [PPAP] (
	[CLIENTE] int, 
	[CLINOME] varchar(50), 
	[COMPRADOR] varchar(5), 
	[COMNOME] varchar(40), 
	[CODIGO] varchar(24), 
	[NOME] varchar(40), 
	[DATAALT] datetime, 
	[ITEM] boolean NOT NULL, 
	[PESO] double, 
	[OBSADC01] varchar(80), 
	[OBSADC02] varchar(80), 
	[SUB01] boolean NOT NULL, 
	[SUB02] boolean NOT NULL, 
	[SUB03] boolean NOT NULL, 
	[SUB04] boolean NOT NULL, 
	[SUB05] boolean NOT NULL, 
	[SUB06] boolean NOT NULL, 
	[SUB07] boolean NOT NULL, 
	[SUB08] boolean NOT NULL, 
	[SUB09] boolean NOT NULL, 
	[NIVEL] varchar(1), 
	[RES01] boolean NOT NULL, 
	[RES02] boolean NOT NULL, 
	[RES03] boolean NOT NULL, 
	[RES04] boolean NOT NULL, 
	[APLIC] boolean NOT NULL, 
	[SUB10] boolean NOT NULL, 
	[DESENHO] varchar(80), 
	[NOT01] boolean NOT NULL, 
	[NOT02] boolean NOT NULL, 
	[INF01] boolean NOT NULL, 
	[INF02] boolean NOT NULL, 
	[INF03] boolean NOT NULL, 
	[EXPOSTO] varchar(80), 
	[PEDOM] varchar(80), 
	[AUXILIAR] varchar(80), 
	[NIVELALT] varchar(80), 
	[NIVELDAT] datetime, 
	[DIVISAO] varchar(80), 
	[APLICACAO] varchar(80), 
	[DATA] datetime, 
	[MOLDE] varchar(50), 
	[DISPO] varchar(1), 
	[APRO] varchar(1), 
	[RESNOME] varchar(50), 
	[RESCARGO] varchar(50), 
	[EXP01] varchar(150), 
	[EXP02] varchar(150), 
	[PPAP] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[TIPCOM] varchar(1), 
	[CODCOM] varchar(24), 
	[NOMCOM] varchar(50), 
	[FORNECEDOR] int, 
	[FORNOM] varchar(50), 
	[COMPRAS] int, 
	[COMITEM] int, 
	[PRGENT] int, 
	[INATIVO] boolean NOT NULL, 
	[SITUACOA] varchar(1), 
	[PF] int
);

-- Tabela: PPAPC
CREATE TABLE IF NOT EXISTS [PPAPC] (
	[PPAP] int, 
	[DATA] datetime, 
	[PREVISTO] datetime, 
	[EFETUADO] datetime, 
	[OBS] longtext, 
	[DISPO] varchar(1), 
	[CODIGO] varchar(50), 
	[item] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: PPAPI
CREATE TABLE IF NOT EXISTS [PPAPI] (
	[DATA] datetime, 
	[OBS] longtext, 
	[PPAP] int, 
	[DISPO] varchar(1), 
	[ITEM] double, 
	[PRAZO] datetime, 
	[APROVADO] datetime, 
	[dispnome] varchar(40), 
	[dispdate] datetime, 
	[dispnum] int
);

-- Tabela: PPAPP
CREATE TABLE IF NOT EXISTS [PPAPP] (
	[PPAP] int, 
	[CODIGO] varchar(50), 
	[PF] int
);

-- �ndice: IDXPPAF_PPAP
CREATE INDEX IF NOT EXISTS [IDXPPAF_PPAP]
	ON [PPAF] ([PPAP]);

-- �ndice: IDXPPAFC_PPAP
CREATE INDEX IF NOT EXISTS [IDXPPAFC_PPAP]
	ON [PPAFC] ([PPAP]);

-- �ndice: IDXPPAFI_PPAP
CREATE INDEX IF NOT EXISTS [IDXPPAFI_PPAP]
	ON [PPAFI] ([PPAP]);

-- �ndice: IDXPPAFP_PPAP
CREATE INDEX IF NOT EXISTS [IDXPPAFP_PPAP]
	ON [PPAFP] ([PPAP]);

-- �ndice: IDXPPAG_PPAP
CREATE INDEX IF NOT EXISTS [IDXPPAG_PPAP]
	ON [PPAG] ([PPAP]);

-- �ndice: IDXPPAGC_PPAP
CREATE INDEX IF NOT EXISTS [IDXPPAGC_PPAP]
	ON [PPAGC] ([PPAP]);

-- �ndice: IDXPPAGI_PPAP
CREATE INDEX IF NOT EXISTS [IDXPPAGI_PPAP]
	ON [PPAGI] ([PPAP]);

-- �ndice: IDXPPAGP_PPAP
CREATE INDEX IF NOT EXISTS [IDXPPAGP_PPAP]
	ON [PPAGP] ([PPAP]);

-- �ndice: IDXPPAP_PPAP
CREATE INDEX IF NOT EXISTS [IDXPPAP_PPAP]
	ON [PPAP] ([PPAP]);

-- �ndice: IDXPPAPC_PPAP
CREATE INDEX IF NOT EXISTS [IDXPPAPC_PPAP]
	ON [PPAPC] ([PPAP]);

-- �ndice: IDXPPAPI_PPAP
CREATE INDEX IF NOT EXISTS [IDXPPAPI_PPAP]
	ON [PPAPI] ([PPAP]);

-- �ndice: IDXPPAPP_PPAP
CREATE INDEX IF NOT EXISTS [IDXPPAPP_PPAP]
	ON [PPAPP] ([PPAP]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
