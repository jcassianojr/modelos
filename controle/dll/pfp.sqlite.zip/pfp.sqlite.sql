--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 16:54:25 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: AP
CREATE TABLE IF NOT EXISTS [AP] (
	[SEQ] int, 
	[DESCRICAO] longtext
);

-- Tabela: CFLX
CREATE TABLE IF NOT EXISTS [CFLX] (
	[LETRA] varchar(1), 
	[DESCRICAO] varchar(50), 
	[LETRA_x] varchar(1), 
	[NUMERO] smallint
);

-- Tabela: DUPLICAR
CREATE TABLE IF NOT EXISTS [DUPLICAR] (
	[TABELA] varchar(50), 
	[CAMPO] varchar(50)
);

-- Tabela: EMPRESA
CREATE TABLE IF NOT EXISTS [EMPRESA] (
	[NOME] varchar(50), 
	[TELEFONE] varchar(50), 
	[FAX] varchar(50), 
	[ENDERECO] varchar(50), 
	[CIDADE] varchar(50), 
	[ESTADO] varchar(2), 
	[CEP] varchar(9)
);

-- Tabela: FEMEA
CREATE TABLE IF NOT EXISTS [FEMEA] (
	[PF] double, 
	[ITEM] double, 
	[PROCESSO] varchar(255), 
	[FALTIP] longtext, 
	[FALEFE] longtext, 
	[FALCAU] longtext, 
	[CRTATU] longtext, 
	[INDOCO] double, 
	[INDSEV] double, 
	[INDDET] double, 
	[INDRIS] double, 
	[ACAREC] longtext, 
	[RESCOD] double, 
	[RESNOM] varchar(40), 
	[RESDAT] datetime, 
	[ACATOM] longtext, 
	[ACADAT] datetime, 
	[RINDOCO] double, 
	[RINDSER] double, 
	[RINDDET] double, 
	[RINDRIS] double, 
	[RESCOD2] double, 
	[RESNOM3] varchar(40), 
	[RESNOM2] varchar(40), 
	[RESDAT2] datetime, 
	[RESDAT3] datetime, 
	[ACAO] boolean NOT NULL, 
	[RESCOD3] double, 
	[SITUACAO] varchar(1), 
	[SIGI] varchar(1), 
	[CARAPREV] longtext, 
	[EXCRPN] boolean NOT NULL, 
	[ALTMAN] boolean NOT NULL, 
	[MUDPAD] boolean NOT NULL, 
	[PSA] varchar(20), 
	[FXSEQ] smallint, 
	[FXSSQ] smallint, 
	[FXITEM] smallint, 
	[PRONUM] smallint, 
	[EFENUM] smallint, 
	[FALNUM] smallint, 
	[CAUNUM] smallint, 
	[SEGGRA] smallint, 
	[TITULO] varchar(50), 
	[BLOQUEADO] boolean NOT NULL, 
	[TIPOAPU] varchar(1), 
	[SIG2] varchar(1), 
	[SIG3] varchar(1), 
	[subtipo] varchar(1), 
	[fxitems] int, 
	[FEMEAREV] double, 
	[CRATU] longtext, 
	[elemento] varchar(200), 
	[estacao] varchar(200), 
	[trabalho] varchar(200), 
	[funcaoitem] varchar(200), 
	[funcaoetapa] varchar(200), 
	[funcaoelemento] varchar(200), 
	[pafemea] varchar(1), 
	[caraespecial] varchar(1), 
	[filtroespecial] varchar(1), 
	[acaoprev] varchar(200), 
	[acaodet] varchar(200), 
	[rpafemea] varchar(1), 
	[observacao] varchar(200)
);

-- Tabela: FEMPRE
CREATE TABLE IF NOT EXISTS [FEMPRE] (
	[FALTIP] longtext, 
	[FALEFE] longtext, 
	[FALCAU] longtext, 
	[CRTATU] longtext, 
	[INDOCO] double, 
	[INDSEV] double, 
	[INDDET] double, 
	[INDRIS] double, 
	[TITULO] varchar(50), 
	[SEGGRA] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[SEGGRA_x] int, 
	[CARAPREV] longtext, 
	[ACAREC] longtext, 
	[ACATOM] longtext, 
	[RINDSER] double, 
	[RINDOCO] double, 
	[RINDDET] double, 
	[RINDRIS] double, 
	[CRATU] longtext, 
	[SITUACAO] varchar(1), 
	[ACAO] boolean NOT NULL, 
	[ACADAT] datetime, 
	[SIGI] varchar(1), 
	[RESCOD] int, 
	[RESCOD3] int, 
	[RESNOM] varchar(40), 
	[RESNOM2] varchar(40), 
	[RESNOM3] varchar(40), 
	[RESDAT] datetime, 
	[RESDAT2] datetime, 
	[RESDAT3] datetime, 
	[RESCOD2] int, 
	[EXCRPN] boolean NOT NULL, 
	[PF] double, 
	[ITEM] double, 
	[PROCESSO] varchar(255), 
	[ALTMAN] boolean NOT NULL, 
	[MUDPAD] boolean NOT NULL, 
	[PSA] varchar(20), 
	[FXSEQ] smallint, 
	[FXSSQ] smallint, 
	[FXITEM] smallint, 
	[PRONUM] smallint, 
	[EFENUM] smallint, 
	[FALNUM] smallint, 
	[CAUNUM] smallint, 
	[bloqueado] boolean NOT NULL, 
	[tipoapu] varchar(1), 
	[SIG2] varchar(1), 
	[SIG3] varchar(1), 
	[subtipo] varchar(1), 
	[suptipo] varchar(1), 
	[fxitems] int, 
	[FEMEAREV] double
);

-- Tabela: IE
CREATE TABLE IF NOT EXISTS [IE] (
	[PF] double PRIMARY KEY, 
	[DETALHE] longtext, 
	[TIPO] longtext, 
	[FECHA] longtext, 
	[NPED] double, 
	[IDENT] longtext, 
	[PROTE] longtext, 
	[QML] double, 
	[COM] double, 
	[LAR] double, 
	[ALT] double, 
	[UND] double, 
	[TOTL] double, 
	[TARA] double, 
	[BRUTO] double, 
	[METODO] longtext, 
	[OBS] longtext, 
	[DATA] datetime, 
	[REVISAO] double, 
	[LOCAL] longtext, 
	[CODMR01] varchar(10), 
	[NOMMR01] varchar(100), 
	[DATAREV] datetime, 
	[CODDIR] varchar(50), 
	[CODESQ] varchar(50), 
	[CODIGOINT] varchar(50), 
	[codigocli] varchar(50), 
	[elaborador] varchar(40)
);

-- Tabela: IED
CREATE TABLE IF NOT EXISTS [IED] (
	[TIPO] varchar(1), 
	[DESCRITIVO] varchar(50), 
	[ITEM] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[DETALHE] longtext, 
	[Valor] int
);

-- Tabela: PCTIPO
CREATE TABLE IF NOT EXISTS [PCTIPO] (
	[IDTIPO] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[DESCRICAO] varchar(50)
);

-- Tabela: PF
CREATE TABLE IF NOT EXISTS [PF] (
	[PF] double PRIMARY KEY, 
	[CPF] varchar(10), 
	[CODIGO] varchar(24), 
	[DESCR] varchar(40), 
	[CLIENTE] double, 
	[CLINOME] varchar(50), 
	[CLIDES] varchar(24), 
	[CLIREV] varchar(10), 
	[CLIDAT] datetime, 
	[NOSDES] varchar(24), 
	[NOSREV] varchar(10), 
	[NOSDAT] datetime, 
	[CONDES] varchar(24), 
	[CONREV] varchar(10), 
	[CONDAT] datetime, 
	[CONPES] double, 
	[CONQTD] double, 
	[PESLIQ] double, 
	[MOTREV] longtext, 
	[OPCAO] tinyint, 
	[CODMU011] varchar(10), 
	[CODMU012] varchar(10), 
	[CODMU013] varchar(10), 
	[NOMMU011] varchar(101), 
	[NOMMU012] varchar(101), 
	[NOMMU013] varchar(101), 
	[OBSMU011] longtext, 
	[OBSMU012] longtext, 
	[OBSMU013] longtext, 
	[PASMU011] double, 
	[PASMU012] double, 
	[PASMU013] double, 
	[PESMU011] double, 
	[PESMU012] double, 
	[PESMU013] double, 
	[QTDMU011] double, 
	[QTDMU012] double, 
	[QTDMU013] double, 
	[PERMU011] double, 
	[PERMU012] double, 
	[PERMU013] double, 
	[TIPO] varchar(50), 
	[OBS] longtext, 
	[SITUACAO] varchar(1), 
	[ELADAT] datetime, 
	[ELANUM] int, 
	[RESDAT] datetime, 
	[ELANOM] varchar(40), 
	[RESNUM] int, 
	[RESNOM] varchar(50), 
	[FEMEAD] datetime, 
	[FEMEAF] double, 
	[FEMEAG] longtext, 
	[FEMEAC] longtext, 
	[FEMEAR] varchar(40), 
	[FEMEAREV] double, 
	[FEMEAREVD] datetime, 
	[FEMEAOBS] varchar(100), 
	[REVPRO] double, 
	[REVDAT] datetime, 
	[PCELANUM] double, 
	[PCELANOM] varchar(50), 
	[PCELADAT] datetime, 
	[PCREV] double, 
	[PCREVD] datetime, 
	[PCLIBNUM] double, 
	[PCLIBNOM] varchar(50), 
	[PCLIBDATE] datetime, 
	[TIPOSITU] varchar(1), 
	[BLOQUEADO] boolean NOT NULL, 
	[BLOQMOTIVO] varchar(50), 
	[PCDINI] datetime, 
	[CODCLIENTE] varchar(50), 
	[STPFFE] boolean NOT NULL, 
	[STPFPC] boolean NOT NULL, 
	[STFEPC] boolean NOT NULL, 
	[PCGRUPO] longtext, 
	[PCRTIPO] varchar(1), 
	[PCLTIPO] varchar(1), 
	[PCPTIPO] varchar(1), 
	[PCFTIPO] varchar(1), 
	[PCCTIPO] varchar(1), 
	[PCRREV] double, 
	[PCLREV] double, 
	[PCPREV] double, 
	[PCFREV] double, 
	[PCCREV] double, 
	[PCRDAT] datetime, 
	[PCLDAT] datetime, 
	[PCPDAT] datetime, 
	[PCFDAT] datetime, 
	[PCCDAT] datetime, 
	[SEQMU011] double, 
	[SEQMU012] double, 
	[SEQMU013] double, 
	[SSQMU011] double, 
	[SSQMU012] double, 
	[SSQMU013] single, 
	[FEMEAEF] double, 
	[FEMEAED] datetime, 
	[FEMEAEN] varchar(50), 
	[FEMEAPRO] datetime, 
	[FEMEACRG] boolean NOT NULL, 
	[CODFINAL] varchar(50), 
	[PCBLOQ] boolean NOT NULL, 
	[FILIAL] varchar(5), 
	[CLIESP] varchar(50), 
	[SEL100] boolean NOT NULL, 
	[CODFISCAL] varchar(24), 
	[seldata] datetime, 
	[EXCRPN] boolean NOT NULL, 
	[CRITICO] boolean NOT NULL, 
	[CRITIOBS] longtext, 
	[OUTRAAPR] varchar(50), 
	[FEMMUDPAD] boolean NOT NULL, 
	[CODIGOINT] varchar(24), 
	[FLX01] varchar(1), 
	[FLX02] varchar(1), 
	[FLX03] varchar(1), 
	[FLX04] varchar(1), 
	[FLX05] varchar(1), 
	[FLX06] varchar(1), 
	[FLX07] varchar(1), 
	[FLX08] varchar(1), 
	[FLX09] varchar(1), 
	[FLX10] varchar(1), 
	[clientelx] varchar(15), 
	[clientepr] varchar(6), 
	[FEMEAREVD2] datetime, 
	[PCREVD2] datetime, 
	[seguranca] boolean NOT NULL, 
	[takt] double, 
	[taktat] double, 
	[CONTATONUM] double, 
	[CONTATONOM] varchar(50), 
	[femeaprepro] datetime, 
	[segnum] int, 
	[segnom] varchar(50), 
	[segdat] datetime, 
	[prdnum] int, 
	[prdnom] varchar(50), 
	[prddat] datetime, 
	[numversaocli] varchar(4), 
	[femeaano] varchar(10), 
	[femeaproj] varchar(100)
);

-- Tabela: PFC
CREATE TABLE IF NOT EXISTS [PFC] (
	[pf] double DEFAULT 0, 
	[seq] double DEFAULT 0, 
	[ssq] double DEFAULT 0, 
	[item] double DEFAULT 0, 
	[CITEM] varchar(3), 
	[COP] longtext DEFAULT '', 
	[DESCR] longtext DEFAULT '', 
	[CARAC] longtext DEFAULT '', 
	[SIGI] varchar(1), 
	[ESPE] longtext DEFAULT '', 
	[TOL] longtext DEFAULT '', 
	[CQTDE] longtext DEFAULT '', 
	[FREQ] longtext DEFAULT '', 
	[TIPINS] varchar(12), 
	[INSTR] varchar(50), 
	[CAPA] longtext DEFAULT '', 
	[REACAO] longtext DEFAULT '', 
	[SETOR] varchar(1), 
	[CARTA] longtext DEFAULT '', 
	[PROCESSO] longtext DEFAULT '', 
	[CERTFOR] boolean NOT NULL DEFAULT False, 
	[codme04] varchar(20), 
	[FILIAL] varchar(5), 
	[codme04b] varchar(20), 
	[TIPINSB] varchar(12), 
	[INSTRB] varchar(50), 
	[SAIPROC] boolean NOT NULL DEFAULT False, 
	[SAIRI] boolean NOT NULL DEFAULT False, 
	[SIG2] varchar(1), 
	[SIG3] varchar(1)
);

-- Tabela: PFCMS03
CREATE TABLE IF NOT EXISTS [PFCMS03] (
	[PF] double, 
	[SEQ] double, 
	[SSQ] double, 
	[ITEM] double, 
	[CITEM] varchar(3), 
	[COP] longtext, 
	[DESCR] longtext, 
	[CARAC] longtext, 
	[SIGI] varchar(1), 
	[ESPE] longtext, 
	[TOL] longtext, 
	[CQTDE] longtext, 
	[FREQ] longtext, 
	[TIPINS] varchar(12), 
	[INSTR] varchar(50), 
	[CAPA] longtext, 
	[REACAO] longtext, 
	[SETOR] varchar(1), 
	[CARTA] longtext, 
	[TIPOENT] varchar(1), 
	[CERTFOR] boolean NOT NULL, 
	[PROCESSO] longtext, 
	[CODCOMP] varchar(50), 
	[codme04] varchar(20), 
	[codme04b] varchar(20), 
	[FILIAL] varchar(5), 
	[TIPINSB] varchar(12), 
	[INSTRB] varchar(50), 
	[SAIPROC] boolean NOT NULL, 
	[SAIRI] boolean NOT NULL, 
	[TEMP] varchar(50), 
	[SIG2] varchar(1), 
	[SIG3] varchar(1)
);

-- Tabela: pfco
CREATE TABLE IF NOT EXISTS [pfco] (
	[PF] double, 
	[SEQ] double, 
	[SSQ] double, 
	[ITEM] double, 
	[CITEM] varchar(3), 
	[COP] longtext, 
	[DESCR] longtext, 
	[CARAC] longtext, 
	[SIGI] varchar(1), 
	[ESPE] longtext, 
	[TOL] longtext, 
	[CQTDE] longtext, 
	[FREQ] longtext, 
	[TIPINS] varchar(12), 
	[INSTR] varchar(50), 
	[CAPA] longtext, 
	[REACAO] longtext, 
	[SETOR] varchar(1), 
	[CARTA] longtext, 
	[PROCESSO] longtext, 
	[CERTFOR] boolean NOT NULL, 
	[codme04] varchar(20), 
	[FILIAL] varchar(5), 
	[codme04b] varchar(20), 
	[TIPINSB] varchar(12), 
	[INSTRB] varchar(50), 
	[SAIPROC] boolean NOT NULL, 
	[SAIRI] boolean NOT NULL, 
	[SIG2] varchar(1), 
	[SIG3] varchar(1)
);

-- Tabela: PFD
CREATE TABLE IF NOT EXISTS [PFD] (
	[CQTDE] longtext, 
	[FREQ] longtext, 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[SETOR] varchar(1)
);

-- Tabela: PFI
CREATE TABLE IF NOT EXISTS [PFI] (
	[PF] double, 
	[SEQ] double, 
	[SSQ] double, 
	[ITEM] double, 
	[DESCR] varchar(255), 
	[NORMA] varchar(20), 
	[TEMPOMAN] double, 
	[TEMPOMAQ] double, 
	[TEMPOMOV] double, 
	[PTOCHAVE] varchar(78), 
	[RAZAO] varchar(78), 
	[takt] int, 
	[taktat] int, 
	[5SOQUE] varchar(255), 
	[5SCOMO] varchar(255), 
	[5SPORQUE] varchar(255), 
	[5SSIMB01] varchar(1), 
	[5SSIMB02] varchar(1), 
	[5SSIMB03] varchar(1), 
	[5SSIMB04] varchar(1), 
	[5ssimb05] varchar(1), 
	[5ssimb06] varchar(1)
);

-- Tabela: PFMS03
CREATE TABLE IF NOT EXISTS [PFMS03] (
	[PF] double, 
	[TIPOENT] varchar(1), 
	[DESCRI] longtext, 
	[QTDDE] double, 
	[PRECO] double, 
	[TOTAL] double, 
	[BAIXAC] varchar(1), 
	[SEQ] int, 
	[SSQ] int, 
	[OPCAO] tinyint, 
	[PCOBS] longtext, 
	[PCTIPO] varchar(50), 
	[CODCOMP] varchar(50), 
	[prdori] varchar(10), 
	[CODINT] varchar(24)
);

-- Tabela: PFQSBLEP
CREATE TABLE IF NOT EXISTS [PFQSBLEP] (
	[PF] double, 
	[SEQ] int, 
	[SSQ] int, 
	[ITEM] int, 
	[FLUXO] varchar(20), 
	[CLASS02] varchar(1), 
	[CARAC] varchar(255), 
	[REQUER] varchar(255), 
	[MUD] varchar(1), 
	[DESCRICAO] varchar(255), 
	[FLX01] varchar(1), 
	[FLX02] varchar(1), 
	[FLX03] varchar(1), 
	[FLX04] varchar(1), 
	[FLX05] varchar(1), 
	[FLX06] varchar(1), 
	[FLX07] varchar(1), 
	[FLX08] varchar(1), 
	[CLASS01] varchar(6), 
	[REQUERSAI] varchar(255), 
	[CARA2] varchar(1), 
	[CARA3] varchar(1)
);

-- Tabela: PFREV
CREATE TABLE IF NOT EXISTS [PFREV] (
	[PF] int, 
	[REV] smallint, 
	[PFDATA] datetime, 
	[FEMEAD] datetime, 
	[FEMEAN] varchar(50), 
	[PCPD] datetime, 
	[PCPN] varchar(50), 
	[PCRD] datetime, 
	[PCRN] varchar(50), 
	[PCLD] datetime, 
	[PCLN] varchar(50), 
	[PCFD] datetime, 
	[PCFN] varchar(50), 
	[PCCD] datetime, 
	[PCCN] varchar(50)
);

-- Tabela: PFS
CREATE TABLE IF NOT EXISTS [PFS] (
	[PF] double DEFAULT 0, 
	[SEQ] double DEFAULT 0, 
	[SSQ] double DEFAULT 0, 
	[descri] varchar(150), 
	[REGULAR] longtext, 
	[NOMMP01] varchar(30), 
	[NOMMP02] varchar(30), 
	[NOMMP03] varchar(30), 
	[NOMMP02D] varchar(30), 
	[NOMMP02C] varchar(30), 
	[NOMMP02B] varchar(30), 
	[CODMP01] varchar(12), 
	[CODMP02] varchar(12), 
	[CODMP02C] varchar(12), 
	[CODMP02D] varchar(12), 
	[CODMP02B] varchar(12), 
	[CODMP03] varchar(12), 
	[FATBAT] double DEFAULT 0, 
	[FATCORTE] double DEFAULT 0, 
	[PCHORA] double DEFAULT 0, 
	[FERRAMEN] varchar(24), 
	[FERRAME2] varchar(24), 
	[FERRAME3] varchar(24), 
	[FERRAME4] varchar(24), 
	[FLX01] varchar(1), 
	[FLX02] varchar(1), 
	[FLX03] varchar(1), 
	[FLX04] varchar(1), 
	[FLX05] varchar(1), 
	[FLX06] varchar(1), 
	[FLX07] varchar(1), 
	[FLX08] varchar(1), 
	[FLX09] varchar(1), 
	[FLX10] varchar(1), 
	[obs] varchar(250), 
	[FERCOD] varchar(24), 
	[fernom] varchar(25), 
	[CODIGOE] varchar(24), 
	[CODIGOD] varchar(24), 
	[pcobs] varchar(200), 
	[pctipo] varchar(40), 
	[OPCAO] tinyint DEFAULT 0, 
	[QTHOMEM] tinyint DEFAULT 0, 
	[SETORREF] varchar(1), 
	[SETORINS] varchar(3), 
	[FEITO] varchar(1), 
	[MONTAGEM] varchar(1), 
	[FILIAL] varchar(5), 
	[CODINT] varchar(24), 
	[ESQTIP] varchar(1), 
	[ESQL01] varchar(8), 
	[ESQL02] varchar(8), 
	[ESQL03] varchar(8), 
	[ESQL04] varchar(8), 
	[ESQL05] varchar(8), 
	[ESQL06] varchar(8), 
	[ESQL07] varchar(8), 
	[ESQL08] varchar(8), 
	[ferajm] varchar(10), 
	[feruci] varchar(15), 
	[feravf] varchar(10), 
	[ferpin] varchar(5), 
	[ferqtd] varchar(10), 
	[ferdim] varchar(5), 
	[fercom] varchar(10), 
	[ferpre] varchar(15), 
	[SIMBOLOSEG] varchar(1), 
	[TAKTIME] double DEFAULT 0, 
	[SIMBOLOSE2] varchar(1), 
	[SIMBOLOSE3] varchar(1), 
	[EPI01] boolean NOT NULL DEFAULT False, 
	[EPI02] boolean NOT NULL DEFAULT False, 
	[EPI03] boolean NOT NULL DEFAULT False, 
	[EPI04] boolean NOT NULL DEFAULT False, 
	[EPI05] boolean NOT NULL DEFAULT False, 
	[EPI06] boolean NOT NULL DEFAULT False, 
	[EPI07] boolean NOT NULL DEFAULT False, 
	[PCCICLO] double DEFAULT 0, 
	[CICLOPC] double DEFAULT 0, 
	[CODIGOCLI] varchar(30), 
	[EMBALCOD] varchar(10), 
	[embalnome] varchar(25), 
	[EMBALQTDE] double DEFAULT 0, 
	[embalmetodo] varchar(25), 
	[COMPON01] varchar(50), 
	[COMPON02] varchar(50), 
	[COMPON03] varchar(50), 
	[COMPON04] varchar(50), 
	[COMPON05] varchar(50), 
	[COMPON06] varchar(50), 
	[COMPON07] varchar(50), 
	[COMPON08] varchar(50), 
	[COMPON09] varchar(50), 
	[ferralt] varchar(30), 
	[FERRPASSO] double DEFAULT 0, 
	[ferrforca] varchar(25), 
	[ferrfixA] varchar(15), 
	[qtdmp01] double DEFAULT 0, 
	[qtdmp02] double DEFAULT 0, 
	[qtdmp02b] double DEFAULT 0, 
	[qtdmp02c] double DEFAULT 0, 
	[qtdmp02d] double DEFAULT 0, 
	[subtipo] varchar(1), 
	[COMPON10] varchar(50), 
	[COMPON11] varchar(50), 
	[COMPON12] varchar(50), 
	[COMPON13] varchar(50), 
	[COMPON14] varchar(50), 
	[COMPON15] varchar(50)
);

-- Tabela: PFSCHECKLIST
CREATE TABLE IF NOT EXISTS [PFSCHECKLIST] (
	[PF] double, 
	[SEQ] double, 
	[SSQ] double, 
	[ORDEM] double, 
	[DESCRICAO] varchar(255)
);

-- Tabela: pfso
CREATE TABLE IF NOT EXISTS [pfso] (
	[PF] double, 
	[SEQ] double, 
	[SSQ] double, 
	[DESCRI] longtext, 
	[PCOBS] longtext, 
	[PCTIPO] varchar(50), 
	[TIPOENT] varchar(1), 
	[CODCOMP] varchar(11), 
	[CODINT] varchar(24)
);

-- Tabela: PFSONTHEJOB
CREATE TABLE IF NOT EXISTS [PFSONTHEJOB] (
	[PF] double, 
	[SEQ] double, 
	[SSQ] double, 
	[ORDEM] double, 
	[DESCRICAO] varchar(255)
);

-- Tabela: PPAF
CREATE TABLE IF NOT EXISTS [PPAF] (
	[CLIENTE] int, 
	[CLINOME] varchar(50), 
	[COMPRADOR] varchar(5), 
	[COMNOME] varchar(40), 
	[CODIGO] varchar(24), 
	[NOME] varchar(40), 
	[DATAALT] datetime, 
	[ITEM] boolean NOT NULL, 
	[PESO] double, 
	[OBSADC01] varchar(80), 
	[OBSADC02] varchar(80), 
	[SUB01] boolean NOT NULL, 
	[SUB02] boolean NOT NULL, 
	[SUB03] boolean NOT NULL, 
	[SUB04] boolean NOT NULL, 
	[SUB05] boolean NOT NULL, 
	[SUB06] boolean NOT NULL, 
	[SUB07] boolean NOT NULL, 
	[SUB08] boolean NOT NULL, 
	[SUB09] boolean NOT NULL, 
	[NIVEL] varchar(1), 
	[RES01] boolean NOT NULL, 
	[RES02] boolean NOT NULL, 
	[RES03] boolean NOT NULL, 
	[RES04] boolean NOT NULL, 
	[APLIC] boolean NOT NULL, 
	[SUB10] boolean NOT NULL, 
	[DESENHO] varchar(80), 
	[NOT01] boolean NOT NULL, 
	[NOT02] boolean NOT NULL, 
	[INF01] boolean NOT NULL, 
	[INF02] boolean NOT NULL, 
	[INF03] boolean NOT NULL, 
	[EXPOSTO] varchar(80), 
	[PEDOM] varchar(80), 
	[AUXILIAR] varchar(80), 
	[NIVELALT] varchar(80), 
	[NIVELDAT] datetime, 
	[DIVISAO] varchar(80), 
	[APLICACAO] varchar(80), 
	[DATA] datetime, 
	[MOLDE] varchar(50), 
	[DISPO] varchar(1), 
	[APRO] varchar(1), 
	[RESNOME] varchar(50), 
	[RESCARGO] varchar(50), 
	[EXP01] varchar(150), 
	[EXP02] varchar(150), 
	[TIPCOM] varchar(1), 
	[CODCOM] varchar(24), 
	[NOMCOM] varchar(50), 
	[FORNECEDOR] int, 
	[FORNOM] varchar(50), 
	[COMPRAS] int, 
	[COMITEM] int, 
	[PRGENT] int, 
	[INATIVO] boolean NOT NULL, 
	[SITUACAO] varchar(1), 
	[PF] int, 
	[PPAP] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: PPAFC
CREATE TABLE IF NOT EXISTS [PPAFC] (
	[PPAP] int, 
	[DATA] datetime, 
	[PREVISTO] datetime, 
	[EFETUADO] datetime, 
	[OBS] longtext, 
	[DISPO] varchar(1), 
	[CODIGO] varchar(50), 
	[ITEM] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: PPAFI
CREATE TABLE IF NOT EXISTS [PPAFI] (
	[DATA] datetime, 
	[OBS] longtext, 
	[DISPO] varchar(1), 
	[ITEM] double, 
	[PPAP] int, 
	[PRAZO] datetime, 
	[APROVADO] datetime, 
	[dispnome] varchar(40), 
	[dispdate] datetime, 
	[dispnum] int
);

-- Tabela: PPAFP
CREATE TABLE IF NOT EXISTS [PPAFP] (
	[PPAP] int, 
	[CODIGO] varchar(50), 
	[PF] int
);

-- Tabela: PPAG
CREATE TABLE IF NOT EXISTS [PPAG] (
	[CLIENTE] int, 
	[CLINOME] varchar(50), 
	[COMPRADOR] varchar(5), 
	[COMNOME] varchar(40), 
	[CODIGO] varchar(24), 
	[DATAALT] datetime, 
	[NOME] varchar(40), 
	[ITEM] boolean NOT NULL, 
	[PESO] double, 
	[OBSADC01] varchar(80), 
	[OBSADC02] varchar(80), 
	[SUB01] boolean NOT NULL, 
	[SUB02] boolean NOT NULL, 
	[SUB03] boolean NOT NULL, 
	[SUB04] boolean NOT NULL, 
	[SUB05] boolean NOT NULL, 
	[SUB06] boolean NOT NULL, 
	[SUB07] boolean NOT NULL, 
	[SUB08] boolean NOT NULL, 
	[SUB09] boolean NOT NULL, 
	[NIVEL] varchar(1), 
	[RES01] boolean NOT NULL, 
	[RES02] boolean NOT NULL, 
	[RES03] boolean NOT NULL, 
	[RES04] boolean NOT NULL, 
	[APLIC] boolean NOT NULL, 
	[SUB10] boolean NOT NULL, 
	[DESENHO] varchar(80), 
	[NOT01] boolean NOT NULL, 
	[NOT02] boolean NOT NULL, 
	[INF01] boolean NOT NULL, 
	[INF02] boolean NOT NULL, 
	[INF03] boolean NOT NULL, 
	[EXPOSTO] varchar(80), 
	[PEDOM] varchar(80), 
	[AUXILIAR] varchar(80), 
	[NIVELALT] varchar(80), 
	[NIVELDAT] datetime, 
	[DIVISAO] varchar(80), 
	[APLICACAO] varchar(80), 
	[DATA] datetime, 
	[MOLDE] varchar(50), 
	[DISPO] varchar(1), 
	[APRO] varchar(1), 
	[RESNOME] varchar(50), 
	[RESCARGO] varchar(50), 
	[EXP01] varchar(150), 
	[EXP02] varchar(150), 
	[TIPCOM] varchar(1), 
	[CODCOM] varchar(24), 
	[FORNECEDOR] int, 
	[NOMCOM] varchar(50), 
	[COMPRAS] int, 
	[FORNOM] varchar(50), 
	[COMITEM] int, 
	[PRGENT] int, 
	[INATIVO] boolean NOT NULL, 
	[PF] int, 
	[SITUACAO] varchar(1), 
	[SSMT] varchar(50), 
	[PPAP] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: PPAGC
CREATE TABLE IF NOT EXISTS [PPAGC] (
	[PPAP] int, 
	[DATA] datetime, 
	[PREVISTO] datetime, 
	[EFETUADO] datetime, 
	[OBS] longtext, 
	[DISPO] varchar(1), 
	[CODIGO] varchar(50), 
	[ITEM] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: PPAGI
CREATE TABLE IF NOT EXISTS [PPAGI] (
	[DATA] datetime, 
	[OBS] longtext, 
	[DISPO] varchar(1), 
	[ITEM] double, 
	[PPAP] int, 
	[PRAZO] datetime, 
	[APROVADO] datetime, 
	[dispnome] varchar(40), 
	[dispdate] datetime, 
	[dispnum] int
);

-- Tabela: PPAGP
CREATE TABLE IF NOT EXISTS [PPAGP] (
	[PPAP] int, 
	[CODIGO] varchar(50), 
	[PF] int
);

-- Tabela: PPAP
CREATE TABLE IF NOT EXISTS [PPAP] (
	[CLIENTE] int, 
	[CLINOME] varchar(50), 
	[COMPRADOR] varchar(5), 
	[COMNOME] varchar(40), 
	[CODIGO] varchar(24), 
	[NOME] varchar(40), 
	[DATAALT] datetime, 
	[ITEM] boolean NOT NULL, 
	[PESO] double, 
	[OBSADC01] varchar(80), 
	[OBSADC02] varchar(80), 
	[SUB01] boolean NOT NULL, 
	[SUB02] boolean NOT NULL, 
	[SUB03] boolean NOT NULL, 
	[SUB04] boolean NOT NULL, 
	[SUB05] boolean NOT NULL, 
	[SUB06] boolean NOT NULL, 
	[SUB07] boolean NOT NULL, 
	[SUB08] boolean NOT NULL, 
	[SUB09] boolean NOT NULL, 
	[NIVEL] varchar(1), 
	[RES01] boolean NOT NULL, 
	[RES02] boolean NOT NULL, 
	[RES03] boolean NOT NULL, 
	[RES04] boolean NOT NULL, 
	[APLIC] boolean NOT NULL, 
	[SUB10] boolean NOT NULL, 
	[DESENHO] varchar(80), 
	[NOT01] boolean NOT NULL, 
	[NOT02] boolean NOT NULL, 
	[INF01] boolean NOT NULL, 
	[INF02] boolean NOT NULL, 
	[INF03] boolean NOT NULL, 
	[EXPOSTO] varchar(80), 
	[PEDOM] varchar(80), 
	[AUXILIAR] varchar(80), 
	[NIVELALT] varchar(80), 
	[NIVELDAT] datetime, 
	[DIVISAO] varchar(80), 
	[APLICACAO] varchar(80), 
	[DATA] datetime, 
	[MOLDE] varchar(50), 
	[DISPO] varchar(1), 
	[APRO] varchar(1), 
	[RESNOME] varchar(50), 
	[RESCARGO] varchar(50), 
	[EXP01] varchar(150), 
	[EXP02] varchar(150), 
	[TIPCOM] varchar(1), 
	[CODCOM] varchar(24), 
	[NOMCOM] varchar(50), 
	[FORNECEDOR] int, 
	[FORNOM] varchar(50), 
	[COMPRAS] int, 
	[COMITEM] int, 
	[PRGENT] int, 
	[INATIVO] boolean NOT NULL, 
	[SITUACOA] varchar(1), 
	[PF] int, 
	[PPAP] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: PPAPC
CREATE TABLE IF NOT EXISTS [PPAPC] (
	[PPAP] int, 
	[DATA] datetime, 
	[PREVISTO] datetime, 
	[EFETUADO] datetime, 
	[OBS] longtext, 
	[DISPO] varchar(1), 
	[CODIGO] varchar(50), 
	[item] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: PPAPI
CREATE TABLE IF NOT EXISTS [PPAPI] (
	[DATA] datetime, 
	[OBS] longtext, 
	[PPAP] int, 
	[DISPO] varchar(1), 
	[ITEM] double, 
	[PRAZO] datetime, 
	[APROVADO] datetime, 
	[dispnome] varchar(40), 
	[dispdate] datetime, 
	[dispnum] int
);

-- Tabela: PPAPP
CREATE TABLE IF NOT EXISTS [PPAPP] (
	[PPAP] int, 
	[CODIGO] varchar(50), 
	[PF] int
);

-- Tabela: REV
CREATE TABLE IF NOT EXISTS [REV] (
	[PF] double, 
	[TIPO] varchar(3), 
	[REVISAO] int, 
	[DATA] datetime, 
	[recsetor] varchar(40), 
	[recnome] varchar(40), 
	[copias] int, 
	[copiasdev] int, 
	[copiasext] int, 
	[obsoleto] varchar(40), 
	[recnum] int, 
	[datarec] datetime
);

-- Tabela: REVI
CREATE TABLE IF NOT EXISTS [REVI] (
	[PF] double, 
	[TIPO] varchar(3), 
	[REVISAO] int, 
	[ITEM] int, 
	[MOTIVO] longtext
);

-- �ndice: IDXAP_SEQ
CREATE INDEX IF NOT EXISTS [IDXAP_SEQ]
	ON [AP] ([SEQ]);

-- �ndice: IDXCFLX_LETRA
CREATE INDEX IF NOT EXISTS [IDXCFLX_LETRA]
	ON [CFLX] ([LETRA]);

-- �ndice: IDXCFLX_NUMERO
CREATE INDEX IF NOT EXISTS [IDXCFLX_NUMERO]
	ON [CFLX] ([NUMERO]);

-- �ndice: IDXDUPLICAR_TABELA_CAMPO
CREATE INDEX IF NOT EXISTS [IDXDUPLICAR_TABELA_CAMPO]
	ON [DUPLICAR] ([TABELA], [CAMPO]);

-- �ndice: IDXFEMEA_ITEM
CREATE INDEX IF NOT EXISTS [IDXFEMEA_ITEM]
	ON [FEMEA] ([ITEM]);

-- �ndice: IDXFEMEA_PF
CREATE INDEX IF NOT EXISTS [IDXFEMEA_PF]
	ON [FEMEA] ([PF]);

-- �ndice: IDXFEMEA_PF_ITEM
CREATE INDEX IF NOT EXISTS [IDXFEMEA_PF_ITEM]
	ON [FEMEA] ([PF], [ITEM]);

-- �ndice: IDXFEMEA_PF_ITEM2
CREATE INDEX IF NOT EXISTS [IDXFEMEA_PF_ITEM2]
	ON [FEMEA] ([PF], [ITEM]);

-- �ndice: IDXIED_TIPO
CREATE INDEX IF NOT EXISTS [IDXIED_TIPO]
	ON [IED] ([TIPO]);

-- �ndice: IDXPF_CLIENTE
CREATE INDEX IF NOT EXISTS [IDXPF_CLIENTE]
	ON [PF] ([CLIENTE]);

-- �ndice: IDXPF_CODFINAL
CREATE INDEX IF NOT EXISTS [IDXPF_CODFINAL]
	ON [PF] ([CODFINAL]);

-- �ndice: IDXPF_CODIGO
CREATE INDEX IF NOT EXISTS [IDXPF_CODIGO]
	ON [PF] ([CODIGO]);

-- �ndice: IDXPFC_pf
CREATE INDEX IF NOT EXISTS [IDXPFC_pf]
	ON [PFC] ([pf]);

-- �ndice: IDXPFC_pf_seq_ssq_item
CREATE INDEX IF NOT EXISTS [IDXPFC_pf_seq_ssq_item]
	ON [PFC] ([pf], [seq], [ssq], [item]);

-- �ndice: IDXPFCMS03_PF
CREATE INDEX IF NOT EXISTS [IDXPFCMS03_PF]
	ON [PFCMS03] ([PF]);

-- �ndice: IDXPFCMS03_PF_CODCOMP_ITEM
CREATE INDEX IF NOT EXISTS [IDXPFCMS03_PF_CODCOMP_ITEM]
	ON [PFCMS03] ([PF], [CODCOMP], [ITEM]);

-- �ndice: IDXpfco_PF
CREATE INDEX IF NOT EXISTS [IDXpfco_PF]
	ON [pfco] ([PF]);

-- �ndice: IDXpfco_PF_SEQ_SSQ_ITEM
CREATE INDEX IF NOT EXISTS [IDXpfco_PF_SEQ_SSQ_ITEM]
	ON [pfco] ([PF], [SEQ], [SSQ], [ITEM]);

-- �ndice: IDXPFI_ITEM
CREATE INDEX IF NOT EXISTS [IDXPFI_ITEM]
	ON [PFI] ([ITEM]);

-- �ndice: IDXPFI_PF
CREATE INDEX IF NOT EXISTS [IDXPFI_PF]
	ON [PFI] ([PF]);

-- �ndice: IDXPFI_PF_SEQ_SSQ_ITEM
CREATE INDEX IF NOT EXISTS [IDXPFI_PF_SEQ_SSQ_ITEM]
	ON [PFI] ([PF], [SEQ], [SSQ], [ITEM]);

-- �ndice: IDXPFMS03_CODCOMP
CREATE INDEX IF NOT EXISTS [IDXPFMS03_CODCOMP]
	ON [PFMS03] ([CODCOMP]);

-- �ndice: IDXPFMS03_PF
CREATE INDEX IF NOT EXISTS [IDXPFMS03_PF]
	ON [PFMS03] ([PF]);

-- �ndice: IDXPFMS03_PF_CODCOMP
CREATE INDEX IF NOT EXISTS [IDXPFMS03_PF_CODCOMP]
	ON [PFMS03] ([PF], [CODCOMP]);

-- �ndice: IDXPFMS03_PF_TIPOENT_CODCOMP
CREATE INDEX IF NOT EXISTS [IDXPFMS03_PF_TIPOENT_CODCOMP]
	ON [PFMS03] ([PF], [TIPOENT], [CODCOMP]);

-- �ndice: IDXPFQSBLEP_ITEM
CREATE INDEX IF NOT EXISTS [IDXPFQSBLEP_ITEM]
	ON [PFQSBLEP] ([ITEM]);

-- �ndice: IDXPFQSBLEP_PF
CREATE INDEX IF NOT EXISTS [IDXPFQSBLEP_PF]
	ON [PFQSBLEP] ([PF]);

-- �ndice: IDXPFQSBLEP_PF_SEQ_SSQ_ITEM
CREATE INDEX IF NOT EXISTS [IDXPFQSBLEP_PF_SEQ_SSQ_ITEM]
	ON [PFQSBLEP] ([PF], [SEQ], [SSQ], [ITEM]);

-- �ndice: IDXPFREV_PF
CREATE INDEX IF NOT EXISTS [IDXPFREV_PF]
	ON [PFREV] ([PF]);

-- �ndice: IDXPFREV_PF_REV
CREATE INDEX IF NOT EXISTS [IDXPFREV_PF_REV]
	ON [PFREV] ([PF], [REV]);

-- �ndice: IDXPFS_CODINT
CREATE INDEX IF NOT EXISTS [IDXPFS_CODINT]
	ON [PFS] ([CODINT]);

-- �ndice: IDXPFS_PF
CREATE INDEX IF NOT EXISTS [IDXPFS_PF]
	ON [PFS] ([PF]);

-- �ndice: IDXPFS_PF_SEQ_SSQ
CREATE INDEX IF NOT EXISTS [IDXPFS_PF_SEQ_SSQ]
	ON [PFS] ([PF], [SEQ], [SSQ]);

-- �ndice: IDXPFSCHECKLIST_PF_SEQ_SSQ_ORDEM
CREATE INDEX IF NOT EXISTS [IDXPFSCHECKLIST_PF_SEQ_SSQ_ORDEM]
	ON [PFSCHECKLIST] ([PF], [SEQ], [SSQ], [ORDEM]);

-- �ndice: IDXpfso_PF
CREATE INDEX IF NOT EXISTS [IDXpfso_PF]
	ON [pfso] ([PF]);

-- �ndice: IDXpfso_PF_SEQ_SSQ
CREATE INDEX IF NOT EXISTS [IDXpfso_PF_SEQ_SSQ]
	ON [pfso] ([PF], [SEQ], [SSQ]);

-- �ndice: IDXpfso_SEQ
CREATE INDEX IF NOT EXISTS [IDXpfso_SEQ]
	ON [pfso] ([SEQ]);

-- �ndice: IDXpfso_SSQ
CREATE INDEX IF NOT EXISTS [IDXpfso_SSQ]
	ON [pfso] ([SSQ]);

-- �ndice: IDXPFSONTHEJOB_PF_SEQ_SSQ_ORDEM
CREATE INDEX IF NOT EXISTS [IDXPFSONTHEJOB_PF_SEQ_SSQ_ORDEM]
	ON [PFSONTHEJOB] ([PF], [SEQ], [SSQ], [ORDEM]);

-- �ndice: IDXREV_PF
CREATE INDEX IF NOT EXISTS [IDXREV_PF]
	ON [REV] ([PF]);

-- �ndice: IDXREV_PF_TIPO_REVISAO
CREATE INDEX IF NOT EXISTS [IDXREV_PF_TIPO_REVISAO]
	ON [REV] ([PF], [TIPO], [REVISAO]);

-- �ndice: IDXREVI_PF
CREATE INDEX IF NOT EXISTS [IDXREVI_PF]
	ON [REVI] ([PF]);

-- �ndice: IDXREVI_PF_TIPO_REVISAO_ITEM
CREATE INDEX IF NOT EXISTS [IDXREVI_PF_TIPO_REVISAO_ITEM]
	ON [REVI] ([PF], [TIPO], [REVISAO], [ITEM]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
