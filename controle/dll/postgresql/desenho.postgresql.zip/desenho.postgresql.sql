--
-- DUMP FILE
--
-- Database is ported from MS Access
--------------------------------------------------------------------
-- Created using "MS Access to PostgreSQL" form http://www.bullzip.com
-- Program Version 5.5.281
--
-- OPTIONS:
--   sourcefilename=C:/Users/jcass/Downloads/desenho.mdb
--   sourceusername=
--   sourcepassword=
--   sourcesystemdatabase=
--   destinationserver=localhost
--   destinationdatabase=desenho
--   maintenancedb=postgres
--   dropdatabase=0
--   createtables=1
--   unicode=0
--   autocommit=1
--   transferdefaultvalues=1
--   transferindexes=1
--   transferautonumbers=1
--   transferrecords=0
--   columnlist=1
--   tableprefix=
--   negativeboolean=0
--   ignorelargeblobs=0
--   memotype=TEXT
--   datetimetype=TIMESTAMP
--

CREATE DATABASE "desenho";

-- NOTICE: At this place you need to connect to the new database and run the rest of the statements.

--
-- Table structure for table 'atual'
--

DROP TABLE IF EXISTS "atual";

CREATE TABLE "atual" (
  "conjunto" VARCHAR(50), 
  "desenho" VARCHAR(50), 
  "descricao" VARCHAR(200), 
  "rev" INTEGER, 
  "data" TIMESTAMP, 
  "recebido" TIMESTAMP, 
  "obs" TEXT, 
  "padronizado" BOOLEAN, 
  "fitadat" INTEGER, 
  "cdrom" INTEGER, 
  "revc" VARCHAR(2)
);

--
-- Table structure for table 'baixado'
--

DROP TABLE IF EXISTS "baixado";

CREATE TABLE "baixado" (
  "conjunto" VARCHAR(50), 
  "desenho" VARCHAR(50), 
  "descricao" VARCHAR(200), 
  "rev" INTEGER, 
  "data" TIMESTAMP, 
  "recebido" TIMESTAMP, 
  "obs" TEXT, 
  "padronizado" BOOLEAN, 
  "fitadat" INTEGER, 
  "cdrom" INTEGER, 
  "revc" VARCHAR(2)
);

--
-- Table structure for table 'CLIENTE'
--

DROP TABLE IF EXISTS "CLIENTE";

CREATE TABLE "CLIENTE" (
  "CLIENTE" INTEGER, 
  "CLINOME" VARCHAR(50)
);

--
-- Table structure for table 'conjunto'
--

DROP TABLE IF EXISTS "conjunto";

CREATE TABLE "conjunto" (
  "conjunto" VARCHAR(50), 
  "cliente" INTEGER, 
  "clinome" VARCHAR(50), 
  "descricao" VARCHAR(200)
);

--
-- Table structure for table 'PRODENG'
--

DROP TABLE IF EXISTS "PRODENG";

CREATE TABLE "PRODENG" (
  "TIPO" VARCHAR(1), 
  "NUMERO" INTEGER, 
  "PRODUTO" VARCHAR(50), 
  "NOME" VARCHAR(200), 
  "DATA" TIMESTAMP, 
  "REVISAO" VARCHAR(10), 
  "RESCLI" VARCHAR(15)
);

--
-- Table structure for table 'PRODUTO'
--

DROP TABLE IF EXISTS "PRODUTO";

CREATE TABLE "PRODUTO" (
  "CLIENTE" INTEGER, 
  "NUMERO" INTEGER, 
  "CODIGO" VARCHAR(50), 
  "NOME" VARCHAR(50), 
  "INATIVO" BOOLEAN, 
  "ITEM" INTEGER
);

--
-- Table structure for table 'PROTO'
--

DROP TABLE IF EXISTS "PROTO";

CREATE TABLE "PROTO" (
  "CLIENTE" INTEGER, 
  "CLINOME" VARCHAR(50), 
  "PARTNUMBER" VARCHAR(50), 
  "PROJETO" VARCHAR(50), 
  "NOME" VARCHAR(50), 
  "COTACAO" BOOLEAN, 
  "ENGENHEIRO" VARCHAR(50), 
  "COTDATA" TIMESTAMP, 
  "COTVAL" DOUBLE PRECISION NULL, 
  "ENGRAMAL" VARCHAR(50)
);

--
-- Table structure for table 'PROTOI'
--

DROP TABLE IF EXISTS "PROTOI";

CREATE TABLE "PROTOI" (
  "PARTNUMBER" VARCHAR(50), 
  "PEDDATA" TIMESTAMP, 
  "PEDIDO" VARCHAR(50), 
  "PEDENTR" TIMESTAMP, 
  "QTDDE" INTEGER, 
  "VALOR" DOUBLE PRECISION NULL, 
  "SSMT" VARCHAR(50), 
  "SSMTDAT" TIMESTAMP, 
  "FASE" VARCHAR(50), 
  "DESENHO" VARCHAR(50), 
  "SSMTREQ" TIMESTAMP, 
  "COMPRADOR" VARCHAR(50), 
  "GP11" BOOLEAN, 
  "GP11DAPR" TIMESTAMP, 
  "TELEFONE" VARCHAR(50), 
  "GP11DFIN" VARCHAR(50), 
  "NFNUMERO" VARCHAR(50), 
  "ENTRDATA" TIMESTAMP, 
  "NFTIPO" VARCHAR(1), 
  "ENTREGA" VARCHAR(50), 
  "NFDATA" TIMESTAMP, 
  "OBS" TEXT, 
  "DESENH2" VARCHAR(50), 
  "PPAP" INTEGER, 
  "DESENH3" VARCHAR(50), 
  "REV" VARCHAR(50), 
  "RE2" VARCHAR(50), 
  "RE3" VARCHAR(50)
);

