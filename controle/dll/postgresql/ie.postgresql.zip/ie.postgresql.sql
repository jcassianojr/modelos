--
-- DUMP FILE
--
-- Database is ported from MS Access
--------------------------------------------------------------------
-- Created using "MS Access to PostgreSQL" form http://www.bullzip.com
-- Program Version 5.5.281
--
-- OPTIONS:
--   sourcefilename=C:/Users/jcass/Downloads/ie.mdb
--   sourceusername=
--   sourcepassword=
--   sourcesystemdatabase=
--   destinationserver=localhost
--   destinationdatabase=ie
--   maintenancedb=postgres
--   dropdatabase=0
--   createtables=1
--   unicode=0
--   autocommit=1
--   transferdefaultvalues=1
--   transferindexes=1
--   transferautonumbers=1
--   transferrecords=0
--   columnlist=1
--   tableprefix=
--   negativeboolean=0
--   ignorelargeblobs=0
--   memotype=TEXT
--   datetimetype=TIMESTAMP
--

CREATE DATABASE "ie";

-- NOTICE: At this place you need to connect to the new database and run the rest of the statements.

--
-- Table structure for table 'IE'
--

DROP TABLE IF EXISTS "IE";

CREATE TABLE "IE" (
  "PF" DOUBLE PRECISION NOT NULL DEFAULT 0, 
  "DETALHE" TEXT, 
  "TIPO" TEXT, 
  "FECHA" TEXT, 
  "NPED" DOUBLE PRECISION NULL DEFAULT 0, 
  "IDENT" TEXT, 
  "PROTE" TEXT, 
  "QML" DOUBLE PRECISION NULL DEFAULT 0, 
  "COM" DOUBLE PRECISION NULL DEFAULT 0, 
  "LAR" DOUBLE PRECISION NULL DEFAULT 0, 
  "ALT" DOUBLE PRECISION NULL DEFAULT 0, 
  "UND" DOUBLE PRECISION NULL DEFAULT 0, 
  "TOTL" DOUBLE PRECISION NULL DEFAULT 0, 
  "TARA" DOUBLE PRECISION NULL DEFAULT 0, 
  "BRUTO" DOUBLE PRECISION NULL DEFAULT 0, 
  "METODO" TEXT, 
  "OBS" TEXT, 
  "IMAGEM" TEXT, 
  "DATA" TIMESTAMP, 
  "REVISAO" DOUBLE PRECISION NULL DEFAULT 0, 
  "LOCAL" TEXT, 
  "CODMR01" VARCHAR(10), 
  "NOMMR01" VARCHAR(100), 
  "DATAREV" TIMESTAMP, 
  "FOTOESQ" TEXT, 
  "FOTODIR" TEXT, 
  "CODDIR" VARCHAR(50), 
  "CODESQ" VARCHAR(50), 
  "CODIGOINT" VARCHAR(50), 
  "codigocli" VARCHAR(50), 
  "elaborador" VARCHAR(40), 
  PRIMARY KEY ("PF")
);

