--
-- DUMP FILE
--
-- Database is ported from MS Access
--------------------------------------------------------------------
-- Created using "MS Access to PostgreSQL" form http://www.bullzip.com
-- Program Version 5.5.281
--
-- OPTIONS:
--   sourcefilename=C:/Users/jcass/Downloads/poa.mdb
--   sourceusername=
--   sourcepassword=
--   sourcesystemdatabase=
--   destinationserver=localhost
--   destinationdatabase=poa
--   maintenancedb=postgres
--   dropdatabase=0
--   createtables=1
--   unicode=0
--   autocommit=1
--   transferdefaultvalues=1
--   transferindexes=1
--   transferautonumbers=1
--   transferrecords=0
--   columnlist=1
--   tableprefix=
--   negativeboolean=0
--   ignorelargeblobs=0
--   memotype=TEXT
--   datetimetype=TIMESTAMP
--

CREATE DATABASE "poa";

-- NOTICE: At this place you need to connect to the new database and run the rest of the statements.

--
-- Table structure for table 'DISPO'
--

DROP TABLE IF EXISTS "DISPO";

CREATE TABLE "DISPO" (
  "NUMERO" INTEGER, 
  "pf" DOUBLE PRECISION NULL, 
  "seq" DOUBLE PRECISION NULL, 
  "ssq" DOUBLE PRECISION NULL, 
  "RESDAT" TIMESTAMP, 
  "RESNUM" INTEGER, 
  "RESNOM" VARCHAR(60), 
  "ELANOM" VARCHAR(60), 
  "ELADAT" TIMESTAMP, 
  "ELANUM" INTEGER, 
  "CODIGO" VARCHAR(24), 
  "CODIGOINT" VARCHAR(24), 
  "NOME" VARCHAR(50), 
  "revisao" INTEGER, 
  "datarev" TIMESTAMP, 
  "item" INTEGER
);

--
-- Table structure for table 'DISPOI'
--

DROP TABLE IF EXISTS "DISPOI";

CREATE TABLE "DISPOI" (
  "NUMERO" INTEGER, 
  "ITEM" DOUBLE PRECISION NULL, 
  "DESCRICAO" VARCHAR(255), 
  "imagem" TEXT
);

--
-- Table structure for table 'POA'
--

DROP TABLE IF EXISTS "POA";

CREATE TABLE "POA" (
  "NUMERO" INTEGER, 
  "CODIGO" VARCHAR(24), 
  "NOME" VARCHAR(50), 
  "PROBLEMA" TEXT, 
  "NUMFUN" INTEGER, 
  "NOMFUN" VARCHAR(50), 
  "ANALISE" TEXT, 
  "SAC" INTEGER, 
  "DATASAC" TIMESTAMP, 
  "FOTO" TEXT, 
  "SACSN" VARCHAR(1), 
  "pf" DOUBLE PRECISION NULL, 
  "seq" DOUBLE PRECISION NULL, 
  "ssq" DOUBLE PRECISION NULL, 
  "RESDAT" TIMESTAMP, 
  "RESNUM" INTEGER, 
  "RESNOM" VARCHAR(60), 
  "ELANOM" VARCHAR(60), 
  "ELADAT" TIMESTAMP, 
  "ELANUM" INTEGER, 
  "item" INTEGER
);

--
-- Table structure for table 'POKA'
--

DROP TABLE IF EXISTS "POKA";

CREATE TABLE "POKA" (
  "NUMERO" INTEGER, 
  "PASSO01" TEXT, 
  "PASSO02" TEXT, 
  "PASSO03" TEXT, 
  "PASSO04" TEXT, 
  "OBSPASSO01" TEXT, 
  "OBSPASSO02" TEXT, 
  "OBSPASSO03" TEXT, 
  "OBSPASSO04" TEXT, 
  "5SOQUE" VARCHAR(255), 
  "5SCOMO" VARCHAR(255), 
  "5SPORQUE" VARCHAR(255), 
  "5SONDE" VARCHAR(255), 
  "FOTOPASSO01" TEXT, 
  "FOTOPASSO02" TEXT, 
  "FOTOPASSO03" TEXT, 
  "FOTOPASSO04" TEXT, 
  "pf" DOUBLE PRECISION NULL, 
  "seq" DOUBLE PRECISION NULL, 
  "ssq" DOUBLE PRECISION NULL, 
  "RESDAT" TIMESTAMP, 
  "RESNUM" INTEGER, 
  "RESNOM" VARCHAR(60), 
  "ELANOM" VARCHAR(60), 
  "ELADAT" TIMESTAMP, 
  "ELANUM" INTEGER, 
  "CODIGO" VARCHAR(24), 
  "NOME" VARCHAR(50), 
  "5SOQUEm" VARCHAR(255), 
  "revisao" INTEGER, 
  "datarev" TIMESTAMP, 
  "item" INTEGER
);

