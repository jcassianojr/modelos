--
-- DUMP FILE
--
-- Database is ported from MS Access
--------------------------------------------------------------------
-- Created using "MS Access to PostgreSQL" form http://www.bullzip.com
-- Program Version 5.5.281
--
-- OPTIONS:
--   sourcefilename=C:/Users/jcass/Downloads/ppap.mdb
--   sourceusername=
--   sourcepassword=
--   sourcesystemdatabase=
--   destinationserver=localhost
--   destinationdatabase=ppap
--   maintenancedb=postgres
--   dropdatabase=0
--   createtables=1
--   unicode=0
--   autocommit=1
--   transferdefaultvalues=1
--   transferindexes=1
--   transferautonumbers=1
--   transferrecords=0
--   columnlist=1
--   tableprefix=
--   negativeboolean=0
--   ignorelargeblobs=0
--   memotype=TEXT
--   datetimetype=TIMESTAMP
--

CREATE DATABASE "ppap";

-- NOTICE: At this place you need to connect to the new database and run the rest of the statements.

--
-- Table structure for table 'PPAF'
--

DROP TABLE IF EXISTS "PPAF";

CREATE TABLE "PPAF" (
  "CLIENTE" INTEGER, 
  "CLINOME" VARCHAR(50), 
  "COMPRADOR" VARCHAR(5), 
  "COMNOME" VARCHAR(40), 
  "CODIGO" VARCHAR(24), 
  "NOME" VARCHAR(40), 
  "DATAALT" TIMESTAMP, 
  "ITEM" BOOLEAN, 
  "PESO" DOUBLE PRECISION NULL, 
  "OBSADC01" VARCHAR(80), 
  "OBSADC02" VARCHAR(80), 
  "SUB01" BOOLEAN, 
  "SUB02" BOOLEAN, 
  "SUB03" BOOLEAN, 
  "SUB04" BOOLEAN, 
  "SUB05" BOOLEAN, 
  "SUB06" BOOLEAN, 
  "SUB07" BOOLEAN, 
  "SUB08" BOOLEAN, 
  "SUB09" BOOLEAN, 
  "NIVEL" VARCHAR(1), 
  "RES01" BOOLEAN, 
  "RES02" BOOLEAN, 
  "RES03" BOOLEAN, 
  "RES04" BOOLEAN, 
  "APLIC" BOOLEAN, 
  "SUB10" BOOLEAN, 
  "DESENHO" VARCHAR(80), 
  "NOT01" BOOLEAN, 
  "NOT02" BOOLEAN, 
  "INF01" BOOLEAN, 
  "INF02" BOOLEAN, 
  "INF03" BOOLEAN, 
  "EXPOSTO" VARCHAR(80), 
  "PEDOM" VARCHAR(80), 
  "AUXILIAR" VARCHAR(80), 
  "NIVELALT" VARCHAR(80), 
  "NIVELDAT" TIMESTAMP, 
  "DIVISAO" VARCHAR(80), 
  "APLICACAO" VARCHAR(80), 
  "DATA" TIMESTAMP, 
  "MOLDE" VARCHAR(50), 
  "DISPO" VARCHAR(1), 
  "APRO" VARCHAR(1), 
  "RESNOME" VARCHAR(50), 
  "RESCARGO" VARCHAR(50), 
  "EXP01" VARCHAR(150), 
  "EXP02" VARCHAR(150), 
  "TIPCOM" VARCHAR(1), 
  "CODCOM" VARCHAR(24), 
  "NOMCOM" VARCHAR(50), 
  "FORNECEDOR" INTEGER, 
  "FORNOM" VARCHAR(50), 
  "PPAP" SERIAL, 
  "COMPRAS" INTEGER, 
  "COMITEM" INTEGER, 
  "PRGENT" INTEGER, 
  "INATIVO" BOOLEAN, 
  "SITUACAO" VARCHAR(1), 
  "PF" INTEGER
);

--
-- Table structure for table 'PPAFC'
--

DROP TABLE IF EXISTS "PPAFC";

CREATE TABLE "PPAFC" (
  "PPAP" INTEGER, 
  "DATA" TIMESTAMP, 
  "PREVISTO" TIMESTAMP, 
  "EFETUADO" TIMESTAMP, 
  "OBS" TEXT, 
  "DISPO" VARCHAR(1), 
  "CODIGO" VARCHAR(50), 
  "ITEM" SERIAL
);

--
-- Table structure for table 'PPAFI'
--

DROP TABLE IF EXISTS "PPAFI";

CREATE TABLE "PPAFI" (
  "DATA" TIMESTAMP, 
  "OBS" TEXT, 
  "DISPO" VARCHAR(1), 
  "ITEM" DOUBLE PRECISION NULL, 
  "PPAP" INTEGER, 
  "PRAZO" TIMESTAMP, 
  "APROVADO" TIMESTAMP, 
  "dispnome" VARCHAR(40), 
  "dispdate" TIMESTAMP, 
  "dispnum" INTEGER
);

--
-- Table structure for table 'PPAFP'
--

DROP TABLE IF EXISTS "PPAFP";

CREATE TABLE "PPAFP" (
  "PPAP" INTEGER, 
  "CODIGO" VARCHAR(50), 
  "PF" INTEGER
);

--
-- Table structure for table 'PPAG'
--

DROP TABLE IF EXISTS "PPAG";

CREATE TABLE "PPAG" (
  "CLIENTE" INTEGER, 
  "CLINOME" VARCHAR(50), 
  "COMPRADOR" VARCHAR(5), 
  "COMNOME" VARCHAR(40), 
  "CODIGO" VARCHAR(24), 
  "NOME" VARCHAR(40), 
  "DATAALT" TIMESTAMP, 
  "ITEM" BOOLEAN, 
  "PESO" DOUBLE PRECISION NULL, 
  "OBSADC01" VARCHAR(80), 
  "OBSADC02" VARCHAR(80), 
  "SUB01" BOOLEAN, 
  "SUB02" BOOLEAN, 
  "SUB03" BOOLEAN, 
  "SUB04" BOOLEAN, 
  "SUB05" BOOLEAN, 
  "SUB06" BOOLEAN, 
  "SUB07" BOOLEAN, 
  "SUB08" BOOLEAN, 
  "SUB09" BOOLEAN, 
  "NIVEL" VARCHAR(1), 
  "RES01" BOOLEAN, 
  "RES02" BOOLEAN, 
  "RES03" BOOLEAN, 
  "RES04" BOOLEAN, 
  "APLIC" BOOLEAN, 
  "SUB10" BOOLEAN, 
  "DESENHO" VARCHAR(80), 
  "NOT01" BOOLEAN, 
  "NOT02" BOOLEAN, 
  "INF01" BOOLEAN, 
  "INF02" BOOLEAN, 
  "INF03" BOOLEAN, 
  "EXPOSTO" VARCHAR(80), 
  "PEDOM" VARCHAR(80), 
  "AUXILIAR" VARCHAR(80), 
  "NIVELALT" VARCHAR(80), 
  "NIVELDAT" TIMESTAMP, 
  "DIVISAO" VARCHAR(80), 
  "APLICACAO" VARCHAR(80), 
  "DATA" TIMESTAMP, 
  "MOLDE" VARCHAR(50), 
  "DISPO" VARCHAR(1), 
  "APRO" VARCHAR(1), 
  "RESNOME" VARCHAR(50), 
  "RESCARGO" VARCHAR(50), 
  "EXP01" VARCHAR(150), 
  "EXP02" VARCHAR(150), 
  "TIPCOM" VARCHAR(1), 
  "CODCOM" VARCHAR(24), 
  "NOMCOM" VARCHAR(50), 
  "FORNECEDOR" INTEGER, 
  "FORNOM" VARCHAR(50), 
  "COMPRAS" INTEGER, 
  "COMITEM" INTEGER, 
  "PRGENT" INTEGER, 
  "INATIVO" BOOLEAN, 
  "SITUACAO" VARCHAR(1), 
  "PF" INTEGER, 
  "PPAP" SERIAL, 
  "SSMT" VARCHAR(50)
);

--
-- Table structure for table 'PPAGC'
--

DROP TABLE IF EXISTS "PPAGC";

CREATE TABLE "PPAGC" (
  "PPAP" INTEGER, 
  "DATA" TIMESTAMP, 
  "PREVISTO" TIMESTAMP, 
  "EFETUADO" TIMESTAMP, 
  "OBS" TEXT, 
  "DISPO" VARCHAR(1), 
  "CODIGO" VARCHAR(50), 
  "ITEM" SERIAL
);

--
-- Table structure for table 'PPAGI'
--

DROP TABLE IF EXISTS "PPAGI";

CREATE TABLE "PPAGI" (
  "DATA" TIMESTAMP, 
  "OBS" TEXT, 
  "DISPO" VARCHAR(1), 
  "ITEM" DOUBLE PRECISION NULL, 
  "PPAP" INTEGER, 
  "PRAZO" TIMESTAMP, 
  "APROVADO" TIMESTAMP, 
  "dispnome" VARCHAR(40), 
  "dispdate" TIMESTAMP, 
  "dispnum" INTEGER
);

--
-- Table structure for table 'PPAGP'
--

DROP TABLE IF EXISTS "PPAGP";

CREATE TABLE "PPAGP" (
  "PPAP" INTEGER, 
  "CODIGO" VARCHAR(50), 
  "PF" INTEGER
);

--
-- Table structure for table 'PPAP'
--

DROP TABLE IF EXISTS "PPAP";

CREATE TABLE "PPAP" (
  "CLIENTE" INTEGER, 
  "CLINOME" VARCHAR(50), 
  "COMPRADOR" VARCHAR(5), 
  "COMNOME" VARCHAR(40), 
  "CODIGO" VARCHAR(24), 
  "NOME" VARCHAR(40), 
  "DATAALT" TIMESTAMP, 
  "ITEM" BOOLEAN, 
  "PESO" DOUBLE PRECISION NULL, 
  "OBSADC01" VARCHAR(80), 
  "OBSADC02" VARCHAR(80), 
  "SUB01" BOOLEAN, 
  "SUB02" BOOLEAN, 
  "SUB03" BOOLEAN, 
  "SUB04" BOOLEAN, 
  "SUB05" BOOLEAN, 
  "SUB06" BOOLEAN, 
  "SUB07" BOOLEAN, 
  "SUB08" BOOLEAN, 
  "SUB09" BOOLEAN, 
  "NIVEL" VARCHAR(1), 
  "RES01" BOOLEAN, 
  "RES02" BOOLEAN, 
  "RES03" BOOLEAN, 
  "RES04" BOOLEAN, 
  "APLIC" BOOLEAN, 
  "SUB10" BOOLEAN, 
  "DESENHO" VARCHAR(80), 
  "NOT01" BOOLEAN, 
  "NOT02" BOOLEAN, 
  "INF01" BOOLEAN, 
  "INF02" BOOLEAN, 
  "INF03" BOOLEAN, 
  "EXPOSTO" VARCHAR(80), 
  "PEDOM" VARCHAR(80), 
  "AUXILIAR" VARCHAR(80), 
  "NIVELALT" VARCHAR(80), 
  "NIVELDAT" TIMESTAMP, 
  "DIVISAO" VARCHAR(80), 
  "APLICACAO" VARCHAR(80), 
  "DATA" TIMESTAMP, 
  "MOLDE" VARCHAR(50), 
  "DISPO" VARCHAR(1), 
  "APRO" VARCHAR(1), 
  "RESNOME" VARCHAR(50), 
  "RESCARGO" VARCHAR(50), 
  "EXP01" VARCHAR(150), 
  "EXP02" VARCHAR(150), 
  "PPAP" SERIAL, 
  "TIPCOM" VARCHAR(1), 
  "CODCOM" VARCHAR(24), 
  "NOMCOM" VARCHAR(50), 
  "FORNECEDOR" INTEGER, 
  "FORNOM" VARCHAR(50), 
  "COMPRAS" INTEGER, 
  "COMITEM" INTEGER, 
  "PRGENT" INTEGER, 
  "INATIVO" BOOLEAN, 
  "SITUACOA" VARCHAR(1), 
  "PF" INTEGER
);

--
-- Table structure for table 'PPAPC'
--

DROP TABLE IF EXISTS "PPAPC";

CREATE TABLE "PPAPC" (
  "PPAP" INTEGER, 
  "DATA" TIMESTAMP, 
  "PREVISTO" TIMESTAMP, 
  "EFETUADO" TIMESTAMP, 
  "OBS" TEXT, 
  "DISPO" VARCHAR(1), 
  "CODIGO" VARCHAR(50), 
  "item" SERIAL
);

--
-- Table structure for table 'PPAPI'
--

DROP TABLE IF EXISTS "PPAPI";

CREATE TABLE "PPAPI" (
  "DATA" TIMESTAMP, 
  "OBS" TEXT, 
  "PPAP" INTEGER, 
  "DISPO" VARCHAR(1), 
  "ITEM" DOUBLE PRECISION NULL, 
  "PRAZO" TIMESTAMP, 
  "APROVADO" TIMESTAMP, 
  "dispnome" VARCHAR(40), 
  "dispdate" TIMESTAMP, 
  "dispnum" INTEGER
);

--
-- Table structure for table 'PPAPP'
--

DROP TABLE IF EXISTS "PPAPP";

CREATE TABLE "PPAPP" (
  "PPAP" INTEGER, 
  "CODIGO" VARCHAR(50), 
  "PF" INTEGER
);

