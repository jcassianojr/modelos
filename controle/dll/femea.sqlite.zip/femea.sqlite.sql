--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 17:17:48 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: FEMADC
CREATE TABLE IF NOT EXISTS [FEMADC] (
	[FALTIP] longtext, 
	[FALEFE] longtext, 
	[FALCAU] longtext, 
	[CRTATU] longtext, 
	[INDOCO] double, 
	[INDSEV] double, 
	[INDDET] double, 
	[INDRIS] double, 
	[TITULO] varchar(50), 
	[SEGGRA] int, 
	[CARAPREV] longtext, 
	[ACAREC] longtext, 
	[ACATOM] longtext, 
	[RINDSER] double, 
	[RINDOCO] double, 
	[RINDDET] double, 
	[RINDRIS] double, 
	[CRATU] longtext, 
	[SITUACAO] varchar(1), 
	[ACAO] boolean NOT NULL, 
	[ACADAT] datetime, 
	[SIGI] varchar(1), 
	[RESCOD] int, 
	[RESCOD3] int, 
	[RESNOM] varchar(40), 
	[RESNOM2] varchar(40), 
	[RESNOM3] varchar(40), 
	[RESDAT] datetime, 
	[RESDAT2] datetime, 
	[RESDAT3] datetime, 
	[RESCOD2] int, 
	[PRONUM] smallint, 
	[FALNUM] smallint, 
	[EFENUM] smallint, 
	[CAUNUM] smallint, 
	[PROCESSO] varchar(255), 
	[ITEM] smallint, 
	[EXCRPN] boolean NOT NULL, 
	[ALTMAN] boolean NOT NULL, 
	[MUDPAD] boolean NOT NULL, 
	[PF] double, 
	[PSA] varchar(20), 
	[FXSEQ] smallint, 
	[FXSSQ] smallint, 
	[FXITEM] smallint, 
	[BLOQUEADO] boolean NOT NULL, 
	[TIPOAPU] varchar(1), 
	[SIG2] varchar(1), 
	[SIG3] varchar(1), 
	[subtipo] varchar(1), 
	[fxitems] int, 
	[FEMEAREV] double, 
	[elemento] varchar(200), 
	[estacao] varchar(200), 
	[trabalho] varchar(200), 
	[funcaoitem] varchar(200), 
	[funcaoetapa] varchar(200), 
	[funcaoelemento] varchar(200), 
	[pafemea] varchar(1), 
	[caraespecial] varchar(1), 
	[filtroespecial] varchar(1), 
	[acaoprev] varchar(200), 
	[acaodet] varchar(200), 
	[rpafemea] varchar(1), 
	[observacao] varchar(200)
);

-- Tabela: FEMAVU
CREATE TABLE IF NOT EXISTS [FEMAVU] (
	[FALTIP] longtext, 
	[FALEFE] longtext, 
	[FALCAU] longtext, 
	[CRTATU] longtext, 
	[INDOCO] double, 
	[INDSEV] double, 
	[INDDET] double, 
	[INDRIS] double, 
	[TITULO] varchar(50), 
	[SEGGRA] int, 
	[CARAPREV] longtext, 
	[ACAREC] longtext, 
	[ACATOM] longtext, 
	[RINDSER] double, 
	[RINDOCO] double, 
	[RINDDET] double, 
	[RINDRIS] double, 
	[CRATU] longtext, 
	[SITUACAO] varchar(1), 
	[ACAO] boolean NOT NULL, 
	[ACADAT] datetime, 
	[SIGI] varchar(1), 
	[RESCOD] int, 
	[RESCOD3] int, 
	[RESNOM] varchar(40), 
	[RESNOM2] varchar(40), 
	[RESNOM3] varchar(40), 
	[RESDAT] datetime, 
	[RESDAT2] datetime, 
	[RESDAT3] datetime, 
	[RESCOD2] int, 
	[PRONUM] smallint, 
	[FALNUM] smallint, 
	[EFENUM] smallint, 
	[CAUNUM] smallint, 
	[PROCESSO] varchar(255), 
	[ITEM] smallint, 
	[EXCRPN] boolean NOT NULL, 
	[ALTMAN] boolean NOT NULL, 
	[MUDPAD] boolean NOT NULL, 
	[PF] double, 
	[PSA] varchar(20), 
	[FXSEQ] smallint, 
	[FXSSQ] smallint, 
	[FXITEM] smallint, 
	[BLOQUEADO] boolean NOT NULL, 
	[TIPOAPU] varchar(1), 
	[SIG2] varchar(1), 
	[SIG3] varchar(1), 
	[subtipo] varchar(1), 
	[fxitems] int, 
	[FEMEAREV] double, 
	[elemento] varchar(200), 
	[estacao] varchar(200), 
	[trabalho] varchar(200), 
	[funcaoitem] varchar(200), 
	[funcaoetapa] varchar(200), 
	[funcaoelemento] varchar(200), 
	[pafemea] varchar(1), 
	[caraespecial] varchar(1), 
	[filtroespecial] varchar(1), 
	[acaoprev] varchar(200), 
	[acaodet] varchar(200), 
	[rpafemea] varchar(1), 
	[observacao] varchar(200)
);

-- Tabela: FEMCAU
CREATE TABLE IF NOT EXISTS [FEMCAU] (
	[FALTIP] longtext, 
	[FALEFE] longtext, 
	[FALCAU] longtext, 
	[CRTATU] longtext, 
	[INDOCO] double, 
	[INDSEV] double, 
	[INDDET] double, 
	[INDRIS] double, 
	[TITULO] varchar(50), 
	[SEGGRA] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[CARAPREV] longtext, 
	[ACAREC] longtext, 
	[ACATOM] longtext, 
	[RINDSER] double, 
	[RINDOCO] double, 
	[RINDDET] double, 
	[RINDRIS] double, 
	[CRATU] longtext, 
	[SITUACAO] varchar(1), 
	[ACAO] boolean NOT NULL, 
	[ACADAT] datetime, 
	[SIGI] varchar(1), 
	[RESCOD] int, 
	[RESCOD3] int, 
	[RESNOM] varchar(40), 
	[RESNOM2] varchar(40), 
	[RESNOM3] varchar(40), 
	[RESDAT] datetime, 
	[RESDAT2] datetime, 
	[RESDAT3] datetime, 
	[RESCOD2] int, 
	[PRONUM] smallint, 
	[FALNUM] smallint, 
	[EFENUM] smallint, 
	[CAUNUM] smallint, 
	[PROCESSO] varchar(255), 
	[EXCRPN] boolean NOT NULL, 
	[ITEM] smallint, 
	[ALTMAN] boolean NOT NULL, 
	[MUDPAD] boolean NOT NULL, 
	[PF] double, 
	[PSA] varchar(20), 
	[FXSEQ] smallint, 
	[FXSSQ] smallint, 
	[FXITEM] smallint, 
	[BLOQUEADO] boolean NOT NULL, 
	[TIPOAPU] varchar(1), 
	[SIG2] varchar(1), 
	[SIG3] varchar(1), 
	[subtipo] varchar(1), 
	[fxitems] int, 
	[FEMEAREV] double, 
	[elemento] varchar(200), 
	[estacao] varchar(200), 
	[trabalho] varchar(200), 
	[funcaoitem] varchar(200), 
	[funcaoetapa] varchar(200), 
	[funcaoelemento] varchar(200), 
	[pafemea] varchar(1), 
	[caraespecial] varchar(1), 
	[filtroespecial] varchar(1), 
	[acaoprev] varchar(200), 
	[acaodet] varchar(200), 
	[rpafemea] varchar(1), 
	[observacao] varchar(200)
);

-- Tabela: FEMCAUREV
CREATE TABLE IF NOT EXISTS [FEMCAUREV] (
	[FALTIP] longtext, 
	[FALEFE] longtext, 
	[FALCAU] longtext, 
	[CRTATU] longtext, 
	[INDOCO] double, 
	[INDSEV] double, 
	[INDDET] double, 
	[INDRIS] double, 
	[TITULO] varchar(50), 
	[SEGGRA] int, 
	[CARAPREV] longtext, 
	[ACAREC] longtext, 
	[ACATOM] longtext, 
	[RINDSER] double, 
	[RINDOCO] double, 
	[RINDDET] double, 
	[RINDRIS] double, 
	[CRATU] longtext, 
	[SITUACAO] varchar(1), 
	[ACAO] boolean NOT NULL, 
	[ACADAT] datetime, 
	[SIGI] varchar(1), 
	[RESCOD] int, 
	[RESCOD3] int, 
	[RESNOM] varchar(40), 
	[RESNOM2] varchar(40), 
	[RESNOM3] varchar(40), 
	[RESDAT] datetime, 
	[RESDAT2] datetime, 
	[RESDAT3] datetime, 
	[RESCOD2] int, 
	[PRONUM] smallint, 
	[FALNUM] smallint, 
	[EFENUM] smallint, 
	[CAUNUM] smallint, 
	[PROCESSO] varchar(255), 
	[ITEM] smallint, 
	[EXCRPN] boolean NOT NULL, 
	[ALTMAN] boolean NOT NULL, 
	[MUDPAD] boolean NOT NULL, 
	[PF] double, 
	[PSA] varchar(20), 
	[FXSEQ] smallint, 
	[FXSSQ] smallint, 
	[FXITEM] smallint, 
	[SIG2] varchar(1), 
	[SIG3] varchar(1), 
	[subtipo] varchar(1), 
	[FEMEAREV] double, 
	[estacao] varchar(200), 
	[trabalho] varchar(200), 
	[funcaoitem] varchar(200), 
	[funcaoetapa] varchar(200), 
	[funcaoelemento] varchar(200), 
	[pafemea] varchar(1), 
	[caraespecial] varchar(1), 
	[filtroespecial] varchar(1), 
	[acaoprev] varchar(200), 
	[acaodet] varchar(200), 
	[rpafemea] varchar(1), 
	[observacao] varchar(200), 
	[elemento] varchar(200)
);

-- Tabela: FEMEA
CREATE TABLE IF NOT EXISTS [FEMEA] (
	[FALTIP] longtext, 
	[FALEFE] longtext, 
	[FALCAU] longtext, 
	[CRTATU] longtext, 
	[INDOCO] double, 
	[INDSEV] double, 
	[INDDET] double, 
	[INDRIS] double, 
	[TITULO] varchar(50), 
	[SEGGRA] int, 
	[CARAPREV] longtext, 
	[ACAREC] longtext, 
	[ACATOM] longtext, 
	[RINDSER] double, 
	[RINDOCO] double, 
	[RINDDET] double, 
	[RINDRIS] double, 
	[CRATU] longtext, 
	[SITUACAO] varchar(1), 
	[ACAO] boolean NOT NULL, 
	[ACADAT] datetime, 
	[SIGI] varchar(1), 
	[RESCOD] int, 
	[RESCOD3] int, 
	[RESNOM] varchar(40), 
	[RESNOM2] varchar(40), 
	[RESNOM3] varchar(40), 
	[RESDAT] datetime, 
	[RESDAT2] datetime, 
	[RESDAT3] datetime, 
	[RESCOD2] int, 
	[PRONUM] smallint, 
	[FALNUM] smallint, 
	[EFENUM] smallint, 
	[CAUNUM] smallint, 
	[PROCESSO] longtext, 
	[ITEM] smallint, 
	[EXCRPN] boolean NOT NULL, 
	[ALTMAN] boolean NOT NULL, 
	[MUDPAD] boolean NOT NULL, 
	[PF] double, 
	[PSA] varchar(10), 
	[FXITEM] smallint, 
	[FXSEQ] smallint, 
	[FXSSQ] smallint, 
	[BLOQUEADO] boolean NOT NULL, 
	[TIPOAPU] varchar(1), 
	[SIG2] varchar(1), 
	[SIG3] varchar(1), 
	[subtipo] varchar(1), 
	[fxitems] int, 
	[FEMEAREV] double, 
	[elemento] varchar(200), 
	[estacao] varchar(200), 
	[trabalho] varchar(200), 
	[funcaoitem] varchar(200), 
	[funcaoetapa] varchar(200), 
	[funcaoelemento] varchar(200), 
	[pafemea] varchar(1), 
	[caraespecial] varchar(1), 
	[filtroespecial] varchar(1), 
	[acaoprev] varchar(200), 
	[acaodet] varchar(200), 
	[rpafemea] varchar(1), 
	[observacao] varchar(200)
);

-- Tabela: FEMEAPAD
CREATE TABLE IF NOT EXISTS [FEMEAPAD] (
	[FALTIP] longtext, 
	[FALEFE] longtext, 
	[FALCAU] longtext, 
	[CRTATU] longtext, 
	[INDOCO] double, 
	[INDSEV] double, 
	[INDDET] double, 
	[INDRIS] double, 
	[TITULO] varchar(50), 
	[SEGGRA] int, 
	[CARAPREV] longtext, 
	[ACAREC] longtext, 
	[ACATOM] longtext, 
	[RINDSER] double, 
	[RINDOCO] double, 
	[RINDDET] double, 
	[RINDRIS] double, 
	[CRATU] longtext, 
	[SITUACAO] varchar(1), 
	[ACAO] boolean NOT NULL, 
	[ACADAT] datetime, 
	[SIGI] varchar(1), 
	[RESCOD] int, 
	[RESCOD3] int, 
	[RESNOM] varchar(40), 
	[RESNOM2] varchar(40), 
	[RESNOM3] varchar(40), 
	[RESDAT] datetime, 
	[RESDAT2] datetime, 
	[RESDAT3] datetime, 
	[RESCOD2] int, 
	[PRONUM] smallint, 
	[FALNUM] smallint, 
	[EFENUM] smallint, 
	[CAUNUM] smallint, 
	[PROCESSO] longtext, 
	[ITEM] smallint, 
	[EXCRPN] boolean NOT NULL, 
	[ALTMAN] boolean NOT NULL, 
	[MUDPAD] boolean NOT NULL, 
	[PF] double, 
	[PSA] varchar(10), 
	[FXITEM] smallint, 
	[FXSEQ] smallint, 
	[FXSSQ] smallint, 
	[BLOQUEADO] boolean NOT NULL, 
	[TIPOAPU] varchar(1), 
	[SIG2] varchar(1), 
	[SIG3] varchar(1), 
	[subtipo] varchar(1), 
	[fxitems] int, 
	[FEMEAREV] double, 
	[elemento] varchar(200), 
	[estacao] varchar(200), 
	[trabalho] varchar(200), 
	[funcaoitem] varchar(200), 
	[funcaoetapa] varchar(200), 
	[funcaoelemento] varchar(200), 
	[pafemea] varchar(1), 
	[caraespecial] varchar(1), 
	[filtroespecial] varchar(1), 
	[acaoprev] varchar(200), 
	[acaodet] varchar(200), 
	[rpafemea] varchar(1), 
	[observacao] varchar(200)
);

-- Tabela: femearpn
CREATE TABLE IF NOT EXISTS [femearpn] (
	[SEQ] smallint, 
	[DIAFIM] datetime, 
	[DIAINI] datetime, 
	[MES] smallint, 
	[ANO] smallint, 
	[ANUAL] boolean NOT NULL, 
	[DESCRI] varchar(30), 
	[FX01] double, 
	[FX02] double, 
	[FX03] double, 
	[FX04] double, 
	[FX05] double, 
	[FX06] double, 
	[FX07] double, 
	[FX08] double, 
	[apurado] boolean NOT NULL, 
	[apudata] datetime, 
	[SEMES] boolean NOT NULL
);

-- Tabela: femearpni
CREATE TABLE IF NOT EXISTS [femearpni] (
	[seq] smallint, 
	[ano] smallint, 
	[mes] smallint, 
	[cliente] int, 
	[cognome] varchar(12), 
	[grupoemp] varchar(12), 
	[qtdesac] smallint, 
	[qtderdp] smallint, 
	[qtdetot] smallint, 
	[CODIGO] varchar(24), 
	[clinome] varchar(50)
);

-- Tabela: FEMEFE
CREATE TABLE IF NOT EXISTS [FEMEFE] (
	[PRONUM] smallint, 
	[FALNUM] smallint, 
	[EFENUM] smallint, 
	[FALEFE] longtext
);

-- Tabela: FEMFAL
CREATE TABLE IF NOT EXISTS [FEMFAL] (
	[PRONUM] smallint, 
	[FALNUM] smallint, 
	[FALTIP] longtext, 
	[FALTIPO] longtext
);

-- Tabela: FEMHIS
CREATE TABLE IF NOT EXISTS [FEMHIS] (
	[FALTIP] longtext, 
	[FALEFE] longtext, 
	[FALCAU] longtext, 
	[CRTATU] longtext, 
	[INDOCO] double, 
	[INDSEV] double, 
	[INDDET] double, 
	[INDRIS] double, 
	[TITULO] varchar(50), 
	[SEGGRA] int, 
	[CARAPREV] longtext, 
	[ACAREC] longtext, 
	[ACATOM] longtext, 
	[RINDSER] double, 
	[RINDOCO] double, 
	[RINDDET] double, 
	[RINDRIS] double, 
	[CRATU] longtext, 
	[SITUACAO] varchar(1), 
	[ACAO] boolean NOT NULL, 
	[ACADAT] datetime, 
	[SIGI] varchar(1), 
	[RESCOD] int, 
	[RESCOD3] int, 
	[RESNOM] varchar(40), 
	[RESNOM2] varchar(40), 
	[RESNOM3] varchar(40), 
	[RESDAT] datetime, 
	[RESDAT2] datetime, 
	[RESDAT3] datetime, 
	[RESCOD2] int, 
	[PRONUM] smallint, 
	[FALNUM] smallint, 
	[EFENUM] smallint, 
	[CAUNUM] smallint, 
	[PROCESSO] varchar(255), 
	[ITEM] smallint, 
	[EXCRPN] boolean NOT NULL, 
	[ALTMAN] boolean NOT NULL, 
	[MUDPAD] boolean NOT NULL, 
	[PF] double, 
	[PSA] varchar(20), 
	[FXSEQ] smallint, 
	[FXSSQ] smallint, 
	[FXITEM] smallint, 
	[BLOQUEADO] boolean NOT NULL, 
	[TIPOAPU] varchar(1), 
	[SIG2] varchar(1), 
	[SIG3] varchar(1), 
	[subtipo] varchar(1), 
	[fxitems] int, 
	[FEMEAREV] double, 
	[elemento] varchar(200), 
	[estacao] varchar(200), 
	[trabalho] varchar(200), 
	[funcaoitem] varchar(200), 
	[funcaoetapa] varchar(200), 
	[funcaoelemento] varchar(200), 
	[pafemea] varchar(1), 
	[caraespecial] varchar(1), 
	[filtroespecial] varchar(1), 
	[acaoprev] varchar(200), 
	[acaodet] varchar(200), 
	[rpafemea] varchar(1), 
	[observacao] varchar(200)
);

-- Tabela: FEMMAQ
CREATE TABLE IF NOT EXISTS [FEMMAQ] (
	[FALTIP] longtext, 
	[FALEFE] longtext, 
	[FALCAU] longtext, 
	[CRTATU] longtext, 
	[INDOCO] double, 
	[INDSEV] double, 
	[INDDET] double, 
	[INDRIS] double, 
	[TITULO] varchar(50), 
	[SEGGRA] int, 
	[CARAPREV] longtext, 
	[ACAREC] longtext, 
	[ACATOM] longtext, 
	[RINDSER] double, 
	[RINDOCO] double, 
	[RINDDET] double, 
	[RINDRIS] double, 
	[CRATU] longtext, 
	[SITUACAO] varchar(1), 
	[ACAO] boolean NOT NULL, 
	[ACADAT] datetime, 
	[SIGI] varchar(1), 
	[RESCOD] int, 
	[RESCOD3] int, 
	[RESNOM] varchar(40), 
	[RESNOM2] varchar(40), 
	[RESNOM3] varchar(40), 
	[RESDAT] datetime, 
	[RESDAT2] datetime, 
	[RESDAT3] datetime, 
	[RESCOD2] int, 
	[PRONUM] smallint, 
	[FALNUM] smallint, 
	[EFENUM] smallint, 
	[CAUNUM] smallint, 
	[PROCESSO] varchar(255), 
	[ITEM] smallint, 
	[EXCRPN] boolean NOT NULL, 
	[ALTMAN] boolean NOT NULL, 
	[MUDPAD] boolean NOT NULL, 
	[PF] double, 
	[PSA] varchar(20), 
	[FXSEQ] smallint, 
	[FXSSQ] smallint, 
	[FXITEM] smallint, 
	[BLOQUEADO] boolean NOT NULL, 
	[TIPOAPU] varchar(1), 
	[SIG2] varchar(1), 
	[SIG3] varchar(1), 
	[subtipo] varchar(1), 
	[fxitems] int, 
	[FEMEAREV] double, 
	[elemento] varchar(200), 
	[estacao] varchar(200), 
	[trabalho] varchar(200), 
	[funcaoitem] varchar(200), 
	[funcaoetapa] varchar(200), 
	[funcaoelemento] varchar(200), 
	[pafemea] varchar(1), 
	[caraespecial] varchar(1), 
	[filtroespecial] varchar(1), 
	[acaoprev] varchar(200), 
	[acaodet] varchar(200), 
	[rpafemea] varchar(1), 
	[observacao] varchar(200)
);

-- Tabela: FEMPF
CREATE TABLE IF NOT EXISTS [FEMPF] (
	[PRONUM] smallint, 
	[FALNUM] smallint, 
	[PF] int
);

-- Tabela: FEMPFHIS
CREATE TABLE IF NOT EXISTS [FEMPFHIS] (
	[PRONUM] smallint, 
	[FALNUM] smallint, 
	[PF] int
);

-- Tabela: FEMPRE
CREATE TABLE IF NOT EXISTS [FEMPRE] (
	[FALTIP] longtext, 
	[FALEFE] longtext, 
	[FALCAU] longtext, 
	[CRTATU] longtext, 
	[INDOCO] double, 
	[INDSEV] double, 
	[INDDET] double, 
	[INDRIS] double, 
	[TITULO] varchar(50), 
	[SEGGRA] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[CARAPREV] longtext, 
	[ACAREC] longtext, 
	[ACATOM] longtext, 
	[RINDSER] double, 
	[RINDOCO] double, 
	[RINDDET] double, 
	[RINDRIS] double, 
	[SITUACAO] varchar(1), 
	[ACAO] boolean NOT NULL, 
	[ACADAT] datetime, 
	[SIGI] varchar(1), 
	[RESCOD] int, 
	[RESCOD3] int, 
	[RESNOM] varchar(40), 
	[RESNOM2] varchar(40), 
	[RESNOM3] varchar(40), 
	[RESDAT] datetime, 
	[RESDAT2] datetime, 
	[RESDAT3] datetime, 
	[RESCOD2] int, 
	[EXCRPN] boolean NOT NULL, 
	[PF] double, 
	[ITEM] double, 
	[PROCESSO] varchar(255), 
	[ALTMAN] boolean NOT NULL, 
	[MUDPAD] boolean NOT NULL, 
	[PSA] varchar(20), 
	[FXSEQ] smallint, 
	[FXSSQ] smallint, 
	[FXITEM] smallint, 
	[PRONUM] smallint, 
	[EFENUM] smallint, 
	[FALNUM] smallint, 
	[CAUNUM] smallint, 
	[CRATU] longtext, 
	[bloqueado] boolean NOT NULL, 
	[tipoapu] varchar(1), 
	[SIG2] varchar(1), 
	[SIG3] varchar(1), 
	[subtipo] varchar(1), 
	[fxitems] int, 
	[FEMEAREV] double, 
	[suptipo] varchar(1), 
	[elemento] varchar(200), 
	[estacao] varchar(200), 
	[trabalho] varchar(200), 
	[funcaoitem] varchar(200), 
	[funcaoetapa] varchar(200), 
	[funcaoelemento] varchar(200), 
	[pafemea] varchar(1), 
	[caraespecial] varchar(1), 
	[filtroespecial] varchar(1), 
	[acaoprev] varchar(200), 
	[acaodet] varchar(200), 
	[rpafemea] varchar(1), 
	[observacao] varchar(200)
);

-- Tabela: FEMPRO
CREATE TABLE IF NOT EXISTS [FEMPRO] (
	[PROCESSO] varchar(255), 
	[PRONUM] smallint
);

-- Tabela: femrevi
CREATE TABLE IF NOT EXISTS [femrevi] (
	[FALTIP] longtext, 
	[FALEFE] longtext, 
	[FALCAU] longtext, 
	[CRTATU] longtext, 
	[INDOCO] double, 
	[INDSEV] double, 
	[INDDET] double, 
	[INDRIS] double, 
	[TITULO] varchar(50), 
	[SEGGRA] int, 
	[CARAPREV] longtext, 
	[ACAREC] longtext, 
	[ACATOM] longtext, 
	[RINDSER] double, 
	[RINDOCO] double, 
	[RINDDET] double, 
	[RINDRIS] double, 
	[CRATU] longtext, 
	[SITUACAO] varchar(1), 
	[ACAO] boolean NOT NULL, 
	[ACADAT] datetime, 
	[SIGI] varchar(1), 
	[RESCOD] int, 
	[RESCOD3] int, 
	[RESNOM] varchar(40), 
	[RESNOM2] varchar(40), 
	[RESNOM3] varchar(40), 
	[RESDAT] datetime, 
	[RESDAT2] datetime, 
	[RESDAT3] datetime, 
	[RESCOD2] int, 
	[PRONUM] smallint, 
	[FALNUM] smallint, 
	[EFENUM] smallint, 
	[CAUNUM] smallint, 
	[PROCESSO] varchar(255), 
	[ITEM] smallint, 
	[EXCRPN] boolean NOT NULL, 
	[ALTMAN] boolean NOT NULL, 
	[MUDPAD] boolean NOT NULL, 
	[PF] double, 
	[PSA] varchar(20), 
	[FXSEQ] smallint, 
	[FXSSQ] smallint, 
	[FXITEM] smallint, 
	[TIPOAPU] varchar(1), 
	[SIG2] varchar(1), 
	[SIG3] varchar(1), 
	[subtipo] varchar(1), 
	[fxitems] int, 
	[FEMEAREV] double, 
	[elemento] varchar(200), 
	[estacao] varchar(200), 
	[trabalho] varchar(200), 
	[funcaoitem] varchar(200), 
	[funcaoetapa] varchar(200), 
	[funcaoelemento] varchar(200), 
	[pafemea] varchar(1), 
	[caraespecial] varchar(1), 
	[filtroespecial] varchar(1), 
	[acaoprev] varchar(200), 
	[acaodet] varchar(200), 
	[rpafemea] varchar(1), 
	[observacao] varchar(200)
);

-- Tabela: femrpng
CREATE TABLE IF NOT EXISTS [femrpng] (
	[ANO] smallint, 
	[MES] smallint, 
	[PF] double, 
	[FX01] smallint, 
	[FX02] smallint, 
	[FX03] smallint, 
	[ANODIZ] smallint, 
	[MESDIZ] smallint
);

-- Tabela: FEMRPNO
CREATE TABLE IF NOT EXISTS [FEMRPNO] (
	[PF] double, 
	[SEQ] smallint, 
	[MES] smallint, 
	[ANO] smallint, 
	[PRONUM] smallint, 
	[TOTCAU] smallint, 
	[TOTM40] smallint, 
	[MAIRPN] smallint, 
	[TOTRPN] int, 
	[TOTRPN01] int, 
	[TOTRPN02] int, 
	[TOTRPN03] int, 
	[TOTFX01] int, 
	[TOTFX02] int, 
	[TOTFX03] int, 
	[TOTFXA1] int, 
	[TOTFXB1] int, 
	[TOTFXC1] int, 
	[TOTFXA2] int, 
	[TOTFXB2] int, 
	[TOTFXC2] int, 
	[TOTFXC3] int, 
	[TOTFXB3] int, 
	[TOTFXA3] int
);

-- Tabela: femrpnt
CREATE TABLE IF NOT EXISTS [femrpnt] (
	[FALTIP] longtext, 
	[FALEFE] longtext, 
	[FALCAU] longtext, 
	[CRTATU] longtext, 
	[INDOCO] double, 
	[INDSEV] double, 
	[INDDET] double, 
	[INDRIS] double, 
	[TITULO] varchar(50), 
	[SEGGRA] int, 
	[CARAPREV] longtext, 
	[ACAREC] longtext, 
	[ACATOM] longtext, 
	[RINDSER] double, 
	[RINDOCO] double, 
	[RINDDET] double, 
	[RINDRIS] double, 
	[CRATU] longtext, 
	[SITUACAO] varchar(1), 
	[ACAO] boolean NOT NULL, 
	[ACADAT] datetime, 
	[SIGI] varchar(1), 
	[RESCOD] int, 
	[RESCOD3] int, 
	[RESNOM] varchar(40), 
	[RESNOM2] varchar(40), 
	[RESNOM3] varchar(40), 
	[RESDAT] datetime, 
	[RESDAT2] datetime, 
	[RESDAT3] datetime, 
	[RESCOD2] int, 
	[PRONUM] smallint, 
	[FALNUM] smallint, 
	[EFENUM] smallint, 
	[CAUNUM] smallint, 
	[PROCESSO] varchar(255), 
	[ITEM] smallint, 
	[EXCRPN] boolean NOT NULL, 
	[ALTMAN] boolean NOT NULL, 
	[MUDPAD] boolean NOT NULL, 
	[PF] double, 
	[SEQ] smallint, 
	[MES] smallint, 
	[ANO] smallint, 
	[PSA] varchar(20), 
	[FXSEQ] smallint, 
	[FXSSQ] smallint, 
	[FXITEM] smallint, 
	[TIPOAPU] varchar(1), 
	[SIG2] varchar(1), 
	[SIG3] varchar(1), 
	[subtipo] varchar(1), 
	[FEMEAREV] double, 
	[elemento] varchar(200), 
	[estacao] varchar(200), 
	[trabalho] varchar(200), 
	[funcaoitem] varchar(200), 
	[funcaoetapa] varchar(200), 
	[funcaoelemento] varchar(200), 
	[pafemea] varchar(1), 
	[caraespecial] varchar(1), 
	[filtroespecial] varchar(1), 
	[acaoprev] varchar(200), 
	[acaodet] varchar(200), 
	[rpafemea] varchar(1), 
	[observacao] varchar(200)
);

-- �ndice: IDXFEMADC_PF
CREATE INDEX IF NOT EXISTS [IDXFEMADC_PF]
	ON [FEMADC] ([PF]);

-- �ndice: IDXFEMAVU_PF
CREATE INDEX IF NOT EXISTS [IDXFEMAVU_PF]
	ON [FEMAVU] ([PF]);

-- �ndice: IDXFEMAVU_PRONUM
CREATE INDEX IF NOT EXISTS [IDXFEMAVU_PRONUM]
	ON [FEMAVU] ([PRONUM]);

-- �ndice: IDXFEMAVU_PRONUM_FALNUM_EFENUM_CAUNUM
CREATE INDEX IF NOT EXISTS [IDXFEMAVU_PRONUM_FALNUM_EFENUM_CAUNUM]
	ON [FEMAVU] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM]);

-- �ndice: IDXFEMCAU_PRONUM
CREATE INDEX IF NOT EXISTS [IDXFEMCAU_PRONUM]
	ON [FEMCAU] ([PRONUM]);

-- �ndice: IDXFEMCAU_PRONUM_FALNUM_EFENUM_CAUNUM
CREATE INDEX IF NOT EXISTS [IDXFEMCAU_PRONUM_FALNUM_EFENUM_CAUNUM]
	ON [FEMCAU] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM]);

-- �ndice: IDXFEMCAUREV_PF
CREATE INDEX IF NOT EXISTS [IDXFEMCAUREV_PF]
	ON [FEMCAUREV] ([PF]);

-- �ndice: IDXFEMCAUREV_PRONUM
CREATE INDEX IF NOT EXISTS [IDXFEMCAUREV_PRONUM]
	ON [FEMCAUREV] ([PRONUM]);

-- �ndice: IDXFEMCAUREV_PRONUM_FALNUM_EFENUM_CAUNUM
CREATE INDEX IF NOT EXISTS [IDXFEMCAUREV_PRONUM_FALNUM_EFENUM_CAUNUM]
	ON [FEMCAUREV] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM]);

-- �ndice: IDXFEMEA_INDRIS
CREATE INDEX IF NOT EXISTS [IDXFEMEA_INDRIS]
	ON [FEMEA] ([INDRIS]);

-- �ndice: IDXFEMEA_ITEM
CREATE INDEX IF NOT EXISTS [IDXFEMEA_ITEM]
	ON [FEMEA] ([ITEM]);

-- �ndice: IDXFEMEA_PF
CREATE INDEX IF NOT EXISTS [IDXFEMEA_PF]
	ON [FEMEA] ([PF]);

-- �ndice: IDXFEMEA_PF_ITEM
CREATE INDEX IF NOT EXISTS [IDXFEMEA_PF_ITEM]
	ON [FEMEA] ([PF], [ITEM]);

-- �ndice: IDXFEMEA_PRONUM
CREATE INDEX IF NOT EXISTS [IDXFEMEA_PRONUM]
	ON [FEMEA] ([PRONUM]);

-- �ndice: IDXFEMEA_PRONUM_FALNUM_EFENUM_CAUNUM
CREATE INDEX IF NOT EXISTS [IDXFEMEA_PRONUM_FALNUM_EFENUM_CAUNUM]
	ON [FEMEA] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM]);

-- �ndice: IDXFEMEA_PRONUM_FALNUM_EFENUM_CAUNUM_PF
CREATE INDEX IF NOT EXISTS [IDXFEMEA_PRONUM_FALNUM_EFENUM_CAUNUM_PF]
	ON [FEMEA] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM], [PF]);

-- �ndice: IDXFEMEAPAD_INDRIS
CREATE INDEX IF NOT EXISTS [IDXFEMEAPAD_INDRIS]
	ON [FEMEAPAD] ([INDRIS]);

-- �ndice: IDXFEMEAPAD_PF
CREATE INDEX IF NOT EXISTS [IDXFEMEAPAD_PF]
	ON [FEMEAPAD] ([PF]);

-- �ndice: IDXFEMEAPAD_PRONUM
CREATE INDEX IF NOT EXISTS [IDXFEMEAPAD_PRONUM]
	ON [FEMEAPAD] ([PRONUM]);

-- �ndice: IDXFEMEAPAD_PRONUM_FALNUM_EFENUM_CAUNUM
CREATE INDEX IF NOT EXISTS [IDXFEMEAPAD_PRONUM_FALNUM_EFENUM_CAUNUM]
	ON [FEMEAPAD] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM]);

-- �ndice: IDXFEMEAPAD_PRONUM_FALNUM_EFENUM_CAUNUM_PF
CREATE INDEX IF NOT EXISTS [IDXFEMEAPAD_PRONUM_FALNUM_EFENUM_CAUNUM_PF]
	ON [FEMEAPAD] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM], [PF]);

-- �ndice: IDXfemearpn_SEQ
CREATE INDEX IF NOT EXISTS [IDXfemearpn_SEQ]
	ON [femearpn] ([SEQ]);

-- �ndice: IDXfemearpn_SEQ_MES_ANO
CREATE INDEX IF NOT EXISTS [IDXfemearpn_SEQ_MES_ANO]
	ON [femearpn] ([SEQ], [MES], [ANO]);

-- �ndice: IDXfemearpni_seq
CREATE INDEX IF NOT EXISTS [IDXfemearpni_seq]
	ON [femearpni] ([seq]);

-- �ndice: IDXFEMEFE_EFENUM
CREATE INDEX IF NOT EXISTS [IDXFEMEFE_EFENUM]
	ON [FEMEFE] ([EFENUM]);

-- �ndice: IDXFEMEFE_FALNUM
CREATE INDEX IF NOT EXISTS [IDXFEMEFE_FALNUM]
	ON [FEMEFE] ([FALNUM]);

-- �ndice: IDXFEMEFE_FALNUM_EFENUM
CREATE INDEX IF NOT EXISTS [IDXFEMEFE_FALNUM_EFENUM]
	ON [FEMEFE] ([FALNUM], [EFENUM]);

-- �ndice: IDXFEMEFE_PRONUM
CREATE INDEX IF NOT EXISTS [IDXFEMEFE_PRONUM]
	ON [FEMEFE] ([PRONUM]);

-- �ndice: IDXFEMFAL_FALNUM
CREATE INDEX IF NOT EXISTS [IDXFEMFAL_FALNUM]
	ON [FEMFAL] ([FALNUM]);

-- �ndice: IDXFEMFAL_PRONUM
CREATE INDEX IF NOT EXISTS [IDXFEMFAL_PRONUM]
	ON [FEMFAL] ([PRONUM]);

-- �ndice: IDXFEMHIS_PF
CREATE INDEX IF NOT EXISTS [IDXFEMHIS_PF]
	ON [FEMHIS] ([PF]);

-- �ndice: IDXFEMHIS_PRONUM
CREATE INDEX IF NOT EXISTS [IDXFEMHIS_PRONUM]
	ON [FEMHIS] ([PRONUM]);

-- �ndice: IDXFEMHIS_PRONUM_FALNUM_EFENUM_CAUNUM
CREATE INDEX IF NOT EXISTS [IDXFEMHIS_PRONUM_FALNUM_EFENUM_CAUNUM]
	ON [FEMHIS] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM]);

-- �ndice: IDXFEMMAQ_PF
CREATE INDEX IF NOT EXISTS [IDXFEMMAQ_PF]
	ON [FEMMAQ] ([PF]);

-- �ndice: IDXFEMPF_PF
CREATE INDEX IF NOT EXISTS [IDXFEMPF_PF]
	ON [FEMPF] ([PF]);

-- �ndice: IDXFEMPF_PF_PRONUM_FALNUM
CREATE INDEX IF NOT EXISTS [IDXFEMPF_PF_PRONUM_FALNUM]
	ON [FEMPF] ([PF], [PRONUM], [FALNUM]);

-- �ndice: IDXFEMPF_PRONUM_FALNUM
CREATE INDEX IF NOT EXISTS [IDXFEMPF_PRONUM_FALNUM]
	ON [FEMPF] ([PRONUM], [FALNUM]);

-- �ndice: IDXFEMPFHIS_PF
CREATE INDEX IF NOT EXISTS [IDXFEMPFHIS_PF]
	ON [FEMPFHIS] ([PF]);

-- �ndice: IDXFEMPFHIS_PF_PRONUM_FALNUM
CREATE INDEX IF NOT EXISTS [IDXFEMPFHIS_PF_PRONUM_FALNUM]
	ON [FEMPFHIS] ([PF], [PRONUM], [FALNUM]);

-- �ndice: IDXFEMPFHIS_PRONUM_FALNUM
CREATE INDEX IF NOT EXISTS [IDXFEMPFHIS_PRONUM_FALNUM]
	ON [FEMPFHIS] ([PRONUM], [FALNUM]);

-- �ndice: IDXFEMPRE_SEGGRA
CREATE INDEX IF NOT EXISTS [IDXFEMPRE_SEGGRA]
	ON [FEMPRE] ([SEGGRA]);

-- �ndice: IDXFEMPRE_TITULO
CREATE INDEX IF NOT EXISTS [IDXFEMPRE_TITULO]
	ON [FEMPRE] ([TITULO]);

-- �ndice: IDXFEMPRO_PRONUM
CREATE INDEX IF NOT EXISTS [IDXFEMPRO_PRONUM]
	ON [FEMPRO] ([PRONUM]);

-- �ndice: IDXfemrevi_PF
CREATE INDEX IF NOT EXISTS [IDXfemrevi_PF]
	ON [femrevi] ([PF]);

-- �ndice: IDXfemrevi_PRONUM
CREATE INDEX IF NOT EXISTS [IDXfemrevi_PRONUM]
	ON [femrevi] ([PRONUM]);

-- �ndice: IDXfemrevi_PRONUM_FALNUM_EFENUM_CAUNUM
CREATE INDEX IF NOT EXISTS [IDXfemrevi_PRONUM_FALNUM_EFENUM_CAUNUM]
	ON [femrevi] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM]);

-- �ndice: IDXfemrevi_PRONUM_FALNUM_EFENUM_CAUNUM_PF
CREATE INDEX IF NOT EXISTS [IDXfemrevi_PRONUM_FALNUM_EFENUM_CAUNUM_PF]
	ON [femrevi] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM], [PF]);

-- �ndice: IDXfemrpng_ANO_MES
CREATE INDEX IF NOT EXISTS [IDXfemrpng_ANO_MES]
	ON [femrpng] ([ANO], [MES]);

-- �ndice: IDXFEMRPNO_ANO_MES
CREATE INDEX IF NOT EXISTS [IDXFEMRPNO_ANO_MES]
	ON [FEMRPNO] ([ANO], [MES]);

-- �ndice: IDXFEMRPNO_PF
CREATE INDEX IF NOT EXISTS [IDXFEMRPNO_PF]
	ON [FEMRPNO] ([PF]);

-- �ndice: IDXFEMRPNO_SEQ
CREATE INDEX IF NOT EXISTS [IDXFEMRPNO_SEQ]
	ON [FEMRPNO] ([SEQ]);

-- �ndice: IDXfemrpnt_SEQ
CREATE INDEX IF NOT EXISTS [IDXfemrpnt_SEQ]
	ON [femrpnt] ([SEQ]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
