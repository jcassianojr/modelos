-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: ORIGEM (MDB)
-- Gerado em: 17/05/2026 09:31:10
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: AP
-- --------------------------------------------------
CREATE TABLE [AP] ([SEQ] LONG, [DESCRICAO] MEMO);
CREATE INDEX [APSEQ] ON [AP] ([SEQ]);

-- --------------------------------------------------
-- Estrutura da Tabela: CFLX
-- --------------------------------------------------
CREATE TABLE [CFLX] ([LETRA] TEXT(1), [DESCRICAO] TEXT(50), [LETRA_x] TEXT(1), [NUMERO] SHORT);
CREATE INDEX [CFLXNUMERO] ON [CFLX] ([NUMERO]);
CREATE INDEX [CLFXLETRA] ON [CFLX] ([LETRA]);

-- --------------------------------------------------
-- Estrutura da Tabela: DUPLICAR
-- --------------------------------------------------
CREATE TABLE [DUPLICAR] ([TABELA] TEXT(50), [CAMPO] TEXT(50));
CREATE INDEX [CHAVE] ON [DUPLICAR] ([TABELA], [CAMPO]);

-- --------------------------------------------------
-- Estrutura da Tabela: EMPRESA
-- --------------------------------------------------
CREATE TABLE [EMPRESA] ([NOME] TEXT(50), [TELEFONE] TEXT(50), [FAX] TEXT(50), [ENDERECO] TEXT(50), [CIDADE] TEXT(50), [ESTADO] TEXT(2), [CEP] TEXT(9));

-- --------------------------------------------------
-- Estrutura da Tabela: FEMEA
-- --------------------------------------------------
CREATE TABLE [FEMEA] ([PF] DOUBLE, [ITEM] DOUBLE, [PROCESSO] TEXT(255), [FALTIP] MEMO, [FALEFE] MEMO, [FALCAU] MEMO, [CRTATU] MEMO, [INDOCO] DOUBLE, [INDSEV] DOUBLE, [INDDET] DOUBLE, [INDRIS] DOUBLE, [ACAREC] MEMO, [RESCOD] DOUBLE, [RESNOM] TEXT(40), [RESDAT] DATETIME, [ACATOM] MEMO, [ACADAT] DATETIME, [RINDOCO] DOUBLE, [RINDSER] DOUBLE, [RINDDET] DOUBLE, [RINDRIS] DOUBLE, [RESCOD2] DOUBLE, [RESNOM3] TEXT(40), [RESNOM2] TEXT(40), [RESDAT2] DATETIME, [RESDAT3] DATETIME, [ACAO] BIT, [RESCOD3] DOUBLE, [SITUACAO] TEXT(1), [SIGI] TEXT(1), [CARAPREV] MEMO, [EXCRPN] BIT, [ALTMAN] BIT, [MUDPAD] BIT, [PSA] TEXT(20), [FXSEQ] SHORT, [FXSSQ] SHORT, [FXITEM] SHORT, [PRONUM] SHORT, [EFENUM] SHORT, [FALNUM] SHORT, [CAUNUM] SHORT, [SEGGRA] SHORT, [TITULO] TEXT(50), [BLOQUEADO] BIT, [TIPOAPU] TEXT(1), [SIG2] TEXT(1), [SIG3] TEXT(1), [subtipo] TEXT(1), [fxitems] LONG, [FEMEAREV] DOUBLE, [CRATU] MEMO, [elemento] TEXT(200), [estacao] TEXT(200), [trabalho] TEXT(200), [funcaoitem] TEXT(200), [funcaoetapa] TEXT(200), [funcaoelemento] TEXT(200), [pafemea] TEXT(1), [caraespecial] TEXT(1), [filtroespecial] TEXT(1), [acaoprev] TEXT(200), [acaodet] TEXT(200), [rpafemea] TEXT(1), [observacao] TEXT(200));
CREATE INDEX [FEMEAPFITEM] ON [FEMEA] ([PF], [ITEM]);
CREATE INDEX [ITEM] ON [FEMEA] ([ITEM]);
CREATE INDEX [PF] ON [FEMEA] ([PF]);
CREATE INDEX [PFITEM] ON [FEMEA] ([PF], [ITEM]);

-- --------------------------------------------------
-- Estrutura da Tabela: FEMPRE
-- --------------------------------------------------
CREATE TABLE [FEMPRE] ([FALTIP] MEMO, [FALEFE] MEMO, [FALCAU] MEMO, [CRTATU] MEMO, [INDOCO] DOUBLE, [INDSEV] DOUBLE, [INDDET] DOUBLE, [INDRIS] DOUBLE, [TITULO] TEXT(50), [SEGGRA] LONG, [SEGGRA_x] LONG, [CARAPREV] MEMO, [ACAREC] MEMO, [ACATOM] MEMO, [RINDSER] DOUBLE, [RINDOCO] DOUBLE, [RINDDET] DOUBLE, [RINDRIS] DOUBLE, [CRATU] MEMO, [SITUACAO] TEXT(1), [ACAO] BIT, [ACADAT] DATETIME, [SIGI] TEXT(1), [RESCOD] LONG, [RESCOD3] LONG, [RESNOM] TEXT(40), [RESNOM2] TEXT(40), [RESNOM3] TEXT(40), [RESDAT] DATETIME, [RESDAT2] DATETIME, [RESDAT3] DATETIME, [RESCOD2] LONG, [EXCRPN] BIT, [PF] DOUBLE, [ITEM] DOUBLE, [PROCESSO] TEXT(255), [ALTMAN] BIT, [MUDPAD] BIT, [PSA] TEXT(20), [FXSEQ] SHORT, [FXSSQ] SHORT, [FXITEM] SHORT, [PRONUM] SHORT, [EFENUM] SHORT, [FALNUM] SHORT, [CAUNUM] SHORT, [bloqueado] BIT, [tipoapu] TEXT(1), [SIG2] TEXT(1), [SIG3] TEXT(1), [subtipo] TEXT(1), [suptipo] TEXT(1), [fxitems] LONG, [FEMEAREV] DOUBLE);

-- --------------------------------------------------
-- Estrutura da Tabela: IE
-- --------------------------------------------------
CREATE TABLE [IE] ([PF] DOUBLE, [DETALHE] MEMO, [TIPO] MEMO, [FECHA] MEMO, [NPED] DOUBLE, [IDENT] MEMO, [PROTE] MEMO, [QML] DOUBLE, [COM] DOUBLE, [LAR] DOUBLE, [ALT] DOUBLE, [UND] DOUBLE, [TOTL] DOUBLE, [TARA] DOUBLE, [BRUTO] DOUBLE, [METODO] MEMO, [OBS] MEMO, [IMAGEM] LONGBINARY, [DATA] DATETIME, [REVISAO] DOUBLE, [LOCAL] MEMO, [CODMR01] TEXT(10), [NOMMR01] TEXT(100), [DATAREV] DATETIME, [FOTOESQ] LONGBINARY, [FOTODIR] LONGBINARY, [CODDIR] TEXT(50), [CODESQ] TEXT(50), [CODIGOINT] TEXT(50), [codigocli] TEXT(50), [elaborador] TEXT(40));
ALTER TABLE [IE] ADD CONSTRAINT [PrimaryKey] PRIMARY KEY ([PF]);

-- --------------------------------------------------
-- Estrutura da Tabela: IED
-- --------------------------------------------------
CREATE TABLE [IED] ([TIPO] TEXT(1), [DESCRITIVO] TEXT(50), [ITEM] LONG, [DETALHE] MEMO, [Valor] LONG);
CREATE INDEX [TIPO] ON [IED] ([TIPO]);

-- --------------------------------------------------
-- Estrutura da Tabela: PCTIPO
-- --------------------------------------------------
CREATE TABLE [PCTIPO] ([IDTIPO] LONG, [DESCRICAO] TEXT(50));
ALTER TABLE [PCTIPO] ADD CONSTRAINT [PrimaryKey] PRIMARY KEY ([IDTIPO]);

-- --------------------------------------------------
-- Estrutura da Tabela: PF
-- --------------------------------------------------
CREATE TABLE [PF] ([PF] DOUBLE, [CPF] TEXT(10), [CODIGO] TEXT(24), [DESCR] TEXT(40), [CLIENTE] DOUBLE, [CLINOME] TEXT(50), [CLIDES] TEXT(24), [CLIREV] TEXT(10), [CLIDAT] DATETIME, [NOSDES] TEXT(24), [NOSREV] TEXT(10), [NOSDAT] DATETIME, [CONDES] TEXT(24), [CONREV] TEXT(10), [CONDAT] DATETIME, [CONPES] DOUBLE, [CONQTD] DOUBLE, [PESLIQ] DOUBLE, [MOTREV] MEMO, [OPCAO] BYTE, [CODMU011] TEXT(10), [CODMU012] TEXT(10), [CODMU013] TEXT(10), [NOMMU011] TEXT(101), [NOMMU012] TEXT(101), [NOMMU013] TEXT(101), [FIGMU011] LONGBINARY, [FIGMU012] LONGBINARY, [FIGMU013] LONGBINARY, [OBSMU011] MEMO, [OBSMU012] MEMO, [OBSMU013] MEMO, [PASMU011] DOUBLE, [PASMU012] DOUBLE, [PASMU013] DOUBLE, [PESMU011] DOUBLE, [PESMU012] DOUBLE, [PESMU013] DOUBLE, [QTDMU011] DOUBLE, [QTDMU012] DOUBLE, [QTDMU013] DOUBLE, [PERMU011] DOUBLE, [PERMU012] DOUBLE, [PERMU013] DOUBLE, [TIPO] TEXT(50), [OBS] MEMO, [SITUACAO] TEXT(1), [ELADAT] DATETIME, [ELANUM] LONG, [RESDAT] DATETIME, [ELANOM] TEXT(40), [RESNUM] LONG, [RESNOM] TEXT(50), [FEMEAD] DATETIME, [FEMEAF] DOUBLE, [FEMEAG] MEMO, [FEMEAC] MEMO, [FEMEAR] TEXT(40), [FEMEAREV] DOUBLE, [FEMEAREVD] DATETIME, [FEMEAOBS] TEXT(100), [REVPRO] DOUBLE, [REVDAT] DATETIME, [PCELANUM] DOUBLE, [PCELANOM] TEXT(50), [PCELADAT] DATETIME, [PCREV] DOUBLE, [PCREVD] DATETIME, [PCLIBNUM] DOUBLE, [PCLIBNOM] TEXT(50), [PCLIBDATE] DATETIME, [TIPOSITU] TEXT(1), [BLOQUEADO] BIT, [BLOQMOTIVO] TEXT(50), [PCDINI] DATETIME, [CODCLIENTE] TEXT(50), [STPFFE] BIT, [STPFPC] BIT, [STFEPC] BIT, [PCGRUPO] MEMO, [PCRTIPO] TEXT(1), [PCLTIPO] TEXT(1), [PCPTIPO] TEXT(1), [PCFTIPO] TEXT(1), [PCCTIPO] TEXT(1), [PCRREV] DOUBLE, [PCLREV] DOUBLE, [PCPREV] DOUBLE, [PCFREV] DOUBLE, [PCCREV] DOUBLE, [PCRDAT] DATETIME, [PCLDAT] DATETIME, [PCPDAT] DATETIME, [PCFDAT] DATETIME, [PCCDAT] DATETIME, [SEQMU011] DOUBLE, [SEQMU012] DOUBLE, [SEQMU013] DOUBLE, [SSQMU011] DOUBLE, [SSQMU012] DOUBLE, [SSQMU013] SINGLE, [FEMEAEF] DOUBLE, [FEMEAED] DATETIME, [FEMEAEN] TEXT(50), [FEMEAPRO] DATETIME, [FEMEACRG] BIT, [CODFINAL] TEXT(50), [PCBLOQ] BIT, [FILIAL] TEXT(5), [CLIESP] TEXT(50), [SEL100] BIT, [CODFISCAL] TEXT(24), [seldata] DATETIME, [EXCRPN] BIT, [CRITICO] BIT, [CRITIOBS] MEMO, [OUTRAAPR] TEXT(50), [FEMMUDPAD] BIT, [CODIGOINT] TEXT(24), [FLX01] TEXT(1), [FLX02] TEXT(1), [FLX03] TEXT(1), [FLX04] TEXT(1), [FLX05] TEXT(1), [FLX06] TEXT(1), [FLX07] TEXT(1), [FLX08] TEXT(1), [FLX09] TEXT(1), [FLX10] TEXT(1), [clientelx] TEXT(15), [clientepr] TEXT(6), [FEMEAREVD2] DATETIME, [PCREVD2] DATETIME, [seguranca] BIT, [takt] DOUBLE, [taktat] DOUBLE, [CONTATONUM] DOUBLE, [CONTATONOM] TEXT(50), [femeaprepro] DATETIME, [segnum] LONG, [segnom] TEXT(50), [segdat] DATETIME, [prdnum] LONG, [prdnom] TEXT(50), [prddat] DATETIME, [numversaocli] TEXT(4), [femeaano] TEXT(10), [femeaproj] TEXT(100));
CREATE INDEX [CLIENTE] ON [PF] ([CLIENTE]);
CREATE INDEX [CODFINAL] ON [PF] ([CODFINAL]);
CREATE INDEX [CODIGO] ON [PF] ([CODIGO]);
ALTER TABLE [PF] ADD CONSTRAINT [PrimaryKey] PRIMARY KEY ([PF]);

-- --------------------------------------------------
-- Estrutura da Tabela: PFC
-- --------------------------------------------------
CREATE TABLE [PFC] ([pf] DOUBLE, [seq] DOUBLE, [ssq] DOUBLE, [item] DOUBLE, [CITEM] TEXT(3), [COP] MEMO, [DESCR] MEMO, [CARAC] MEMO, [SIGI] TEXT(1), [ESPE] MEMO, [TOL] MEMO, [CQTDE] MEMO, [FREQ] MEMO, [TIPINS] TEXT(12), [INSTR] TEXT(50), [CAPA] MEMO, [REACAO] MEMO, [SETOR] TEXT(1), [CARTA] MEMO, [PROCESSO] MEMO, [CERTFOR] BIT, [codme04] TEXT(20), [FILIAL] TEXT(5), [codme04b] TEXT(20), [TIPINSB] TEXT(12), [INSTRB] TEXT(50), [SAIPROC] BIT, [SAIRI] BIT, [SIG2] TEXT(1), [SIG3] TEXT(1), [imagem] LONGBINARY);
CREATE INDEX [PF] ON [PFC] ([pf]);
CREATE INDEX [PFCSEQSSSQITEM] ON [PFC] ([pf], [seq], [ssq], [item]);

-- --------------------------------------------------
-- Estrutura da Tabela: PFCMS03
-- --------------------------------------------------
CREATE TABLE [PFCMS03] ([PF] DOUBLE, [SEQ] DOUBLE, [SSQ] DOUBLE, [ITEM] DOUBLE, [CITEM] TEXT(3), [COP] MEMO, [DESCR] MEMO, [CARAC] MEMO, [SIGI] TEXT(1), [ESPE] MEMO, [TOL] MEMO, [CQTDE] MEMO, [FREQ] MEMO, [TIPINS] TEXT(12), [INSTR] TEXT(50), [CAPA] MEMO, [REACAO] MEMO, [SETOR] TEXT(1), [CARTA] MEMO, [TIPOENT] TEXT(1), [CERTFOR] BIT, [PROCESSO] MEMO, [CODCOMP] TEXT(50), [codme04] TEXT(20), [codme04b] TEXT(20), [FILIAL] TEXT(5), [TIPINSB] TEXT(12), [INSTRB] TEXT(50), [SAIPROC] BIT, [SAIRI] BIT, [TEMP] TEXT(50), [SIG2] TEXT(1), [SIG3] TEXT(1), [imagem] LONGBINARY);
CREATE INDEX [PCCODCCOMPITEM] ON [PFCMS03] ([PF], [CODCOMP], [ITEM]);
CREATE INDEX [PF] ON [PFCMS03] ([PF]);

-- --------------------------------------------------
-- Estrutura da Tabela: pfco
-- --------------------------------------------------
CREATE TABLE [pfco] ([PF] DOUBLE, [SEQ] DOUBLE, [SSQ] DOUBLE, [ITEM] DOUBLE, [CITEM] TEXT(3), [COP] MEMO, [DESCR] MEMO, [CARAC] MEMO, [SIGI] TEXT(1), [ESPE] MEMO, [TOL] MEMO, [CQTDE] MEMO, [FREQ] MEMO, [TIPINS] TEXT(12), [INSTR] TEXT(50), [CAPA] MEMO, [REACAO] MEMO, [SETOR] TEXT(1), [CARTA] MEMO, [PROCESSO] MEMO, [CERTFOR] BIT, [codme04] TEXT(20), [FILIAL] TEXT(5), [codme04b] TEXT(20), [TIPINSB] TEXT(12), [INSTRB] TEXT(50), [SAIPROC] BIT, [SAIRI] BIT, [SIG2] TEXT(1), [SIG3] TEXT(1), [imagem] LONGBINARY);
CREATE INDEX [PF] ON [pfco] ([PF]);
CREATE INDEX [PFSEQSSQITEM] ON [pfco] ([PF], [SEQ], [SSQ], [ITEM]);

-- --------------------------------------------------
-- Estrutura da Tabela: PFD
-- --------------------------------------------------
CREATE TABLE [PFD] ([CQTDE] MEMO, [FREQ] MEMO, [ID] LONG, [SETOR] TEXT(1));

-- --------------------------------------------------
-- Estrutura da Tabela: PFI
-- --------------------------------------------------
CREATE TABLE [PFI] ([PF] DOUBLE, [SEQ] DOUBLE, [SSQ] DOUBLE, [ITEM] DOUBLE, [DESCR] TEXT(255), [NORMA] TEXT(20), [TEMPOMAN] DOUBLE, [TEMPOMAQ] DOUBLE, [TEMPOMOV] DOUBLE, [PTOCHAVE] TEXT(78), [RAZAO] TEXT(78), [takt] LONG, [taktat] LONG, [5SOQUE] TEXT(255), [5SCOMO] TEXT(255), [5SPORQUE] TEXT(255), [5SSIMB01] TEXT(1), [5SSIMB02] TEXT(1), [5SSIMB03] TEXT(1), [5SSIMB04] TEXT(1), [imagem] LONGBINARY, [5ssimb05] TEXT(1), [5ssimb06] TEXT(1));
CREATE INDEX [ITEM] ON [PFI] ([ITEM]);
CREATE INDEX [PF] ON [PFI] ([PF]);
CREATE INDEX [PFSEQSSQITEM] ON [PFI] ([PF], [SEQ], [SSQ], [ITEM]);

-- --------------------------------------------------
-- Estrutura da Tabela: PFMS03
-- --------------------------------------------------
CREATE TABLE [PFMS03] ([PF] DOUBLE, [TIPOENT] TEXT(1), [DESCRI] MEMO, [QTDDE] DOUBLE, [PRECO] DOUBLE, [TOTAL] DOUBLE, [BAIXAC] TEXT(1), [SEQ] LONG, [SSQ] LONG, [OPCAO] BYTE, [PCOBS] MEMO, [PCTIPO] TEXT(50), [FIGSEQ01] LONGBINARY, [FIGSEQ02] LONGBINARY, [CODCOMP] TEXT(50), [prdori] TEXT(10), [CODINT] TEXT(24));
CREATE INDEX [CODIGO] ON [PFMS03] ([CODCOMP]);
CREATE INDEX [PF] ON [PFMS03] ([PF]);
CREATE INDEX [PFCODIGO] ON [PFMS03] ([PF], [CODCOMP]);
CREATE INDEX [PFTIPOCODIGO] ON [PFMS03] ([PF], [TIPOENT], [CODCOMP]);

-- --------------------------------------------------
-- Estrutura da Tabela: PFQSBLEP
-- --------------------------------------------------
CREATE TABLE [PFQSBLEP] ([PF] DOUBLE, [SEQ] LONG, [SSQ] LONG, [ITEM] LONG, [FLUXO] TEXT(20), [CLASS02] TEXT(1), [CARAC] TEXT(255), [REQUER] TEXT(255), [MUD] TEXT(1), [DESCRICAO] TEXT(255), [FLX01] TEXT(1), [FLX02] TEXT(1), [FLX03] TEXT(1), [FLX04] TEXT(1), [FLX05] TEXT(1), [FLX06] TEXT(1), [FLX07] TEXT(1), [FLX08] TEXT(1), [CLASS01] TEXT(6), [REQUERSAI] TEXT(255), [CARA2] TEXT(1), [CARA3] TEXT(1));
CREATE INDEX [ITEM] ON [PFQSBLEP] ([ITEM]);
CREATE INDEX [PF] ON [PFQSBLEP] ([PF]);
CREATE INDEX [PFSEQSSQITEM] ON [PFQSBLEP] ([PF], [SEQ], [SSQ], [ITEM]);

-- --------------------------------------------------
-- Estrutura da Tabela: PFREV
-- --------------------------------------------------
CREATE TABLE [PFREV] ([PF] LONG, [REV] SHORT, [PFDATA] DATETIME, [FEMEAD] DATETIME, [FEMEAN] TEXT(50), [PCPD] DATETIME, [PCPN] TEXT(50), [PCRD] DATETIME, [PCRN] TEXT(50), [PCLD] DATETIME, [PCLN] TEXT(50), [PCFD] DATETIME, [PCFN] TEXT(50), [PCCD] DATETIME, [PCCN] TEXT(50));
CREATE INDEX [PF] ON [PFREV] ([PF]);
CREATE INDEX [PFREV] ON [PFREV] ([PF], [REV]);

-- --------------------------------------------------
-- Estrutura da Tabela: PFS
-- --------------------------------------------------
CREATE TABLE [PFS] ([PF] DOUBLE, [SEQ] DOUBLE, [SSQ] DOUBLE, [descri] TEXT(150), [REGULAR] MEMO, [NOMMP01] TEXT(30), [NOMMP02] TEXT(30), [NOMMP03] TEXT(30), [NOMMP02D] TEXT(30), [NOMMP02C] TEXT(30), [NOMMP02B] TEXT(30), [CODMP01] TEXT(12), [CODMP02] TEXT(12), [CODMP02C] TEXT(12), [CODMP02D] TEXT(12), [CODMP02B] TEXT(12), [CODMP03] TEXT(12), [FATBAT] DOUBLE, [FATCORTE] DOUBLE, [PCHORA] DOUBLE, [FERRAMEN] TEXT(24), [FERRAME2] TEXT(24), [FERRAME3] TEXT(24), [FERRAME4] TEXT(24), [FIG01] LONGBINARY, [FLX01] TEXT(1), [FLX02] TEXT(1), [FLX03] TEXT(1), [FLX04] TEXT(1), [FLX05] TEXT(1), [FLX06] TEXT(1), [FLX07] TEXT(1), [FLX08] TEXT(1), [FLX09] TEXT(1), [FLX10] TEXT(1), [obs] TEXT(250), [FERCOD] TEXT(24), [fernom] TEXT(25), [CODIGOE] TEXT(24), [CODIGOD] TEXT(24), [pcobs] TEXT(200), [pctipo] TEXT(40), [FIGSEQ01] LONGBINARY, [FIGSEQ02] LONGBINARY, [OPCAO] BYTE, [QTHOMEM] BYTE, [SETORREF] TEXT(1), [SETORINS] TEXT(3), [FEITO] TEXT(1), [MONTAGEM] TEXT(1), [FILIAL] TEXT(5), [CODINT] TEXT(24), [FIG02] LONGBINARY, [ESQTIP] TEXT(1), [ESQL01] TEXT(8), [ESQL02] TEXT(8), [ESQL03] TEXT(8), [ESQL04] TEXT(8), [ESQL05] TEXT(8), [ESQL06] TEXT(8), [ESQL07] TEXT(8), [ESQL08] TEXT(8), [ferajm] TEXT(10), [feruci] TEXT(15), [feravf] TEXT(10), [ferpin] TEXT(5), [ferqtd] TEXT(10), [ferdim] TEXT(5), [fercom] TEXT(10), [ferpre] TEXT(15), [SIMBOLOSEG] TEXT(1), [TAKTIME] DOUBLE, [SIMBOLOSE2] TEXT(1), [SIMBOLOSE3] TEXT(1), [EPI01] BIT, [EPI02] BIT, [EPI03] BIT, [EPI04] BIT, [EPI05] BIT, [EPI06] BIT, [EPI07] BIT, [PCCICLO] DOUBLE, [CICLOPC] DOUBLE, [CODIGOCLI] TEXT(30), [figembal] LONGBINARY, [EMBALCOD] TEXT(10), [embalnome] TEXT(25), [EMBALQTDE] DOUBLE, [embalmetodo] TEXT(25), [COMPON01] TEXT(50), [COMPON02] TEXT(50), [COMPON03] TEXT(50), [COMPON04] TEXT(50), [COMPON05] TEXT(50), [COMPON06] TEXT(50), [COMPON07] TEXT(50), [COMPON08] TEXT(50), [COMPON09] TEXT(50), [ferralt] TEXT(30), [FERRPASSO] DOUBLE, [ferrforca] TEXT(25), [ferrfixA] TEXT(15), [qtdmp01] DOUBLE, [qtdmp02] DOUBLE, [qtdmp02b] DOUBLE, [qtdmp02c] DOUBLE, [qtdmp02d] DOUBLE, [subtipo] TEXT(1), [imgalerta] LONGBINARY, [imgcroqui] LONGBINARY, [COMPON10] TEXT(50), [COMPON11] TEXT(50), [COMPON12] TEXT(50), [COMPON13] TEXT(50), [COMPON14] TEXT(50), [COMPON15] TEXT(50));
CREATE INDEX [CODINT] ON [PFS] ([CODINT]);
CREATE INDEX [PF] ON [PFS] ([PF]);
CREATE INDEX [SEQ] ON [PFS] ([SEQ]);
CREATE INDEX [SEQUENCIA] ON [PFS] ([PF], [SEQ], [SSQ]);
CREATE INDEX [SSQ] ON [PFS] ([SSQ]);

-- --------------------------------------------------
-- Estrutura da Tabela: PFSCHECKLIST
-- --------------------------------------------------
CREATE TABLE [PFSCHECKLIST] ([PF] DOUBLE, [SEQ] DOUBLE, [SSQ] DOUBLE, [ORDEM] DOUBLE, [DESCRICAO] TEXT(255));
CREATE INDEX [PFSEQSSQITEM] ON [PFSCHECKLIST] ([PF], [SEQ], [SSQ], [ORDEM]);

-- --------------------------------------------------
-- Estrutura da Tabela: pfso
-- --------------------------------------------------
CREATE TABLE [pfso] ([PF] DOUBLE, [SEQ] DOUBLE, [SSQ] DOUBLE, [DESCRI] MEMO, [PCOBS] MEMO, [PCTIPO] TEXT(50), [FIGSEQ01] LONGBINARY, [FIGSEQ02] LONGBINARY, [TIPOENT] TEXT(1), [CODCOMP] TEXT(11), [CODINT] TEXT(24));
CREATE INDEX [PF] ON [pfso] ([PF]);
CREATE INDEX [SEQ] ON [pfso] ([SEQ]);
CREATE INDEX [SEQUENCIA] ON [pfso] ([PF], [SEQ], [SSQ]);
CREATE INDEX [SSQ] ON [pfso] ([SSQ]);

-- --------------------------------------------------
-- Estrutura da Tabela: PFSONTHEJOB
-- --------------------------------------------------
CREATE TABLE [PFSONTHEJOB] ([PF] DOUBLE, [SEQ] DOUBLE, [SSQ] DOUBLE, [ORDEM] DOUBLE, [DESCRICAO] TEXT(255));
CREATE INDEX [PFSEQSSQITEM] ON [PFSONTHEJOB] ([PF], [SEQ], [SSQ], [ORDEM]);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAF
-- --------------------------------------------------
CREATE TABLE [PPAF] ([CLIENTE] LONG, [CLINOME] TEXT(50), [COMPRADOR] TEXT(5), [COMNOME] TEXT(40), [CODIGO] TEXT(24), [NOME] TEXT(40), [DATAALT] DATETIME, [ITEM] BIT, [PESO] DOUBLE, [OBSADC01] TEXT(80), [OBSADC02] TEXT(80), [SUB01] BIT, [SUB02] BIT, [SUB03] BIT, [SUB04] BIT, [SUB05] BIT, [SUB06] BIT, [SUB07] BIT, [SUB08] BIT, [SUB09] BIT, [NIVEL] TEXT(1), [RES01] BIT, [RES02] BIT, [RES03] BIT, [RES04] BIT, [APLIC] BIT, [SUB10] BIT, [DESENHO] TEXT(80), [NOT01] BIT, [NOT02] BIT, [INF01] BIT, [INF02] BIT, [INF03] BIT, [EXPOSTO] TEXT(80), [PEDOM] TEXT(80), [AUXILIAR] TEXT(80), [NIVELALT] TEXT(80), [NIVELDAT] DATETIME, [DIVISAO] TEXT(80), [APLICACAO] TEXT(80), [DATA] DATETIME, [MOLDE] TEXT(50), [DISPO] TEXT(1), [APRO] TEXT(1), [RESNOME] TEXT(50), [RESCARGO] TEXT(50), [EXP01] TEXT(150), [EXP02] TEXT(150), [TIPCOM] TEXT(1), [CODCOM] TEXT(24), [NOMCOM] TEXT(50), [FORNECEDOR] LONG, [FORNOM] TEXT(50), [COMPRAS] LONG, [COMITEM] LONG, [PRGENT] LONG, [INATIVO] BIT, [SITUACAO] TEXT(1), [PF] LONG, [PPAP] LONG);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAFC
-- --------------------------------------------------
CREATE TABLE [PPAFC] ([PPAP] LONG, [DATA] DATETIME, [PREVISTO] DATETIME, [EFETUADO] DATETIME, [OBS] MEMO, [DISPO] TEXT(1), [CODIGO] TEXT(50), [ITEM] LONG);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAFI
-- --------------------------------------------------
CREATE TABLE [PPAFI] ([DATA] DATETIME, [OBS] MEMO, [DISPO] TEXT(1), [ITEM] DOUBLE, [PPAP] LONG, [PRAZO] DATETIME, [APROVADO] DATETIME, [dispnome] TEXT(40), [dispdate] DATETIME, [dispnum] LONG);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAFP
-- --------------------------------------------------
CREATE TABLE [PPAFP] ([PPAP] LONG, [CODIGO] TEXT(50), [PF] LONG);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAG
-- --------------------------------------------------
CREATE TABLE [PPAG] ([CLIENTE] LONG, [CLINOME] TEXT(50), [COMPRADOR] TEXT(5), [COMNOME] TEXT(40), [CODIGO] TEXT(24), [DATAALT] DATETIME, [NOME] TEXT(40), [ITEM] BIT, [PESO] DOUBLE, [OBSADC01] TEXT(80), [OBSADC02] TEXT(80), [SUB01] BIT, [SUB02] BIT, [SUB03] BIT, [SUB04] BIT, [SUB05] BIT, [SUB06] BIT, [SUB07] BIT, [SUB08] BIT, [SUB09] BIT, [NIVEL] TEXT(1), [RES01] BIT, [RES02] BIT, [RES03] BIT, [RES04] BIT, [APLIC] BIT, [SUB10] BIT, [DESENHO] TEXT(80), [NOT01] BIT, [NOT02] BIT, [INF01] BIT, [INF02] BIT, [INF03] BIT, [EXPOSTO] TEXT(80), [PEDOM] TEXT(80), [AUXILIAR] TEXT(80), [NIVELALT] TEXT(80), [NIVELDAT] DATETIME, [DIVISAO] TEXT(80), [APLICACAO] TEXT(80), [DATA] DATETIME, [MOLDE] TEXT(50), [DISPO] TEXT(1), [APRO] TEXT(1), [RESNOME] TEXT(50), [RESCARGO] TEXT(50), [EXP01] TEXT(150), [EXP02] TEXT(150), [TIPCOM] TEXT(1), [CODCOM] TEXT(24), [FORNECEDOR] LONG, [NOMCOM] TEXT(50), [COMPRAS] LONG, [FORNOM] TEXT(50), [COMITEM] LONG, [PRGENT] LONG, [INATIVO] BIT, [PF] LONG, [SITUACAO] TEXT(1), [SSMT] TEXT(50), [PPAP] LONG);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAGC
-- --------------------------------------------------
CREATE TABLE [PPAGC] ([PPAP] LONG, [DATA] DATETIME, [PREVISTO] DATETIME, [EFETUADO] DATETIME, [OBS] MEMO, [DISPO] TEXT(1), [CODIGO] TEXT(50), [ITEM] LONG);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAGI
-- --------------------------------------------------
CREATE TABLE [PPAGI] ([DATA] DATETIME, [OBS] MEMO, [DISPO] TEXT(1), [ITEM] DOUBLE, [PPAP] LONG, [PRAZO] DATETIME, [APROVADO] DATETIME, [dispnome] TEXT(40), [dispdate] DATETIME, [dispnum] LONG);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAGP
-- --------------------------------------------------
CREATE TABLE [PPAGP] ([PPAP] LONG, [CODIGO] TEXT(50), [PF] LONG);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAP
-- --------------------------------------------------
CREATE TABLE [PPAP] ([CLIENTE] LONG, [CLINOME] TEXT(50), [COMPRADOR] TEXT(5), [COMNOME] TEXT(40), [CODIGO] TEXT(24), [NOME] TEXT(40), [DATAALT] DATETIME, [ITEM] BIT, [PESO] DOUBLE, [OBSADC01] TEXT(80), [OBSADC02] TEXT(80), [SUB01] BIT, [SUB02] BIT, [SUB03] BIT, [SUB04] BIT, [SUB05] BIT, [SUB06] BIT, [SUB07] BIT, [SUB08] BIT, [SUB09] BIT, [NIVEL] TEXT(1), [RES01] BIT, [RES02] BIT, [RES03] BIT, [RES04] BIT, [APLIC] BIT, [SUB10] BIT, [DESENHO] TEXT(80), [NOT01] BIT, [NOT02] BIT, [INF01] BIT, [INF02] BIT, [INF03] BIT, [EXPOSTO] TEXT(80), [PEDOM] TEXT(80), [AUXILIAR] TEXT(80), [NIVELALT] TEXT(80), [NIVELDAT] DATETIME, [DIVISAO] TEXT(80), [APLICACAO] TEXT(80), [DATA] DATETIME, [MOLDE] TEXT(50), [DISPO] TEXT(1), [APRO] TEXT(1), [RESNOME] TEXT(50), [RESCARGO] TEXT(50), [EXP01] TEXT(150), [EXP02] TEXT(150), [TIPCOM] TEXT(1), [CODCOM] TEXT(24), [NOMCOM] TEXT(50), [FORNECEDOR] LONG, [FORNOM] TEXT(50), [COMPRAS] LONG, [COMITEM] LONG, [PRGENT] LONG, [INATIVO] BIT, [SITUACOA] TEXT(1), [PF] LONG, [PPAP] LONG);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAPC
-- --------------------------------------------------
CREATE TABLE [PPAPC] ([PPAP] LONG, [DATA] DATETIME, [PREVISTO] DATETIME, [EFETUADO] DATETIME, [OBS] MEMO, [DISPO] TEXT(1), [CODIGO] TEXT(50), [item] LONG);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAPI
-- --------------------------------------------------
CREATE TABLE [PPAPI] ([DATA] DATETIME, [OBS] MEMO, [PPAP] LONG, [DISPO] TEXT(1), [ITEM] DOUBLE, [PRAZO] DATETIME, [APROVADO] DATETIME, [dispnome] TEXT(40), [dispdate] DATETIME, [dispnum] LONG);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAPP
-- --------------------------------------------------
CREATE TABLE [PPAPP] ([PPAP] LONG, [CODIGO] TEXT(50), [PF] LONG);

-- --------------------------------------------------
-- Estrutura da Tabela: REV
-- --------------------------------------------------
CREATE TABLE [REV] ([PF] DOUBLE, [TIPO] TEXT(3), [REVISAO] LONG, [DATA] DATETIME, [recsetor] TEXT(40), [recnome] TEXT(40), [copias] LONG, [copiasdev] LONG, [copiasext] LONG, [obsoleto] TEXT(40), [recnum] LONG, [datarec] DATETIME);
CREATE INDEX [chave] ON [REV] ([PF], [TIPO], [REVISAO]);
CREATE INDEX [PF] ON [REV] ([PF]);

-- --------------------------------------------------
-- Estrutura da Tabela: REVI
-- --------------------------------------------------
CREATE TABLE [REVI] ([PF] DOUBLE, [TIPO] TEXT(3), [REVISAO] LONG, [ITEM] LONG, [MOTIVO] MEMO);
CREATE INDEX [chave] ON [REVI] ([PF], [TIPO], [REVISAO], [ITEM]);
CREATE INDEX [PF] ON [REVI] ([PF]);

-- Fim do Script de ORIGEM (MDB)
