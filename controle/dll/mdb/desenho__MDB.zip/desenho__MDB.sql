-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: ORIGEM (MDB)
-- Gerado em: 17/05/2026 09:31:06
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: atual
-- --------------------------------------------------
CREATE TABLE [atual] ([conjunto] TEXT(50), [desenho] TEXT(50), [descricao] TEXT(200), [rev] LONG, [data] DATETIME, [recebido] DATETIME, [obs] MEMO, [padronizado] BIT, [fitadat] LONG, [cdrom] LONG, [revc] TEXT(2));
CREATE INDEX [conjunto] ON [atual] ([conjunto]);
CREATE INDEX [conjuntodesenho] ON [atual] ([conjunto], [desenho]);

-- --------------------------------------------------
-- Estrutura da Tabela: baixado
-- --------------------------------------------------
CREATE TABLE [baixado] ([conjunto] TEXT(50), [desenho] TEXT(50), [descricao] TEXT(200), [rev] LONG, [data] DATETIME, [recebido] DATETIME, [obs] MEMO, [padronizado] BIT, [fitadat] LONG, [cdrom] LONG, [revc] TEXT(2));
CREATE INDEX [conjunto] ON [baixado] ([conjunto]);
CREATE INDEX [conjuntodesenho] ON [baixado] ([conjunto], [desenho]);

-- --------------------------------------------------
-- Estrutura da Tabela: CLIENTE
-- --------------------------------------------------
CREATE TABLE [CLIENTE] ([CLIENTE] LONG, [CLINOME] TEXT(50));
CREATE INDEX [CLIENTE] ON [CLIENTE] ([CLIENTE]);

-- --------------------------------------------------
-- Estrutura da Tabela: conjunto
-- --------------------------------------------------
CREATE TABLE [conjunto] ([conjunto] TEXT(50), [cliente] LONG, [clinome] TEXT(50), [descricao] TEXT(200));
CREATE INDEX [conjunto] ON [conjunto] ([conjunto]);

-- --------------------------------------------------
-- Estrutura da Tabela: PRODENG
-- --------------------------------------------------
CREATE TABLE [PRODENG] ([TIPO] TEXT(1), [NUMERO] LONG, [PRODUTO] TEXT(50), [NOME] TEXT(200), [DATA] DATETIME, [REVISAO] TEXT(10), [RESCLI] TEXT(15));
CREATE INDEX [PRODUTO] ON [PRODENG] ([PRODUTO]);
CREATE INDEX [TIPONUMERO] ON [PRODENG] ([TIPO], [NUMERO]);

-- --------------------------------------------------
-- Estrutura da Tabela: PRODUTO
-- --------------------------------------------------
CREATE TABLE [PRODUTO] ([CLIENTE] LONG, [NUMERO] LONG, [CODIGO] TEXT(50), [NOME] TEXT(50), [INATIVO] BIT, [ITEM] LONG);
CREATE INDEX [CLIENTE] ON [PRODUTO] ([CLIENTE]);

-- --------------------------------------------------
-- Estrutura da Tabela: PROTO
-- --------------------------------------------------
CREATE TABLE [PROTO] ([CLIENTE] LONG, [CLINOME] TEXT(50), [PARTNUMBER] TEXT(50), [PROJETO] TEXT(50), [NOME] TEXT(50), [COTACAO] BIT, [ENGENHEIRO] TEXT(50), [COTDATA] DATETIME, [COTVAL] DOUBLE, [ENGRAMAL] TEXT(50));
CREATE INDEX [PARTNUMBER] ON [PROTO] ([PARTNUMBER]);

-- --------------------------------------------------
-- Estrutura da Tabela: PROTOI
-- --------------------------------------------------
CREATE TABLE [PROTOI] ([PARTNUMBER] TEXT(50), [PEDDATA] DATETIME, [PEDIDO] TEXT(50), [PEDENTR] DATETIME, [QTDDE] LONG, [VALOR] DOUBLE, [SSMT] TEXT(50), [SSMTDAT] DATETIME, [FASE] TEXT(50), [DESENHO] TEXT(50), [SSMTREQ] DATETIME, [COMPRADOR] TEXT(50), [GP11] BIT, [GP11DAPR] DATETIME, [TELEFONE] TEXT(50), [GP11DFIN] TEXT(50), [NFNUMERO] TEXT(50), [ENTRDATA] DATETIME, [NFTIPO] TEXT(1), [ENTREGA] TEXT(50), [NFDATA] DATETIME, [OBS] MEMO, [DESENH2] TEXT(50), [PPAP] LONG, [DESENH3] TEXT(50), [REV] TEXT(50), [RE2] TEXT(50), [RE3] TEXT(50));
CREATE INDEX [PARTNUMBER] ON [PROTOI] ([PARTNUMBER]);

-- Fim do Script de ORIGEM (MDB)
