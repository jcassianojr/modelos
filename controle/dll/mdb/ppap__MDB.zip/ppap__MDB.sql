-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: ORIGEM (MDB)
-- Gerado em: 17/05/2026 09:31:12
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: PPAF
-- --------------------------------------------------
CREATE TABLE [PPAF] ([CLIENTE] LONG, [CLINOME] TEXT(50), [COMPRADOR] TEXT(5), [COMNOME] TEXT(40), [CODIGO] TEXT(24), [NOME] TEXT(40), [DATAALT] DATETIME, [ITEM] BIT, [PESO] DOUBLE, [OBSADC01] TEXT(80), [OBSADC02] TEXT(80), [SUB01] BIT, [SUB02] BIT, [SUB03] BIT, [SUB04] BIT, [SUB05] BIT, [SUB06] BIT, [SUB07] BIT, [SUB08] BIT, [SUB09] BIT, [NIVEL] TEXT(1), [RES01] BIT, [RES02] BIT, [RES03] BIT, [RES04] BIT, [APLIC] BIT, [SUB10] BIT, [DESENHO] TEXT(80), [NOT01] BIT, [NOT02] BIT, [INF01] BIT, [INF02] BIT, [INF03] BIT, [EXPOSTO] TEXT(80), [PEDOM] TEXT(80), [AUXILIAR] TEXT(80), [NIVELALT] TEXT(80), [NIVELDAT] DATETIME, [DIVISAO] TEXT(80), [APLICACAO] TEXT(80), [DATA] DATETIME, [MOLDE] TEXT(50), [DISPO] TEXT(1), [APRO] TEXT(1), [RESNOME] TEXT(50), [RESCARGO] TEXT(50), [EXP01] TEXT(150), [EXP02] TEXT(150), [TIPCOM] TEXT(1), [CODCOM] TEXT(24), [NOMCOM] TEXT(50), [FORNECEDOR] LONG, [FORNOM] TEXT(50), [PPAP] LONG, [COMPRAS] LONG, [COMITEM] LONG, [PRGENT] LONG, [INATIVO] BIT, [SITUACAO] TEXT(1), [PF] LONG);
CREATE INDEX [PPAP] ON [PPAF] ([PPAP]);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAFC
-- --------------------------------------------------
CREATE TABLE [PPAFC] ([PPAP] LONG, [DATA] DATETIME, [PREVISTO] DATETIME, [EFETUADO] DATETIME, [OBS] MEMO, [DISPO] TEXT(1), [CODIGO] TEXT(50), [ITEM] LONG);
CREATE INDEX [PPAP] ON [PPAFC] ([PPAP]);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAFI
-- --------------------------------------------------
CREATE TABLE [PPAFI] ([DATA] DATETIME, [OBS] MEMO, [DISPO] TEXT(1), [ITEM] DOUBLE, [PPAP] LONG, [PRAZO] DATETIME, [APROVADO] DATETIME, [dispnome] TEXT(40), [dispdate] DATETIME, [dispnum] LONG);
CREATE INDEX [PPAP] ON [PPAFI] ([PPAP]);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAFP
-- --------------------------------------------------
CREATE TABLE [PPAFP] ([PPAP] LONG, [CODIGO] TEXT(50), [PF] LONG);
CREATE INDEX [PPAP] ON [PPAFP] ([PPAP]);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAG
-- --------------------------------------------------
CREATE TABLE [PPAG] ([CLIENTE] LONG, [CLINOME] TEXT(50), [COMPRADOR] TEXT(5), [COMNOME] TEXT(40), [CODIGO] TEXT(24), [NOME] TEXT(40), [DATAALT] DATETIME, [ITEM] BIT, [PESO] DOUBLE, [OBSADC01] TEXT(80), [OBSADC02] TEXT(80), [SUB01] BIT, [SUB02] BIT, [SUB03] BIT, [SUB04] BIT, [SUB05] BIT, [SUB06] BIT, [SUB07] BIT, [SUB08] BIT, [SUB09] BIT, [NIVEL] TEXT(1), [RES01] BIT, [RES02] BIT, [RES03] BIT, [RES04] BIT, [APLIC] BIT, [SUB10] BIT, [DESENHO] TEXT(80), [NOT01] BIT, [NOT02] BIT, [INF01] BIT, [INF02] BIT, [INF03] BIT, [EXPOSTO] TEXT(80), [PEDOM] TEXT(80), [AUXILIAR] TEXT(80), [NIVELALT] TEXT(80), [NIVELDAT] DATETIME, [DIVISAO] TEXT(80), [APLICACAO] TEXT(80), [DATA] DATETIME, [MOLDE] TEXT(50), [DISPO] TEXT(1), [APRO] TEXT(1), [RESNOME] TEXT(50), [RESCARGO] TEXT(50), [EXP01] TEXT(150), [EXP02] TEXT(150), [TIPCOM] TEXT(1), [CODCOM] TEXT(24), [NOMCOM] TEXT(50), [FORNECEDOR] LONG, [FORNOM] TEXT(50), [COMPRAS] LONG, [COMITEM] LONG, [PRGENT] LONG, [INATIVO] BIT, [SITUACAO] TEXT(1), [PF] LONG, [PPAP] LONG, [SSMT] TEXT(50));
CREATE INDEX [PPAP] ON [PPAG] ([PPAP]);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAGC
-- --------------------------------------------------
CREATE TABLE [PPAGC] ([PPAP] LONG, [DATA] DATETIME, [PREVISTO] DATETIME, [EFETUADO] DATETIME, [OBS] MEMO, [DISPO] TEXT(1), [CODIGO] TEXT(50), [ITEM] LONG);
CREATE INDEX [PPAP] ON [PPAGC] ([PPAP]);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAGI
-- --------------------------------------------------
CREATE TABLE [PPAGI] ([DATA] DATETIME, [OBS] MEMO, [DISPO] TEXT(1), [ITEM] DOUBLE, [PPAP] LONG, [PRAZO] DATETIME, [APROVADO] DATETIME, [dispnome] TEXT(40), [dispdate] DATETIME, [dispnum] LONG);
CREATE INDEX [PPAP] ON [PPAGI] ([PPAP]);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAGP
-- --------------------------------------------------
CREATE TABLE [PPAGP] ([PPAP] LONG, [CODIGO] TEXT(50), [PF] LONG);
CREATE INDEX [PPAP] ON [PPAGP] ([PPAP]);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAP
-- --------------------------------------------------
CREATE TABLE [PPAP] ([CLIENTE] LONG, [CLINOME] TEXT(50), [COMPRADOR] TEXT(5), [COMNOME] TEXT(40), [CODIGO] TEXT(24), [NOME] TEXT(40), [DATAALT] DATETIME, [ITEM] BIT, [PESO] DOUBLE, [OBSADC01] TEXT(80), [OBSADC02] TEXT(80), [SUB01] BIT, [SUB02] BIT, [SUB03] BIT, [SUB04] BIT, [SUB05] BIT, [SUB06] BIT, [SUB07] BIT, [SUB08] BIT, [SUB09] BIT, [NIVEL] TEXT(1), [RES01] BIT, [RES02] BIT, [RES03] BIT, [RES04] BIT, [APLIC] BIT, [SUB10] BIT, [DESENHO] TEXT(80), [NOT01] BIT, [NOT02] BIT, [INF01] BIT, [INF02] BIT, [INF03] BIT, [EXPOSTO] TEXT(80), [PEDOM] TEXT(80), [AUXILIAR] TEXT(80), [NIVELALT] TEXT(80), [NIVELDAT] DATETIME, [DIVISAO] TEXT(80), [APLICACAO] TEXT(80), [DATA] DATETIME, [MOLDE] TEXT(50), [DISPO] TEXT(1), [APRO] TEXT(1), [RESNOME] TEXT(50), [RESCARGO] TEXT(50), [EXP01] TEXT(150), [EXP02] TEXT(150), [PPAP] LONG, [TIPCOM] TEXT(1), [CODCOM] TEXT(24), [NOMCOM] TEXT(50), [FORNECEDOR] LONG, [FORNOM] TEXT(50), [COMPRAS] LONG, [COMITEM] LONG, [PRGENT] LONG, [INATIVO] BIT, [SITUACOA] TEXT(1), [PF] LONG);
CREATE INDEX [PPAP] ON [PPAP] ([PPAP]);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAPC
-- --------------------------------------------------
CREATE TABLE [PPAPC] ([PPAP] LONG, [DATA] DATETIME, [PREVISTO] DATETIME, [EFETUADO] DATETIME, [OBS] MEMO, [DISPO] TEXT(1), [CODIGO] TEXT(50), [item] LONG);
CREATE INDEX [PPAP] ON [PPAPC] ([PPAP]);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAPI
-- --------------------------------------------------
CREATE TABLE [PPAPI] ([DATA] DATETIME, [OBS] MEMO, [PPAP] LONG, [DISPO] TEXT(1), [ITEM] DOUBLE, [PRAZO] DATETIME, [APROVADO] DATETIME, [dispnome] TEXT(40), [dispdate] DATETIME, [dispnum] LONG);
CREATE INDEX [PPAP] ON [PPAPI] ([PPAP]);

-- --------------------------------------------------
-- Estrutura da Tabela: PPAPP
-- --------------------------------------------------
CREATE TABLE [PPAPP] ([PPAP] LONG, [CODIGO] TEXT(50), [PF] LONG);
CREATE INDEX [PPAP] ON [PPAPP] ([PPAP]);

-- Fim do Script de ORIGEM (MDB)
