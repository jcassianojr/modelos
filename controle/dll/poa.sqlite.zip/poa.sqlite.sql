--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 17:27:33 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: DISPO
CREATE TABLE IF NOT EXISTS [DISPO] (
	[NUMERO] int, 
	[pf] double, 
	[seq] double, 
	[ssq] double, 
	[RESDAT] datetime, 
	[RESNUM] int, 
	[RESNOM] varchar(60), 
	[ELANOM] varchar(60), 
	[ELADAT] datetime, 
	[ELANUM] int, 
	[CODIGO] varchar(24), 
	[CODIGOINT] varchar(24), 
	[NOME] varchar(50), 
	[revisao] int, 
	[datarev] datetime, 
	[item] int
);

-- Tabela: DISPOI
CREATE TABLE IF NOT EXISTS [DISPOI] (
	[NUMERO] int, 
	[ITEM] double, 
	[DESCRICAO] varchar(255)
);

-- Tabela: POA
CREATE TABLE IF NOT EXISTS [POA] (
	[NUMERO] int, 
	[CODIGO] varchar(24), 
	[NOME] varchar(50), 
	[PROBLEMA] longtext, 
	[NUMFUN] int, 
	[NOMFUN] varchar(50), 
	[ANALISE] longtext, 
	[SAC] int, 
	[DATASAC] datetime, 
	[SACSN] varchar(1), 
	[pf] double, 
	[seq] double, 
	[ssq] double, 
	[RESDAT] datetime, 
	[RESNUM] int, 
	[RESNOM] varchar(60), 
	[ELANOM] varchar(60), 
	[ELADAT] datetime, 
	[ELANUM] int, 
	[item] int
);

-- Tabela: POKA
CREATE TABLE IF NOT EXISTS [POKA] (
	[NUMERO] int, 
	[PASSO01] longtext, 
	[PASSO02] longtext, 
	[PASSO03] longtext, 
	[PASSO04] longtext, 
	[OBSPASSO01] longtext, 
	[OBSPASSO02] longtext, 
	[OBSPASSO03] longtext, 
	[OBSPASSO04] longtext, 
	[5SOQUE] varchar(255), 
	[5SCOMO] varchar(255), 
	[5SPORQUE] varchar(255), 
	[5SONDE] varchar(255), 
	[pf] double, 
	[seq] double, 
	[ssq] double, 
	[RESDAT] datetime, 
	[RESNUM] int, 
	[RESNOM] varchar(60), 
	[ELANOM] varchar(60), 
	[ELADAT] datetime, 
	[ELANUM] int, 
	[CODIGO] varchar(24), 
	[NOME] varchar(50), 
	[5SOQUEm] varchar(255), 
	[revisao] int, 
	[datarev] datetime, 
	[item] int
);

-- �ndice: IDXDISPO_NUMERO
CREATE INDEX IF NOT EXISTS [IDXDISPO_NUMERO]
	ON [DISPO] ([NUMERO]);

-- �ndice: IDXDISPO_pf_seq_ssq
CREATE INDEX IF NOT EXISTS [IDXDISPO_pf_seq_ssq]
	ON [DISPO] ([pf], [seq], [ssq]);

-- �ndice: IDXDISPOI_NUMERO_ITEM
CREATE INDEX IF NOT EXISTS [IDXDISPOI_NUMERO_ITEM]
	ON [DISPOI] ([NUMERO], [ITEM]);

-- �ndice: IDXPOA_CODIGO
CREATE INDEX IF NOT EXISTS [IDXPOA_CODIGO]
	ON [POA] ([CODIGO]);

-- �ndice: IDXPOA_NUMERO
CREATE INDEX IF NOT EXISTS [IDXPOA_NUMERO]
	ON [POA] ([NUMERO]);

-- �ndice: IDXPOA_pf_seq_ssq
CREATE INDEX IF NOT EXISTS [IDXPOA_pf_seq_ssq]
	ON [POA] ([pf], [seq], [ssq]);

-- �ndice: IDXPOKA_NUMERO
CREATE INDEX IF NOT EXISTS [IDXPOKA_NUMERO]
	ON [POKA] ([NUMERO]);

-- �ndice: IDXPOKA_pf_seq_ssq
CREATE INDEX IF NOT EXISTS [IDXPOKA_pf_seq_ssq]
	ON [POKA] ([pf], [seq], [ssq]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
