-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: DESTINO (ACCDB)
-- Gerado em: 17/05/2026 09:31:07
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: FEMADC
-- --------------------------------------------------
CREATE TABLE [FEMADC] ([FALTIP] MEMO, [FALEFE] MEMO, [FALCAU] MEMO, [CRTATU] MEMO, [INDOCO] DOUBLE, [INDSEV] DOUBLE, [INDDET] DOUBLE, [INDRIS] DOUBLE, [TITULO] TEXT(50), [SEGGRA] LONG, [CARAPREV] MEMO, [ACAREC] MEMO, [ACATOM] MEMO, [RINDSER] DOUBLE, [RINDOCO] DOUBLE, [RINDDET] DOUBLE, [RINDRIS] DOUBLE, [CRATU] MEMO, [SITUACAO] TEXT(1), [ACAO] BIT, [ACADAT] DATETIME, [SIGI] TEXT(1), [RESCOD] LONG, [RESCOD3] LONG, [RESNOM] TEXT(40), [RESNOM2] TEXT(40), [RESNOM3] TEXT(40), [RESDAT] DATETIME, [RESDAT2] DATETIME, [RESDAT3] DATETIME, [RESCOD2] LONG, [PRONUM] SHORT, [FALNUM] SHORT, [EFENUM] SHORT, [CAUNUM] SHORT, [PROCESSO] TEXT(255), [ITEM] SHORT, [EXCRPN] BIT, [ALTMAN] BIT, [MUDPAD] BIT, [PF] DOUBLE, [PSA] TEXT(20), [FXSEQ] SHORT, [FXSSQ] SHORT, [FXITEM] SHORT, [BLOQUEADO] BIT, [TIPOAPU] TEXT(1), [SIG2] TEXT(1), [SIG3] TEXT(1), [subtipo] TEXT(1), [fxitems] LONG, [FEMEAREV] DOUBLE, [elemento] TEXT(200), [estacao] TEXT(200), [trabalho] TEXT(200), [funcaoitem] TEXT(200), [funcaoetapa] TEXT(200), [funcaoelemento] TEXT(200), [pafemea] TEXT(1), [caraespecial] TEXT(1), [filtroespecial] TEXT(1), [acaoprev] TEXT(200), [acaodet] TEXT(200), [rpafemea] TEXT(1), [observacao] TEXT(200));
CREATE INDEX [idxPF] ON [FEMADC] ([PF]);

-- --------------------------------------------------
-- Estrutura da Tabela: FEMAVU
-- --------------------------------------------------
CREATE TABLE [FEMAVU] ([FALTIP] MEMO, [FALEFE] MEMO, [FALCAU] MEMO, [CRTATU] MEMO, [INDOCO] DOUBLE, [INDSEV] DOUBLE, [INDDET] DOUBLE, [INDRIS] DOUBLE, [TITULO] TEXT(50), [SEGGRA] LONG, [CARAPREV] MEMO, [ACAREC] MEMO, [ACATOM] MEMO, [RINDSER] DOUBLE, [RINDOCO] DOUBLE, [RINDDET] DOUBLE, [RINDRIS] DOUBLE, [CRATU] MEMO, [SITUACAO] TEXT(1), [ACAO] BIT, [ACADAT] DATETIME, [SIGI] TEXT(1), [RESCOD] LONG, [RESCOD3] LONG, [RESNOM] TEXT(40), [RESNOM2] TEXT(40), [RESNOM3] TEXT(40), [RESDAT] DATETIME, [RESDAT2] DATETIME, [RESDAT3] DATETIME, [RESCOD2] LONG, [PRONUM] SHORT, [FALNUM] SHORT, [EFENUM] SHORT, [CAUNUM] SHORT, [PROCESSO] TEXT(255), [ITEM] SHORT, [EXCRPN] BIT, [ALTMAN] BIT, [MUDPAD] BIT, [PF] DOUBLE, [PSA] TEXT(20), [FXSEQ] SHORT, [FXSSQ] SHORT, [FXITEM] SHORT, [BLOQUEADO] BIT, [TIPOAPU] TEXT(1), [SIG2] TEXT(1), [SIG3] TEXT(1), [subtipo] TEXT(1), [fxitems] LONG, [FEMEAREV] DOUBLE, [elemento] TEXT(200), [estacao] TEXT(200), [trabalho] TEXT(200), [funcaoitem] TEXT(200), [funcaoetapa] TEXT(200), [funcaoelemento] TEXT(200), [pafemea] TEXT(1), [caraespecial] TEXT(1), [filtroespecial] TEXT(1), [acaoprev] TEXT(200), [acaodet] TEXT(200), [rpafemea] TEXT(1), [observacao] TEXT(200));
CREATE INDEX [CHAVE] ON [FEMAVU] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM]);
CREATE INDEX [PF] ON [FEMAVU] ([PF]);
CREATE INDEX [PRONUM] ON [FEMAVU] ([PRONUM]);

-- --------------------------------------------------
-- Estrutura da Tabela: FEMCAU
-- --------------------------------------------------
CREATE TABLE [FEMCAU] ([FALTIP] MEMO, [FALEFE] MEMO, [FALCAU] MEMO, [CRTATU] MEMO, [INDOCO] DOUBLE, [INDSEV] DOUBLE, [INDDET] DOUBLE, [INDRIS] DOUBLE, [TITULO] TEXT(50), [SEGGRA] LONG, [CARAPREV] MEMO, [ACAREC] MEMO, [ACATOM] MEMO, [RINDSER] DOUBLE, [RINDOCO] DOUBLE, [RINDDET] DOUBLE, [RINDRIS] DOUBLE, [CRATU] MEMO, [SITUACAO] TEXT(1), [ACAO] BIT, [ACADAT] DATETIME, [SIGI] TEXT(1), [RESCOD] LONG, [RESCOD3] LONG, [RESNOM] TEXT(40), [RESNOM2] TEXT(40), [RESNOM3] TEXT(40), [RESDAT] DATETIME, [RESDAT2] DATETIME, [RESDAT3] DATETIME, [RESCOD2] LONG, [PRONUM] SHORT, [FALNUM] SHORT, [EFENUM] SHORT, [CAUNUM] SHORT, [PROCESSO] TEXT(255), [EXCRPN] BIT, [ITEM] SHORT, [ALTMAN] BIT, [MUDPAD] BIT, [PF] DOUBLE, [PSA] TEXT(20), [FXSEQ] SHORT, [FXSSQ] SHORT, [FXITEM] SHORT, [BLOQUEADO] BIT, [TIPOAPU] TEXT(1), [SIG2] TEXT(1), [SIG3] TEXT(1), [subtipo] TEXT(1), [fxitems] LONG, [FEMEAREV] DOUBLE, [elemento] TEXT(200), [estacao] TEXT(200), [trabalho] TEXT(200), [funcaoitem] TEXT(200), [funcaoetapa] TEXT(200), [funcaoelemento] TEXT(200), [pafemea] TEXT(1), [caraespecial] TEXT(1), [filtroespecial] TEXT(1), [acaoprev] TEXT(200), [acaodet] TEXT(200), [rpafemea] TEXT(1), [observacao] TEXT(200));
CREATE INDEX [CHAVE] ON [FEMCAU] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM]);
CREATE INDEX [PRONUM] ON [FEMCAU] ([PRONUM]);

-- --------------------------------------------------
-- Estrutura da Tabela: FEMCAUREV
-- --------------------------------------------------
CREATE TABLE [FEMCAUREV] ([FALTIP] MEMO, [FALEFE] MEMO, [FALCAU] MEMO, [CRTATU] MEMO, [INDOCO] DOUBLE, [INDSEV] DOUBLE, [INDDET] DOUBLE, [INDRIS] DOUBLE, [TITULO] TEXT(50), [SEGGRA] LONG, [CARAPREV] MEMO, [ACAREC] MEMO, [ACATOM] MEMO, [RINDSER] DOUBLE, [RINDOCO] DOUBLE, [RINDDET] DOUBLE, [RINDRIS] DOUBLE, [CRATU] MEMO, [SITUACAO] TEXT(1), [ACAO] BIT, [ACADAT] DATETIME, [SIGI] TEXT(1), [RESCOD] LONG, [RESCOD3] LONG, [RESNOM] TEXT(40), [RESNOM2] TEXT(40), [RESNOM3] TEXT(40), [RESDAT] DATETIME, [RESDAT2] DATETIME, [RESDAT3] DATETIME, [RESCOD2] LONG, [PRONUM] SHORT, [FALNUM] SHORT, [EFENUM] SHORT, [CAUNUM] SHORT, [PROCESSO] TEXT(255), [ITEM] SHORT, [EXCRPN] BIT, [ALTMAN] BIT, [MUDPAD] BIT, [PF] DOUBLE, [PSA] TEXT(20), [FXSEQ] SHORT, [FXSSQ] SHORT, [FXITEM] SHORT, [SIG2] TEXT(1), [SIG3] TEXT(1), [subtipo] TEXT(1), [FEMEAREV] DOUBLE, [estacao] TEXT(200), [trabalho] TEXT(200), [funcaoitem] TEXT(200), [funcaoetapa] TEXT(200), [funcaoelemento] TEXT(200), [pafemea] TEXT(1), [caraespecial] TEXT(1), [filtroespecial] TEXT(1), [acaoprev] TEXT(200), [acaodet] TEXT(200), [rpafemea] TEXT(1), [observacao] TEXT(200), [elemento] TEXT(200));
CREATE INDEX [CHAVE] ON [FEMCAUREV] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM]);
CREATE INDEX [PF] ON [FEMCAUREV] ([PF]);
CREATE INDEX [PRONUM] ON [FEMCAUREV] ([PRONUM]);

-- --------------------------------------------------
-- Estrutura da Tabela: FEMEA
-- --------------------------------------------------
CREATE TABLE [FEMEA] ([FALTIP] MEMO, [FALEFE] MEMO, [FALCAU] MEMO, [CRTATU] MEMO, [INDOCO] DOUBLE, [INDSEV] DOUBLE, [INDDET] DOUBLE, [INDRIS] DOUBLE, [TITULO] TEXT(50), [SEGGRA] LONG, [CARAPREV] MEMO, [ACAREC] MEMO, [ACATOM] MEMO, [RINDSER] DOUBLE, [RINDOCO] DOUBLE, [RINDDET] DOUBLE, [RINDRIS] DOUBLE, [CRATU] MEMO, [SITUACAO] TEXT(1), [ACAO] BIT, [ACADAT] DATETIME, [SIGI] TEXT(1), [RESCOD] LONG, [RESCOD3] LONG, [RESNOM] TEXT(40), [RESNOM2] TEXT(40), [RESNOM3] TEXT(40), [RESDAT] DATETIME, [RESDAT2] DATETIME, [RESDAT3] DATETIME, [RESCOD2] LONG, [PRONUM] SHORT, [FALNUM] SHORT, [EFENUM] SHORT, [CAUNUM] SHORT, [PROCESSO] MEMO, [ITEM] SHORT, [EXCRPN] BIT, [ALTMAN] BIT, [MUDPAD] BIT, [PF] DOUBLE, [PSA] TEXT(10), [FXITEM] SHORT, [FXSEQ] SHORT, [FXSSQ] SHORT, [BLOQUEADO] BIT, [TIPOAPU] TEXT(1), [SIG2] TEXT(1), [SIG3] TEXT(1), [subtipo] TEXT(1), [fxitems] LONG, [FEMEAREV] DOUBLE, [elemento] TEXT(200), [estacao] TEXT(200), [trabalho] TEXT(200), [funcaoitem] TEXT(200), [funcaoetapa] TEXT(200), [funcaoelemento] TEXT(200), [pafemea] TEXT(1), [caraespecial] TEXT(1), [filtroespecial] TEXT(1), [acaoprev] TEXT(200), [acaodet] TEXT(200), [rpafemea] TEXT(1), [observacao] TEXT(200));
CREATE INDEX [CHAVE] ON [FEMEA] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM]);
CREATE INDEX [CHAVE2] ON [FEMEA] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM], [PF]);
CREATE INDEX [INDRIS] ON [FEMEA] ([INDRIS]);
CREATE INDEX [ITEM] ON [FEMEA] ([ITEM]);
CREATE INDEX [PF] ON [FEMEA] ([PF]);
CREATE INDEX [PFITEM] ON [FEMEA] ([PF], [ITEM]);
CREATE INDEX [PRONUM] ON [FEMEA] ([PRONUM]);

-- --------------------------------------------------
-- Estrutura da Tabela: FEMEAPAD
-- --------------------------------------------------
CREATE TABLE [FEMEAPAD] ([FALTIP] MEMO, [FALEFE] MEMO, [FALCAU] MEMO, [CRTATU] MEMO, [INDOCO] DOUBLE, [INDSEV] DOUBLE, [INDDET] DOUBLE, [INDRIS] DOUBLE, [TITULO] TEXT(50), [SEGGRA] LONG, [CARAPREV] MEMO, [ACAREC] MEMO, [ACATOM] MEMO, [RINDSER] DOUBLE, [RINDOCO] DOUBLE, [RINDDET] DOUBLE, [RINDRIS] DOUBLE, [CRATU] MEMO, [SITUACAO] TEXT(1), [ACAO] BIT, [ACADAT] DATETIME, [SIGI] TEXT(1), [RESCOD] LONG, [RESCOD3] LONG, [RESNOM] TEXT(40), [RESNOM2] TEXT(40), [RESNOM3] TEXT(40), [RESDAT] DATETIME, [RESDAT2] DATETIME, [RESDAT3] DATETIME, [RESCOD2] LONG, [PRONUM] SHORT, [FALNUM] SHORT, [EFENUM] SHORT, [CAUNUM] SHORT, [PROCESSO] MEMO, [ITEM] SHORT, [EXCRPN] BIT, [ALTMAN] BIT, [MUDPAD] BIT, [PF] DOUBLE, [PSA] TEXT(10), [FXITEM] SHORT, [FXSEQ] SHORT, [FXSSQ] SHORT, [BLOQUEADO] BIT, [TIPOAPU] TEXT(1), [SIG2] TEXT(1), [SIG3] TEXT(1), [subtipo] TEXT(1), [fxitems] LONG, [FEMEAREV] DOUBLE, [elemento] TEXT(200), [estacao] TEXT(200), [trabalho] TEXT(200), [funcaoitem] TEXT(200), [funcaoetapa] TEXT(200), [funcaoelemento] TEXT(200), [pafemea] TEXT(1), [caraespecial] TEXT(1), [filtroespecial] TEXT(1), [acaoprev] TEXT(200), [acaodet] TEXT(200), [rpafemea] TEXT(1), [observacao] TEXT(200));
CREATE INDEX [CHAVE] ON [FEMEAPAD] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM]);
CREATE INDEX [CHAVE2] ON [FEMEAPAD] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM], [PF]);
CREATE INDEX [INDRIS] ON [FEMEAPAD] ([INDRIS]);
CREATE INDEX [PF] ON [FEMEAPAD] ([PF]);
CREATE INDEX [PRONUM] ON [FEMEAPAD] ([PRONUM]);

-- --------------------------------------------------
-- Estrutura da Tabela: femearpn
-- --------------------------------------------------
CREATE TABLE [femearpn] ([SEQ] SHORT, [DIAFIM] DATETIME, [DIAINI] DATETIME, [MES] SHORT, [ANO] SHORT, [ANUAL] BIT, [DESCRI] TEXT(30), [FX01] DOUBLE, [FX02] DOUBLE, [FX03] DOUBLE, [FX04] DOUBLE, [FX05] DOUBLE, [FX06] DOUBLE, [FX07] DOUBLE, [FX08] DOUBLE, [apurado] BIT, [apudata] DATETIME, [SEMES] BIT);
CREATE INDEX [SEQ] ON [femearpn] ([SEQ]);
CREATE INDEX [SEQMESANO] ON [femearpn] ([SEQ], [MES], [ANO]);

-- --------------------------------------------------
-- Estrutura da Tabela: femearpni
-- --------------------------------------------------
CREATE TABLE [femearpni] ([seq] SHORT, [ano] SHORT, [mes] SHORT, [cliente] LONG, [cognome] TEXT(12), [grupoemp] TEXT(12), [qtdesac] SHORT, [qtderdp] SHORT, [qtdetot] SHORT, [CODIGO] TEXT(24), [clinome] TEXT(50));
CREATE INDEX [seq] ON [femearpni] ([seq]);

-- --------------------------------------------------
-- Estrutura da Tabela: FEMEFE
-- --------------------------------------------------
CREATE TABLE [FEMEFE] ([PRONUM] SHORT, [FALNUM] SHORT, [EFENUM] SHORT, [FALEFE] MEMO);
CREATE INDEX [EFENUM] ON [FEMEFE] ([EFENUM]);
CREATE INDEX [FALEFE] ON [FEMEFE] ([FALNUM], [EFENUM]);
CREATE INDEX [FALNUM] ON [FEMEFE] ([FALNUM]);
CREATE INDEX [PRONUM] ON [FEMEFE] ([PRONUM]);

-- --------------------------------------------------
-- Estrutura da Tabela: FEMFAL
-- --------------------------------------------------
CREATE TABLE [FEMFAL] ([PRONUM] SHORT, [FALNUM] SHORT, [FALTIP] MEMO, [FALTIPO] MEMO);
CREATE INDEX [FALNUM] ON [FEMFAL] ([FALNUM]);
CREATE INDEX [PRONUM] ON [FEMFAL] ([PRONUM]);

-- --------------------------------------------------
-- Estrutura da Tabela: FEMHIS
-- --------------------------------------------------
CREATE TABLE [FEMHIS] ([FALTIP] MEMO, [FALEFE] MEMO, [FALCAU] MEMO, [CRTATU] MEMO, [INDOCO] DOUBLE, [INDSEV] DOUBLE, [INDDET] DOUBLE, [INDRIS] DOUBLE, [TITULO] TEXT(50), [SEGGRA] LONG, [CARAPREV] MEMO, [ACAREC] MEMO, [ACATOM] MEMO, [RINDSER] DOUBLE, [RINDOCO] DOUBLE, [RINDDET] DOUBLE, [RINDRIS] DOUBLE, [CRATU] MEMO, [SITUACAO] TEXT(1), [ACAO] BIT, [ACADAT] DATETIME, [SIGI] TEXT(1), [RESCOD] LONG, [RESCOD3] LONG, [RESNOM] TEXT(40), [RESNOM2] TEXT(40), [RESNOM3] TEXT(40), [RESDAT] DATETIME, [RESDAT2] DATETIME, [RESDAT3] DATETIME, [RESCOD2] LONG, [PRONUM] SHORT, [FALNUM] SHORT, [EFENUM] SHORT, [CAUNUM] SHORT, [PROCESSO] TEXT(255), [ITEM] SHORT, [EXCRPN] BIT, [ALTMAN] BIT, [MUDPAD] BIT, [PF] DOUBLE, [PSA] TEXT(20), [FXSEQ] SHORT, [FXSSQ] SHORT, [FXITEM] SHORT, [BLOQUEADO] BIT, [TIPOAPU] TEXT(1), [SIG2] TEXT(1), [SIG3] TEXT(1), [subtipo] TEXT(1), [fxitems] LONG, [FEMEAREV] DOUBLE, [elemento] TEXT(200), [estacao] TEXT(200), [trabalho] TEXT(200), [funcaoitem] TEXT(200), [funcaoetapa] TEXT(200), [funcaoelemento] TEXT(200), [pafemea] TEXT(1), [caraespecial] TEXT(1), [filtroespecial] TEXT(1), [acaoprev] TEXT(200), [acaodet] TEXT(200), [rpafemea] TEXT(1), [observacao] TEXT(200));
CREATE INDEX [CHAVE] ON [FEMHIS] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM]);
CREATE INDEX [PF] ON [FEMHIS] ([PF]);
CREATE INDEX [PRONUM] ON [FEMHIS] ([PRONUM]);

-- --------------------------------------------------
-- Estrutura da Tabela: FEMMAQ
-- --------------------------------------------------
CREATE TABLE [FEMMAQ] ([FALTIP] MEMO, [FALEFE] MEMO, [FALCAU] MEMO, [CRTATU] MEMO, [INDOCO] DOUBLE, [INDSEV] DOUBLE, [INDDET] DOUBLE, [INDRIS] DOUBLE, [TITULO] TEXT(50), [SEGGRA] LONG, [CARAPREV] MEMO, [ACAREC] MEMO, [ACATOM] MEMO, [RINDSER] DOUBLE, [RINDOCO] DOUBLE, [RINDDET] DOUBLE, [RINDRIS] DOUBLE, [CRATU] MEMO, [SITUACAO] TEXT(1), [ACAO] BIT, [ACADAT] DATETIME, [SIGI] TEXT(1), [RESCOD] LONG, [RESCOD3] LONG, [RESNOM] TEXT(40), [RESNOM2] TEXT(40), [RESNOM3] TEXT(40), [RESDAT] DATETIME, [RESDAT2] DATETIME, [RESDAT3] DATETIME, [RESCOD2] LONG, [PRONUM] SHORT, [FALNUM] SHORT, [EFENUM] SHORT, [CAUNUM] SHORT, [PROCESSO] TEXT(255), [ITEM] SHORT, [EXCRPN] BIT, [ALTMAN] BIT, [MUDPAD] BIT, [PF] DOUBLE, [PSA] TEXT(20), [FXSEQ] SHORT, [FXSSQ] SHORT, [FXITEM] SHORT, [BLOQUEADO] BIT, [TIPOAPU] TEXT(1), [SIG2] TEXT(1), [SIG3] TEXT(1), [subtipo] TEXT(1), [fxitems] LONG, [FEMEAREV] DOUBLE, [elemento] TEXT(200), [estacao] TEXT(200), [trabalho] TEXT(200), [funcaoitem] TEXT(200), [funcaoetapa] TEXT(200), [funcaoelemento] TEXT(200), [pafemea] TEXT(1), [caraespecial] TEXT(1), [filtroespecial] TEXT(1), [acaoprev] TEXT(200), [acaodet] TEXT(200), [rpafemea] TEXT(1), [observacao] TEXT(200));
CREATE INDEX [idxPF] ON [FEMMAQ] ([PF]);

-- --------------------------------------------------
-- Estrutura da Tabela: FEMPF
-- --------------------------------------------------
CREATE TABLE [FEMPF] ([PRONUM] SHORT, [FALNUM] SHORT, [PF] LONG);
CREATE INDEX [CHAVE] ON [FEMPF] ([PF], [PRONUM], [FALNUM]);
CREATE INDEX [PF] ON [FEMPF] ([PF]);
CREATE INDEX [PRONUM] ON [FEMPF] ([PRONUM], [FALNUM]);

-- --------------------------------------------------
-- Estrutura da Tabela: FEMPFHIS
-- --------------------------------------------------
CREATE TABLE [FEMPFHIS] ([PRONUM] SHORT, [FALNUM] SHORT, [PF] LONG);
CREATE INDEX [CHAVE] ON [FEMPFHIS] ([PF], [PRONUM], [FALNUM]);
CREATE INDEX [PF] ON [FEMPFHIS] ([PF]);
CREATE INDEX [PRONUM] ON [FEMPFHIS] ([PRONUM], [FALNUM]);

-- --------------------------------------------------
-- Estrutura da Tabela: FEMPRE
-- --------------------------------------------------
CREATE TABLE [FEMPRE] ([FALTIP] MEMO, [FALEFE] MEMO, [FALCAU] MEMO, [CRTATU] MEMO, [INDOCO] DOUBLE, [INDSEV] DOUBLE, [INDDET] DOUBLE, [INDRIS] DOUBLE, [TITULO] TEXT(50), [SEGGRA] LONG, [CARAPREV] MEMO, [ACAREC] MEMO, [ACATOM] MEMO, [RINDSER] DOUBLE, [RINDOCO] DOUBLE, [RINDDET] DOUBLE, [RINDRIS] DOUBLE, [SITUACAO] TEXT(1), [ACAO] BIT, [ACADAT] DATETIME, [SIGI] TEXT(1), [RESCOD] LONG, [RESCOD3] LONG, [RESNOM] TEXT(40), [RESNOM2] TEXT(40), [RESNOM3] TEXT(40), [RESDAT] DATETIME, [RESDAT2] DATETIME, [RESDAT3] DATETIME, [RESCOD2] LONG, [EXCRPN] BIT, [PF] DOUBLE, [ITEM] DOUBLE, [PROCESSO] TEXT(255), [ALTMAN] BIT, [MUDPAD] BIT, [PSA] TEXT(20), [FXSEQ] SHORT, [FXSSQ] SHORT, [FXITEM] SHORT, [PRONUM] SHORT, [EFENUM] SHORT, [FALNUM] SHORT, [CAUNUM] SHORT, [CRATU] MEMO, [bloqueado] BIT, [tipoapu] TEXT(1), [SIG2] TEXT(1), [SIG3] TEXT(1), [subtipo] TEXT(1), [fxitems] LONG, [FEMEAREV] DOUBLE, [suptipo] TEXT(1), [elemento] TEXT(200), [estacao] TEXT(200), [trabalho] TEXT(200), [funcaoitem] TEXT(200), [funcaoetapa] TEXT(200), [funcaoelemento] TEXT(200), [pafemea] TEXT(1), [caraespecial] TEXT(1), [filtroespecial] TEXT(1), [acaoprev] TEXT(200), [acaodet] TEXT(200), [rpafemea] TEXT(1), [observacao] TEXT(200));
CREATE INDEX [SEGRA] ON [FEMPRE] ([SEGGRA]);
CREATE INDEX [TITULO] ON [FEMPRE] ([TITULO]);

-- --------------------------------------------------
-- Estrutura da Tabela: FEMPRO
-- --------------------------------------------------
CREATE TABLE [FEMPRO] ([PROCESSO] TEXT(255), [PRONUM] SHORT);
CREATE INDEX [PRONUM] ON [FEMPRO] ([PRONUM]);

-- --------------------------------------------------
-- Estrutura da Tabela: femrevi
-- --------------------------------------------------
CREATE TABLE [femrevi] ([FALTIP] MEMO, [FALEFE] MEMO, [FALCAU] MEMO, [CRTATU] MEMO, [INDOCO] DOUBLE, [INDSEV] DOUBLE, [INDDET] DOUBLE, [INDRIS] DOUBLE, [TITULO] TEXT(50), [SEGGRA] LONG, [CARAPREV] MEMO, [ACAREC] MEMO, [ACATOM] MEMO, [RINDSER] DOUBLE, [RINDOCO] DOUBLE, [RINDDET] DOUBLE, [RINDRIS] DOUBLE, [CRATU] MEMO, [SITUACAO] TEXT(1), [ACAO] BIT, [ACADAT] DATETIME, [SIGI] TEXT(1), [RESCOD] LONG, [RESCOD3] LONG, [RESNOM] TEXT(40), [RESNOM2] TEXT(40), [RESNOM3] TEXT(40), [RESDAT] DATETIME, [RESDAT2] DATETIME, [RESDAT3] DATETIME, [RESCOD2] LONG, [PRONUM] SHORT, [FALNUM] SHORT, [EFENUM] SHORT, [CAUNUM] SHORT, [PROCESSO] TEXT(255), [ITEM] SHORT, [EXCRPN] BIT, [ALTMAN] BIT, [MUDPAD] BIT, [PF] DOUBLE, [PSA] TEXT(20), [FXSEQ] SHORT, [FXSSQ] SHORT, [FXITEM] SHORT, [TIPOAPU] TEXT(1), [SIG2] TEXT(1), [SIG3] TEXT(1), [subtipo] TEXT(1), [fxitems] LONG, [FEMEAREV] DOUBLE, [elemento] TEXT(200), [estacao] TEXT(200), [trabalho] TEXT(200), [funcaoitem] TEXT(200), [funcaoetapa] TEXT(200), [funcaoelemento] TEXT(200), [pafemea] TEXT(1), [caraespecial] TEXT(1), [filtroespecial] TEXT(1), [acaoprev] TEXT(200), [acaodet] TEXT(200), [rpafemea] TEXT(1), [observacao] TEXT(200));
CREATE INDEX [CHAVE] ON [femrevi] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM]);
CREATE INDEX [CHAVE2] ON [femrevi] ([PRONUM], [FALNUM], [EFENUM], [CAUNUM], [PF]);
CREATE INDEX [PF] ON [femrevi] ([PF]);
CREATE INDEX [PRONUM] ON [femrevi] ([PRONUM]);

-- --------------------------------------------------
-- Estrutura da Tabela: femrpng
-- --------------------------------------------------
CREATE TABLE [femrpng] ([ANO] SHORT, [MES] SHORT, [PF] DOUBLE, [FX01] SHORT, [FX02] SHORT, [FX03] SHORT, [ANODIZ] SHORT, [MESDIZ] SHORT);
CREATE INDEX [COMP] ON [femrpng] ([ANO], [MES]);

-- --------------------------------------------------
-- Estrutura da Tabela: FEMRPNO
-- --------------------------------------------------
CREATE TABLE [FEMRPNO] ([PF] DOUBLE, [SEQ] SHORT, [MES] SHORT, [ANO] SHORT, [PRONUM] SHORT, [TOTCAU] SHORT, [TOTM40] SHORT, [MAIRPN] SHORT, [TOTRPN] LONG, [TOTRPN01] LONG, [TOTRPN02] LONG, [TOTRPN03] LONG, [TOTFX01] LONG, [TOTFX02] LONG, [TOTFX03] LONG, [TOTFXA1] LONG, [TOTFXB1] LONG, [TOTFXC1] LONG, [TOTFXA2] LONG, [TOTFXB2] LONG, [TOTFXC2] LONG, [TOTFXC3] LONG, [TOTFXB3] LONG, [TOTFXA3] LONG);
CREATE INDEX [ANOMES] ON [FEMRPNO] ([ANO], [MES]);
CREATE INDEX [PF] ON [FEMRPNO] ([PF]);
CREATE INDEX [SEQ] ON [FEMRPNO] ([SEQ]);

-- --------------------------------------------------
-- Estrutura da Tabela: femrpnt
-- --------------------------------------------------
CREATE TABLE [femrpnt] ([FALTIP] MEMO, [FALEFE] MEMO, [FALCAU] MEMO, [CRTATU] MEMO, [INDOCO] DOUBLE, [INDSEV] DOUBLE, [INDDET] DOUBLE, [INDRIS] DOUBLE, [TITULO] TEXT(50), [SEGGRA] LONG, [CARAPREV] MEMO, [ACAREC] MEMO, [ACATOM] MEMO, [RINDSER] DOUBLE, [RINDOCO] DOUBLE, [RINDDET] DOUBLE, [RINDRIS] DOUBLE, [CRATU] MEMO, [SITUACAO] TEXT(1), [ACAO] BIT, [ACADAT] DATETIME, [SIGI] TEXT(1), [RESCOD] LONG, [RESCOD3] LONG, [RESNOM] TEXT(40), [RESNOM2] TEXT(40), [RESNOM3] TEXT(40), [RESDAT] DATETIME, [RESDAT2] DATETIME, [RESDAT3] DATETIME, [RESCOD2] LONG, [PRONUM] SHORT, [FALNUM] SHORT, [EFENUM] SHORT, [CAUNUM] SHORT, [PROCESSO] TEXT(255), [ITEM] SHORT, [EXCRPN] BIT, [ALTMAN] BIT, [MUDPAD] BIT, [PF] DOUBLE, [SEQ] SHORT, [MES] SHORT, [ANO] SHORT, [PSA] TEXT(20), [FXSEQ] SHORT, [FXSSQ] SHORT, [FXITEM] SHORT, [TIPOAPU] TEXT(1), [SIG2] TEXT(1), [SIG3] TEXT(1), [subtipo] TEXT(1), [FEMEAREV] DOUBLE, [elemento] TEXT(200), [estacao] TEXT(200), [trabalho] TEXT(200), [funcaoitem] TEXT(200), [funcaoetapa] TEXT(200), [funcaoelemento] TEXT(200), [pafemea] TEXT(1), [caraespecial] TEXT(1), [filtroespecial] TEXT(1), [acaoprev] TEXT(200), [acaodet] TEXT(200), [rpafemea] TEXT(1), [observacao] TEXT(200));
CREATE INDEX [SEQ] ON [femrpnt] ([SEQ]);

-- Fim do Script de DESTINO (ACCDB)
