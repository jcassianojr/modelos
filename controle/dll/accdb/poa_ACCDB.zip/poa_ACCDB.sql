-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: DESTINO (ACCDB)
-- Gerado em: 17/05/2026 09:31:11
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: DISPO
-- --------------------------------------------------
CREATE TABLE [DISPO] ([NUMERO] LONG, [pf] DOUBLE, [seq] DOUBLE, [ssq] DOUBLE, [RESDAT] DATETIME, [RESNUM] LONG, [RESNOM] TEXT(60), [ELANOM] TEXT(60), [ELADAT] DATETIME, [ELANUM] LONG, [CODIGO] TEXT(24), [CODIGOINT] TEXT(24), [NOME] TEXT(50), [revisao] LONG, [datarev] DATETIME, [item] LONG);
CREATE INDEX [NUMERO] ON [DISPO] ([NUMERO]);
CREATE INDEX [pfseqssq] ON [DISPO] ([pf], [seq], [ssq]);

-- --------------------------------------------------
-- Estrutura da Tabela: DISPOI
-- --------------------------------------------------
CREATE TABLE [DISPOI] ([NUMERO] LONG, [ITEM] DOUBLE, [DESCRICAO] TEXT(255), [imagem] LONGBINARY);
CREATE INDEX [NUMEROITEM] ON [DISPOI] ([NUMERO], [ITEM]);

-- --------------------------------------------------
-- Estrutura da Tabela: POA
-- --------------------------------------------------
CREATE TABLE [POA] ([NUMERO] LONG, [CODIGO] TEXT(24), [NOME] TEXT(50), [PROBLEMA] MEMO, [NUMFUN] LONG, [NOMFUN] TEXT(50), [ANALISE] MEMO, [SAC] LONG, [DATASAC] DATETIME, [FOTO] LONGBINARY, [SACSN] TEXT(1), [pf] DOUBLE, [seq] DOUBLE, [ssq] DOUBLE, [RESDAT] DATETIME, [RESNUM] LONG, [RESNOM] TEXT(60), [ELANOM] TEXT(60), [ELADAT] DATETIME, [ELANUM] LONG, [item] LONG);
CREATE INDEX [CODIGO] ON [POA] ([CODIGO]);
CREATE INDEX [NUMERO] ON [POA] ([NUMERO]);
CREATE INDEX [pfseqssq] ON [POA] ([pf], [seq], [ssq]);

-- --------------------------------------------------
-- Estrutura da Tabela: POKA
-- --------------------------------------------------
CREATE TABLE [POKA] ([NUMERO] LONG, [PASSO01] MEMO, [PASSO02] MEMO, [PASSO03] MEMO, [PASSO04] MEMO, [OBSPASSO01] MEMO, [OBSPASSO02] MEMO, [OBSPASSO03] MEMO, [OBSPASSO04] MEMO, [5SOQUE] TEXT(255), [5SCOMO] TEXT(255), [5SPORQUE] TEXT(255), [5SONDE] TEXT(255), [FOTOPASSO01] LONGBINARY, [FOTOPASSO02] LONGBINARY, [FOTOPASSO03] LONGBINARY, [FOTOPASSO04] LONGBINARY, [pf] DOUBLE, [seq] DOUBLE, [ssq] DOUBLE, [RESDAT] DATETIME, [RESNUM] LONG, [RESNOM] TEXT(60), [ELANOM] TEXT(60), [ELADAT] DATETIME, [ELANUM] LONG, [CODIGO] TEXT(24), [NOME] TEXT(50), [5SOQUEm] TEXT(255), [revisao] LONG, [datarev] DATETIME, [item] LONG);
CREATE INDEX [NUMERO] ON [POKA] ([NUMERO]);
CREATE INDEX [pfseqssq] ON [POKA] ([pf], [seq], [ssq]);

-- Fim do Script de DESTINO (ACCDB)
