-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: DESTINO (ACCDB)
-- Gerado em: 17/05/2026 09:31:05
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: CONTROLE
-- --------------------------------------------------
CREATE TABLE [CONTROLE] ([FORM] TEXT(20), [CONTROLE] TEXT(20), [INDICE] LONG, [IMAGEM] SHORT, [CAPTION] TEXT(20), [TOOLTIP] TEXT(50), [TOP] LONG, [LEFT] LONG, [HEIGHT] LONG, [WIDTH] LONG, [MAXLEN] LONG, [CORFRENTE] TEXT(12), [CORFUNDO] TEXT(12), [FONTE] TEXT(12), [TAMANHO] SHORT, [LIGADO] BIT, [ATUALIZADO] BIT, [DISPONIVEL] BIT);
CREATE INDEX [controle-1] ON [CONTROLE] ([FORM], [CONTROLE], [INDICE]);

-- --------------------------------------------------
-- Estrutura da Tabela: EMPRESA
-- --------------------------------------------------
CREATE TABLE [EMPRESA] ([NUMERO] SHORT, [NOME] TEXT(40), [ENDERECO] TEXT(40), [ENDNUM] SHORT, [ENDCOM] TEXT(20), [BAIRRO] TEXT(30), [CIDADE] TEXT(30), [ESTADO] TEXT(2), [CEP] TEXT(9), [DDD] TEXT(4), [TELEFONE] TEXT(9), [FAX] TEXT(9), [MAXCAIXA] DOUBLE, [COBRANCA] BIT, [DIACOBR] SHORT, [JUROS] BIT, [TXJUROS] DOUBLE, [NUMUSER] SHORT, [REF] TEXT(50), [CGC] TEXT(19), [INSCR] TEXT(16), [NUMSOC] SHORT, [CONTRATO] MEMO, [VLCLIENTE] CURRENCY, [IOF] CURRENCY, [ISS] CURRENCY, [SERVICO] CURRENCY, [CAPTACAO] CURRENCY, [LIMITECGC] CURRENCY, [CPMF] CURRENCY);

-- --------------------------------------------------
-- Estrutura da Tabela: MENU
-- --------------------------------------------------
CREATE TABLE [MENU] ([MENU] TEXT(12), [DESCRICAO] TEXT(50), [INDICE] SHORT, [LIGADO] BIT, [CADASTRO] SHORT, [HOTKEY] TEXT(20));
ALTER TABLE [MENU] ADD CONSTRAINT [MENU-1] PRIMARY KEY ([MENU], [INDICE]);
CREATE INDEX [MENU-2] ON [MENU] ([CADASTRO]);

-- --------------------------------------------------
-- Estrutura da Tabela: MENUUSU
-- --------------------------------------------------
CREATE TABLE [MENUUSU] ([IDUSUARIO] LONG, [MENU] TEXT(12), [INDICE] SHORT, [LIGADO] BIT, [ATUALIZADO] BIT);
ALTER TABLE [MENUUSU] ADD CONSTRAINT [MENUUSU-1] PRIMARY KEY ([IDUSUARIO], [MENU], [INDICE]);

-- --------------------------------------------------
-- Estrutura da Tabela: USUARIO
-- --------------------------------------------------
CREATE TABLE [USUARIO] ([IDUSUARIO] LONG, [USUARIO] TEXT(10), [SENHA] TEXT(8), [DATAVAL] DATETIME, [DATAULT] DATETIME, [EQUIVALENTE] LONG, [ATIVO] BIT, [HORAINI] DATETIME, [HORAFIM] DATETIME, [WEEKEND] BIT, [IDFOLHA] DOUBLE, [NOMEFOLHA] TEXT(50), [TROCAR] DATETIME, [ID] LONG, [postelaa] TEXT(30), [postelaB] TEXT(30), [CHAVEH] TEXT(64), [CHAVEV] TEXT(64));
CREATE INDEX [IDUSUARIO] ON [USUARIO] ([IDUSUARIO]);
ALTER TABLE [USUARIO] ADD CONSTRAINT [USUARIO-1] PRIMARY KEY ([USUARIO]);

-- --------------------------------------------------
-- Estrutura da Tabela: USUCAD
-- --------------------------------------------------
CREATE TABLE [USUCAD] ([IDUSUARIO] LONG, [FORM] TEXT(20), [CADASTRO] SHORT, [CONTROLE] TEXT(20), [INDICE] LONG, [CAPTION] TEXT(20), [TOOLTIP] TEXT(50), [CORFRENTE] TEXT(12), [CORFUNDO] TEXT(12), [FONTE] TEXT(12), [LIGADO] BIT, [ATUALIZADO] BIT);
ALTER TABLE [USUCAD] ADD CONSTRAINT [USUCAD-1] PRIMARY KEY ([IDUSUARIO], [FORM], [CONTROLE], [INDICE]);

-- Fim do Script de DESTINO (ACCDB)
