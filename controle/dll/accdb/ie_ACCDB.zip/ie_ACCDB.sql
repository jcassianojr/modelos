-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: DESTINO (ACCDB)
-- Gerado em: 17/05/2026 09:31:08
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: IE
-- --------------------------------------------------
CREATE TABLE [IE] ([PF] DOUBLE, [DETALHE] MEMO, [TIPO] MEMO, [FECHA] MEMO, [NPED] DOUBLE, [IDENT] MEMO, [PROTE] MEMO, [QML] DOUBLE, [COM] DOUBLE, [LAR] DOUBLE, [ALT] DOUBLE, [UND] DOUBLE, [TOTL] DOUBLE, [TARA] DOUBLE, [BRUTO] DOUBLE, [METODO] MEMO, [OBS] MEMO, [IMAGEM] LONGBINARY, [DATA] DATETIME, [REVISAO] DOUBLE, [LOCAL] MEMO, [CODMR01] TEXT(10), [NOMMR01] TEXT(100), [DATAREV] DATETIME, [FOTOESQ] LONGBINARY, [FOTODIR] LONGBINARY, [CODDIR] TEXT(50), [CODESQ] TEXT(50), [CODIGOINT] TEXT(50), [codigocli] TEXT(50), [elaborador] TEXT(40));
ALTER TABLE [IE] ADD CONSTRAINT [PrimaryKey] PRIMARY KEY ([PF]);

-- Fim do Script de DESTINO (ACCDB)
