--
-- Arquivo gerado com SQLiteStudio v3.4.4 em sex set 20 11:34:15 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: anp
CREATE TABLE IF NOT EXISTS anp (
    codigo    TEXT (30)  NOT NULL,
    descricao TEXT (254) NOT NULL,
    dt_ini    SHORTDATE  NOT NULL,
    dt_fin    SHORTDATE  NOT NULL
);


-- Tabela: cartaobandeira
CREATE TABLE IF NOT EXISTS cartaobandeira (
    codigo TEXT (2)  NOT NULL,
    nome   TEXT (20) NOT NULL,
    dt_ini SHORTDATE NOT NULL,
    dt_fin SHORTDATE NOT NULL
);


-- Tabela: cest
CREATE TABLE IF NOT EXISTS cest (
    codigo    TEXT (7)   NOT NULL,
    descricao TEXT (255) NOT NULL,
    segmento  TEXT (2)   NOT NULL
);


-- Tabela: cest_ncm
CREATE TABLE IF NOT EXISTS cest_ncm (
    cest_id    TEXT (7) NOT NULL,
    ncm_id     TEXT (8) NOT NULL,
    tamanho    TEXT (1) NOT NULL,
    faixa_i    TEXT (8) NOT NULL,
    faixa_f    TEXT (8) NOT NULL,
    cest_segme TEXT (2) NOT NULL
);


-- Tabela: cest_segmento
CREATE TABLE IF NOT EXISTS cest_segmento (
    id        TEXT (2)   NOT NULL,
    anexo     TEXT (10)  NOT NULL,
    descricao TEXT (120) NOT NULL
);


-- Tabela: cl_enq_ipi
CREATE TABLE IF NOT EXISTS cl_enq_ipi (
    codigo    TEXT (30)  NOT NULL,
    descricao TEXT (254) NOT NULL,
    dt_ini    SHORTDATE  NOT NULL,
    dt_fin    SHORTDATE  NOT NULL
);


-- Tabela: cst_cofins
CREATE TABLE IF NOT EXISTS cst_cofins (
    codigo TEXT (2)   NOT NULL,
    nome   TEXT (150) NOT NULL,
    dt_ini SHORTDATE  NOT NULL,
    dt_fin SHORTDATE  NOT NULL
);


-- Tabela: cst_icm
CREATE TABLE IF NOT EXISTS cst_icm (
    codigo TEXT (3)   NOT NULL,
    nome   TEXT (150) NOT NULL,
    dt_ini SHORTDATE  NOT NULL,
    dt_fin SHORTDATE  NOT NULL
);


-- Tabela: cst_icms
CREATE TABLE IF NOT EXISTS cst_icms (
    codigo TEXT (30)  NOT NULL,
    nome   TEXT (254) NOT NULL,
    dt_ini SHORTDATE  NOT NULL,
    dt_fin SHORTDATE  NOT NULL
);


-- Tabela: cst_ipi
CREATE TABLE IF NOT EXISTS cst_ipi (
    codigo TEXT (2)   NOT NULL,
    nome   TEXT (150) NOT NULL,
    dt_ini SHORTDATE  NOT NULL,
    dt_fin SHORTDATE  NOT NULL
);


-- Tabela: cst_pis
CREATE TABLE IF NOT EXISTS cst_pis (
    codigo TEXT (2)   NOT NULL,
    nome   TEXT (150) NOT NULL,
    dt_ini SHORTDATE  NOT NULL,
    dt_fin SHORTDATE  NOT NULL
);


-- Tabela: efdtprod
CREATE TABLE IF NOT EXISTS efdtprod (
    codigo TEXT (2)  NOT NULL,
    nome   TEXT (30) NOT NULL
);


-- Tabela: fi_cai
CREATE TABLE IF NOT EXISTS fi_cai (
    seq     REAL      NOT NULL,
    data    SHORTDATE NOT NULL,
    descr   TEXT (30) NOT NULL,
    credito REAL      NOT NULL,
    debito  REAL      NOT NULL,
    saldo   REAL      NOT NULL,
    conta   TEXT (11) NOT NULL
);


-- Tabela: fi_cdipam
CREATE TABLE IF NOT EXISTS fi_cdipam (
    codigo TEXT (8)  NOT NULL,
    nome   TEXT (35) NOT NULL,
    uf     TEXT (2)  NOT NULL,
    ufibge TEXT (2)  NOT NULL,
    dipam  TEXT (4)  NOT NULL
);


-- Tabela: fi_ciap
CREATE TABLE IF NOT EXISTS fi_ciap (
    ciap      REAL      NOT NULL,
    ativo     TEXT (10) NOT NULL,
    nome      TEXT (40) NOT NULL,
    fornecedo REAL      NOT NULL,
    fornome   TEXT (40) NOT NULL,
    nrnota    REAL      NOT NULL,
    nritem    REAL      NOT NULL,
    lre       TEXT (3)  NOT NULL,
    lref      TEXT (3)  NOT NULL,
    nrentrega SHORTDATE NOT NULL,
    valoricm  REAL      NOT NULL,
    nrsaida   REAL      NOT NULL,
    modsaida  TEXT (3)  NOT NULL,
    dtsaida   SHORTDATE NOT NULL,
    dtinicio  SHORTDATE NOT NULL,
    obsnf     TEXT (20) NOT NULL
);


-- Tabela: fi_ciapi
CREATE TABLE IF NOT EXISTS fi_ciapi (
    ciap  REAL     NOT NULL,
    item  REAL     NOT NULL,
    mes   REAL     NOT NULL,
    ano   REAL     NOT NULL,
    valor REAL     NOT NULL,
    somar TEXT (1) NOT NULL
);


-- Tabela: fi_con
CREATE TABLE IF NOT EXISTS fi_con (
    codser TEXT (5)  NOT NULL,
    desser TEXT (60) NOT NULL,
    tipser TEXT (1)  NOT NULL
);


-- Tabela: fi_dipam
CREATE TABLE IF NOT EXISTS fi_dipam (
    dipam TEXT (2)   NOT NULL,
    nome  TEXT (100) NOT NULL
);


-- Tabela: fi_esp
CREATE TABLE IF NOT EXISTS fi_esp (
    codser  TEXT (7)  NOT NULL,
    desser  TEXT (60) NOT NULL,
    tipser  TEXT (1)  NOT NULL,
    expcont TEXT (1)  NOT NULL
);


-- Tabela: fi_inv
CREATE TABLE IF NOT EXISTS fi_inv (
    numero   REAL      NOT NULL,
    codipi   TEXT (2)  NOT NULL,
    classifi TEXT (14) NOT NULL,
    nome     TEXT (40) NOT NULL,
    qtdde    REAL      NOT NULL,
    unidade  TEXT (2)  NOT NULL,
    valoruni REAL      NOT NULL,
    valorpar REAL      NOT NULL,
    obs      TEXT (15) NOT NULL
);


-- Tabela: fi_mens
CREATE TABLE IF NOT EXISTS fi_mens (
    codigo   REAL       NOT NULL,
    ocorr    TEXT (254) NOT NULL,
    flegal   TEXT (100) NOT NULL,
    operacao TEXT (1)   NOT NULL
);


-- Tabela: fi_nbm
CREATE TABLE IF NOT EXISTS fi_nbm (
    numeronbm TEXT (8)   NOT NULL,
    descri    TEXT (100) NOT NULL,
    ipi_nbm   REAL       NOT NULL,
    icms_nbm  REAL       NOT NULL,
    tipo      TEXT (1)   NOT NULL,
    codnbm    TEXT (10)  NOT NULL,
    tributar  TEXT (1)   NOT NULL,
    aliqnac   REAL       NOT NULL,
    aliqimp   REAL       NOT NULL,
    ex        REAL       NOT NULL,
    aliqest   REAL       NOT NULL,
    aliqmun   REAL       NOT NULL,
    dataimp   SHORTDATE  NOT NULL
);


-- Tabela: fi_nbmcnv
CREATE TABLE IF NOT EXISTS fi_nbmcnv (
    numeronbm TEXT (8)  NOT NULL,
    codnbm    TEXT (10) NOT NULL,
    nomenbm   TEXT (55) NOT NULL
);


-- Tabela: fi_nbms
CREATE TABLE IF NOT EXISTS fi_nbms (
    numeronbm TEXT (9)   NOT NULL,
    descri    TEXT (100) NOT NULL,
    ipi_nbm   REAL       NOT NULL,
    icms_nbm  REAL       NOT NULL,
    tipo      TEXT (1)   NOT NULL,
    codnbm    TEXT (10)  NOT NULL,
    tributar  TEXT (1)   NOT NULL,
    aliqnac   REAL       NOT NULL,
    aliqimp   REAL       NOT NULL,
    ex        REAL       NOT NULL,
    aliqest   REAL       NOT NULL,
    aliqmun   REAL       NOT NULL,
    dataimp   SHORTDATE  NOT NULL
);


-- Tabela: fi_oco
CREATE TABLE IF NOT EXISTS fi_oco (
    ano       REAL      NOT NULL,
    mes       REAL      NOT NULL,
    tipo      TEXT (1)  NOT NULL,
    item      REAL      NOT NULL,
    descricao TEXT (50) NOT NULL,
    valicm    REAL      NOT NULL,
    valipi    REAL      NOT NULL
);


-- Tabela: fi_ser
CREATE TABLE IF NOT EXISTS fi_ser (
    codser  TEXT (5)  NOT NULL,
    desser  TEXT (60) NOT NULL,
    tipser  TEXT (1)  NOT NULL,
    expcont TEXT (1)  NOT NULL
);


-- Tabela: fi_temp1
CREATE TABLE IF NOT EXISTS fi_temp1 (
    cfo      TEXT (3) NOT NULL,
    cfonew   TEXT (4) NOT NULL,
    subcfo   TEXT (1) NOT NULL,
    icm      REAL     NOT NULL,
    ipi      REAL     NOT NULL,
    contabil REAL     NOT NULL,
    icmbas   REAL     NOT NULL,
    icmval   REAL     NOT NULL,
    icmise   REAL     NOT NULL,
    icmout   REAL     NOT NULL,
    obsicm   REAL     NOT NULL,
    ipibas   REAL     NOT NULL,
    ipival   REAL     NOT NULL,
    ipiise   REAL     NOT NULL,
    ipiout   REAL     NOT NULL,
    obsipi   REAL     NOT NULL
);


-- Tabela: indicador_presenca
CREATE TABLE IF NOT EXISTS indicador_presenca (
    codigo    TEXT (1)  NOT NULL,
    descricao TEXT (50) NOT NULL
);


-- Tabela: md03
CREATE TABLE IF NOT EXISTS md03 (
    codigo    TEXT (2)  NOT NULL,
    classific TEXT (14) NOT NULL,
    descricao TEXT (50) NOT NULL,
    aliquota  REAL      NOT NULL,
    aliquotar REAL      NOT NULL,
    aliquotai REAL      NOT NULL,
    dsta      TEXT (1)  NOT NULL
);


-- Tabela: md04
CREATE TABLE IF NOT EXISTS md04 (
    cfonew    TEXT (4)   NOT NULL,
    descricao TEXT (150) NOT NULL,
    cfo       TEXT (3)   NOT NULL,
    nomenota  TEXT (25)  NOT NULL,
    tipo      TEXT (1)   NOT NULL,
    dipam     TEXT (2)   NOT NULL,
    fin       TEXT (1)   NOT NULL,
    pis       TEXT (1)   NOT NULL,
    remessa   TEXT (1)   NOT NULL,
    dipipi    TEXT (1)   NOT NULL,
    dipicm    TEXT (1)   NOT NULL,
    codicm    TEXT (3)   NOT NULL,
    expcont   TEXT (1)   NOT NULL,
    contacre  TEXT (11)  NOT NULL,
    contadeb  TEXT (11)  NOT NULL,
    contas    TEXT (1)   NOT NULL,
    apura     TEXT (1)   NOT NULL,
    zeraipi   TEXT (1)   NOT NULL,
    ficha     TEXT (1)   NOT NULL,
    fatura    TEXT (1)   NOT NULL,
    irenda    TEXT (1)   NOT NULL,
    st        TEXT (1)   NOT NULL,
    stfrete   TEXT (1)   NOT NULL,
    benef     TEXT (1)   NOT NULL,
    icms      TEXT (1)   NOT NULL,
    ipi       TEXT (1)   NOT NULL,
    iss       TEXT (1)   NOT NULL,
    devolucao TEXT (1)   NOT NULL,
    servprod  TEXT (1)   NOT NULL,
    estoque   TEXT (1)   NOT NULL,
    tipo2     TEXT (1)   NOT NULL,
    nfe       TEXT (1)   NOT NULL,
    comunica  TEXT (1)   NOT NULL,
    transp    TEXT (1)   NOT NULL
);


-- Tabela: md05x
CREATE TABLE IF NOT EXISTS md05x (
    uficms     TEXT (2)  NOT NULL,
    ufdest     TEXT (2)  NOT NULL,
    nomeext    TEXT (20) NOT NULL,
    aliquota   REAL      NOT NULL,
    aliquotar  REAL      NOT NULL,
    zonafranca TEXT (1)  NOT NULL
);


-- Tabela: modais_frete
CREATE TABLE IF NOT EXISTS modais_frete (
    codigo    TEXT (1)  NOT NULL,
    descricao TEXT (30) NOT NULL
);


-- Tabela: modalidade_frete
CREATE TABLE IF NOT EXISTS modalidade_frete (
    codigo    TEXT (1)  NOT NULL,
    descricao TEXT (55) NOT NULL
);


-- Tabela: modalidade_frete_anp
CREATE TABLE IF NOT EXISTS modalidade_frete_anp (
    codigo    TEXT (2)  NOT NULL,
    descricao TEXT (50) NOT NULL
);


-- Tabela: modelo_cobranca
CREATE TABLE IF NOT EXISTS modelo_cobranca (
    codigo    TEXT (1)  NOT NULL,
    descricao TEXT (50) NOT NULL
);


-- Tabela: modelo_cobranca_cst
CREATE TABLE IF NOT EXISTS modelo_cobranca_cst (
    codigo    TEXT (1)  NOT NULL,
    descricao TEXT (50) NOT NULL
);


-- Tabela: MOEDA
CREATE TABLE IF NOT EXISTS MOEDA (
    CODIGO   INTEGER,
    NOME     CHAR (17),
    DATA_INI DATE,
    DATA_FIM DATE,
    PAIS     CHAR (60),
    SIMBOLO  CHAR (3),
    BACEN    INTEGER,
    TIPO     CHAR (1),
    MOEDA    CHAR (60),
    NUMINT   INTEGER,
    NUMDEC   INTEGER
);


-- Tabela: qualif_assinante
CREATE TABLE IF NOT EXISTS qualif_assinante (
    codigo    TEXT (3)  NOT NULL,
    descricao TEXT (70) NOT NULL,
    dt_ini    SHORTDATE NOT NULL,
    dt_fin    SHORTDATE NOT NULL
);


-- Tabela: sintdoc
CREATE TABLE IF NOT EXISTS sintdoc (
    codigo TEXT (2)  NOT NULL,
    nome   TEXT (70) NOT NULL,
    dt_ini SHORTDATE NOT NULL,
    dt_fin SHORTDATE NOT NULL
);


-- Tabela: sintsitu
CREATE TABLE IF NOT EXISTS sintsitu (
    codigo TEXT (1)  NOT NULL,
    nome   TEXT (20) NOT NULL
);


-- Tabela: tipo_pagamento
CREATE TABLE IF NOT EXISTS tipo_pagamento (
    codigo    TEXT (2)  NOT NULL,
    descricao TEXT (50) NOT NULL
);


-- Tabela: unidade_medida_comercial
CREATE TABLE IF NOT EXISTS unidade_medida_comercial (
    unidade TEXT (7)  NOT NULL,
    uniddes TEXT (25) NOT NULL,
    uniddec TEXT (1)  NOT NULL
);


-- �ndice: idx_anp_codigo
CREATE INDEX IF NOT EXISTS idx_anp_codigo ON anp (
    codigo
);


-- �ndice: idx_cartaobandeira_codigo
CREATE INDEX IF NOT EXISTS idx_cartaobandeira_codigo ON cartaobandeira (
    codigo
);


-- �ndice: idx_cest_codigo
CREATE INDEX IF NOT EXISTS idx_cest_codigo ON cest (
    codigo
);


-- �ndice: idx_cest_ncm_cest_ncm01
CREATE INDEX IF NOT EXISTS idx_cest_ncm_cest_ncm01 ON cest_ncm (
    cest_id
);


-- �ndice: idx_cest_ncm_cest_ncm02
CREATE INDEX IF NOT EXISTS idx_cest_ncm_cest_ncm02 ON cest_ncm (
    ncm_id
);


-- �ndice: idx_cest_ncm_cest_ncm03
CREATE INDEX IF NOT EXISTS idx_cest_ncm_cest_ncm03 ON cest_ncm (
    cest_segme
);


-- �ndice: idx_cest_ncm_cest_ncm04
CREATE INDEX IF NOT EXISTS idx_cest_ncm_cest_ncm04 ON cest_ncm (
    cest_segme,
    ncm_id
);


-- �ndice: idx_cest_segmento_segmento01
CREATE INDEX IF NOT EXISTS idx_cest_segmento_segmento01 ON cest_segmento (
    id
);


-- �ndice: idx_cest_segmento_segmento02
CREATE INDEX IF NOT EXISTS idx_cest_segmento_segmento02 ON cest_segmento (
    descricao
);


-- �ndice: idx_cl_enq_ipi_codigo
CREATE INDEX IF NOT EXISTS idx_cl_enq_ipi_codigo ON cl_enq_ipi (
    codigo
);


-- �ndice: idx_codigo
CREATE INDEX IF NOT EXISTS idx_codigo ON unidade_medida_comercial (
    unidade
);


-- �ndice: idx_cst_cofins_codigo
CREATE INDEX IF NOT EXISTS idx_cst_cofins_codigo ON cst_cofins (
    codigo
);


-- �ndice: idx_cst_cofins_nome
CREATE INDEX IF NOT EXISTS idx_cst_cofins_nome ON cst_cofins (
    nome
);


-- �ndice: idx_cst_icm_codigo
CREATE INDEX IF NOT EXISTS idx_cst_icm_codigo ON cst_icm (
    codigo
);


-- �ndice: idx_cst_icm_nome
CREATE INDEX IF NOT EXISTS idx_cst_icm_nome ON cst_icm (
    nome
);


-- �ndice: idx_cst_icms_codigo
CREATE INDEX IF NOT EXISTS idx_cst_icms_codigo ON cst_icms (
    codigo
);


-- �ndice: idx_cst_ipi_codigo
CREATE INDEX IF NOT EXISTS idx_cst_ipi_codigo ON cst_ipi (
    codigo
);


-- �ndice: idx_cst_ipi_nome
CREATE INDEX IF NOT EXISTS idx_cst_ipi_nome ON cst_ipi (
    nome
);


-- �ndice: idx_cst_pis_codigo
CREATE INDEX IF NOT EXISTS idx_cst_pis_codigo ON cst_pis (
    codigo
);


-- �ndice: idx_cst_pis_nome
CREATE INDEX IF NOT EXISTS idx_cst_pis_nome ON cst_pis (
    nome
);


-- �ndice: idx_efdtprod_efdprod
CREATE INDEX IF NOT EXISTS idx_efdtprod_efdprod ON efdtprod (
    codigo
);


-- �ndice: idx_fi_cai_fi_cai
CREATE INDEX IF NOT EXISTS idx_fi_cai_fi_cai ON fi_cai (
    seq
);


-- �ndice: idx_fi_cdipam_fi_cdipam
CREATE INDEX IF NOT EXISTS idx_fi_cdipam_fi_cdipam ON fi_cdipam (
    codigo
);


-- �ndice: idx_fi_cdipam_fi_cdipam2
CREATE INDEX IF NOT EXISTS idx_fi_cdipam_fi_cdipam2 ON fi_cdipam (
    uf,
    nome
);


-- �ndice: idx_fi_ciap_fi_ciap
CREATE INDEX IF NOT EXISTS idx_fi_ciap_fi_ciap ON fi_ciap (
    ciap
);


-- �ndice: idx_fi_ciapi_fi_ciap2
CREATE INDEX IF NOT EXISTS idx_fi_ciapi_fi_ciap2 ON fi_ciapi (
    ciap
);


-- �ndice: idx_fi_ciapi_fi_ciapi
CREATE INDEX IF NOT EXISTS idx_fi_ciapi_fi_ciapi ON fi_ciapi (
    ciap,
    item
);


-- �ndice: idx_fi_dipam_fi_dipam
CREATE INDEX IF NOT EXISTS idx_fi_dipam_fi_dipam ON fi_dipam (
    dipam
);


-- �ndice: idx_fi_esp_fi_esp
CREATE INDEX IF NOT EXISTS idx_fi_esp_fi_esp ON fi_esp (
    codser
);


-- �ndice: idx_fi_inv_fi_inv01
CREATE INDEX IF NOT EXISTS idx_fi_inv_fi_inv01 ON fi_inv (
    numero
);


-- �ndice: idx_fi_mens_fi_mens
CREATE INDEX IF NOT EXISTS idx_fi_mens_fi_mens ON fi_mens (
    codigo
);


-- �ndice: idx_fi_nbm_fi_nbm
CREATE INDEX IF NOT EXISTS idx_fi_nbm_fi_nbm ON fi_nbm (
    numeronbm
);


-- �ndice: idx_fi_nbm_fi_nbm-2
CREATE INDEX IF NOT EXISTS [idx_fi_nbm_fi_nbm-2] ON fi_nbm (
    codnbm
);


-- �ndice: idx_fi_nbmcnv_fi_nbm
CREATE INDEX IF NOT EXISTS idx_fi_nbmcnv_fi_nbm ON fi_nbmcnv (
    numeronbm
);


-- �ndice: idx_fi_nbmcnv_fi_nbm-2
CREATE INDEX IF NOT EXISTS [idx_fi_nbmcnv_fi_nbm-2] ON fi_nbmcnv (
    codnbm
);


-- �ndice: idx_fi_nbms_fi_nbm
CREATE INDEX IF NOT EXISTS idx_fi_nbms_fi_nbm ON fi_nbms (
    numeronbm
);


-- �ndice: idx_fi_nbms_fi_nbm-2
CREATE INDEX IF NOT EXISTS [idx_fi_nbms_fi_nbm-2] ON fi_nbms (
    codnbm
);


-- �ndice: idx_fi_oco_fi_oco
CREATE INDEX IF NOT EXISTS idx_fi_oco_fi_oco ON fi_oco (
    ano,
    mes,
    tipo,
    item
);


-- �ndice: idx_fi_ser_fi_ser01
CREATE INDEX IF NOT EXISTS idx_fi_ser_fi_ser01 ON fi_ser (
    codser
);


-- �ndice: idx_fi_temp1_fi_tem11
CREATE INDEX IF NOT EXISTS idx_fi_temp1_fi_tem11 ON fi_temp1 (
    cfo,
    subcfo,
    icm
);


-- �ndice: idx_fi_temp1_fi_tem12
CREATE INDEX IF NOT EXISTS idx_fi_temp1_fi_tem12 ON fi_temp1 (
    cfonew,
    icm
);


-- �ndice: idx_fi_temp1_fi_tem13
CREATE INDEX IF NOT EXISTS idx_fi_temp1_fi_tem13 ON fi_temp1 (
    cfo,
    subcfo,
    ipi
);


-- �ndice: idx_fi_temp1_fi_tem14
CREATE INDEX IF NOT EXISTS idx_fi_temp1_fi_tem14 ON fi_temp1 (
    cfonew,
    ipi
);


-- �ndice: idx_indicador_presenca_codigo
CREATE INDEX IF NOT EXISTS idx_indicador_presenca_codigo ON indicador_presenca (
    codigo
);


-- �ndice: idx_md04_md04-1
CREATE INDEX IF NOT EXISTS [idx_md04_md04-1] ON md04 (
    cfo,
    cfonew
);


-- �ndice: idx_md04_md04-2
CREATE INDEX IF NOT EXISTS [idx_md04_md04-2] ON md04 (
    cfonew
);


-- �ndice: idx_md04_md04-3
CREATE INDEX IF NOT EXISTS [idx_md04_md04-3] ON md04 (
    cfo
);


-- �ndice: idx_md05x_md05x-1
CREATE INDEX IF NOT EXISTS [idx_md05x_md05x-1] ON md05x (
    uficms
);


-- �ndice: idx_md05x_md05x-2
CREATE INDEX IF NOT EXISTS [idx_md05x_md05x-2] ON md05x (
    nomeext
);


-- �ndice: idx_md05x_md05x-3
CREATE INDEX IF NOT EXISTS [idx_md05x_md05x-3] ON md05x (
    uficms,
    ufdest
);


-- �ndice: idx_modais_frete_codigo
CREATE INDEX IF NOT EXISTS idx_modais_frete_codigo ON modais_frete (
    codigo
);


-- �ndice: idx_modalidade_frete_anp_codigo
CREATE INDEX IF NOT EXISTS idx_modalidade_frete_anp_codigo ON modalidade_frete_anp (
    codigo
);


-- �ndice: idx_modalidade_frete_codigo
CREATE INDEX IF NOT EXISTS idx_modalidade_frete_codigo ON modalidade_frete (
    codigo
);


-- �ndice: idx_modelo_cobranca_codigo
CREATE INDEX IF NOT EXISTS idx_modelo_cobranca_codigo ON modelo_cobranca (
    codigo
);


-- �ndice: idx_modelo_cobranca_cst_codigo
CREATE INDEX IF NOT EXISTS idx_modelo_cobranca_cst_codigo ON modelo_cobranca_cst (
    codigo
);


-- �ndice: idx_qualif_assinante_codigo
CREATE INDEX IF NOT EXISTS idx_qualif_assinante_codigo ON qualif_assinante (
    codigo
);


-- �ndice: idx_sintdoc_codigo
CREATE INDEX IF NOT EXISTS idx_sintdoc_codigo ON sintdoc (
    codigo
);


-- �ndice: idx_sintdoc_nome
CREATE INDEX IF NOT EXISTS idx_sintdoc_nome ON sintdoc (
    nome
);


-- �ndice: idx_sintsitu_sintsit2
CREATE INDEX IF NOT EXISTS idx_sintsitu_sintsit2 ON sintsitu (
    nome
);


-- �ndice: idx_sintsitu_sintsitu
CREATE INDEX IF NOT EXISTS idx_sintsitu_sintsitu ON sintsitu (
    codigo
);


-- �ndice: idx_tipo_pagamento_codigo
CREATE INDEX IF NOT EXISTS idx_tipo_pagamento_codigo ON tipo_pagamento (
    codigo
);


-- �ndice: NOME
CREATE INDEX IF NOT EXISTS NOME ON MOEDA (
    NOME
);


-- �ndice: PAIS
CREATE INDEX IF NOT EXISTS PAIS ON MOEDA (
    PAIS
);


-- �ndice: SIMBOLO
CREATE INDEX IF NOT EXISTS SIMBOLO ON MOEDA (
    SIMBOLO
);


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
