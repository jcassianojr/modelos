--
-- Arquivo gerado com SQLiteStudio v3.4.4 em ter ago 6 17:30:24 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: bs1
CREATE TABLE IF NOT EXISTS [bs1] ([qtdde] REAL NOT NULL, [qtd01] REAL NOT NULL, [qtd02] REAL NOT NULL, [qtd03] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [per01] REAL NOT NULL, [per02] REAL NOT NULL, [per03] REAL NOT NULL, [peq01] REAL NOT NULL, [peq02] REAL NOT NULL, [peq03] REAL NOT NULL, [f0] REAL NOT NULL, [f1] REAL NOT NULL, [f2] REAL NOT NULL, [ent] REAL NOT NULL, [emplogix] TEXT(2) NOT NULL);

-- Tabela: bs2
CREATE TABLE IF NOT EXISTS [bs2] ([grupo] TEXT(12) NOT NULL, [qtdde] REAL NOT NULL, [qtd01] REAL NOT NULL, [qtd02] REAL NOT NULL, [qtd03] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [per01] REAL NOT NULL, [per02] REAL NOT NULL, [per03] REAL NOT NULL, [peq01] REAL NOT NULL, [peq02] REAL NOT NULL, [peq03] REAL NOT NULL, [f0] REAL NOT NULL, [f1] REAL NOT NULL, [f2] REAL NOT NULL, [ent] REAL NOT NULL, [emplogix] TEXT(2) NOT NULL);

-- Tabela: bs3
CREATE TABLE IF NOT EXISTS [bs3] ([codigo] TEXT(12) NOT NULL, [nome] TEXT(30) NOT NULL, [grupoutl] TEXT(3) NOT NULL, [estoque] REAL NOT NULL, [estoqu3] REAL NOT NULL, [uso01] REAL NOT NULL, [uso02] REAL NOT NULL, [uso03] REAL NOT NULL, [uso04] REAL NOT NULL, [sal01] REAL NOT NULL, [sal02] REAL NOT NULL, [sal03] REAL NOT NULL, [sal04] REAL NOT NULL, [sa301] REAL NOT NULL, [sa302] REAL NOT NULL, [sa303] REAL NOT NULL, [sa304] REAL NOT NULL, [emplogix] TEXT(2) NOT NULL);

-- Tabela: bs5
CREATE TABLE IF NOT EXISTS [bs5] ([cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [grupo] TEXT(12) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [qtdde] REAL NOT NULL, [qtd01] REAL NOT NULL, [qtd02] REAL NOT NULL, [qtd03] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [per01] REAL NOT NULL, [per02] REAL NOT NULL, [per03] REAL NOT NULL, [peq01] REAL NOT NULL, [peq02] REAL NOT NULL, [peq03] REAL NOT NULL, [f0] REAL NOT NULL, [f1] REAL NOT NULL, [f2] REAL NOT NULL, [ent] REAL NOT NULL, [emplogix] TEXT(2) NOT NULL);

-- Tabela: bs6
CREATE TABLE IF NOT EXISTS [bs6] ([cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [grupo] TEXT(12) NOT NULL, [nome] TEXT(40) NOT NULL, [qtdde] REAL NOT NULL, [qtd01] REAL NOT NULL, [qtd02] REAL NOT NULL, [qtd03] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [per01] REAL NOT NULL, [per02] REAL NOT NULL, [per03] REAL NOT NULL, [peq01] REAL NOT NULL, [peq02] REAL NOT NULL, [peq03] REAL NOT NULL, [f0] REAL NOT NULL, [f1] REAL NOT NULL, [f2] REAL NOT NULL, [ent] REAL NOT NULL, [emplogix] TEXT(2) NOT NULL);

-- Tabela: iacseq
CREATE TABLE IF NOT EXISTS [iacseq] ([seq] REAL NOT NULL, [diafim] SHORTDATE NOT NULL, [diaini] SHORTDATE NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [descri] TEXT(30) NOT NULL, [anual] TEXT(1) NOT NULL, [semes] TEXT(1) NOT NULL, [descr2] TEXT(10) NOT NULL);

-- Tabela: mm02iac
CREATE TABLE IF NOT EXISTS [mm02iac] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [os] REAL NOT NULL, [qtde] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [entrega] SHORTDATE NOT NULL, [qtdesal] REAL NOT NULL, [ositem] REAL NOT NULL, [codigoint] TEXT(24) NOT NULL, [codcliente] TEXT(20) NOT NULL, [preco] REAL NOT NULL, [nome] TEXT(25) NOT NULL, [valormer] REAL NOT NULL, [classipi] TEXT(10) NOT NULL, [tipoent] TEXT(1) NOT NULL, [cgc] TEXT(18) NOT NULL, [cognome] TEXT(20) NOT NULL, [emplogix] TEXT(2) NOT NULL);

-- Tabela: rd
CREATE TABLE IF NOT EXISTS [rd] ([seq] REAL NOT NULL, [diaini] SHORTDATE NOT NULL, [diafim] SHORTDATE NOT NULL, [anual] TEXT(1) NOT NULL, [semes] TEXT(1) NOT NULL, [descri] TEXT(30) NOT NULL, [descr2] TEXT(10) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [eqpu] REAL NOT NULL, [eqpe] REAL NOT NULL, [eqpp] REAL NOT NULL, [fupu] REAL NOT NULL, [fupe] REAL NOT NULL, [fupp] REAL NOT NULL, [eqht] REAL NOT NULL, [eqhp] REAL NOT NULL, [eqh24] REAL NOT NULL, [eqhd] REAL NOT NULL, [eqqp] REAL NOT NULL, [fuht] REAL NOT NULL, [fuhp] REAL NOT NULL, [fuhd] REAL NOT NULL, [fuqp] REAL NOT NULL, [pahp] REAL NOT NULL, [eqpere] REAL NOT NULL, [eqppre] REAL NOT NULL, [eqpure] REAL NOT NULL, [eqpe24] REAL NOT NULL, [eqpp24] REAL NOT NULL, [eqpu24] REAL NOT NULL, [prpe] REAL NOT NULL);

-- Tabela: rde
CREATE TABLE IF NOT EXISTS [rde] ([seq] REAL NOT NULL, [numero] TEXT(4) NOT NULL, [nome] TEXT(40) NOT NULL, [ht] REAL NOT NULL, [hp] REAL NOT NULL, [hd] REAL NOT NULL, [hdre] REAL NOT NULL, [hd24] REAL NOT NULL, [qp] REAL NOT NULL, [media] REAL NOT NULL, [pu] REAL NOT NULL, [pe] REAL NOT NULL, [pp] REAL NOT NULL, [pe24] REAL NOT NULL, [pere] REAL NOT NULL, [pu24] REAL NOT NULL, [pure] REAL NOT NULL, [pp24] REAL NOT NULL, [ppre] REAL NOT NULL);

-- Tabela: rdf
CREATE TABLE IF NOT EXISTS [rdf] ([seq] REAL NOT NULL, [numero] REAL NOT NULL, [nome] TEXT(40) NOT NULL, [ht] REAL NOT NULL, [hp] REAL NOT NULL, [hd] REAL NOT NULL, [qp] REAL NOT NULL, [media] REAL NOT NULL, [pu] REAL NOT NULL, [pe] REAL NOT NULL, [pp] REAL NOT NULL);

-- Tabela: rdp
CREATE TABLE IF NOT EXISTS [rdp] ([seq] REAL NOT NULL, [numero] TEXT(3) NOT NULL, [nome] TEXT(40) NOT NULL, [hp] REAL NOT NULL, [anual] TEXT(1) NOT NULL, [mes] REAL NOT NULL);

-- Tabela: rdpd
CREATE TABLE IF NOT EXISTS [rdpd] ([seq] REAL NOT NULL, [numero] TEXT(2) NOT NULL, [nome] TEXT(40) NOT NULL, [hp] REAL NOT NULL);

-- Tabela: rdt
CREATE TABLE IF NOT EXISTS [rdt] ([codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [pqtdde] REAL NOT NULL, [phoras] REAL NOT NULL, [qtdde] REAL NOT NULL, [padrao] REAL NOT NULL, [padra4] REAL NOT NULL, [media] REAL NOT NULL, [medi4] REAL NOT NULL, [simetrica] BIT NOT NULL, [dataapu] SHORTDATE NOT NULL);

-- Tabela: rdtbx
CREATE TABLE IF NOT EXISTS [rdtbx] ([codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [pqtdde] REAL NOT NULL, [phoras] REAL NOT NULL, [qtdde] REAL NOT NULL, [padrao] REAL NOT NULL, [padra4] REAL NOT NULL, [media] REAL NOT NULL, [medi4] REAL NOT NULL, [simetrica] BIT NOT NULL, [dataapu] SHORTDATE NOT NULL, [databai] SHORTDATE NOT NULL);

-- �ndice: idx_bs1_bs1-1
CREATE INDEX IF NOT EXISTS [idx_bs1_bs1-1] ON [bs1] ([ano], [mes]);

-- �ndice: idx_bs2_bs2-1
CREATE INDEX IF NOT EXISTS [idx_bs2_bs2-1] ON [bs2] ([ano], [mes], [grupo]);

-- �ndice: idx_bs5_bs5-1
CREATE INDEX IF NOT EXISTS [idx_bs5_bs5-1] ON [bs5] ([ano], [mes], [cliente], [codigo]);

-- �ndice: idx_bs5_bs5-2
CREATE INDEX IF NOT EXISTS [idx_bs5_bs5-2] ON [bs5] ([codigo], [ano], [mes]);

-- �ndice: idx_bs6_bs6-1
CREATE INDEX IF NOT EXISTS [idx_bs6_bs6-1] ON [bs6] ([ano], [mes], [cliente]);

-- �ndice: idx_iacseq_seq
CREATE INDEX IF NOT EXISTS [idx_iacseq_seq] ON [iacseq] ([seq]);

-- �ndice: idx_rd_rd
CREATE INDEX IF NOT EXISTS [idx_rd_rd] ON [rd] ([seq]);

-- �ndice: idx_rd_rd-2
CREATE INDEX IF NOT EXISTS [idx_rd_rd-2] ON [rd] ([ano], [mes]);

-- �ndice: idx_rde_rde
CREATE INDEX IF NOT EXISTS [idx_rde_rde] ON [rde] ([seq]);

-- �ndice: idx_rdf_rdf
CREATE INDEX IF NOT EXISTS [idx_rdf_rdf] ON [rdf] ([seq]);

-- �ndice: idx_rdp_rdp
CREATE INDEX IF NOT EXISTS [idx_rdp_rdp] ON [rdp] ([seq]);

-- �ndice: idx_rdp_rdp-2
CREATE INDEX IF NOT EXISTS [idx_rdp_rdp-2] ON [rdp] ([numero]);

-- �ndice: idx_rdpd_rdpd
CREATE INDEX IF NOT EXISTS [idx_rdpd_rdpd] ON [rdpd] ([seq]);

-- �ndice: idx_rdt_rdt
CREATE INDEX IF NOT EXISTS [idx_rdt_rdt] ON [rdt] ([codigo], [seq], [ssq], [ano], [mes]);

-- �ndice: idx_rdtbx
CREATE INDEX IF NOT EXISTS [idx_rdtbx] ON [rdtbx] ([codigo], [seq], [ssq], [ano], [mes]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
