CREATE TABLE IF NOT EXISTS BS1 (
    QTDDE INTEGER default 0
    ,QTD01 INTEGER default 0
    ,QTD02 INTEGER default 0
    ,QTD03 INTEGER default 0
    ,MES INTEGER default 0
    ,ANO INTEGER default 0
    ,PER01 FLOAT  default 0
    ,PER02 FLOAT  default 0
    ,PER03 FLOAT  default 0
    ,PEQ01 FLOAT  default 0
    ,PEQ02 FLOAT  default 0
    ,PEQ03 FLOAT  default 0
    ,F0 INTEGER default 0
    ,F1 INTEGER default 0
    ,F2 INTEGER default 0
    ,ENT INTEGER default 0
    ,EMPLOGIX TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX BS1_1 ON BS1 ( ANO,MES ) ;
ALTER TABLE BS1 ADD PRIMARY KEY(ANO,MES) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS BS2 (
    GRUPO TEXT NOT NULL DEFAULT ('')
    ,QTDDE INTEGER default 0
    ,QTD01 INTEGER default 0
    ,QTD02 INTEGER default 0
    ,QTD03 INTEGER default 0
    ,MES INTEGER default 0
    ,ANO INTEGER default 0
    ,PER01 FLOAT  default 0
    ,PER02 FLOAT  default 0
    ,PER03 FLOAT  default 0
    ,PEQ01 FLOAT  default 0
    ,PEQ02 FLOAT  default 0
    ,PEQ03 FLOAT  default 0
    ,F0 INTEGER default 0
    ,F1 INTEGER default 0
    ,F2 INTEGER default 0
    ,ENT INTEGER default 0
    ,EMPLOGIX TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX BS2_1 ON BS2 ( ANO,MES,GRUPO ) ;
ALTER TABLE BS2 ADD PRIMARY KEY(ANO,MES,GRUPO) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS BS3 (
    CODIGO TEXT NOT NULL DEFAULT ('')
    ,NOME TEXT NOT NULL DEFAULT ('')
    ,GRUPOUTL TEXT NOT NULL DEFAULT ('')
    ,ESTOQUE INTEGER default 0
    ,ESTOQU3 INTEGER default 0
    ,USO01 INTEGER default 0
    ,USO02 INTEGER default 0
    ,USO03 INTEGER default 0
    ,USO04 INTEGER default 0
    ,SAL01 INTEGER default 0
    ,SAL02 INTEGER default 0
    ,SAL03 INTEGER default 0
    ,SAL04 INTEGER default 0
    ,SA301 INTEGER default 0
    ,SA302 INTEGER default 0
    ,SA303 INTEGER default 0
    ,SA304 INTEGER default 0
    ,EMPLOGIX TEXT NOT NULL DEFAULT ('')
) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS BS5 (
    CLIENTE INTEGER default 0
    ,COGCLI TEXT NOT NULL DEFAULT ('')
    ,GRUPO TEXT NOT NULL DEFAULT ('')
    ,CODIGO TEXT NOT NULL DEFAULT ('')
    ,NOME TEXT NOT NULL DEFAULT ('')
    ,QTDDE INTEGER default 0
    ,QTD01 INTEGER default 0
    ,QTD02 INTEGER default 0
    ,QTD03 INTEGER default 0
    ,MES INTEGER default 0
    ,ANO INTEGER default 0
    ,PER01 FLOAT  default 0
    ,PER02 FLOAT  default 0
    ,PER03 FLOAT  default 0
    ,PEQ01 FLOAT  default 0
    ,PEQ02 FLOAT  default 0
    ,PEQ03 FLOAT  default 0
    ,F0 INTEGER default 0
    ,F1 INTEGER default 0
    ,F2 INTEGER default 0
    ,ENT INTEGER default 0
    ,EMPLOGIX TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX BS5_1 ON BS5 ( ANO,MES,CLIENTE,CODIGO ) ;
ALTER TABLE BS5 ADD PRIMARY KEY(ANO,MES,CLIENTE,CODIGO) ;
CREATE INDEX BS5_2 ON BS5 ( CODIGO,ANO,MES ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS BS6 (
    CLIENTE INTEGER default 0
    ,COGCLI TEXT NOT NULL DEFAULT ('')
    ,GRUPO TEXT NOT NULL DEFAULT ('')
    ,NOME TEXT NOT NULL DEFAULT ('')
    ,QTDDE INTEGER default 0
    ,QTD01 INTEGER default 0
    ,QTD02 INTEGER default 0
    ,QTD03 INTEGER default 0
    ,MES INTEGER default 0
    ,ANO INTEGER default 0
    ,PER01 FLOAT  default 0
    ,PER02 FLOAT  default 0
    ,PER03 FLOAT  default 0
    ,PEQ01 FLOAT  default 0
    ,PEQ02 FLOAT  default 0
    ,PEQ03 FLOAT  default 0
    ,F0 INTEGER default 0
    ,F1 INTEGER default 0
    ,F2 INTEGER default 0
    ,ENT INTEGER default 0
    ,EMPLOGIX TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX BS6_1 ON BS6 ( ANO,MES,CLIENTE ) ;
ALTER TABLE BS6 ADD PRIMARY KEY(ANO,MES,CLIENTE) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS IACSEQ (
    SEQ INTEGER default 0
    ,DIAFIM DATE NOT NULL DEFAULT ('')
    ,DIAINI DATE NOT NULL DEFAULT ('')
    ,MES INTEGER default 0
    ,ANO INTEGER default 0
    ,DESCRI TEXT NOT NULL DEFAULT ('')
    ,ANUAL TEXT NOT NULL DEFAULT ('')
    ,SEMES TEXT NOT NULL DEFAULT ('')
    ,DESCR2 TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX SEQ ON IACSEQ ( SEQ ) ;
ALTER TABLE IACSEQ ADD PRIMARY KEY(SEQ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS MM02IAC (
    NUMERO INTEGER default 0
    ,DATA DATE NOT NULL DEFAULT ('')
    ,FORNECEDO INTEGER default 0
    ,OS INTEGER default 0
    ,QTDE FLOAT  default 0
    ,CODIGO TEXT NOT NULL DEFAULT ('')
    ,ENTREGA DATE NOT NULL DEFAULT ('')
    ,QTDESAL FLOAT  default 0
    ,OSITEM INTEGER default 0
    ,CODIGOINT TEXT NOT NULL DEFAULT ('')
    ,CODCLIENTE TEXT NOT NULL DEFAULT ('')
    ,PRECO FLOAT  default 0
    ,NOME TEXT NOT NULL DEFAULT ('')
    ,VALORMER FLOAT  default 0
    ,CLASSIPI TEXT NOT NULL DEFAULT ('')
    ,TIPOENT TEXT NOT NULL DEFAULT ('')
    ,CGC TEXT NOT NULL DEFAULT ('')
    ,COGNOME TEXT NOT NULL DEFAULT ('')
    ,EMPLOGIX TEXT NOT NULL DEFAULT ('')
) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS RD (
    SEQ INTEGER default 0
    ,DIAINI DATE NOT NULL DEFAULT ('')
    ,DIAFIM DATE NOT NULL DEFAULT ('')
    ,ANUAL TEXT NOT NULL DEFAULT ('')
    ,SEMES TEXT NOT NULL DEFAULT ('')
    ,DESCRI TEXT NOT NULL DEFAULT ('')
    ,DESCR2 TEXT NOT NULL DEFAULT ('')
    ,MES INTEGER default 0
    ,ANO INTEGER default 0
    ,EQPU FLOAT  default 0
    ,EQPE FLOAT  default 0
    ,EQPP FLOAT  default 0
    ,FUPU FLOAT  default 0
    ,FUPE FLOAT  default 0
    ,FUPP FLOAT  default 0
    ,EQHT FLOAT  default 0
    ,EQHP FLOAT  default 0
    ,EQH24 FLOAT  default 0
    ,EQHD FLOAT  default 0
    ,EQQP INTEGER default 0
    ,FUHT FLOAT  default 0
    ,FUHP FLOAT  default 0
    ,FUHD FLOAT  default 0
    ,FUQP INTEGER default 0
    ,PAHP FLOAT  default 0
    ,EQPERE FLOAT  default 0
    ,EQPPRE FLOAT  default 0
    ,EQPURE FLOAT  default 0
    ,EQPE24 FLOAT  default 0
    ,EQPP24 FLOAT  default 0
    ,EQPU24 FLOAT  default 0
    ,PRPE FLOAT  default 0
) ;
CREATE INDEX RD ON RD ( SEQ ) ;
ALTER TABLE RD ADD PRIMARY KEY(SEQ) ;
CREATE INDEX RD_2 ON RD ( ANO,MES ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS RDE (
    SEQ INTEGER default 0
    ,NUMERO TEXT NOT NULL DEFAULT ('')
    ,NOME TEXT NOT NULL DEFAULT ('')
    ,HT FLOAT  default 0
    ,HP FLOAT  default 0
    ,HD FLOAT  default 0
    ,HDRE FLOAT  default 0
    ,HD24 FLOAT  default 0
    ,QP INTEGER default 0
    ,MEDIA INTEGER default 0
    ,PU FLOAT  default 0
    ,PE FLOAT  default 0
    ,PP FLOAT  default 0
    ,PE24 FLOAT  default 0
    ,PERE FLOAT  default 0
    ,PU24 FLOAT  default 0
    ,PURE FLOAT  default 0
    ,PP24 FLOAT  default 0
    ,PPRE FLOAT  default 0
) ;
CREATE INDEX RDE ON RDE ( SEQ ) ;
ALTER TABLE RDE ADD PRIMARY KEY(SEQ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS RDF (
    SEQ INTEGER default 0
    ,NUMERO INTEGER default 0
    ,NOME TEXT NOT NULL DEFAULT ('')
    ,HT FLOAT  default 0
    ,HP FLOAT  default 0
    ,HD FLOAT  default 0
    ,QP INTEGER default 0
    ,MEDIA INTEGER default 0
    ,PU FLOAT  default 0
    ,PE FLOAT  default 0
    ,PP FLOAT  default 0
) ;
CREATE INDEX RDF ON RDF ( SEQ ) ;
ALTER TABLE RDF ADD PRIMARY KEY(SEQ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS RDP (
    SEQ INTEGER default 0
    ,NUMERO TEXT NOT NULL DEFAULT ('')
    ,NOME TEXT NOT NULL DEFAULT ('')
    ,HP FLOAT  default 0
    ,ANUAL TEXT NOT NULL DEFAULT ('')
    ,MES INTEGER default 0
) ;
CREATE INDEX RDP ON RDP ( SEQ ) ;
ALTER TABLE RDP ADD PRIMARY KEY(SEQ) ;
CREATE INDEX RDP_2 ON RDP ( NUMERO ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS RDPD (
    SEQ INTEGER default 0
    ,NUMERO TEXT NOT NULL DEFAULT ('')
    ,NOME TEXT NOT NULL DEFAULT ('')
    ,HP FLOAT  default 0
) ;
CREATE INDEX RDPD ON RDPD ( SEQ ) ;
ALTER TABLE RDPD ADD PRIMARY KEY(SEQ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS RDPT (
    NUMERO TEXT NOT NULL DEFAULT ('')
    ,NOME TEXT NOT NULL DEFAULT ('')
    ,VAL01 FLOAT  default 0
    ,POS01 INTEGER default 0
    ,POX01 INTEGER default 0
    ,VAL02 FLOAT  default 0
    ,POS02 INTEGER default 0
    ,POX02 INTEGER default 0
    ,VAL03 FLOAT  default 0
    ,POS03 INTEGER default 0
    ,POX03 INTEGER default 0
    ,VAL04 FLOAT  default 0
    ,POS04 INTEGER default 0
    ,POX04 INTEGER default 0
    ,VAL05 FLOAT  default 0
    ,POS05 INTEGER default 0
    ,POX05 INTEGER default 0
    ,VAL06 FLOAT  default 0
    ,POS06 INTEGER default 0
    ,POX06 INTEGER default 0
    ,VAL07 FLOAT  default 0
    ,POS07 INTEGER default 0
    ,POX07 INTEGER default 0
    ,VAL08 FLOAT  default 0
    ,POS08 INTEGER default 0
    ,POX08 INTEGER default 0
    ,VAL09 FLOAT  default 0
    ,POS09 INTEGER default 0
    ,POX09 INTEGER default 0
    ,VAL10 FLOAT  default 0
    ,POS10 INTEGER default 0
    ,POX10 INTEGER default 0
    ,VAL11 FLOAT  default 0
    ,POS11 INTEGER default 0
    ,POX11 INTEGER default 0
    ,VAL12 FLOAT  default 0
    ,POS12 INTEGER default 0
    ,POX12 INTEGER default 0
    ,TOTAL FLOAT  default 0
    ,POS00 INTEGER default 0
    ,POX00 INTEGER default 0
) ;
CREATE INDEX RDPT ON RDPT ( NUMERO ) ;
ALTER TABLE RDPT ADD PRIMARY KEY(NUMERO) ;
CREATE INDEX TOTAL ON RDPT ( TOTAL ) ;
CREATE INDEX VAL01 ON RDPT ( VAL01 ) ;
CREATE INDEX VAL02 ON RDPT ( VAL02 ) ;
CREATE INDEX VAL03 ON RDPT ( VAL03 ) ;
CREATE INDEX VAL04 ON RDPT ( VAL04 ) ;
CREATE INDEX VAL05 ON RDPT ( VAL05 ) ;
CREATE INDEX VAL06 ON RDPT ( VAL06 ) ;
CREATE INDEX VAL07 ON RDPT ( VAL07 ) ;
CREATE INDEX VAL08 ON RDPT ( VAL08 ) ;
CREATE INDEX VAL09 ON RDPT ( VAL09 ) ;
CREATE INDEX VAL10 ON RDPT ( VAL10 ) ;
CREATE INDEX VAL11 ON RDPT ( VAL11 ) ;
CREATE INDEX VAL12 ON RDPT ( VAL12 ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS RDT (
    CODIGO TEXT NOT NULL DEFAULT ('')
    ,SEQ INTEGER default 0
    ,SSQ INTEGER default 0
    ,MES INTEGER default 0
    ,ANO INTEGER default 0
    ,PQTDDE INTEGER default 0
    ,PHORAS FLOAT  default 0
    ,QTDDE FLOAT  default 0
    ,PADRAO INTEGER default 0
    ,PADRA4 INTEGER default 0
    ,MEDIA FLOAT  default 0
    ,MEDI4 FLOAT  default 0
    ,SIMETRICA BOOLEAN
    ,DATAAPU DATE NOT NULL DEFAULT ('')
) ;
CREATE INDEX RDT ON RDT ( CODIGO,SEQ,SSQ,ANO,MES ) ;
ALTER TABLE RDT ADD PRIMARY KEY(CODIGO,SEQ,SSQ,ANO,MES) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS RDTBX (
    CODIGO TEXT NOT NULL DEFAULT ('')
    ,SEQ INTEGER default 0
    ,SSQ INTEGER default 0
    ,MES INTEGER default 0
    ,ANO INTEGER default 0
    ,PQTDDE INTEGER default 0
    ,PHORAS FLOAT  default 0
    ,QTDDE FLOAT  default 0
    ,PADRAO INTEGER default 0
    ,PADRA4 INTEGER default 0
    ,MEDIA FLOAT  default 0
    ,MEDI4 FLOAT  default 0
    ,SIMETRICA BOOLEAN
    ,DATAAPU DATE NOT NULL DEFAULT ('')
    ,DATABAI DATE NOT NULL DEFAULT ('')
) ;
CREATE INDEX RDTBX ON RDTBX ( CODIGO,SEQ,SSQ,ANO,MES ) ;
ALTER TABLE RDTBX ADD PRIMARY KEY(CODIGO,SEQ,SSQ,ANO,MES) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
