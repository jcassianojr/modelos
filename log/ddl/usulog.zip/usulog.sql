--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 17:34:11 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: log
CREATE TABLE IF NOT EXISTS [log] (
	[user] int, 
	[form] int, 
	[opr] varchar(50), 
	[botao] int, 
	[data] datetime, 
	[OBS] longtext
);

-- Tabela: USULOG
CREATE TABLE IF NOT EXISTS [USULOG] (
	[IDUSUARIO] int, 
	[TIPO] tinyint, 
	[FORM] varchar(20), 
	[ACAO] tinyint, 
	[DATA] datetime, 
	[HORA] datetime
);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
