--
-- Arquivo gerado com SQLiteStudio v3.4.4 em qui ago 8 09:05:20 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: log
CREATE TABLE IF NOT EXISTS log (userid int DEFAULT (0), form int DEFAULT (0), opr varchar (50), botao int DEFAULT (0), data datetime, OBS longtext, idlog INTEGER PRIMARY KEY AUTOINCREMENT);

-- Tabela: manerr
CREATE TABLE IF NOT EXISTS manerr (
    usuario TEXT (10) NOT NULL,
    data    DATETIME NOT NULL,
    hora    TEXT (8)  NOT NULL,
    erro    TEXT (20) NOT NULL,
    opr     TEXT (3)  NOT NULL,
    arquivo TEXT (8)  NOT NULL,
    idlog   INTEGER   PRIMARY KEY AUTOINCREMENT
);

-- Tabela: USULOG
CREATE TABLE IF NOT EXISTS USULOG (IDUSUARIO int, TIPO tinyint, FORM varchar (20), ACAO tinyint, DATA datetime, HORA datetime, idlog INTEGER PRIMARY KEY AUTOINCREMENT);

-- �ndice: MANERR-1
CREATE INDEX IF NOT EXISTS "MANERR-1" ON manerr (usuario, data);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
