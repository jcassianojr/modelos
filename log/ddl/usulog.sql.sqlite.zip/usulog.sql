--
-- Arquivo gerado com SQLiteStudio v3.4.4 em s�b ago 3 14:58:33 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: log
CREATE TABLE IF NOT EXISTS log (userid int DEFAULT (0), form int DEFAULT (0), opr varchar (50), botao int DEFAULT (0), data datetime, OBS longtext, idlog INTEGER PRIMARY KEY AUTOINCREMENT);

-- Tabela: USULOG
CREATE TABLE IF NOT EXISTS USULOG (IDUSUARIO int, TIPO tinyint, FORM varchar (20), ACAO tinyint, DATA datetime, HORA datetime, idlog INTEGER PRIMARY KEY AUTOINCREMENT);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
