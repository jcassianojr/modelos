--
-- File generated with SQLiteStudio v3.4.21 on dom mai 17 08:24:06 2026
--
-- Text encoding used: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: log
DROP TABLE IF EXISTS log;

CREATE TABLE IF NOT EXISTS log (
    userid INT          DEFAULT (0),
    form   INT          DEFAULT (0),
    opr    VARCHAR (50),
    botao  INT          DEFAULT (0),
    data   DATETIME,
    OBS    LONGTEXT,
    idlog  INTEGER      PRIMARY KEY AUTOINCREMENT
);


-- Table: manerr
DROP TABLE IF EXISTS manerr;

CREATE TABLE IF NOT EXISTS manerr (
    usuario TEXT (10) NOT NULL,
    data    DATETIME  NOT NULL,
    hora    TEXT (8)  NOT NULL,
    erro    TEXT (20) NOT NULL,
    opr     TEXT (3)  NOT NULL,
    arquivo TEXT (8)  NOT NULL,
    idlog   INTEGER   PRIMARY KEY AUTOINCREMENT
);


-- Table: USULOG
DROP TABLE IF EXISTS USULOG;

CREATE TABLE IF NOT EXISTS USULOG (
    IDUSUARIO INT,
    TIPO      TINYINT,
    FORM      VARCHAR (20),
    ACAO      TINYINT,
    DATA      DATETIME,
    HORA      DATETIME,
    idlog     INTEGER      PRIMARY KEY AUTOINCREMENT
);


-- Index: MANERR-1
DROP INDEX IF EXISTS [MANERR-1];

CREATE INDEX IF NOT EXISTS [MANERR-1] ON manerr (
    usuario,
    data
);


-- Index: userid1
DROP INDEX IF EXISTS userid1;

CREATE INDEX IF NOT EXISTS userid1 ON log (
    userid,
    data
);


-- Index: usulog1
DROP INDEX IF EXISTS usulog1;

CREATE INDEX IF NOT EXISTS usulog1 ON USULOG (
    IDUSUARIO,
    DATA
);


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
