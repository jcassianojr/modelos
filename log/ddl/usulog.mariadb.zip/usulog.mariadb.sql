#
# DUMP FILE
#
# Database is ported from MS Access
#------------------------------------------------------------------
# Created using "MS Access to MySQL" form http://www.bullzip.com
# Program Version 5.5.282
#
# OPTIONS:
#   sourcefilename=C:/temp/usulog.mdb
#   sourceusername=
#   sourcepassword=
#   sourcesystemdatabase=
#   destinationdatabase=usulog
#   storageengine=InnoDB
#   dropdatabase=0
#   createtables=1
#   unicode=0
#   autocommit=1
#   transferdefaultvalues=1
#   transferindexes=1
#   transferautonumbers=1
#   transferrecords=0
#   columnlist=1
#   tableprefix=
#   negativeboolean=0
#   ignorelargeblobs=0
#   memotype=LONGTEXT
#   datetimetype=DATETIME
#

CREATE DATABASE IF NOT EXISTS `usulog`;
USE `usulog`;

#
# Table structure for table 'log'
#

DROP TABLE IF EXISTS `log`;

CREATE TABLE `log` (
  `user` INTEGER, 
  `form` INTEGER, 
  `opr` VARCHAR(50), 
  `botao` INTEGER, 
  `data` DATETIME, 
  `OBS` LONGTEXT
) ENGINE=innodb;

#
# Table structure for table 'MANERR'
#

DROP TABLE IF EXISTS `MANERR`;

CREATE TABLE `MANERR` (
  `USUARIO` VARCHAR(10), 
  `DATA` DATETIME, 
  `HORA` VARCHAR(8), 
  `ERRO` VARCHAR(20), 
  `OPR` VARCHAR(3), 
  `ARQUIVO` VARCHAR(8), 
  INDEX (`USUARIO`, `DATA`)
) ENGINE=innodb;

#
# Table structure for table 'USULOG'
#

DROP TABLE IF EXISTS `USULOG`;

CREATE TABLE `USULOG` (
  `IDUSUARIO` INTEGER, 
  `TIPO` TINYINT(3) UNSIGNED, 
  `FORM` VARCHAR(20), 
  `ACAO` TINYINT(3) UNSIGNED, 
  `DATA` DATETIME, 
  `HORA` DATETIME
) ENGINE=innodb;

