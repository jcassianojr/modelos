--------------------------------------------
--------------- Dump details ---------------
--------------------------------------------
-- Original file: C:\cnvoracle\log\usulog.mdb
-- Dump date: 12-18-2024 10:15:58
--------------------------------------------

-- creating table
CREATE TABLE LOG (
	"USER" NUMBER (10),
	FORM NUMBER (10),
	OPR VARCHAR2 (50),
	BOTAO NUMBER (10),
	DATA DATE,
	OBS CLOB
);


-- creating table
CREATE TABLE MANERR (
	USUARIO VARCHAR2 (10),
	DATA DATE,
	HORA VARCHAR2 (8),
	ERRO VARCHAR2 (20),
	OPR VARCHAR2 (3),
	ARQUIVO VARCHAR2 (8)
);


-- creating table
CREATE TABLE USULOG (
	IDUSUARIO NUMBER (10),
	TIPO NUMBER (3),
	FORM VARCHAR2 (20),
	ACAO NUMBER (3),
	DATA DATE,
	HORA DATE
);


