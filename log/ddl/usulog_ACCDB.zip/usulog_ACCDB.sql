-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: DESTINO (ACCDB)
-- Gerado em: 17/05/2026 08:20:56
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: log
-- --------------------------------------------------
CREATE TABLE [log] ([user] LONG, [form] LONG, [opr] TEXT(50), [botao] LONG, [data] DATETIME, [OBS] MEMO);
CREATE INDEX [log1] ON [log] ([user], [data]);

-- --------------------------------------------------
-- Estrutura da Tabela: MANERR
-- --------------------------------------------------
CREATE TABLE [MANERR] ([USUARIO] TEXT(10), [DATA] DATETIME, [HORA] TEXT(8), [ERRO] TEXT(20), [OPR] TEXT(3), [ARQUIVO] TEXT(8));
CREATE INDEX [manerr-1] ON [MANERR] ([USUARIO], [DATA]);

-- --------------------------------------------------
-- Estrutura da Tabela: USULOG
-- --------------------------------------------------
CREATE TABLE [USULOG] ([IDUSUARIO] LONG, [TIPO] BYTE, [FORM] TEXT(20), [ACAO] BYTE, [DATA] DATETIME, [HORA] DATETIME);
CREATE INDEX [usulog1] ON [USULOG] ([IDUSUARIO], [DATA]);

-- Fim do Script de DESTINO (ACCDB)
