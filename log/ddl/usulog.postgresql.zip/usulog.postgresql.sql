--
-- DUMP FILE
--
-- Database is ported from MS Access
--------------------------------------------------------------------
-- Created using "MS Access to PostgreSQL" form http://www.bullzip.com
-- Program Version 5.5.281
--
-- OPTIONS:
--   sourcefilename=C:/Users/jcass/Downloads/usulog.mdb
--   sourceusername=
--   sourcepassword=
--   sourcesystemdatabase=
--   destinationserver=localhost
--   destinationdatabase=usulog
--   maintenancedb=postgres
--   dropdatabase=0
--   createtables=1
--   unicode=0
--   autocommit=1
--   transferdefaultvalues=1
--   transferindexes=1
--   transferautonumbers=1
--   transferrecords=0
--   columnlist=1
--   tableprefix=
--   negativeboolean=0
--   ignorelargeblobs=0
--   memotype=TEXT
--   datetimetype=TIMESTAMP
--

CREATE DATABASE "usulog";

-- NOTICE: At this place you need to connect to the new database and run the rest of the statements.

--
-- Table structure for table 'log'
--

DROP TABLE IF EXISTS "log";

CREATE TABLE "log" (
  "user" INTEGER, 
  "form" INTEGER, 
  "opr" VARCHAR(50), 
  "botao" INTEGER, 
  "data" TIMESTAMP, 
  "OBS" TEXT
);

--
-- Table structure for table 'MANERR'
--

DROP TABLE IF EXISTS "MANERR";

CREATE TABLE "MANERR" (
  "USUARIO" VARCHAR(10), 
  "DATA" TIMESTAMP, 
  "HORA" VARCHAR(8), 
  "ERRO" VARCHAR(20), 
  "OPR" VARCHAR(3), 
  "ARQUIVO" VARCHAR(8)
);

--
-- Table structure for table 'USULOG'
--

DROP TABLE IF EXISTS "USULOG";

CREATE TABLE "USULOG" (
  "IDUSUARIO" INTEGER, 
  "TIPO" SMALLINT, 
  "FORM" VARCHAR(20), 
  "ACAO" SMALLINT, 
  "DATA" TIMESTAMP, 
  "HORA" TIMESTAMP
);

