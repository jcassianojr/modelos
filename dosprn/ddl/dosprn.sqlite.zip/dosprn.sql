--
-- Arquivo gerado com SQLiteStudio v3.4.4 em qui ago 1 20:57:56 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: dosprn1
CREATE TABLE IF NOT EXISTS [dosprn1] ([pr_no] REAL NOT NULL, [pr_name] TEXT(50) NOT NULL, [init_pr] TEXT(50) NOT NULL, [exit_pr] TEXT(40) NOT NULL, [bold_on] TEXT(40) NOT NULL, [bold_off] TEXT(40) NOT NULL, [undl_on] TEXT(40) NOT NULL, [undl_off] TEXT(40) NOT NULL, [enl_on] TEXT(40) NOT NULL, [enl_off] TEXT(40) NOT NULL, [ital_on] TEXT(40) NOT NULL, [ital_off] TEXT(40) NOT NULL, [high_on] TEXT(40) NOT NULL, [high_off] TEXT(40) NOT NULL, [low_on] TEXT(40) NOT NULL, [low_off] TEXT(40) NOT NULL, [cond_on] TEXT(40) NOT NULL, [cond_off] TEXT(40) NOT NULL, [nlq_on] TEXT(40) NOT NULL, [nlq_off] TEXT(40) NOT NULL, [reserv_on] TEXT(40) NOT NULL, [reserv_off] TEXT(40) NOT NULL, [graph_driv] TEXT(20) NOT NULL, [page_len] REAL NOT NULL, [head_marg] REAL NOT NULL, [foot_marg] REAL NOT NULL);

-- Tabela: dosprn2
CREATE TABLE IF NOT EXISTS [dosprn2] ([empresa] TEXT(15) NOT NULL, [impress] TEXT(14) NOT NULL, [emula] TEXT(14) NOT NULL, [inicializa] TEXT(14) NOT NULL, [c10pp] TEXT(14) NOT NULL, [c12pp] TEXT(14) NOT NULL, [condon] TEXT(14) NOT NULL, [condoff] TEXT(14) NOT NULL, [spcpron] TEXT(14) NOT NULL, [spcproff] TEXT(14) NOT NULL, [setchar] TEXT(14) NOT NULL, [mstfnt] TEXT(14) NOT NULL, [prtstyl] TEXT(14) NOT NULL, [draft] TEXT(14) NOT NULL, [carta] TEXT(14) NOT NULL, [l6pp] TEXT(14) NOT NULL, [l8pp] TEXT(14) NOT NULL, [l12pp] TEXT(14) NOT NULL, [spcline] TEXT(14) NOT NULL, [spclinea] TEXT(14) NOT NULL, [negron] TEXT(14) NOT NULL, [negroff] TEXT(14) NOT NULL, [dwideon] TEXT(14) NOT NULL, [dwideoff] TEXT(14) NOT NULL, [dheigon] TEXT(14) NOT NULL, [dheigoff] TEXT(14) NOT NULL, [enfaton] TEXT(14) NOT NULL, [enfatoff] TEXT(14) NOT NULL, [boldon] TEXT(14) NOT NULL, [boldoff] TEXT(14) NOT NULL, [subscron] TEXT(14) NOT NULL, [subscroff] TEXT(14) NOT NULL, [italon] TEXT(14) NOT NULL, [italoff] TEXT(14) NOT NULL, [supscron] TEXT(14) NOT NULL, [supscroff] TEXT(14) NOT NULL, [sub1scron] TEXT(14) NOT NULL, [sub1scroff] TEXT(14) NOT NULL, [skpon] TEXT(14) NOT NULL, [skpoff] TEXT(14) NOT NULL, [uniprt] TEXT(14) NOT NULL, [biprt] TEXT(14) NOT NULL, [svcursor] TEXT(14) NOT NULL, [rtcursor] TEXT(14) NOT NULL, [pgtam] TEXT(14) NOT NULL, [pglin] TEXT(14) NOT NULL, [tabstop] TEXT(14) NOT NULL, [margtop] TEXT(14) NOT NULL, [margbott] TEXT(14) NOT NULL, [margleft] TEXT(14) NOT NULL, [margright] TEXT(14) NOT NULL, [mvabsvloc] TEXT(14) NOT NULL, [mvrelvloc] TEXT(14) NOT NULL, [mvabshloc] TEXT(14) NOT NULL, [mvrelhloc] TEXT(14) NOT NULL, [intchsphmi] TEXT(14) NOT NULL, [c11pp] TEXT(14) NOT NULL, [c13pp] TEXT(14) NOT NULL, [c14pp] TEXT(14) NOT NULL, [c16pp] TEXT(14) NOT NULL, [c20pp] TEXT(14) NOT NULL, [expand01] TEXT(14) NOT NULL, [expand02] TEXT(14) NOT NULL, [expand03] TEXT(14) NOT NULL, [expand04] TEXT(14) NOT NULL);

-- Tabela: dosprn3
CREATE TABLE IF NOT EXISTS [dosprn3] ([nome] TEXT(22) NOT NULL, [c_10cpi] TEXT(20) NOT NULL, [c_17cpi] TEXT(20) NOT NULL);

-- �ndice: idx_dosprn1_dosprn
CREATE INDEX IF NOT EXISTS [idx_dosprn1_dosprn] ON [dosprn1] ([pr_name]);

-- �ndice: idx_dosprn2_dosprn2
CREATE INDEX IF NOT EXISTS [idx_dosprn2_dosprn2] ON [dosprn2] ([empresa], [impress]);

-- �ndice: idx_nome
CREATE INDEX IF NOT EXISTS [idx_nome] ON [dosprn3] ([nome]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
