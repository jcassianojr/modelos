--
-- Arquivo gerado com SQLiteStudio v3.4.4 em ter ago 6 17:30:05 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: ac
CREATE TABLE IF NOT EXISTS [ac] ([ac] REAL NOT NULL, [tipo] TEXT(1) NOT NULL, [codigo] TEXT(10) NOT NULL, [nome] TEXT(100) NOT NULL, [aplicacao] TEXT(50) NOT NULL, [peso] REAL NOT NULL, [for01] REAL NOT NULL, [for02] REAL NOT NULL, [for03] REAL NOT NULL, [cog01] TEXT(15) NOT NULL, [cog02] TEXT(15) NOT NULL, [cog03] TEXT(15) NOT NULL, [unidade] TEXT(10) NOT NULL);

-- Tabela: aci
CREATE TABLE IF NOT EXISTS [aci] ([ac] REAL NOT NULL, [item] REAL NOT NULL, [data] SHORTDATE NOT NULL, [detalhe] TEXT(20) NOT NULL, [entpc] REAL NOT NULL, [entkg] REAL NOT NULL, [saipc] REAL NOT NULL, [saikg] REAL NOT NULL, [salpc] REAL NOT NULL, [salkg] REAL NOT NULL);

-- Tabela: estqint
CREATE TABLE IF NOT EXISTS [estqint] ([cod_empres] TEXT(2) NOT NULL, [cod_item] TEXT(14) NOT NULL, [qtd_libera] REAL NOT NULL, [qtd_impedi] REAL NOT NULL, [qtd_rejeit] REAL NOT NULL, [qtd_lib_ex] REAL NOT NULL, [qtd_disp_v] REAL NOT NULL, [qtd_reserv] REAL NOT NULL, [dat_ult_in] SHORTDATE NOT NULL, [dat_ult_en] SHORTDATE NOT NULL, [dat_ult_sa] SHORTDATE NOT NULL);

-- Tabela: op01
CREATE TABLE IF NOT EXISTS [op01] ([op] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [ativo] TEXT(1) NOT NULL, [vmes] REAL NOT NULL, [vqui] REAL NOT NULL, [vmed] REAL NOT NULL, [vmeq] REAL NOT NULL, [vprg] REAL NOT NULL, [qatr] REAL NOT NULL, [qsem] REAL NOT NULL, [qse2] REAL NOT NULL, [qini] REAL NOT NULL, [qin2] REAL NOT NULL, [qsai] REAL NOT NULL, [qsal] REAL NOT NULL, [qsaa] REAL NOT NULL, [qsas] REAL NOT NULL, [qsa2] REAL NOT NULL, [dataa] SHORTDATE NOT NULL, [datas] SHORTDATE NOT NULL, [data2] SHORTDATE NOT NULL, [imagem] TEXT(40) NOT NULL, [codigoint] TEXT(24) NOT NULL);

-- Tabela: op01x
CREATE TABLE IF NOT EXISTS [op01x] ([op] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [ativo] TEXT(1) NOT NULL, [vmes] REAL NOT NULL, [vqui] REAL NOT NULL, [vmed] REAL NOT NULL, [vmeq] REAL NOT NULL, [vprg] REAL NOT NULL, [qatr] REAL NOT NULL, [qsem] REAL NOT NULL, [qse2] REAL NOT NULL, [qini] REAL NOT NULL, [qin2] REAL NOT NULL, [qsai] REAL NOT NULL, [qsal] REAL NOT NULL, [qsaa] REAL NOT NULL, [qsas] REAL NOT NULL, [qsa2] REAL NOT NULL, [dataa] SHORTDATE NOT NULL, [datas] SHORTDATE NOT NULL, [data2] SHORTDATE NOT NULL, [imagem] TEXT(40) NOT NULL, [codigoint] TEXT(24) NOT NULL);

-- Tabela: op02
CREATE TABLE IF NOT EXISTS [op02] ([op] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [qpini] REAL NOT NULL, [qpin2] REAL NOT NULL, [qpins] REAL NOT NULL, [qpina] REAL NOT NULL, [qpsai] REAL NOT NULL, [qpsal] REAL NOT NULL, [qpref] REAL NOT NULL, [qpant] REAL NOT NULL, [qpaaa] REAL NOT NULL, [qpaa2] REAL NOT NULL, [qpaas] REAL NOT NULL, [qpsa2] REAL NOT NULL, [qpain] REAL NOT NULL, [qttime] REAL NOT NULL, [qttim2] REAL NOT NULL, [qttimm] REAL NOT NULL, [qttimd] REAL NOT NULL, [codmp01] TEXT(12) NOT NULL, [cogmp01] TEXT(10) NOT NULL, [codmp02] TEXT(12) NOT NULL, [codmp02b] TEXT(12) NOT NULL, [codmp02c] TEXT(12) NOT NULL, [codmp02d] TEXT(12) NOT NULL, [codmp03] TEXT(24) NOT NULL, [descri] TEXT(70) NOT NULL, [tipfec] TEXT(1) NOT NULL, [pulreq] TEXT(1) NOT NULL, [nomer] TEXT(15) NOT NULL, [setorop] TEXT(1) NOT NULL, [limtime] REAL NOT NULL, [filial] REAL NOT NULL, [leadesp] REAL NOT NULL, [fator] REAL NOT NULL, [codint] TEXT(24) NOT NULL);

-- Tabela: op02set
CREATE TABLE IF NOT EXISTS [op02set] ([op] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [codmp01] TEXT(12) NOT NULL, [cogmp01] TEXT(10) NOT NULL, [codmp03] TEXT(12) NOT NULL, [descri] TEXT(70) NOT NULL, [nomer] TEXT(15) NOT NULL, [setorop] TEXT(1) NOT NULL, [limtime] REAL NOT NULL, [data] SHORTDATE NOT NULL, [dataini] SHORTDATE NOT NULL, [qtdeini] REAL NOT NULL, [qtdeuso] REAL NOT NULL, [bloquear] TEXT(1) NOT NULL, [urgente] TEXT(1) NOT NULL, [obs] TEXT(80) NOT NULL, [pchormeq] REAL NOT NULL, [pchornec] REAL NOT NULL, [dataprz] SHORTDATE NOT NULL, [semana] TEXT(1) NOT NULL, [prelead] REAL NOT NULL, [filial] REAL NOT NULL, [leadesp] REAL NOT NULL, [numferr] REAL NOT NULL, [codint] TEXT(24) NOT NULL);

-- Tabela: op02sex
CREATE TABLE IF NOT EXISTS [op02sex] ([op] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [codmp01] TEXT(12) NOT NULL, [cogmp01] TEXT(10) NOT NULL, [codmp03] TEXT(12) NOT NULL, [descri] TEXT(70) NOT NULL, [nomer] TEXT(15) NOT NULL, [setorop] TEXT(1) NOT NULL, [tempo01] REAL NOT NULL, [tempo02] REAL NOT NULL, [tempo03] REAL NOT NULL, [datai01] SHORTDATE NOT NULL, [datai02] SHORTDATE NOT NULL, [datai03] SHORTDATE NOT NULL, [prazo01] SHORTDATE NOT NULL, [prazo02] SHORTDATE NOT NULL, [prazo03] SHORTDATE NOT NULL, [qtdde01] REAL NOT NULL, [qtdde02] REAL NOT NULL, [qtdde03] REAL NOT NULL, [bloquear] TEXT(1) NOT NULL, [urgen01] TEXT(1) NOT NULL, [urgen02] TEXT(1) NOT NULL, [urgen03] TEXT(1) NOT NULL, [inici01] SHORTDATE NOT NULL, [inici02] SHORTDATE NOT NULL, [inici03] SHORTDATE NOT NULL, [dataref] SHORTDATE NOT NULL, [leadesp] REAL NOT NULL, [filial] REAL NOT NULL, [hora01] REAL NOT NULL, [hora02] REAL NOT NULL, [hora03] REAL NOT NULL, [databas] SHORTDATE NOT NULL, [tem01] TEXT(1) NOT NULL, [databa2] SHORTDATE NOT NULL, [databa3] SHORTDATE NOT NULL, [databa4] SHORTDATE NOT NULL, [numferr] REAL NOT NULL, [codint] TEXT(24) NOT NULL);

-- Tabela: op02x
CREATE TABLE IF NOT EXISTS [op02x] ([op] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [qpini] REAL NOT NULL, [qpin2] REAL NOT NULL, [qpins] REAL NOT NULL, [qpina] REAL NOT NULL, [qpsai] REAL NOT NULL, [qpsal] REAL NOT NULL, [qpref] REAL NOT NULL, [qpant] REAL NOT NULL, [qpaaa] REAL NOT NULL, [qpaa2] REAL NOT NULL, [qpaas] REAL NOT NULL, [qpsa2] REAL NOT NULL, [qpain] REAL NOT NULL, [qttime] REAL NOT NULL, [qttim2] REAL NOT NULL, [qttimm] REAL NOT NULL, [qttimd] REAL NOT NULL, [codmp01] TEXT(12) NOT NULL, [cogmp01] TEXT(10) NOT NULL, [codmp02] TEXT(12) NOT NULL, [codmp02b] TEXT(12) NOT NULL, [codmp02c] TEXT(12) NOT NULL, [codmp02d] TEXT(12) NOT NULL, [codmp03] TEXT(24) NOT NULL, [descri] TEXT(70) NOT NULL, [tipfec] TEXT(1) NOT NULL, [pulreq] TEXT(1) NOT NULL, [nomer] TEXT(15) NOT NULL, [setorop] TEXT(1) NOT NULL, [limtime] REAL NOT NULL, [filial] REAL NOT NULL, [leadesp] REAL NOT NULL, [fator] REAL NOT NULL, [codint] TEXT(24) NOT NULL);

-- Tabela: op03
CREATE TABLE IF NOT EXISTS [op03] ([op] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [vmes] REAL NOT NULL, [vqui] REAL NOT NULL, [vmed] REAL NOT NULL, [vmeq] REAL NOT NULL, [vprg] REAL NOT NULL, [codmp01] TEXT(12) NOT NULL, [cogmp01] TEXT(10) NOT NULL, [qttime] REAL NOT NULL, [qttim2] REAL NOT NULL, [qttimm] REAL NOT NULL, [qttimd] REAL NOT NULL, [qini] REAL NOT NULL, [qsai] REAL NOT NULL, [qsal] REAL NOT NULL, [qpro] REAL NOT NULL, [filial] REAL NOT NULL, [codint] TEXT(24) NOT NULL);

-- Tabela: op03b
CREATE TABLE IF NOT EXISTS [op03b] ([op] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [vmes] REAL NOT NULL, [vqui] REAL NOT NULL, [vmed] REAL NOT NULL, [vmeq] REAL NOT NULL, [vprg] REAL NOT NULL, [codmp01] TEXT(12) NOT NULL, [cogmp01] TEXT(10) NOT NULL, [qttime] REAL NOT NULL, [qttim2] REAL NOT NULL, [qttimm] REAL NOT NULL, [qttimd] REAL NOT NULL, [qini] REAL NOT NULL, [qsai] REAL NOT NULL, [qsal] REAL NOT NULL, [qpro] REAL NOT NULL, [filial] REAL NOT NULL, [codint] TEXT(24) NOT NULL);

-- Tabela: oscrt
CREATE TABLE IF NOT EXISTS [oscrt] ([os] REAL NOT NULL, [data] SHORTDATE NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [pedidocli] TEXT(20) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [obs] TEXT(30) NOT NULL, [pf] REAL NOT NULL, [emuso] TEXT(1) NOT NULL, [ativo] TEXT(1) NOT NULL, [obsfin01] TEXT(80) NOT NULL, [obsfin02] TEXT(80) NOT NULL, [obsfin03] TEXT(80) NOT NULL, [obsfin04] TEXT(80) NOT NULL, [obsfin05] TEXT(80) NOT NULL, [obsfin06] TEXT(80) NOT NULL, [dataimp] SHORTDATE NOT NULL, [codcli] TEXT(15) NOT NULL, [saiobs] BIT NOT NULL, [pedcliite] REAL NOT NULL, [codigoint] TEXT(24) NOT NULL, [delivery] TEXT(20) NOT NULL, [stock] TEXT(20) NOT NULL, [pedcliobs] TEXT(10) NOT NULL, [doca] TEXT(10) NOT NULL);

-- Tabela: ospr2
CREATE TABLE IF NOT EXISTS [ospr2] ([numero] REAL NOT NULL, [produto] TEXT(24) NOT NULL, [planta] TEXT(10) NOT NULL, [programa] SHORTDATE NOT NULL, [qtde] REAL NOT NULL, [dataimp] SHORTDATE NOT NULL, [horaprg] REAL NOT NULL, [codigoint] TEXT(24) NOT NULL);

-- Tabela: ospr3
CREATE TABLE IF NOT EXISTS [ospr3] ([numero] REAL NOT NULL, [produto] TEXT(24) NOT NULL, [planta] TEXT(10) NOT NULL, [programa] SHORTDATE NOT NULL, [qtde] REAL NOT NULL, [dataimp] SHORTDATE NOT NULL, [horaprg] REAL NOT NULL, [seqcliprg] REAL NOT NULL);

-- Tabela: ospra
CREATE TABLE IF NOT EXISTS [ospra] ([produto] TEXT(24) NOT NULL, [dataacm] SHORTDATE NOT NULL, [dataprg] SHORTDATE NOT NULL, [qtde] REAL NOT NULL, [lista] TEXT(1) NOT NULL, [tipo] TEXT(1) NOT NULL);

-- Tabela: osprb
CREATE TABLE IF NOT EXISTS [osprb] ([produto] TEXT(24) NOT NULL, [dataacm] SHORTDATE NOT NULL, [dataprg] SHORTDATE NOT NULL, [qtde] REAL NOT NULL, [planta] TEXT(5) NOT NULL);

-- Tabela: osprd
CREATE TABLE IF NOT EXISTS [osprd] ([produto] TEXT(24) NOT NULL, [dataacm] SHORTDATE NOT NULL, [dataprg] SHORTDATE NOT NULL, [qtde] REAL NOT NULL, [planta] TEXT(5) NOT NULL);

-- Tabela: ospre
CREATE TABLE IF NOT EXISTS [ospre] ([numero] REAL NOT NULL, [produto] TEXT(24) NOT NULL, [planta] TEXT(10) NOT NULL, [programa] SHORTDATE NOT NULL, [qtde] REAL NOT NULL, [dataimp] SHORTDATE NOT NULL, [horaprg] REAL NOT NULL, [seqcliprg] REAL NOT NULL);

-- Tabela: osprf
CREATE TABLE IF NOT EXISTS [osprf] ([produto] TEXT(24) NOT NULL, [dataacm] SHORTDATE NOT NULL, [dataprg] SHORTDATE NOT NULL, [qtde] REAL NOT NULL, [planta] TEXT(5) NOT NULL);

-- Tabela: osprg
CREATE TABLE IF NOT EXISTS [osprg] ([numero] REAL NOT NULL, [produto] TEXT(24) NOT NULL, [planta] TEXT(10) NOT NULL, [programa] SHORTDATE NOT NULL, [qtde] REAL NOT NULL, [dataimp] SHORTDATE NOT NULL, [horaprg] REAL NOT NULL, [codigoint] TEXT(24) NOT NULL);

-- Tabela: osprh
CREATE TABLE IF NOT EXISTS [osprh] ([numero] REAL NOT NULL, [produto] TEXT(24) NOT NULL, [planta] TEXT(10) NOT NULL, [programa] SHORTDATE NOT NULL, [qtde] REAL NOT NULL, [dataimp] SHORTDATE NOT NULL, [horaprg] REAL NOT NULL, [seqcliprg] REAL NOT NULL, [codigoint] TEXT(24) NOT NULL);

-- Tabela: ospri
CREATE TABLE IF NOT EXISTS [ospri] ([numero] REAL NOT NULL, [produto] TEXT(24) NOT NULL, [planta] TEXT(10) NOT NULL, [programa] SHORTDATE NOT NULL, [qtde] REAL NOT NULL, [dataimp] SHORTDATE NOT NULL, [horaprg] REAL NOT NULL, [seqcliprg] REAL NOT NULL, [codigoint] TEXT(24) NOT NULL);

-- Tabela: ospro
CREATE TABLE IF NOT EXISTS [ospro] ([produto] TEXT(24) NOT NULL, [dataacm] SHORTDATE NOT NULL, [dataprg] SHORTDATE NOT NULL, [qtde] REAL NOT NULL);

-- Tabela: osprr
CREATE TABLE IF NOT EXISTS [osprr] ([numero] REAL NOT NULL, [produto] TEXT(24) NOT NULL, [planta] TEXT(10) NOT NULL, [programa] SHORTDATE NOT NULL, [qtde] REAL NOT NULL, [dataimp] SHORTDATE NOT NULL, [horaprg] REAL NOT NULL, [codigoint] TEXT(24) NOT NULL, [cliente] REAL NOT NULL);

-- Tabela: osprs
CREATE TABLE IF NOT EXISTS [osprs] ([numero] REAL NOT NULL, [produto] TEXT(24) NOT NULL, [planta] TEXT(10) NOT NULL, [programa] SHORTDATE NOT NULL, [qtde] REAL NOT NULL, [dataimp] SHORTDATE NOT NULL, [horaprg] REAL NOT NULL, [codigoint] TEXT(24) NOT NULL, [cliente] REAL NOT NULL);

-- Tabela: pcorte
CREATE TABLE IF NOT EXISTS [pcorte] ([numero] REAL NOT NULL, [nfnossa] REAL NOT NULL, [nfusina] REAL NOT NULL, [rastrou] TEXT(12) NOT NULL, [rastro] TEXT(12) NOT NULL, [esp] REAL NOT NULL, [lar] REAL NOT NULL, [peso] REAL NOT NULL, [localuso] TEXT(10) NOT NULL, [ac] TEXT(15) NOT NULL, [crm] REAL NOT NULL, [obs01] TEXT(80) NOT NULL, [obs02] TEXT(80) NOT NULL, [nforn] REAL NOT NULL, [mforn] TEXT(40) NOT NULL, [nfornu] REAL NOT NULL, [mfornu] TEXT(40) NOT NULL, [codigo] TEXT(24) NOT NULL, [descricao] TEXT(100) NOT NULL, [data] SHORTDATE NOT NULL, [lancado] TEXT(1) NOT NULL, [crmitem] REAL NOT NULL, [crmtipo] TEXT(1) NOT NULL, [crmitemu] REAL NOT NULL, [refnf] REAL NOT NULL, [refdata] SHORTDATE NOT NULL, [refqtde] REAL NOT NULL, [lxfornu] TEXT(15) NOT NULL, [lxfornc] TEXT(15) NOT NULL);

-- Tabela: pcortei
CREATE TABLE IF NOT EXISTS [pcortei] ([numero] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [descricao] TEXT(100) NOT NULL, [itelar] REAL NOT NULL, [itecom] REAL NOT NULL, [rolos] REAL NOT NULL, [peso] REAL NOT NULL, [prazo] SHORTDATE NOT NULL, [compras] REAL NOT NULL, [comitem] REAL NOT NULL, [qtde] REAL NOT NULL, [pe] REAL NOT NULL, [aplicacao] TEXT(40) NOT NULL, [retnf] REAL NOT NULL, [retdata] SHORTDATE NOT NULL, [retqtde] REAL NOT NULL);

-- Tabela: pe
CREATE TABLE IF NOT EXISTS [pe] ([pedido] REAL NOT NULL, [tipped] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(50) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(15) NOT NULL, [unid] TEXT(2) NOT NULL, [nom2] TEXT(50) NOT NULL, [compras] REAL NOT NULL, [comitem] REAL NOT NULL, [aplicacao] TEXT(50) NOT NULL, [locent] REAL NOT NULL, [obsobs] TEXT(40) NOT NULL, [ativo] TEXT(1) NOT NULL, [dddpcp] TEXT(2) NOT NULL, [telpcp] TEXT(12) NOT NULL, [rampcp] TEXT(4) NOT NULL, [conpcp] TEXT(24) NOT NULL, [dddfaxpcp] TEXT(2) NOT NULL, [telfaxpcp] TEXT(12) NOT NULL, [emailpcp] TEXT(50) NOT NULL, [nomefor] TEXT(40) NOT NULL);

-- Tabela: pe01
CREATE TABLE IF NOT EXISTS [pe01] ([tipped] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(50) NOT NULL, [nom2] TEXT(50) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [datafat] SHORTDATE NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pedido] REAL NOT NULL, [item] REAL NOT NULL, [receber] TEXT(1) NOT NULL, [obs] TEXT(20) NOT NULL, [rastrofor] TEXT(20) NOT NULL, [dcorte] SHORTDATE NOT NULL, [ar] REAL NOT NULL, [rirm] REAL NOT NULL);

-- Tabela: pe01ap
CREATE TABLE IF NOT EXISTS [pe01ap] ([tipped] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(50) NOT NULL, [nom2] TEXT(50) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [datafat] SHORTDATE NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pedido] REAL NOT NULL, [item] REAL NOT NULL, [receber] TEXT(1) NOT NULL);

-- Tabela: pe01bx
CREATE TABLE IF NOT EXISTS [pe01bx] ([tipped] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(50) NOT NULL, [nom2] TEXT(50) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [datafat] SHORTDATE NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pedido] REAL NOT NULL, [item] REAL NOT NULL, [receber] TEXT(1) NOT NULL, [obs] TEXT(20) NOT NULL, [rastrofor] TEXT(20) NOT NULL, [dcorte] SHORTDATE NOT NULL, [ar] REAL NOT NULL, [rirm] REAL NOT NULL);

-- Tabela: pe99
CREATE TABLE IF NOT EXISTS [pe99] ([tipped] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(50) NOT NULL, [nom2] TEXT(50) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [datafat] SHORTDATE NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pedido] REAL NOT NULL, [item] REAL NOT NULL, [receber] TEXT(1) NOT NULL, [obs] TEXT(20) NOT NULL, [rastrofor] TEXT(20) NOT NULL, [dcorte] SHORTDATE NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: pecrt
CREATE TABLE IF NOT EXISTS [pecrt] ([tipo] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [unrnota] REAL NOT NULL, [uforne] REAL NOT NULL, [uqtde] REAL NOT NULL, [udata] SHORTDATE NOT NULL);

-- Tabela: pemo
CREATE TABLE IF NOT EXISTS [pemo] ([pedido] REAL NOT NULL, [tipped] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(50) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(15) NOT NULL, [unid] TEXT(2) NOT NULL, [nom2] TEXT(50) NOT NULL, [compras] REAL NOT NULL, [comitem] REAL NOT NULL, [aplicacao] TEXT(50) NOT NULL);

-- Tabela: petr
CREATE TABLE IF NOT EXISTS [petr] ([pedido] REAL NOT NULL, [tipped] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(50) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(15) NOT NULL, [unid] TEXT(2) NOT NULL, [nom2] TEXT(50) NOT NULL, [compras] REAL NOT NULL, [comitem] REAL NOT NULL, [aplicacao] TEXT(50) NOT NULL);

-- Tabela: prnec
CREATE TABLE IF NOT EXISTS [prnec] ([codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [qtdsal] REAL NOT NULL, [qtde01] REAL NOT NULL, [qtdr01] REAL NOT NULL, [qtdi01] REAL NOT NULL, [data01] SHORTDATE NOT NULL, [qtde02] REAL NOT NULL, [qtdr02] REAL NOT NULL, [qtdi02] REAL NOT NULL, [data02] SHORTDATE NOT NULL, [qtde03] REAL NOT NULL, [qtdr03] REAL NOT NULL, [qtdi03] REAL NOT NULL, [data03] SHORTDATE NOT NULL, [qtde04] REAL NOT NULL, [qtdr04] REAL NOT NULL, [qtdi04] REAL NOT NULL, [data04] SHORTDATE NOT NULL, [qtde05] REAL NOT NULL, [qtdr05] REAL NOT NULL, [qtdi05] REAL NOT NULL, [data05] SHORTDATE NOT NULL, [qtde06] REAL NOT NULL, [qtdr06] REAL NOT NULL, [qtdi06] REAL NOT NULL, [data06] SHORTDATE NOT NULL, [qtde07] REAL NOT NULL, [qtdr07] REAL NOT NULL, [qtdi07] REAL NOT NULL, [data07] SHORTDATE NOT NULL, [qtde08] REAL NOT NULL, [qtdr08] REAL NOT NULL, [qtdi08] REAL NOT NULL, [data08] SHORTDATE NOT NULL, [qtde09] REAL NOT NULL, [qtdr09] REAL NOT NULL, [qtdi09] REAL NOT NULL, [data09] SHORTDATE NOT NULL, [qtde10] REAL NOT NULL, [qtdr10] REAL NOT NULL, [qtdi10] REAL NOT NULL, [data10] SHORTDATE NOT NULL, [qtde11] REAL NOT NULL, [qtdr11] REAL NOT NULL, [qtdi11] REAL NOT NULL, [data11] SHORTDATE NOT NULL, [qtde12] REAL NOT NULL, [qtdr12] REAL NOT NULL, [qtdi12] REAL NOT NULL, [data12] SHORTDATE NOT NULL, [qtde13] REAL NOT NULL, [qtdr13] REAL NOT NULL, [qtdi13] REAL NOT NULL, [data13] SHORTDATE NOT NULL, [qtde14] REAL NOT NULL, [qtdr14] REAL NOT NULL, [qtdi14] REAL NOT NULL, [data14] SHORTDATE NOT NULL, [qtde15] REAL NOT NULL, [qtdr15] REAL NOT NULL, [qtdi15] REAL NOT NULL, [data15] SHORTDATE NOT NULL, [qtde16] REAL NOT NULL, [qtdr16] REAL NOT NULL, [qtdi16] REAL NOT NULL, [data16] SHORTDATE NOT NULL, [qtde17] REAL NOT NULL, [qtdr17] REAL NOT NULL, [qtdi17] REAL NOT NULL, [data17] SHORTDATE NOT NULL, [qtde18] REAL NOT NULL, [qtdr18] REAL NOT NULL, [qtdi18] REAL NOT NULL, [data18] SHORTDATE NOT NULL, [qtde19] REAL NOT NULL, [qtdr19] REAL NOT NULL, [qtdi19] REAL NOT NULL, [data19] SHORTDATE NOT NULL, [qtde20] REAL NOT NULL, [qtdr20] REAL NOT NULL, [qtdi20] REAL NOT NULL, [data20] SHORTDATE NOT NULL, [op] REAL NOT NULL, [opqtde1] REAL NOT NULL, [tipoprg] TEXT(1) NOT NULL);

-- Tabela: prneca
CREATE TABLE IF NOT EXISTS [prneca] ([codigo] TEXT(24) NOT NULL, [qtde] REAL NOT NULL, [qtde01] REAL NOT NULL, [qtde02] REAL NOT NULL, [qtde03] REAL NOT NULL, [qtde04] REAL NOT NULL, [qtde05] REAL NOT NULL, [qtde06] REAL NOT NULL, [qtde07] REAL NOT NULL, [qtde08] REAL NOT NULL, [qtde09] REAL NOT NULL, [qtde10] REAL NOT NULL, [qtde11] REAL NOT NULL, [qtde12] REAL NOT NULL, [qtde13] REAL NOT NULL, [qtde14] REAL NOT NULL, [qtde15] REAL NOT NULL, [qtde16] REAL NOT NULL, [qtde17] REAL NOT NULL, [qtde18] REAL NOT NULL, [qtde19] REAL NOT NULL, [qtde20] REAL NOT NULL);

-- Tabela: prneci
CREATE TABLE IF NOT EXISTS [prneci] ([codigo] TEXT(24) NOT NULL, [tipoent] TEXT(1) NOT NULL, [codcomp] TEXT(24) NOT NULL, [estqpro] REAL NOT NULL, [qtdecomp] REAL NOT NULL, [qtdi01] REAL NOT NULL, [qtdi02] REAL NOT NULL, [qtdi03] REAL NOT NULL, [qtdi04] REAL NOT NULL, [qtdi05] REAL NOT NULL, [qtdi06] REAL NOT NULL, [qtdi07] REAL NOT NULL, [qtdi08] REAL NOT NULL, [qtdi09] REAL NOT NULL, [qtdi10] REAL NOT NULL, [qtdi11] REAL NOT NULL, [qtdi12] REAL NOT NULL, [qtdi13] REAL NOT NULL, [qtdi14] REAL NOT NULL, [qtdi15] REAL NOT NULL, [qtdi16] REAL NOT NULL, [qtdi17] REAL NOT NULL, [qtdi18] REAL NOT NULL, [qtdi19] REAL NOT NULL, [qtdi20] REAL NOT NULL);

-- Tabela: prnect
CREATE TABLE IF NOT EXISTS [prnect] ([tipoent] TEXT(1) NOT NULL, [codcomp] TEXT(24) NOT NULL, [diaspr] REAL NOT NULL, [qtdest] REAL NOT NULL, [qtdpro] REAL NOT NULL, [qtdsal] REAL NOT NULL, [qtdini] REAL NOT NULL, [qtdtot] REAL NOT NULL, [qtdt01] REAL NOT NULL, [datr01] SHORTDATE NOT NULL, [qtdi01] REAL NOT NULL, [data01] SHORTDATE NOT NULL, [qtdt02] REAL NOT NULL, [datr02] SHORTDATE NOT NULL, [qtdi02] REAL NOT NULL, [data02] SHORTDATE NOT NULL, [qtdt03] REAL NOT NULL, [datr03] SHORTDATE NOT NULL, [qtdi03] REAL NOT NULL, [data03] SHORTDATE NOT NULL, [qtdt04] REAL NOT NULL, [datr04] SHORTDATE NOT NULL, [qtdi04] REAL NOT NULL, [data04] SHORTDATE NOT NULL, [qtdt05] REAL NOT NULL, [datr05] SHORTDATE NOT NULL, [qtdi05] REAL NOT NULL, [data05] SHORTDATE NOT NULL, [qtdt06] REAL NOT NULL, [datr06] SHORTDATE NOT NULL, [qtdi06] REAL NOT NULL, [data06] SHORTDATE NOT NULL, [qtdt07] REAL NOT NULL, [datr07] SHORTDATE NOT NULL, [qtdi07] REAL NOT NULL, [data07] SHORTDATE NOT NULL, [qtdt08] REAL NOT NULL, [datr08] SHORTDATE NOT NULL, [qtdi08] REAL NOT NULL, [data08] SHORTDATE NOT NULL, [qtdt09] REAL NOT NULL, [datr09] SHORTDATE NOT NULL, [qtdi09] REAL NOT NULL, [data09] SHORTDATE NOT NULL, [qtdt10] REAL NOT NULL, [datr10] SHORTDATE NOT NULL, [qtdi10] REAL NOT NULL, [data10] SHORTDATE NOT NULL, [qtdt11] REAL NOT NULL, [datr11] SHORTDATE NOT NULL, [qtdi11] REAL NOT NULL, [data11] SHORTDATE NOT NULL, [qtdt12] REAL NOT NULL, [datr12] SHORTDATE NOT NULL, [qtdi12] REAL NOT NULL, [data12] SHORTDATE NOT NULL, [qtdt13] REAL NOT NULL, [datr13] SHORTDATE NOT NULL, [qtdi13] REAL NOT NULL, [data13] SHORTDATE NOT NULL, [qtdt14] REAL NOT NULL, [datr14] SHORTDATE NOT NULL, [qtdi14] REAL NOT NULL, [data14] SHORTDATE NOT NULL, [qtdt15] REAL NOT NULL, [datr15] SHORTDATE NOT NULL, [qtdi15] REAL NOT NULL, [data15] SHORTDATE NOT NULL, [qtdt16] REAL NOT NULL, [datr16] SHORTDATE NOT NULL, [qtdi16] REAL NOT NULL, [data16] SHORTDATE NOT NULL, [qtdt17] REAL NOT NULL, [datr17] SHORTDATE NOT NULL, [qtdi17] REAL NOT NULL, [data17] SHORTDATE NOT NULL, [qtdt18] REAL NOT NULL, [datr18] SHORTDATE NOT NULL, [qtdi18] REAL NOT NULL, [data18] SHORTDATE NOT NULL, [qtdt19] REAL NOT NULL, [datr19] SHORTDATE NOT NULL, [qtdi19] REAL NOT NULL, [data19] SHORTDATE NOT NULL, [qtdt20] REAL NOT NULL, [datr20] SHORTDATE NOT NULL, [qtdi20] REAL NOT NULL, [data20] SHORTDATE NOT NULL, [semanas] REAL NOT NULL, [nome] TEXT(100) NOT NULL);

-- �ndice: idx_ac_ac
CREATE INDEX IF NOT EXISTS [idx_ac_ac] ON [ac] ([ac]);

-- �ndice: idx_ac_ac2
CREATE INDEX IF NOT EXISTS [idx_ac_ac2] ON [ac] ([codigo]);

-- �ndice: idx_aci_aci
CREATE INDEX IF NOT EXISTS [idx_aci_aci] ON [aci] ([ac], [item]);

-- �ndice: idx_aci_aci-2
CREATE INDEX IF NOT EXISTS [idx_aci_aci-2] ON [aci] ([ac], [data], [item]);

-- �ndice: idx_aci_aci-3
CREATE INDEX IF NOT EXISTS [idx_aci_aci-3] ON [aci] ([ac]);

-- �ndice: idx_estqint_estqint
CREATE INDEX IF NOT EXISTS [idx_estqint_estqint] ON [estqint] ([cod_item]);

-- �ndice: idx_op01_op01-1
CREATE INDEX IF NOT EXISTS [idx_op01_op01-1] ON [op01] ([op]);

-- �ndice: idx_op01_op01-2
CREATE INDEX IF NOT EXISTS [idx_op01_op01-2] ON [op01] ([codigo]);

-- �ndice: idx_op01_op01-3
CREATE INDEX IF NOT EXISTS [idx_op01_op01-3] ON [op01] ([op]);

-- �ndice: idx_op01_op01-4
CREATE INDEX IF NOT EXISTS [idx_op01_op01-4] ON [op01] ([codigoint]);

-- �ndice: idx_op01x_op01x-1
CREATE INDEX IF NOT EXISTS [idx_op01x_op01x-1] ON [op01x] ([op]);

-- �ndice: idx_op01x_op01x-2
CREATE INDEX IF NOT EXISTS [idx_op01x_op01x-2] ON [op01x] ([codigo]);

-- �ndice: idx_op01x_op01x-3
CREATE INDEX IF NOT EXISTS [idx_op01x_op01x-3] ON [op01x] ([op]);

-- �ndice: idx_op02set_op02set1
CREATE INDEX IF NOT EXISTS [idx_op02set_op02set1] ON [op02set] ([data], [codigo], [seq], [ssq]);

-- �ndice: idx_op02set_op02set2
CREATE INDEX IF NOT EXISTS [idx_op02set_op02set2] ON [op02set] ([codigo], [seq], [ssq], [data]);

-- �ndice: idx_op02set_op02set3
CREATE INDEX IF NOT EXISTS [idx_op02set_op02set3] ON [op02set] ([cliente], [data], [codigo], [seq], [ssq]);

-- �ndice: idx_op02set_op02set4
CREATE INDEX IF NOT EXISTS [idx_op02set_op02set4] ON [op02set] ([codmp01], [data], [codigo], [seq], [ssq]);

-- �ndice: idx_op02set_op02set5
CREATE INDEX IF NOT EXISTS [idx_op02set_op02set5] ON [op02set] ([semana], [codigo], [seq], [ssq]);

-- �ndice: idx_op02sex_op02sex
CREATE INDEX IF NOT EXISTS [idx_op02sex_op02sex] ON [op02sex] ([codigo], [seq], [ssq]);

-- �ndice: idx_op02sex_op02sex2
CREATE INDEX IF NOT EXISTS [idx_op02sex_op02sex2] ON [op02sex] ([setorop], [codigo]);

-- �ndice: idx_op02x_op02x-1
CREATE INDEX IF NOT EXISTS [idx_op02x_op02x-1] ON [op02x] ([op], [seq], [ssq]);

-- �ndice: idx_op02x_op02x-2
CREATE INDEX IF NOT EXISTS [idx_op02x_op02x-2] ON [op02x] ([op]);

-- �ndice: idx_op02x_op02x-3
CREATE INDEX IF NOT EXISTS [idx_op02x_op02x-3] ON [op02x] ([codigo]);

-- �ndice: idx_op02x_op02x-4
CREATE INDEX IF NOT EXISTS [idx_op02x_op02x-4] ON [op02x] ([codigo], [seq], [ssq]);

-- �ndice: idx_op02x_op02x-5
CREATE INDEX IF NOT EXISTS [idx_op02x_op02x-5] ON [op02x] ([setorop], [codigo]);

-- �ndice: idx_op03_op03-1
CREATE INDEX IF NOT EXISTS [idx_op03_op03-1] ON [op03] ([op], [codmp01]);

-- �ndice: idx_op03b_op03b-1
CREATE INDEX IF NOT EXISTS [idx_op03b_op03b-1] ON [op03b] ([op], [codmp01]);

-- �ndice: idx_oscrt_oscrt
CREATE INDEX IF NOT EXISTS [idx_oscrt_oscrt] ON [oscrt] ([os]);

-- �ndice: idx_oscrt_oscrt-2
CREATE INDEX IF NOT EXISTS [idx_oscrt_oscrt-2] ON [oscrt] ([cliente], [codigo]);

-- �ndice: idx_oscrt_oscrt-3
CREATE INDEX IF NOT EXISTS [idx_oscrt_oscrt-3] ON [oscrt] ([pf]);

-- �ndice: idx_oscrt_oscrt-4
CREATE INDEX IF NOT EXISTS [idx_oscrt_oscrt-4] ON [oscrt] ([codigo]);

-- �ndice: idx_oscrt_oscrt-5
CREATE INDEX IF NOT EXISTS [idx_oscrt_oscrt-5] ON [oscrt] ([codigoint]);

-- �ndice: idx_ospr2_ospr2-1
CREATE INDEX IF NOT EXISTS [idx_ospr2_ospr2-1] ON [ospr2] ([numero]);

-- �ndice: idx_ospr2_ospr2-2
CREATE INDEX IF NOT EXISTS [idx_ospr2_ospr2-2] ON [ospr2] ([produto]);

-- �ndice: idx_ospr2_ospr2-3
CREATE INDEX IF NOT EXISTS [idx_ospr2_ospr2-3] ON [ospr2] ([produto], [planta], [programa], [qtde]);

-- �ndice: idx_ospr2_ospr2-4
CREATE INDEX IF NOT EXISTS [idx_ospr2_ospr2-4] ON [ospr2] ([produto], [programa]);

-- �ndice: idx_ospr2_ospr2-5
CREATE INDEX IF NOT EXISTS [idx_ospr2_ospr2-5] ON [ospr2] ([codigoint]);

-- �ndice: idx_ospra_ospra-1
CREATE INDEX IF NOT EXISTS [idx_ospra_ospra-1] ON [ospra] ([produto], [dataacm], [dataprg]);

-- �ndice: idx_osprb_osprb-1
CREATE INDEX IF NOT EXISTS [idx_osprb_osprb-1] ON [osprb] ([produto], [dataacm], [dataprg]);

-- �ndice: idx_osprg_osprg-1
CREATE INDEX IF NOT EXISTS [idx_osprg_osprg-1] ON [osprg] ([numero]);

-- �ndice: idx_osprg_osprg-2
CREATE INDEX IF NOT EXISTS [idx_osprg_osprg-2] ON [osprg] ([produto]);

-- �ndice: idx_osprg_osprg-3
CREATE INDEX IF NOT EXISTS [idx_osprg_osprg-3] ON [osprg] ([produto], [planta], [programa], [qtde]);

-- �ndice: idx_osprg_osprg-4
CREATE INDEX IF NOT EXISTS [idx_osprg_osprg-4] ON [osprg] ([produto], [programa]);

-- �ndice: idx_osprg_osprg-5
CREATE INDEX IF NOT EXISTS [idx_osprg_osprg-5] ON [osprg] ([codigoint]);

-- �ndice: idx_osprh_osprh-1
CREATE INDEX IF NOT EXISTS [idx_osprh_osprh-1] ON [osprh] ([numero]);

-- �ndice: idx_osprh_osprh-2
CREATE INDEX IF NOT EXISTS [idx_osprh_osprh-2] ON [osprh] ([produto]);

-- �ndice: idx_osprh_osprh-3
CREATE INDEX IF NOT EXISTS [idx_osprh_osprh-3] ON [osprh] ([produto], [planta], [programa], [qtde]);

-- �ndice: idx_osprh_osprh-4
CREATE INDEX IF NOT EXISTS [idx_osprh_osprh-4] ON [osprh] ([produto], [programa]);

-- �ndice: idx_osprh_osprh-5
CREATE INDEX IF NOT EXISTS [idx_osprh_osprh-5] ON [osprh] ([codigoint]);

-- �ndice: idx_ospri_ospri-1
CREATE INDEX IF NOT EXISTS [idx_ospri_ospri-1] ON [ospri] ([numero]);

-- �ndice: idx_ospri_ospri-2
CREATE INDEX IF NOT EXISTS [idx_ospri_ospri-2] ON [ospri] ([produto]);

-- �ndice: idx_ospri_ospri-3
CREATE INDEX IF NOT EXISTS [idx_ospri_ospri-3] ON [ospri] ([produto], [planta], [programa], [qtde]);

-- �ndice: idx_ospri_ospri-4
CREATE INDEX IF NOT EXISTS [idx_ospri_ospri-4] ON [ospri] ([produto], [programa]);

-- �ndice: idx_ospri_ospri-5
CREATE INDEX IF NOT EXISTS [idx_ospri_ospri-5] ON [ospri] ([codigoint]);

-- �ndice: idx_ospro_ospro-1
CREATE INDEX IF NOT EXISTS [idx_ospro_ospro-1] ON [ospro] ([produto], [dataacm], [dataprg]);

-- �ndice: idx_osprr_osprr-1
CREATE INDEX IF NOT EXISTS [idx_osprr_osprr-1] ON [osprr] ([numero]);

-- �ndice: idx_osprr_osprr-2
CREATE INDEX IF NOT EXISTS [idx_osprr_osprr-2] ON [osprr] ([produto]);

-- �ndice: idx_osprr_osprr-3
CREATE INDEX IF NOT EXISTS [idx_osprr_osprr-3] ON [osprr] ([produto], [planta], [programa], [qtde]);

-- �ndice: idx_osprr_osprr-4
CREATE INDEX IF NOT EXISTS [idx_osprr_osprr-4] ON [osprr] ([produto], [programa]);

-- �ndice: idx_osprr_osprr-5
CREATE INDEX IF NOT EXISTS [idx_osprr_osprr-5] ON [osprr] ([codigoint]);

-- �ndice: idx_osprs_osprs-1
CREATE INDEX IF NOT EXISTS [idx_osprs_osprs-1] ON [osprs] ([numero]);

-- �ndice: idx_osprs_osprs-2
CREATE INDEX IF NOT EXISTS [idx_osprs_osprs-2] ON [osprs] ([produto]);

-- �ndice: idx_osprs_osprs-3
CREATE INDEX IF NOT EXISTS [idx_osprs_osprs-3] ON [osprs] ([produto], [planta], [programa], [qtde]);

-- �ndice: idx_osprs_osprs-4
CREATE INDEX IF NOT EXISTS [idx_osprs_osprs-4] ON [osprs] ([produto], [programa]);

-- �ndice: idx_osprs_osprs-5
CREATE INDEX IF NOT EXISTS [idx_osprs_osprs-5] ON [osprs] ([codigoint]);

-- �ndice: idx_pcorte_pcorte
CREATE INDEX IF NOT EXISTS [idx_pcorte_pcorte] ON [pcorte] ([numero]);

-- �ndice: idx_pcorte_pcorte-2
CREATE INDEX IF NOT EXISTS [idx_pcorte_pcorte-2] ON [pcorte] ([rastrou]);

-- �ndice: idx_pcorte_pcorte-3
CREATE INDEX IF NOT EXISTS [idx_pcorte_pcorte-3] ON [pcorte] ([data]);

-- �ndice: idx_pcortei_pcortei
CREATE INDEX IF NOT EXISTS [idx_pcortei_pcortei] ON [pcortei] ([numero]);

-- �ndice: idx_pcortei_pcortei-2
CREATE INDEX IF NOT EXISTS [idx_pcortei_pcortei-2] ON [pcortei] ([codigo]);

-- �ndice: idx_pe01_pe01
CREATE INDEX IF NOT EXISTS [idx_pe01_pe01] ON [pe01] ([pedido], [item], [digctr]);

-- �ndice: idx_pe01_pe01-2
CREATE INDEX IF NOT EXISTS [idx_pe01_pe01-2] ON [pe01] ([pedido]);

-- �ndice: idx_pe01ap_pe01ap
CREATE INDEX IF NOT EXISTS [idx_pe01ap_pe01ap] ON [pe01ap] ([cliente], [pedido], [item], [datasai]);

-- �ndice: idx_pe01bx_pe01bx
CREATE INDEX IF NOT EXISTS [idx_pe01bx_pe01bx] ON [pe01bx] ([pedido], [item], [digctr]);

-- �ndice: idx_pe01bx_pe01bx-2
CREATE INDEX IF NOT EXISTS [idx_pe01bx_pe01bx-2] ON [pe01bx] ([nrnotasai], [cliente]);

-- �ndice: idx_pe01bx_pe01bx-3
CREATE INDEX IF NOT EXISTS [idx_pe01bx_pe01bx-3] ON [pe01bx] ([pedido]);

-- �ndice: idx_pe01bx_pe01bx-4
CREATE INDEX IF NOT EXISTS [idx_pe01bx_pe01bx-4] ON [pe01bx] ([cliente]);

-- �ndice: idx_pe99_pe99-1
CREATE INDEX IF NOT EXISTS [idx_pe99_pe99-1] ON [pe99] ([pedido], [item], [digctr]);

-- �ndice: idx_pe99_pe99-2
CREATE INDEX IF NOT EXISTS [idx_pe99_pe99-2] ON [pe99] ([nrnotasai], [cliente]);

-- �ndice: idx_pe99_pe99-3
CREATE INDEX IF NOT EXISTS [idx_pe99_pe99-3] ON [pe99] ([pedido]);

-- �ndice: idx_pe99_pe99-4
CREATE INDEX IF NOT EXISTS [idx_pe99_pe99-4] ON [pe99] ([cliente]);

-- �ndice: idx_pe_pe
CREATE INDEX IF NOT EXISTS [idx_pe_pe] ON [pe] ([pedido]);

-- �ndice: idx_pe_pe-2
CREATE INDEX IF NOT EXISTS [idx_pe_pe-2] ON [pe] ([tipped], [codigo], [fornecedo]);

-- �ndice: idx_pe_pe-3
CREATE INDEX IF NOT EXISTS [idx_pe_pe-3] ON [pe] ([codigo]);

-- �ndice: idx_pe_pe-4
CREATE INDEX IF NOT EXISTS [idx_pe_pe-4] ON [pe] ([fornecedo]);

-- �ndice: idx_pecrt_pecrt
CREATE INDEX IF NOT EXISTS [idx_pecrt_pecrt] ON [pecrt] ([tipo], [codigo], [uforne]);

-- �ndice: idx_pecrt_pecrt-2
CREATE INDEX IF NOT EXISTS [idx_pecrt_pecrt-2] ON [pecrt] ([uforne], [codigo]);

-- �ndice: idx_pecrt_pecrt-3
CREATE INDEX IF NOT EXISTS [idx_pecrt_pecrt-3] ON [pecrt] ([uforne]);

-- �ndice: idx_pecrt_pecrt-4
CREATE INDEX IF NOT EXISTS [idx_pecrt_pecrt-4] ON [pecrt] ([codigo]);

-- �ndice: idx_pemo_pemo
CREATE INDEX IF NOT EXISTS [idx_pemo_pemo] ON [pemo] ([pedido]);

-- �ndice: idx_pemo_pemo-2
CREATE INDEX IF NOT EXISTS [idx_pemo_pemo-2] ON [pemo] ([tipped], [codigo], [fornecedo]);

-- �ndice: idx_petr_petr
CREATE INDEX IF NOT EXISTS [idx_petr_petr] ON [petr] ([pedido]);

-- �ndice: idx_petr_petr-2
CREATE INDEX IF NOT EXISTS [idx_petr_petr-2] ON [petr] ([tipped], [codigo], [fornecedo]);

-- �ndice: idx_prnec_codigo
CREATE INDEX IF NOT EXISTS [idx_prnec_codigo] ON [prnec] ([codigo]);

-- �ndice: idx_prneca_codigo
CREATE INDEX IF NOT EXISTS [idx_prneca_codigo] ON [prneca] ([codigo]);

-- �ndice: idx_prneci_chave
CREATE INDEX IF NOT EXISTS [idx_prneci_chave] ON [prneci] ([codigo], [tipoent], [codcomp]);

-- �ndice: idx_prneci_codigo
CREATE INDEX IF NOT EXISTS [idx_prneci_codigo] ON [prneci] ([codigo]);

-- �ndice: idx_prneci_tipcod
CREATE INDEX IF NOT EXISTS [idx_prneci_tipcod] ON [prneci] ([tipoent], [codcomp]);

-- �ndice: idx_tipcod
CREATE INDEX IF NOT EXISTS [idx_tipcod] ON [prnect] ([tipoent], [codcomp]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
