--
-- Arquivo gerado com SQLiteStudio v3.4.4 em seg ago 5 11:03:54 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: adipie
CREATE TABLE IF NOT EXISTS [adipie] ([fornecedo] REAL NOT NULL, [dclassipi] TEXT(14) NOT NULL, [doper] TEXT(3) NOT NULL, [dvalornf] REAL NOT NULL, [dvalipi] REAL NOT NULL, [cgc] TEXT(18) NOT NULL, [cognome] TEXT(20) NOT NULL, [dcfonew] TEXT(4) NOT NULL, [ficha] BIT NOT NULL, [descri] TEXT(60) NOT NULL);

-- Tabela: adipig
CREATE TABLE IF NOT EXISTS [adipig] ([grupo] TEXT(5) NOT NULL, [cfop] TEXT(4) NOT NULL);

-- Tabela: adipis
CREATE TABLE IF NOT EXISTS [adipis] ([fornecedo] REAL NOT NULL, [dclassipi] TEXT(14) NOT NULL, [doper] TEXT(3) NOT NULL, [dvalornf] REAL NOT NULL, [dvalipi] REAL NOT NULL, [cgc] TEXT(18) NOT NULL, [cognome] TEXT(20) NOT NULL, [dcfonew] TEXT(4) NOT NULL, [ficha] BIT NOT NULL, [descri] TEXT(60) NOT NULL);

-- Tabela: bpforc
CREATE TABLE IF NOT EXISTS [bpforc] ([fornecedo] REAL NOT NULL, [sai] TEXT(1) NOT NULL);

-- Tabela: bpforr
CREATE TABLE IF NOT EXISTS [bpforr] ([fornecedo] REAL NOT NULL, [tipo] TEXT(1) NOT NULL, [valor] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [grupo] TEXT(4) NOT NULL, [cognome] TEXT(15) NOT NULL, [perc] REAL NOT NULL);

-- Tabela: bs3
CREATE TABLE IF NOT EXISTS [bs3] ([codigo] TEXT(12) NOT NULL, [nome] TEXT(30) NOT NULL, [grupoutl] TEXT(3) NOT NULL, [estoque] REAL NOT NULL, [estoqu3] REAL NOT NULL, [uso01] REAL NOT NULL, [uso02] REAL NOT NULL, [uso03] REAL NOT NULL, [uso04] REAL NOT NULL, [sal01] REAL NOT NULL, [sal02] REAL NOT NULL, [sal03] REAL NOT NULL, [sal04] REAL NOT NULL, [sa301] REAL NOT NULL, [sa302] REAL NOT NULL, [sa303] REAL NOT NULL, [sa304] REAL NOT NULL);

-- �ndice: idx_adipie_adipie-1
CREATE INDEX IF NOT EXISTS [idx_adipie_adipie-1] ON [adipie] ([fornecedo], [doper], [dclassipi]);

-- �ndice: idx_adipie_adipie-2
CREATE INDEX IF NOT EXISTS [idx_adipie_adipie-2] ON [adipie] ([fornecedo], [dcfonew], [dclassipi]);

-- �ndice: idx_adipie_adipie-3
CREATE INDEX IF NOT EXISTS [idx_adipie_adipie-3] ON [adipie] ([dcfonew]);

-- �ndice: idx_adipig_adipig
CREATE INDEX IF NOT EXISTS [idx_adipig_adipig] ON [adipig] ([grupo], [cfop]);

-- �ndice: idx_adipig_adipig-2
CREATE INDEX IF NOT EXISTS [idx_adipig_adipig-2] ON [adipig] ([cfop]);

-- �ndice: idx_adipis_adipis-1
CREATE INDEX IF NOT EXISTS [idx_adipis_adipis-1] ON [adipis] ([fornecedo], [doper], [dclassipi]);

-- �ndice: idx_adipis_adipis-2
CREATE INDEX IF NOT EXISTS [idx_adipis_adipis-2] ON [adipis] ([fornecedo], [dcfonew], [dclassipi]);

-- �ndice: idx_adipis_adipis-3
CREATE INDEX IF NOT EXISTS [idx_adipis_adipis-3] ON [adipis] ([dcfonew]);

-- �ndice: idx_bpforc_bpforc
CREATE INDEX IF NOT EXISTS [idx_bpforc_bpforc] ON [bpforc] ([fornecedo]);

-- �ndice: idx_bpforr_bpforr
CREATE INDEX IF NOT EXISTS [idx_bpforr_bpforr] ON [bpforr] ([ano], [mes], [fornecedo]);

-- �ndice: idx_bs3-1
CREATE INDEX IF NOT EXISTS [idx_bs3-1] ON [bs3] ([codigo]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
