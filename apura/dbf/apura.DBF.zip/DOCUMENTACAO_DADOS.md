# 🗄️ Dicionario de Estruturas de Dados do Projeto
> Varredura automatica realizada em: 05/12/26

## 📋 Tabela DBF: `adipie.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| FORNECEDO | N | 8 | 0 |
| DCLASSIPI | C | 14 | 0 |
| DOPER | C | 3 | 0 |
| DVALORNF | N | 18 | 2 |
| DVALIPI | N | 18 | 2 |
| CGC | C | 18 | 0 |
| COGNOME | C | 20 | 0 |
| DCFONEW | C | 4 | 0 |
| FICHA | L | 1 | 0 |
| DESCRI | C | 60 | 0 |

**Índices vinculados:**
- Tag: `ADIPIE-1` Expressão: `STR(FORNECEDO,8)+DOPER+DCLASSIPI`
- Tag: `ADIPIE-2` Expressão: `STR(FORNECEDO,8)+DCFONEW+DCLASSIPI`
- Tag: `ADIPIE-3` Expressão: `DCFONEW`

---
## 📋 Tabela DBF: `adipig.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| GRUPO | C | 5 | 0 |
| CFOP | C | 4 | 0 |

**Índices vinculados:**
- Tag: `ADIPIG` Expressão: `GRUPO+CFOP`
- Tag: `ADIPIG-2` Expressão: `CFOP`

---
## 📋 Tabela DBF: `adipis.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| FORNECEDO | N | 8 | 0 |
| DCLASSIPI | C | 14 | 0 |
| DOPER | C | 3 | 0 |
| DVALORNF | N | 18 | 2 |
| DVALIPI | N | 18 | 2 |
| CGC | C | 18 | 0 |
| COGNOME | C | 20 | 0 |
| DCFONEW | C | 4 | 0 |
| FICHA | L | 1 | 0 |
| DESCRI | C | 60 | 0 |

**Índices vinculados:**
- Tag: `ADIPIS-1` Expressão: `STR(FORNECEDO,8)+DOPER+DCLASSIPI`
- Tag: `ADIPIS-2` Expressão: `STR(FORNECEDO,8)+DCFONEW+DCLASSIPI`
- Tag: `ADIPIS-3` Expressão: `DCFONEW`

---
## 📋 Tabela DBF: `bpforc.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| FORNECEDO | N | 8 | 0 |
| SAI | C | 1 | 0 |

**Índices vinculados:**
- Tag: `BPFORC` Expressão: `FORNECEDO`

---
## 📋 Tabela DBF: `bpforr.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| FORNECEDO | N | 8 | 0 |
| TIPO | C | 1 | 0 |
| VALOR | N | 18 | 2 |
| MES | N | 2 | 0 |
| ANO | N | 4 | 0 |
| GRUPO | C | 4 | 0 |
| COGNOME | C | 15 | 0 |
| PERC | N | 15 | 6 |

**Índices vinculados:**
- Tag: `BPFORR` Expressão: `STR(ANO,4)+STR(MES,2)+STR(FORNECEDO,8)`

---
## 📋 Tabela DBF: `bs3.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 12 | 0 |
| NOME | C | 30 | 0 |
| GRUPOUTL | C | 3 | 0 |
| ESTOQUE | N | 10 | 0 |
| ESTOQU3 | N | 10 | 0 |
| USO01 | N | 10 | 0 |
| USO02 | N | 10 | 0 |
| USO03 | N | 10 | 0 |
| USO04 | N | 10 | 0 |
| SAL01 | N | 10 | 0 |
| SAL02 | N | 10 | 0 |
| SAL03 | N | 10 | 0 |
| SAL04 | N | 10 | 0 |
| SA301 | N | 10 | 0 |
| SA302 | N | 10 | 0 |
| SA303 | N | 10 | 0 |
| SA304 | N | 10 | 0 |

**Índices vinculados:**
- Tag: `BS3-1` Expressão: `CODIGO`

---
