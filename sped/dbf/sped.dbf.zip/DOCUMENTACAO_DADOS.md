# 🗄️ Dicionario de Estruturas de Dados do Projeto
> Varredura automatica realizada em: 05/12/26

## 📋 Tabela DBF: `regc170for.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| COD_PART | C | 20 | 0 |
| COD_ITEM | C | 20 | 0 |
| COD_FORN | C | 30 | 0 |
| DESCR_FORN | C | 120 | 0 |
| NCM_FORN | C | 8 | 0 |
| QTD_DESCR | N | 10 | 0 |

**Índices vinculados:**
- Tag: `REGC170FOR` Expressão: `COD_PART+  COD_item+  COD_forn`

---
## 📋 Tabela DBF: `regh010lxval.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| COD_ITEM | C | 60 | 0 |
| VL_UNIT | N | 14 | 6 |
| TIPOPRECO | C | 1 | 0 |

**Índices vinculados:**
- Tag: `REGH10LXV1` Expressão: `TIPOPRECO+  COD_ITEM`
- Tag: `REGH010XV2` Expressão: `cod_item`

---
