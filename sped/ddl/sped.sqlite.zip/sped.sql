--
-- Arquivo gerado com SQLiteStudio v3.4.4 em ter ago 6 17:31:29 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: regc170for
CREATE TABLE IF NOT EXISTS [regc170for] ([cod_part] TEXT(20) NOT NULL, [cod_item] TEXT(20) NOT NULL, [cod_forn] TEXT(30) NOT NULL, [descr_forn] TEXT(120) NOT NULL, [ncm_forn] TEXT(8) NOT NULL, [qtd_descr] REAL NOT NULL);

-- Tabela: regh010lxval
CREATE TABLE IF NOT EXISTS [regh010lxval] ([cod_item] TEXT(60) NOT NULL, [vl_unit] REAL NOT NULL, [tipopreco] TEXT(1) NOT NULL);

-- �ndice: idx_regc170for_regc170for
CREATE INDEX IF NOT EXISTS [idx_regc170for_regc170for] ON [regc170for] ([cod_part], [cod_item], [cod_forn]);

-- �ndice: idx_regh010lxval_regh010xv2
CREATE INDEX IF NOT EXISTS [idx_regh010lxval_regh010xv2] ON [regh010lxval] ([cod_item]);

-- �ndice: idx_regh10lxv1
CREATE INDEX IF NOT EXISTS [idx_regh10lxv1] ON [regh010lxval] ([tipopreco], [cod_item]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
