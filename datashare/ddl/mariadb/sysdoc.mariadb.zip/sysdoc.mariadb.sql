#
# DUMP FILE
#
# Database is ported from MS Access
#------------------------------------------------------------------
# Created using "MS Access to MySQL" form http://www.bullzip.com
# Program Version 5.5.282
#
# OPTIONS:
#   sourcefilename=C:/temp/sysdoc.mdb
#   sourceusername=
#   sourcepassword=
#   sourcesystemdatabase=
#   destinationdatabase=sysdoc
#   storageengine=InnoDB
#   dropdatabase=0
#   createtables=1
#   unicode=0
#   autocommit=1
#   transferdefaultvalues=1
#   transferindexes=1
#   transferautonumbers=1
#   transferrecords=1
#   columnlist=1
#   tableprefix=
#   negativeboolean=0
#   ignorelargeblobs=0
#   memotype=LONGTEXT
#   datetimetype=DATETIME
#

CREATE DATABASE IF NOT EXISTS `sysdoc`;
USE `sysdoc`;

#
# Table structure for table 'Alteracao'
#

DROP TABLE IF EXISTS `Alteracao`;

CREATE TABLE `Alteracao` (
  `NUMERO` INTEGER, 
  `ITEM` INTEGER, 
  `DIZER` LONGTEXT, 
  `DATA` DATETIME, 
  `ID` INTEGER AUTO_INCREMENT, 
  INDEX (`NUMERO`), 
  INDEX (`ID`)
) ENGINE=innodb;

SET autocommit=1;

#
# Dumping data for table 'Alteracao'
#

INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (1, 1, 'Inclusao Form Alteraçao', '2003-12-12 11:15:26', 1);
INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (1, 2, 'Inclusao Tabelas Tipos Caracteristicas Sistema', '2003-12-12 12:45:03', 2);
INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (1, 3, 'Inclusão Documentaçao Sistema Caracteristicas', '2003-12-12 13:42:58', 3);
INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (1, 4, 'Inclusao do Editor de Textos', '2003-12-12 17:35:25', 4);
INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (1, 5, 'Inclusao de Editor de Arquivos INI', '2003-12-19 19:39:52', 5);
INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (1, 6, 'Documentaçao Permite Alterar o arquivo Ini do Sistema', '2003-12-19 22:14:48', 6);
INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (1, 7, 'Inclusao Tabela SYSRPT', '2003-12-27 13:04:40', 7);
INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (1, 8, 'Criaçao Formulario Escolha Relatorios/Documentos 1057(escgrpmain.frm)', '2003-12-27 13:19:08', 8);
INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (0, 0, NULL, '2003-12-27 21:46:41', 9);
INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (1, 9, 'Criaçao Formulário Ediçao Relatórios/Documentos 1058 frmRptMain', '2003-12-27 21:58:31', 10);
INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (1, 10, 'Criaçao Formularios Escolher Grupo Relatorios 1059 escrptgrp', '2003-12-29 15:03:25', 11);
INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (1, 11, 'Criaçao Formularios Editar Grupo Relatorios 1060 frmrptgrp', '2003-12-29 15:03:51', 12);
INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (1, 12, 'Criaçao Formularios Escolher Tipos Arquivos 1060 escodnome', '2003-12-29 15:04:23', 13);
INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (1, 13, 'Criaçao Formularios Editar tipos arquivos 1062 frmcodnome', '2003-12-29 15:04:56', 14);
INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (1, 14, 'Inclusao Formulario de Senhas', '2004-02-06 12:32:56', 15);
INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (1, 15, 'Teste Grid', '2004-02-17 17:59:30', 16);
INSERT INTO `Alteracao` (`NUMERO`, `ITEM`, `DIZER`, `DATA`, `ID`) VALUES (5, 1, 'Integraçao Novo Vblib2', '2004-02-18 19:32:22', 17);
# 17 records

#
# Table structure for table 'BaseDados'
#

DROP TABLE IF EXISTS `BaseDados`;

CREATE TABLE `BaseDados` (
  `NUMERO` INTEGER, 
  `ITEM` INTEGER, 
  `CAMINHO` VARCHAR(200), 
  `NOME` VARCHAR(50), 
  `TIPO` VARCHAR(20), 
  `COGNOME` VARCHAR(20), 
  `ID` INTEGER AUTO_INCREMENT, 
  INDEX (`NUMERO`), 
  INDEX (`ID`)
) ENGINE=innodb;

SET autocommit=1;

#
# Dumping data for table 'BaseDados'
#

INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (2, 1, 'C:\\develop\\os\\reparar.mdb', 'Configuração Reparação Base de Dados', 'MDB', 'REPARAR', 1);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (1, 1, '{REPARQ}', 'Configuraçao Reparaçao Banco de Dados', 'MDB', 'REPARAR', 2);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (1, 2, '{CFG}', 'Configuraçao do Sistema', 'MDB', 'SYSCONF', 3);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (1, 3, '{SYSDOC}', 'Documentaçao do Sistema', 'MDB', 'SYSDOC', 4);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (1, 4, '{LOG}', 'Log de Utilizaçao do Sistema', 'MDB', 'SYSLOG', 5);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (1, 5, '{USR}', 'Configuraçoes de Usuarios', 'MDB', 'SYSUSER', 6);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (1, 6, '{TAB}', 'Tabela Modulo Ordem de Serviço', 'MDB', 'TABOS', 7);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (1, 7, '{USRTAB}', 'Tabelas Ordem Serviço Usuario', 'MDB', 'TABOSUSR', 8);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (1, 8, '{TABSYS}', 'Tabelas do Sistema', 'MDB', 'TABSYS', 9);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (1, 9, '{USRTAB}', 'Cadastro do Usuarios', 'MDB', 'TABUSR', 10);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (4, 1, 'C:\\develop\\comex\\comexcad.mdb', 'Cadastro', 'MDB', 'COMEXCAD', 11);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (4, 2, 'C:\\develop\\comex\\comextab.mdb', 'Tabelas', 'MDB', 'COMEXTAB', 12);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (5, 1, 'C:\\dicion\\Dic.mdb', 'Configurações dos Dicionários', 'MDB', 'DIC', 13);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (6, 1, 'C:\\develop\\MidArc\\midarc.mdb', 'Cadastro', 'MDB', 'MIDARC', 14);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (6, 2, 'D:\\cddb\\FreeDB.mdb', 'FreeDb', 'MDB', 'FREEDB', 15);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (1, 10, '{USRCAD}', 'Cadastros dos Usuarios', 'MDB', 'USRCAD', 16);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (13, 1, 'C:\\develop\\aplifolha\\tabfolsys.mdb', NULL, 'MDB', 'TABFOLSYS', 17);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (13, 2, 'C:\\develop\\aplifolha\\tabusrfol.mdb', NULL, 'MDB', 'TABUSRFOL', 18);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (4, 3, 'C:\\develop\\comex\\REPARAR.MDB', NULL, 'MDB', 'REPARAR', 19);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (5, 2, 'C:\\develop\\DICION\\reparar.mdb', NULL, 'MDB', 'REPARAR', 20);
INSERT INTO `BaseDados` (`NUMERO`, `ITEM`, `CAMINHO`, `NOME`, `TIPO`, `COGNOME`, `ID`) VALUES (1, 11, '{SYSRPT}', 'Configuraçao de Relatorios', 'MDB', 'SYSRPT', 21);
# 21 records

#
# Table structure for table 'Caracter'
#

DROP TABLE IF EXISTS `Caracter`;

CREATE TABLE `Caracter` (
  `NUMERO` INTEGER, 
  `ITEM` INTEGER, 
  `DATA` DATETIME, 
  `TIPO` VARCHAR(10), 
  `temp` VARCHAR(50), 
  `DIZER` VARCHAR(50), 
  `ID` INTEGER AUTO_INCREMENT, 
  INDEX (`NUMERO`), 
  INDEX (`ID`)
) ENGINE=innodb;

SET autocommit=1;

#
# Dumping data for table 'Caracter'
#

INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 1, '2003-12-12 12:48:02', 'CAD', 'Clientes', 'Clientes', 1);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 2, '2003-12-12 13:52:25', 'CAD', 'Bancos', 'Bancos', 2);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 3, '2003-12-12 13:52:54', 'CAD', 'Bancos - Agencias', 'Bancos - Agencias', 3);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 4, '2003-12-12 13:53:40', 'CAD', 'Bancos - contas correntes', 'Bancos - contas correntes', 4);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 5, '2003-12-12 13:54:15', 'CAD', 'Bancos - Praças', 'Bancos - Praças', 5);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 6, '2003-12-12 13:55:13', 'CAD', 'cheques Recebidos/Emitidos', 'cheques Recebidos/Emitidos', 6);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 7, '2003-12-12 13:56:03', 'TAB', 'Codigos Devolução Cheques', 'Codigos Devolução Cheques', 7);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 8, '2003-12-12 13:57:38', 'TAB', 'Regioes', 'Regioes', 8);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 9, '2003-12-12 13:57:54', 'TAB', 'Estados', 'Estados', 9);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 10, '2003-12-12 13:58:15', 'TAB', 'Cidades', 'Cidades', 10);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 11, '2003-12-12 13:58:54', 'TAB', 'Paises', 'Paises', 11);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 12, '2003-12-12 13:59:27', 'TAB', 'Moedas', 'Moedas', 12);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 13, '2003-12-12 13:59:53', 'UTIL', 'Visualizar Imagens', 'Visualizar Imagens', 13);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (2, 1, '2003-12-12 14:03:34', 'SIS', 'Reparaçao Base Dados', 'Reparaçao Base Dados', 14);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (2, 2, '2003-12-12 14:04:17', 'SIS', 'Documentaçao Base Dados', 'Documentaçao Base Dados', 15);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 14, '2003-12-12 14:06:24', 'TAB', 'CNAB - Carteiras', 'CNAB - Carteiras', 16);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 15, '2003-12-12 14:06:45', 'TAB', 'CNAB - Especies', 'CNAB - Especies', 17);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 16, '2003-12-12 14:07:12', 'TAB', 'CNAB - Ocorrencias', 'CNAB - Ocorrencias', 18);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 17, '2003-12-12 14:07:38', 'CAD', 'CNAB - Instruções', 'CNAB - Instruções', 19);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 18, '2003-12-12 14:10:21', 'CON', 'Usuários', 'Usuários', 20);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 19, '2003-12-12 14:10:59', 'CON', 'Menus', 'Menus', 21);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 20, '2003-12-12 14:11:10', 'CON', 'Formulários', 'Formulários', 22);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 21, '2003-12-12 14:11:22', 'CON', 'Icones', 'Icones', 23);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 22, '2003-12-12 14:11:36', 'SIS', 'Arquivos', 'Arquivos', 24);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 23, '2003-12-12 14:13:24', 'SISDOC', 'Documetação Sistema', 'Documetação Sistema', 25);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 24, '2003-12-12 14:13:40', 'SISDOC', 'Tipos Linguagens Programação', 'Tipos Linguagens Programação', 26);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 25, '2003-12-12 14:13:57', 'SISDOC', 'Base de Dados', 'Base de Dados', 27);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 26, '2003-12-12 14:14:55', 'SISDOC', 'Tipos de Campos Base de Dados', 'Tipos de Campos Base de Dados', 28);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 27, '2003-12-12 14:16:03', 'SISDOC', 'Tipos de Base de Dados', 'Tipos de Base de Dados', 29);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 28, '2003-12-12 14:29:15', 'SISDOC', 'Relatorios', 'Relatorios', 30);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 29, '2003-12-12 14:29:39', 'SISDOC', 'Caracteristicas', 'Caracteristicas', 31);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 30, '2003-12-12 17:35:12', 'UTIL', NULL, 'Editor de Textos', 32);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (4, 1, '2003-12-12 18:48:19', 'UTIL', NULL, 'Visualizador de Imagens', 33);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (4, 2, '2003-12-12 18:48:35', 'UTIL', NULL, 'Editor de Textos', 34);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (5, 1, '2003-12-12 18:49:13', 'UTIL', NULL, 'Visualizador de Imagens', 35);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (5, 2, '2003-12-12 18:49:40', 'UTIL', NULL, 'Editor de Textos', 36);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (6, 1, '2003-12-12 18:50:08', 'UTIL', NULL, 'Visualizador de Imagens', 37);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (6, 2, '2003-12-12 18:50:26', 'UTIL', NULL, 'Editor de Textos', 38);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 31, '2003-12-19 19:39:24', 'UTIL', NULL, 'Editor de Arquivos INI', 39);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (4, 3, '2003-12-19 19:48:37', 'UTIL', NULL, 'Editor de Arquivos INI', 40);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (6, 3, '2003-12-19 19:49:24', 'UTIL', NULL, 'Editor de Arquivos INI', 41);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (1, 32, '2003-12-27 13:20:14', 'REL', NULL, 'Gerenciador de Relatorios/Documentos', 42);
INSERT INTO `Caracter` (`NUMERO`, `ITEM`, `DATA`, `TIPO`, `temp`, `DIZER`, `ID`) VALUES (13, 1, '2004-02-06 15:02:45', NULL, NULL, NULL, 43);
# 43 records

#
# Table structure for table 'LINGUAGEM'
#

DROP TABLE IF EXISTS `LINGUAGEM`;

CREATE TABLE `LINGUAGEM` (
  `CODIGO` VARCHAR(20), 
  `NOME` VARCHAR(50), 
  `ID` INTEGER AUTO_INCREMENT, 
  INDEX (`CODIGO`), 
  INDEX (`ID`)
) ENGINE=innodb;

SET autocommit=1;

#
# Dumping data for table 'LINGUAGEM'
#

INSERT INTO `LINGUAGEM` (`CODIGO`, `NOME`, `ID`) VALUES ('CLIPPER', 'CLIPPER', 1);
INSERT INTO `LINGUAGEM` (`CODIGO`, `NOME`, `ID`) VALUES ('VO', 'Visual Objects', 2);
INSERT INTO `LINGUAGEM` (`CODIGO`, `NOME`, `ID`) VALUES ('DELPHI', 'DELPHI', 3);
INSERT INTO `LINGUAGEM` (`CODIGO`, `NOME`, `ID`) VALUES ('VB', 'Visual Basic', 4);
# 4 records

#
# Table structure for table 'MODASS'
#

DROP TABLE IF EXISTS `MODASS`;

CREATE TABLE `MODASS` (
  `ID` INTEGER AUTO_INCREMENT, 
  `MODULO` INTEGER, 
  `MODASS` INTEGER, 
  INDEX (`ID`)
) ENGINE=innodb;

SET autocommit=1;

#
# Dumping data for table 'MODASS'
#

# 0 records

#
# Table structure for table 'Modulos'
#

DROP TABLE IF EXISTS `Modulos`;

CREATE TABLE `Modulos` (
  `NUMERO` INTEGER, 
  `COGNOME` VARCHAR(20), 
  `EXECUTAVEL` VARCHAR(20), 
  `LINGUAGEM` VARCHAR(50), 
  `ARQINI` VARCHAR(250), 
  `nome` VARCHAR(120), 
  `ID` INTEGER AUTO_INCREMENT, 
  INDEX (`NUMERO`), 
  INDEX (`ID`)
) ENGINE=innodb;

SET autocommit=1;

#
# Dumping data for table 'Modulos'
#

INSERT INTO `Modulos` (`NUMERO`, `COGNOME`, `EXECUTAVEL`, `LINGUAGEM`, `ARQINI`, `nome`, `ID`) VALUES (13, 'FOLHA', NULL, 'HARBOUR', 'folha.ini', 'FOLHA', 10);
INSERT INTO `Modulos` (`NUMERO`, `COGNOME`, `EXECUTAVEL`, `LINGUAGEM`, `ARQINI`, `nome`, `ID`) VALUES (14, 'PONTO', NULL, 'HARBOUR', 'folha.ini', 'Ponto', 11);
INSERT INTO `Modulos` (`NUMERO`, `COGNOME`, `EXECUTAVEL`, `LINGUAGEM`, `ARQINI`, `nome`, `ID`) VALUES (1, 'CONTROLE', 'controle.exe', 'VB', 'controle.ini', NULL, 23);
INSERT INTO `Modulos` (`NUMERO`, `COGNOME`, `EXECUTAVEL`, `LINGUAGEM`, `ARQINI`, `nome`, `ID`) VALUES (2, 'WRPT', 'wrpt.exe', 'VB', 'wrpt.ini', NULL, 24);
INSERT INTO `Modulos` (`NUMERO`, `COGNOME`, `EXECUTAVEL`, `LINGUAGEM`, `ARQINI`, `nome`, `ID`) VALUES (3, 'WRPTX', 'wrptx.exe', 'VB', 'wrpt.inii ->wrptf.ini wrptx.ini wrpti.ini', NULL, 25);
INSERT INTO `Modulos` (`NUMERO`, `COGNOME`, `EXECUTAVEL`, `LINGUAGEM`, `ARQINI`, `nome`, `ID`) VALUES (4, 'IMAGENSJPG', 'imagens.exe', 'VB', 'imagens.ini', NULL, 26);
INSERT INTO `Modulos` (`NUMERO`, `COGNOME`, `EXECUTAVEL`, `LINGUAGEM`, `ARQINI`, `nome`, `ID`) VALUES (5, 'IMAGENSCPF', 'imgmpcpf.exe', 'VB', 'imagens.ini', NULL, 27);
# 7 records

#
# Table structure for table 'Relatorios'
#

DROP TABLE IF EXISTS `Relatorios`;

CREATE TABLE `Relatorios` (
  `NUMERO` INTEGER, 
  `ITEM` INTEGER, 
  `CAMINHO` VARCHAR(200), 
  `NOME` VARCHAR(50), 
  `ID` INTEGER AUTO_INCREMENT, 
  INDEX (`NUMERO`), 
  INDEX (`ID`)
) ENGINE=innodb;

SET autocommit=1;

#
# Dumping data for table 'Relatorios'
#

# 0 records

#
# Table structure for table 'TipoCampos'
#

DROP TABLE IF EXISTS `TipoCampos`;

CREATE TABLE `TipoCampos` (
  `CODIGO` VARCHAR(20), 
  `NOME` VARCHAR(50), 
  `ID` INTEGER AUTO_INCREMENT, 
  INDEX (`CODIGO`), 
  INDEX (`ID`)
) ENGINE=innodb;

SET autocommit=1;

#
# Dumping data for table 'TipoCampos'
#

INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('N', 'Numerico', 1);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('D', 'Data', 2);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('C', 'Caracter', 3);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('M', 'Memo', 4);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('L', 'Logico(Boolean)', 5);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('BOOLEAN', 'Boolean(Logico)', 6);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('INTEGER', 'Integer', 7);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('LONG', 'Long', 8);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('SINGLE', 'Single Precision', 9);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('DOUBLE', 'Doble Precision', 10);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('MEMO', 'MEMO', 11);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('BYTE', 'Byte', 12);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('CURRENCY', 'Currency(Number)', 13);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('TEXT', 'Texto', 14);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('BINARY', 'Binary', 15);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('DATE/TIME', 'Data Hora', 16);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('REAL', 'REAL(SINGLE)', 17);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('SMALLINT', 'Small Integer', 18);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('VARCHAR', 'Texto Variavel', 19);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('COUNTER', 'Integer (Auto Increment)', 20);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('CHAR', 'Texto Fixo', 21);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('LONGCHAR', 'LongChar (Memo)', 22);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('VARBINARY', 'Binary Variavel', 23);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('CUID', 'Binary', 24);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('LONGBINARY', 'LongBinary (Image)', 25);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('TINYINT', 'TinyInt (Byte)', 26);
INSERT INTO `TipoCampos` (`CODIGO`, `NOME`, `ID`) VALUES ('BIT', 'BIT', 27);
# 27 records

#
# Table structure for table 'TipoDados'
#

DROP TABLE IF EXISTS `TipoDados`;

CREATE TABLE `TipoDados` (
  `CODIGO` VARCHAR(20), 
  `NOME` VARCHAR(50), 
  `ID` INTEGER AUTO_INCREMENT, 
  INDEX (`CODIGO`), 
  INDEX (`ID`)
) ENGINE=innodb;

SET autocommit=1;

#
# Dumping data for table 'TipoDados'
#

INSERT INTO `TipoDados` (`CODIGO`, `NOME`, `ID`) VALUES ('DBFNTX', 'Clipper DBF/DBT Indices NTX', 1);
INSERT INTO `TipoDados` (`CODIGO`, `NOME`, `ID`) VALUES ('DBFCDX', 'Foxpro DBF/FPT Indices CDX', 2);
INSERT INTO `TipoDados` (`CODIGO`, `NOME`, `ID`) VALUES ('MDB', 'Access MDB', 3);
INSERT INTO `TipoDados` (`CODIGO`, `NOME`, `ID`) VALUES ('MYSQL', 'MySql', 4);
INSERT INTO `TipoDados` (`CODIGO`, `NOME`, `ID`) VALUES ('SQL2K', 'MS Sql Server 2000', 5);
INSERT INTO `TipoDados` (`CODIGO`, `NOME`, `ID`) VALUES ('SQL97', 'MS SQL Server 97', 6);
INSERT INTO `TipoDados` (`CODIGO`, `NOME`, `ID`) VALUES ('PARADOX', 'Paradox', 7);
# 7 records

#
# Table structure for table 'TiposArq'
#

DROP TABLE IF EXISTS `TiposArq`;

CREATE TABLE `TiposArq` (
  `CODIGO` VARCHAR(8), 
  `NOME` VARCHAR(100), 
  `ID` INTEGER AUTO_INCREMENT, 
  INDEX (`CODIGO`), 
  INDEX (`ID`)
) ENGINE=innodb;

SET autocommit=1;

#
# Dumping data for table 'TiposArq'
#

INSERT INTO `TiposArq` (`CODIGO`, `NOME`, `ID`) VALUES ('INI', 'Configuraçao de Inicializacao', 1);
INSERT INTO `TiposArq` (`CODIGO`, `NOME`, `ID`) VALUES ('MDB', 'Base de Dados Access', 2);
INSERT INTO `TiposArq` (`CODIGO`, `NOME`, `ID`) VALUES ('DBF', 'Tabelas Base Dados DBASE/FOXPRO', 3);
INSERT INTO `TiposArq` (`CODIGO`, `NOME`, `ID`) VALUES ('RTF', 'Rith Text Formato (Textos)', 4);
INSERT INTO `TiposArq` (`CODIGO`, `NOME`, `ID`) VALUES ('TXT', 'Arquivos de Textos', 5);
INSERT INTO `TiposArq` (`CODIGO`, `NOME`, `ID`) VALUES ('CDX', 'Arquivos de Indices FOXPRO', 6);
INSERT INTO `TiposArq` (`CODIGO`, `NOME`, `ID`) VALUES ('NTX', 'Arquivos de Indices Clipper', 7);
INSERT INTO `TiposArq` (`CODIGO`, `NOME`, `ID`) VALUES ('MAN', 'Manuais Sistema Dos', 8);
# 8 records

#
# Table structure for table 'TiposCarac'
#

DROP TABLE IF EXISTS `TiposCarac`;

CREATE TABLE `TiposCarac` (
  `CODIGO` VARCHAR(20), 
  `NOME` VARCHAR(50), 
  `ID` INTEGER AUTO_INCREMENT, 
  INDEX (`CODIGO`), 
  INDEX (`ID`)
) ENGINE=innodb;

SET autocommit=1;

#
# Dumping data for table 'TiposCarac'
#

INSERT INTO `TiposCarac` (`CODIGO`, `NOME`, `ID`) VALUES ('UTIL', 'Utilitarios', 1);
INSERT INTO `TiposCarac` (`CODIGO`, `NOME`, `ID`) VALUES ('CAD', 'Cadastros', 2);
INSERT INTO `TiposCarac` (`CODIGO`, `NOME`, `ID`) VALUES ('TAB', 'Tabelas', 3);
INSERT INTO `TiposCarac` (`CODIGO`, `NOME`, `ID`) VALUES ('DOC', 'Documentaçao', 4);
INSERT INTO `TiposCarac` (`CODIGO`, `NOME`, `ID`) VALUES ('INT', 'Integraçao', 5);
INSERT INTO `TiposCarac` (`CODIGO`, `NOME`, `ID`) VALUES ('SIS', 'Sistema', 6);
INSERT INTO `TiposCarac` (`CODIGO`, `NOME`, `ID`) VALUES ('CON', 'Configuração', 7);
INSERT INTO `TiposCarac` (`CODIGO`, `NOME`, `ID`) VALUES ('SISDOC', 'Documentaçao do Sistema', 8);
INSERT INTO `TiposCarac` (`CODIGO`, `NOME`, `ID`) VALUES ('REL', 'Relatorios/Documentação', 9);
INSERT INTO `TiposCarac` (`CODIGO`, `NOME`, `ID`) VALUES ('IMP', 'Importaçao', 10);
# 10 records

