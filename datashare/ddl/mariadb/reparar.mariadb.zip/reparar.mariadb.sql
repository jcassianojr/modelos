#
# DUMP FILE
#
# Database is ported from MS Access
#------------------------------------------------------------------
# Created using "MS Access to MySQL" form http://www.bullzip.com
# Program Version 5.5.282
#
# OPTIONS:
#   sourcefilename=C:/temp/reparar.mdb
#   sourceusername=
#   sourcepassword=
#   sourcesystemdatabase=
#   destinationdatabase=reparar
#   storageengine=InnoDB
#   dropdatabase=0
#   createtables=1
#   unicode=0
#   autocommit=1
#   transferdefaultvalues=1
#   transferindexes=1
#   transferautonumbers=1
#   transferrecords=1
#   columnlist=1
#   tableprefix=
#   negativeboolean=0
#   ignorelargeblobs=0
#   memotype=LONGTEXT
#   datetimetype=DATETIME
#

CREATE DATABASE IF NOT EXISTS `reparar`;
USE `reparar`;

#
# Table structure for table 'REPARAR'
#

DROP TABLE IF EXISTS `REPARAR`;

CREATE TABLE `REPARAR` (
  `ARQUIVO` VARCHAR(50), 
  `CAMINHO` VARCHAR(250), 
  `DIZER` VARCHAR(150), 
  INDEX (`ARQUIVO`)
) ENGINE=innodb;

SET autocommit=1;

#
# Dumping data for table 'REPARAR'
#

INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('CONTROLE.MDB', 'F:\\ITAESBRA\\CONTROLE\\CONTROLE.MDB', 'Configuracao Modulo Controle');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('DESENHO.MDB', 'F:\\ITAESBRA\\CONTROLE\\DESENHO.MDB', 'Cadastros Engenharia Modulo Controle');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('PF.MDB', 'F:\\ITAESBRA\\CONTROLE\\PF.MDB', 'PF/PC/PPAP/FEMEA');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('PFP.MDB', 'F:\\ITAESBRA\\CONTROLE\\PFP.MDB', 'PC Preliminar');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('POA.MDB', 'F:\\ITAESBRA\\CONTROLE\\POA.MDB', 'Programa Olhos Abertos');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('USULOG.MDB', 'F:\\ITAESBRA\\LOG\\USULOG.MDB', 'Arquivo de Log Inicial');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('DIC.MDB', 'F:\\ITAESBRA\\DICION\\DIC.MDB', 'Dicionarios');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('IMAGEM.MDB', 'F:\\ITAESBRA\\PECAS\\IMAGEM.MDB', 'Fotos Peças');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('IMGFER.MDB', 'F:\\ITAESBRA\\PECAS\\IMGFER.MDB', 'Fotos Ferramentas');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('IMGME04.MDB', 'F:\\ITAESBRA\\PECAS\\IMGME04.MDB', 'Fotos Equipamentos');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('IMGME06.MDB', 'F:\\ITAESBRA\\PECAS\\IMGME06.MDB', 'Fotos Utilitarios');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('IMGMP04.MDB', 'F:\\ITAESBRA\\PECAS\\IMGMP04.MDB', 'Fotos Funcionarios Matriz');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('IMGMP042.MDB', 'F:\\ITAESBRA\\PECAS\\IMGMP042.MDB', 'Fotos Funcionarios Filial');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('IMGMR01.MDB', 'F:\\ITAESBRA\\PECAS\\IMGMR01.MDB', 'Fotos Embalagens');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('IMGMT01.MDB', 'F:\\ITAESBRA\\PECAS\\IMGMT01.MDB', 'Fotos Componentes');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('IMGMU01.MDB', 'F:\\ITAESBRA\\PECAS\\IMGMU01.MDB', 'Fotos Materia Prima');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('IMGMW05.MDB', 'F:\\ITAESBRA\\PECAS\\IMGMW05.MDB', 'Fotos Consumiveis');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('MA01LOGO.MDB', 'F:\\ITAESBRA\\PECAS\\MA01LOGO.MDB', 'Fotos Cadastro Cliente');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('RTF.MDB', 'F:\\ITAESBRA\\WDOC\\RTF.MDB', 'Configuracao de Documentos WRPT (WDOC)');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('RPT.MDB', 'F:\\ITAESBRA\\WRPT\\RPT.MDB', 'Relaçao de Relatorios WRPT');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('VORET.MDB', 'F:\\ITAESBRA\\WRPT\\VORET.MDB', 'Configuraçao Relatorios VORET-2');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('WRPT.MDB', 'F:\\ITAESBRA\\WRPT\\WRPT.MDB', 'Configuracao WRPT');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('USULOG.MDB', 'F:\\ITAESBRA\\WRPT\\USULOG.MDB', 'Wrpt Log de Uso');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('IMGMQ01.MDB', 'F:\\ITAESBRA\\PECAS\\IMGMQ01.MDB', 'Fotos Sub Produtos');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('LOGCONTROLE', 'F:\\ITAESBRA\\LOG\\CONTROLE\\LOG[MM][AAAA]..MDB', 'Log Controle Mensal');
INSERT INTO `REPARAR` (`ARQUIVO`, `CAMINHO`, `DIZER`) VALUES ('FEMEA.MDB', 'F:\\ITAESBRA\\CONTROLE\\FEMEA.MDB', 'Femeas');
# 26 records

