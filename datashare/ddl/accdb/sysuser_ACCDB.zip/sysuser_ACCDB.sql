-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: DESTINO (ACCDB)
-- Gerado em: 17/05/2026 09:29:30
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: USUARIO
-- --------------------------------------------------
CREATE TABLE [USUARIO] ([USUARIO] TEXT(10), [SENHA] TEXT(8), [DATAVAL] DATETIME, [DATAULT] DATETIME, [EQUIVALENTE] TEXT(10), [ATIVO] BIT, [HORAINI] DATETIME, [HORAFIM] DATETIME, [WEEKEND] BIT, [IDFOLHA] DOUBLE, [NOMEFOLHA] TEXT(50), [TROCAR] DATETIME, [IDUSUARIO] LONG, [id] LONG, [postelaa] TEXT(30), [postelaB] TEXT(30), [CHAVEH] TEXT(64), [CHAVEV] TEXT(64));
CREATE INDEX [IDFOLHA] ON [USUARIO] ([IDFOLHA]);
CREATE INDEX [IDUSUARIO] ON [USUARIO] ([IDUSUARIO]);
CREATE INDEX [USUARIO] ON [USUARIO] ([USUARIO]);

-- --------------------------------------------------
-- Estrutura da Tabela: USUBTN
-- --------------------------------------------------
CREATE TABLE [USUBTN] ([IDUSUARIO] LONG, [FORM] LONG, [INDICE] SHORT, [USUARIO] TEXT(10), [id] LONG);
CREATE INDEX [CHAVE] ON [USUBTN] ([FORM], [IDUSUARIO], [INDICE]);

-- --------------------------------------------------
-- Estrutura da Tabela: USUFORM
-- --------------------------------------------------
CREATE TABLE [USUFORM] ([IDUSUARIO] LONG, [FORM] LONG, [USUARIO] TEXT(10), [id] LONG);

-- --------------------------------------------------
-- Estrutura da Tabela: USURPT
-- --------------------------------------------------
CREATE TABLE [USURPT] ([IDUSUARIO] LONG, [RPT] TEXT(8), [IMPRIME] BIT, [EXPORTA] BIT, [VISUALIZA] BIT, [SALVARTF] BIT, [SALVATXT] BIT, [NOVO] BIT, [ABRIR] BIT, [EDITAR] BIT, [CODIGO] TEXT(8), [ABRIRCOM] TEXT(50), [GRP] TEXT(8), [USUARIO] TEXT(10), [id] LONG);

-- Fim do Script de DESTINO (ACCDB)
