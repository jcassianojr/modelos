-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: DESTINO (ACCDB)
-- Gerado em: 17/05/2026 09:29:27
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: tblAutor
-- --------------------------------------------------
CREATE TABLE [tblAutor] ([codAutor] LONG, [Nome] TEXT(80), [Obs] TEXT(80), [codOcupacao] LONG, [Nacionalidade] TEXT(20));
ALTER TABLE [tblAutor] ADD CONSTRAINT [PrimaryKey] PRIMARY KEY ([codAutor]);

-- --------------------------------------------------
-- Estrutura da Tabela: tblCitacao
-- --------------------------------------------------
CREATE TABLE [tblCitacao] ([codCitacao] LONG, [Titulo] TEXT(50), [Fonte] TEXT(120), [codAutor] LONG, [Citacao] MEMO, [ocultar] BIT);
ALTER TABLE [tblCitacao] ADD CONSTRAINT [PrimaryKey] PRIMARY KEY ([codCitacao]);

-- --------------------------------------------------
-- Estrutura da Tabela: tblOcupacao
-- --------------------------------------------------
CREATE TABLE [tblOcupacao] ([codOcupacao] LONG, [Nome] TEXT(50));
ALTER TABLE [tblOcupacao] ADD CONSTRAINT [PrimaryKey] PRIMARY KEY ([codOcupacao]);

-- Fim do Script de DESTINO (ACCDB)
