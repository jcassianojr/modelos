-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: DESTINO (ACCDB)
-- Gerado em: 17/05/2026 09:29:32
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: CONDPAGTO
-- --------------------------------------------------
CREATE TABLE [CONDPAGTO] ([ID] LONG, [CODIGO] TEXT(20), [NOME] TEXT(50), [IPI] TEXT(1), [DESPFINANC] TEXT(1), [CODIGODESPFINANC] TEXT(15), [PARCELAS] LONG, [QTDEDIAS] LONG, [DIA1] SHORT, [DIA2] SHORT, [DIA3] SHORT, [DIA4] SHORT, [DIA5] SHORT, [DIA6] SHORT, [DIA7] SHORT, [DIA8] SHORT, [DIA9] SHORT, [DIA10] SHORT, [POR1] SHORT, [POR2] SHORT, [POR3] SHORT, [POR4] SHORT, [POR5] SHORT, [POR6] SHORT, [POR7] SHORT, [POR8] SHORT, [POR9] SHORT, [POR10] SHORT, [DADATA] TEXT(1), [CAI1] SHORT, [CAI2] SHORT, [CAI3] SHORT, [CAI4] SHORT, [SEMANA] TEXT(2), [PADRAO] TEXT(1));
ALTER TABLE [CONDPAGTO] ADD CONSTRAINT [PrimaryKey] PRIMARY KEY ([ID]);

-- --------------------------------------------------
-- Estrutura da Tabela: RAMO
-- --------------------------------------------------
CREATE TABLE [RAMO] ([ID] LONG, [CODIGO] TEXT(10), [NOME] TEXT(50), [PADRAO] TEXT(1), [CONTATOS] LONG);
ALTER TABLE [RAMO] ADD CONSTRAINT [PrimaryKey] PRIMARY KEY ([ID]);
CREATE INDEX [RAMORAMO] ON [RAMO] ([CODIGO]);

-- --------------------------------------------------
-- Estrutura da Tabela: ZONAS
-- --------------------------------------------------
CREATE TABLE [ZONAS] ([ID] LONG, [CODIGO] TEXT(20), [NOME] TEXT(30), [QTDE] LONG);
CREATE INDEX [ID] ON [ZONAS] ([ID]);
ALTER TABLE [ZONAS] ADD CONSTRAINT [PrimaryKey] PRIMARY KEY ([ID]);

-- Fim do Script de DESTINO (ACCDB)
