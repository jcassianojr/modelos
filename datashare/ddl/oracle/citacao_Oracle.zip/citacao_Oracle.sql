--------------------------------------------
--------------- Dump details ---------------
--------------------------------------------
-- Original file: C:\cnvoracle\datashare\citacao.mdb
-- Dump date: 12-18-2024 10:12:13
--------------------------------------------

-- creating sequence for autonumber column
CREATE SEQUENCE SEQ_TBLAUTOR INCREMENT BY 1 START WITH 1 MINVALUE 1 NOMAXVALUE NOCACHE;

-- creating table
CREATE TABLE TBLAUTOR (
	CODAUTOR NUMBER (10) NOT NULL,
	NOME VARCHAR2 (80),
	OBS VARCHAR2 (80),
	CODOCUPACAO NUMBER (10) DEFAULT 0,
	NACIONALIDADE VARCHAR2 (20)
);

-- adding primary key
ALTER TABLE TBLAUTOR
  ADD CONSTRAINT PK_TBLAUTOR PRIMARY KEY (CODAUTOR);



-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (1, 'Jonathan Freedman', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (2, 'Cal Thomas', NULL, 8, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (3, 'Henry Thoreau', 'S�culo XIX', 2, 'americano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (4, 'Alexander Rose', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (5, 'Ralph Waldo Emerson', 'S�culo XIX', 10, 'norte-americano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (6, 'Lance Morrow', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (7, 'Voltaire', NULL, 1, 'franc�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (8, 'Jim Trelease', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (9, 'Jonathan Swift', NULL, 1, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (10, 'Henry Van Dyke', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (11, 'Manfred Barthel', NULL, 11, 'alem�o');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (12, 'Engenhe Kennedy', NULL, 12, 'norte-americano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (13, 'U. S. News & World Report', NULL, 13, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (14, 'A. L. McGinnis', NULL, 11, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (15, 'Abra�o Lincoln', '16.� presidente dos Estados Unidos', 9, 'norte-americano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (16, 'Will Durant', NULL, 14, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (17, 'Sir Isaac Newton', NULL, 7, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (18, 'Ivo Duchacek', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (19, 'Michael Argyle', NULL, 1, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (20, 'Ronald Kotulak', NULL, 15, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (21, 'John Lyly', NULL, 1, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (22, 'Fedro', 'viveu h� 2 mil anos', 2, 'romano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (23, 'Norman Moss', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (24, 'Dem�stenes', 'viveu h� 2.400 anos', 16, 'grego');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (25, 'Samuel Johnson', 'S�culo XVIII', 2, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (26, 'George Leonard', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (27, 'Charles Dickens', 'S�culo XIX', 1, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (28, 'Aesop', NULL, 1, 'grego');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (29, 'James Baldwin', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (30, 'Les Donaldson', NULL, 2, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (31, 'G. K. Chesterton', NULL, 1, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (32, 'Dale Carnegie', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (33, 'Milo O. Frank', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (34, 'Glenn Doman', 'diretor dos Institutos para a Consecu��o do Potencial Humano', 11, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (35, 'Masaru Ibuka', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (36, 'Lorde Chesterfield', 'S�culo XVIII', 1, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (37, 'The Art of Book Reading (A Arte da Leitura de Livros)', NULL, 17, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (38, 'Thomas Carlyle', 'S�culo XIX', 14, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (39, 'Ren� Descartes', 'S�culo XVII', 3, 'franc�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (40, 'Patrick Henry', NULL, 9, 'americano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (42, 'The Encyclopoedia Britannica', NULL, 0, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (43, 'Cervantes', NULL, 1, 'espanhol');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (44, 'James J. Lynch', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (45, 'Walter C. Alvarez', NULL, 11, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (46, 'Walter Modell', 'de Farmacologia', 18, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (47, 'Randolph S. Bourne', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (48, 'Jean Guitton', NULL, 3, 'franc�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (49, 'Awake!', NULL, 13, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (50, 'Israel Zangwill', NULL, 1, 'judeu');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (51, 'Aldous Huxley', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (52, 'Erich Fromm', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (53, 'F. Alexander Magoun', NULL, 19, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (54, 'John T. Molloy', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (55, 'Joseph Addison', NULL, 10, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (56, 'George Byron', NULL, 10, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (57, 'Henry Austin Dobson', 'S�culo XIX', 10, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (58, 'Johann Wolfgang von Goethe', NULL, 10, 'alem�o');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (59, 'John Milton', NULL, 10, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (60, 'Joyce Kilmer', NULL, 10, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (62, 'Alfred Tennyson', 'S�culo XIX', 10, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (63, 'William Shakespeare', NULL, 20, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (64, 'Juvenal', NULL, 10, 'romano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (65, 'Poeta do s�culo 19', 'S�culo XIX', 10, 'alem�o');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (66, 'Robert Burns', 'S�culo XIX', 10, 'escoc�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (67, 'Hor�cio', NULL, 10, 'romano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (68, 'John Keats', NULL, 10, 'brit�nico');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (69, 'Prov�rbio', NULL, 0, 'espanhol');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (70, 'Henry Wadsworth Longfellow', 'S�culo XIX', 10, 'estadunidense');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (71, 'Ibsen', NULL, 10, 'noruegu�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (72, 'William Cowper', 'S�culo XVIII', 10, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (73, 'Alexander Pope', NULL, 10, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (74, 'Te�crito', NULL, 10, 'grego');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (75, 'Rei Salom�o', NULL, 10, 'judeu');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (76, 'Howard McCordin', NULL, 10, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (77, 'Um poeta do s�culo 19', 'S�culo XIX', 10, 'franc�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (78, 'Langston Hughes', NULL, 10, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (79, 'John Donne', 'S�culo XVII', 10, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (80, 'John Dryden', 'S�culo XVII', 10, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (81, 'Baudelaire', NULL, 10, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (82, 'William Ernest Henley', NULL, 10, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (83, 'Philip James Bailey', NULL, 10, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (84, 'Jorge Luis Borges', NULL, 10, 'argentino');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (85, 'Edward Young', 'S�culo XVIII', 10, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (86, 'Thomas A. Edison', NULL, 21, 'americano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (87, 'Insight On The Scriptures', NULL, 22, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (88, 'Ernesto Che Guevara', NULL, 23, 'Argentino');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (89, 'Rabindranath Tagore', 'Pr�mio Nobel de literatura em 1913', 10, 'Indiano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (90, 'Martin Luther King', NULL, 24, 'norte-americano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (91, 'Leon Joseph Suenens', NULL, 25, 'belga');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (92, 'Vitor Hugo', NULL, 2, 'franc�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (93, 'S�crates', NULL, 3, 'grego');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (94, 'Carlos Drummond de Andrade', NULL, 10, 'brasileiro');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (95, 'Mahatma Gandhi', NULL, 25, 'Indiano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (96, 'George Bernard Shaw', NULL, 20, 'irland�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (97, 'Ludwig van Beethoven', NULL, 26, 'alem�o');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (98, 'Erasmo de Rotterd�', NULL, 3, 'holand�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (99, 'Franz Kafka', NULL, 2, 'tcheco');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (100, 'Pit�goras', NULL, 3, 'grego');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (101, 'Samuel Smiles', NULL, 2, 'escoc�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (102, 'Benjamim Franklin', NULL, 9, 'norte-americano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (103, 'Jean de Rond D''Alembert', 'S�culo XVIII', 3, 'franc�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (104, 'Fran�ois Rabelais', 'S�culo XV', 1, 'franc�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (105, 'Fran�ois de la Rochefoucauld', NULL, 27, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (106, 'Karen Horney', 'contempor�nea de Freud', 28, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (107, 'Massimo Bontempelli', NULL, 2, 'italiano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (108, 'Pl�nio', NULL, 14, 'romano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (109, 'Josh Billings', NULL, 1, 'norte-americano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (110, 'Paul Val�ry
Paul Val�ry', NULL, 10, 'franc�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (111, 'Whillein Bousset', NULL, 10, 'franc�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (112, 'Mic�taus do ISS�S', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (113, 'The WatchTower', NULL, 13, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (114, 'Paulo', 'Primeiro S�culo da Era Comum', 29, 'judeu');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (115, NULL, NULL, 0, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (116, 'Frank Trippett', NULL, 2, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (117, 'Antoine de Saint-Exupery', 'Escritor de O Pequeno Pr�ncipe', 2, 'Franc�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (118, 'Arist�toles', NULL, 3, 'Grego');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (119, 'Douglas MacArthur', NULL, 30, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (120, 'Ernest Hemingway', NULL, 1, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (121, 'Karl Marx', NULL, 3, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (122, 'Sigmund Freud', NULL, 28, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (123, 'Prov�rbio', NULL, 0, 'franc�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (124, 'Prov�rbio', NULL, 0, 'judaico');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (125, 'Albert Einstein', NULL, 7, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (126, 'Talmud', NULL, 0, 'judaico');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (127, 'William Blake', NULL, 10, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (128, 'Menachem Mendel Schneerson', NULL, 31, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (129, 'Thomas Jefferson', NULL, 9, 'americano');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (130, 'John F. Kennedy', NULL, 9, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (131, 'Andrew Carnegie', 'S�culo XIX', 32, 'escoc�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (132, 'Winston Churchill', NULL, 9, 'ingl�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (133, 'Louis Pasteur', NULL, 7, 'franc�s');

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (134, 'Jean Paul Getty', 'petr�leo', 33, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (135, 'The New York Times', NULL, 34, NULL);

-- inserting data
INSERT INTO TBLAUTOR (CODAUTOR, NOME, OBS, CODOCUPACAO, NACIONALIDADE)
VALUES (136, 'An�nimo', NULL, 0, NULL);
-- creating sequence for autonumber column
CREATE SEQUENCE SEQ_TBLCITACAO INCREMENT BY 1 START WITH 1 MINVALUE 1 NOMAXVALUE NOCACHE;

-- creating table
CREATE TABLE TBLCITACAO (
	CODCITACAO NUMBER (10) NOT NULL,
	TITULO VARCHAR2 (50),
	FONTE VARCHAR2 (120),
	CODAUTOR NUMBER (10) DEFAULT 0,
	CITACAO CLOB,
	OCULTAR NUMBER (1) NOT NULL
);

-- adding primary key
ALTER TABLE TBLCITACAO
  ADD CONSTRAINT PK_TBLCITACAO PRIMARY KEY (CODCITACAO);



-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1, NULL, 'Happy People (Gente Feliz)', 1, 'Uma vez que se consegue uma renda m�nima, a quantia de dinheiro que voc� possui pouco importa em termos de dar felicidade. Acima do n�vel da pobreza, a rela��o entre a renda e a felicidade � notavelmente pequena.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (2, NULL, 'w01 15/10 p. 4 Poder� tornar o mundo um lugar melhor?', 2, 'A verdadeira mudan�a vem de conquistar cora��es, n�o de vencer elei��es, porque os nossos problemas principais n�o s�o econ�micos e pol�ticos, mas morais e espirituais.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (3, NULL, 'w00 1/7 p. 3 Voc� pode encontrar paz interior?', 3, 'A maioria dos homens vive em silencioso desespero.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (4, NULL, 'w00 1/9 p. 3 Sabe esperar?', 4, 'Metade da agonia de viver � ter de esperar.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (5, NULL, 'w00 1/9 p. 3 Sabe esperar?', 5, 'Quanto da vida humana � perdido na espera!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (6, NULL, 'w00 1/9 pp. 3-4 Sabe esperar?', 6, 'A afli��o mais sutil da espera � saber que o recurso mais precioso que se tem, o tempo, uma fra��o da nossa vida, est� sendo furtado, irrevogavelmente perdido.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (7, NULL, 'w00 15/9 p. 4 Pedido de socorro', 7, 'O homem que, numa crise de melancolia, se mata hoje, teria desejado viver se tivesse esperado uma semana.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (8, NULL, 'w96 15/7 p. 31 Eduque-os desde a inf�ncia', 8, 'A leitura � a mais poderosa habilidade na vida que temos hoje na nossa sociedade humana.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (9, NULL, 'w95 15/6 p. 4 O �dio ter� fim algum dia?', 9, 'Temos bastante religi�o para fazer-nos odiar uns aos outros, mas n�o o bastante para que nos amemos uns aos outros.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (10, NULL, 'w92 15/7 p. 3 � a B�blia contradit�ria?', 10, 'Nascida no Oriente e vestida de formas e de imagens orientais, a B�blia percorre as estradas do mundo inteiro, familiarizada com os caminhos por onde vai; penetra nos pa�ses, um ap�s outro, para em toda parte sentir-se bem, como em seu pr�prio ambiente. Aprendeu a falar ao cora��o do homem em centenas de l�nguas. As crian�as ouvem suas hist�rias com admira��o e prazer, e os s�bios ponderam-nas como par�bolas de vida. Os maus e os soberbos estremecem com os seus avisos, mas aos ouvidos dos que sofrem e dos penitentes sua voz tem timbre maternal. . . . Tendo como seu esse tesouro, ningu�m � pobre nem desolado.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (11, NULL, 'Was wirklich in der Bibel steht (O Que a B�blia Realmente Diz)', 11, 'Se desejarmos imaginar os anjos do Senhor como os autores do Velho Testamento os viram, primeiro teremos de esquecer os querubins com covinhas no rosto . . . que decoram os nossos cart�es de felicita��es.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (12, NULL, 'O Livro do C�rebro', 0, 'Dentro de nossa pr�pria cabe�a jaz um dos mais complexos sistemas do universo conhecido. Seu potencial e sua versatilidade ultrapassam em muito os de qualquer computador de fabrica��o humana. Diz-se freq�entemente que usamos apenas 10 por cento de nosso pleno potencial mental. Isto, conforme parece agora, � uma superestima��o. Provavelmente n�o usamos nem mesmo 1 por cento - mais provavelmente 0,1 por cento, ou menos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (13, NULL, 'w84 15/3 p. 27 Por Dentro das Not�cias', 12, 'O maior mito a respeito da amizade � que as pessoas a ter�o sem fazer nada em troca dela.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (14, NULL, 'w84 15/3 p. 27 Por Dentro das Not�cias', 13, 'As pessoas t�m dificuldade em saber como fazer amigos, porque a nossa sociedade lhes diz que a auto-satisfa��o as tornar� bem-sucedidas e felizes.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (15, NULL, 'O Fator da Amizade (em ingl�s)', 14, 'Uma das melhores maneiras de aprofundar uma amizade � as pessoas comerem juntas. Partir o p�o com outro envolve algo quase que sacramental. Por exemplo, j� notou qu�o dif�cil � jantar com um inimigo e continuar inimigo dele?', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (16, NULL, 'w81 1/11 p. 3 Pode este livro ajud�-lo a ser bem-sucedido?', 15, 'Creio que a B�blia � a melhor d�diva que Deus j� deu ao homem.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (17, NULL, 'w79 1/2 p. 29 Por Dentro das Not�cias', 16, 'Amai-vos uns aos outros. Minha derradeira li��o da hist�ria � a mesma que a de Jesus, que o amor � a coisa mais pr�tica no mundo.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (18, NULL, 'w77 15/10 p. 628 Isaac Newton em busca de Deus', 17, 'N�o sei o que pare�o ser para o mundo, mas, para mim mesmo, s� pare�o ter sido um menino brincando � beira do mar, e divertindo-me de vez em quando com achar uma pedra mais lisa ou uma concha mais bonita do que costuma ser, ao passo que o grande oceano da verdade jazia diante de mim ainda todo por descobrir.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (19, NULL, 'Conflito e Coopera��o Entre Na��es', 18, 'O nacionalismo divide a humanidade em unidades mutuamente intolerantes. Como resultado, as pessoas pensam como estadunidenses, russos, chineses, eg�pcios ou peruanos, em primeiro lugar, e como seres humanos, em segundo - se � que pensam nisso.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (20, NULL, 'Sunday Times, de Londres', 19, 'Os que mais d�o valor ao dinheiro s�o os menos satisfeitos e com as piores condi��es de sa�de mental. Talvez isso aconte�a porque o dinheiro s� d� satisfa��o superficial.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (21, NULL, 'g99 22/7 p. 13 Pode-se esperar viver para sempre?', 20, 'Os cientistas h� muito sabem que a renda, a ocupa��o e a educa��o s�o os mais importantes prognosticadores da sa�de da pessoa e de quanto tempo ela viver�. . . . Mas � a educa��o que emerge como o mais importante prognosticador da longevidade.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (22, NULL, 'g99 22/7 p. 13 Pode-se esperar viver para sempre?', 20, 'Assim como os alimentos d�o ao nosso sistema imunol�gico a for�a para combater os micr�bios que amea�am a vida, a educa��o nos protege contra m�s escolhas.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (23, NULL, 'g97 22/3 p. 10 A busca de solu��es', 21, 'AO DISCUTIR os efeitos de um problema, � f�cil esquecer-se das suas causas.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (24, NULL, 'g96 8/2 p. 4 Confiar ou n�o confiar?', 22, 'Tanto confiar como n�o confiar � perigoso.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (25, NULL, 'The Pleasures of Deception', 23, '�s vezes, aceitamos algo como verdade porque queremos que tal coisa seja verdade.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (26, NULL, 'g96 8/2 p. 6 Confiar ou n�o confiar?', 24, 'A coisa mais f�cil de todas � enganar a si mesmo, pois o que o homem deseja ele geralmente cr� ser verdade.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (27, NULL, 'g96 8/2 p. 6 Confiar ou n�o confiar?', 25, '� prefer�vel ser enganado, �s vezes, do que n�o confiar em ningu�m.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (28, NULL, 'g95 22/10 p. 8 Projetados para uma vida eterna', 26, 'A derradeira capacidade criativa do c�rebro pode ser, para todos os efeitos, infinita.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (29, NULL, 'g92 8/3 Parte 5: O alto com�rcio exerce mais press�o', 28, 'A ostenta��o � um pobre substituto da riqueza interior.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (30, NULL, 'g91 22/9 p. 8 Amor � primeira vista - e para sempre depois disso!', 29, 'Os filhos nunca foram muito bons em dar ouvidos aos mais velhos, mas eles jamais deixaram de imit�-los.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (31, NULL, 'Conversational Magic (M�gica Para a Conversa��o)', 30, 'Se procurar nas pessoas as coisas dignas de elogios, voc� as encontrar� em abund�ncia.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (32, NULL, 'g88 22/6 p. 27 Permanecer saud�vel - o enfoque naturalista', 31, 'A dificuldade de sempre tentar preservar a sa�de do corpo � que � muito dif�cil fazer isso sem destruir a sa�de da mente.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (33, NULL, 'g88 22/8 p. 12 Por que as pessoas n�o gostam de mim?', 32, 'Voc� pode fazer mais amigos em dois meses, interessando-se pelas outras pessoas, do que em dois anos, tentando conseguir o interesse dos outros sobre voc�.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (34, NULL, 'g88 22/11 Como posso fazer que as pessoas gostem de mim?', 33, 'A longo prazo, n�o importa realmente qu�o caras sejam suas roupas, ou qu�o antiquadas ou da moda atual, contanto que d� a impress�o de que voc� se importa. Quando se importa o suficiente para apresentar-se da melhor forma poss�vel, ent�o as pessoas se importar�o com voc�.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (35, NULL, 'g87 22/5 p. 5 O empenho de criar g�nios', 34, 'O mundo poderia estar repleto de gigantes intelectuais, como Einstein, Shakespeare, Beethoven e Leonardo da Vinci, se ensin�ssemos aos beb�s, em vez de �s crian�as.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (36, NULL, 'Kindergarten Is Too Late! (O Jardim de Inf�ncia j� � Tarde Demais!)', 35, 'Nenhuma crian�a nasce um g�nio, e nenhuma nasce um tolo. Tudo depende do est�mulo das c�lulas cerebrais durante os anos cruciais. Estes anos s�o os anos que decorrem do nascimento aos tr�s anos. O jardim de inf�ncia j� � tarde demais.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (37, NULL, 'g85 22/4 p. 26 Dar� not�cias suas?', 36, 'As cartas devem ser simples e naturais, e transmitir �s pessoas a quem as enviamos exatamente o que dir�amos a tais pessoas se estiv�ssemos com elas.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (38, NULL, 'g85 8/7 p. 23 Poder� tornar-se um melhor leitor!', 37, 'O meio mais seguro de lembrar-se do que l� � ler de forma estrutural, sentindo o desenrolar ordeiro dos pensamentos do escritor.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (39, NULL, 'g84 22/4 p. 21 Como devo agir para reter meu emprego?', 38, 'Aquele que encontrou seu trabalho � aben�oado; n�o deve almejar nenhuma outra b�n��o.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (40, NULL, 'g84 22/6 p. 17 Que diferen�a faz o que eu leio?', 39, 'Quando a pessoa l� bons livros � como se palestrasse com homens de gabarito que viveram no passado. Poder�amos at� mesmo chamar isto de palestra seletiva, na qual o autor s� expressa seus pensamentos mais nobres.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (41, NULL, 'g84 22/9 Por que devo ler a B�blia?', 40, 'A B�blia vale o mesmo que todos os outros livros que j� foram impressos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (42, NULL, 'g84 22/9 Por que devo ler a B�blia?', 58, 'Estou convicto de que a B�blia se torna cada vez mais linda � medida que a pessoa a compreende mais. Que a cultura e a ci�ncia continuem progredindo, e a mente avance como possa, mas jamais ir� al�m da eleva��o e da cultura moral do Cristianismo, � medida que reluz e brilha nos Evangelhos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (43, NULL, 'g84 22/9 Por que devo ler a B�blia?', 17, 'Verifico haver mais sinais seguros de autenticidade na B�blia do que em qualquer hist�ria profana que seja.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (44, NULL, 'g84 22/9 Por que devo ler a B�blia?', 42, 'A B�blia. . . provavelmente � a cole��o mais influente de livros da hist�ria humana. Seja o que for que se pense sobre o conte�do da B�blia, seu papel no desenvolvimento da cultura ocidental e na evolu��o de muitas culturas orientais faz com que pelo menos alguma familiaridade com sua literatura e sua hist�ria seja um marco indispens�vel do homem instru�do.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (45, NULL, 'g84 22/9 Por que devo ler a B�blia?', 27, '� o melhor livro (A B�blia) que j� existiu ou existir� no mundo porque lhe ensina as melhores li��es pelas quais qualquer criatura humana que tentasse ser ver�dica e fiel poder� ser guiada.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (46, NULL, 'g80 8/4 p. 7 O conselho s�bio protege contra o crime', 43, 'Os prov�rbios s�o senten�as pequenas advindas de longa experi�ncia.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (47, NULL, 'The Broken Heart - The Medical Consequences of Loneliness (O Cora��o Partido - Conseq��ncias M�dicas da Solid�o)', 44, 'O companheirismo humano � bem literalmente uma importante forma de seguro de vida.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (48, NULL, 'g76 22/3 pp. 14-15 Como tornar recompensadora a aposentadoria', 45, 'Talvez andar uma milha [1.600 metros] por dia ajudaria [a um homem] mais do que ficar faminto. . . . a pior coisa que uma pessoa que j� passou da meia-idade pode fazer � n�o exercitar-se o bastante. Talvez nosso inimigo n�o seja tanto a glutonaria como a indol�ncia.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (49, NULL, 'Venenos Que Salvam Vidas', 46, 'Todos os rem�dios s�o venenos, e todos os venenos s�o rem�dios. N�o � por acaso que as palavras ''veneno'' e ''po��o'' [em ingl�s, poison e potion] venham do mesmo radical, ou que a palavra grega pharmakon, cujo radical encontramos em nossas palavras ''farmacia'' e ''farmacologia'', originalmente significassem tanto uma bebida curativa como uma mort�fera.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (50, NULL, 'g75 8/9 p. 13 Tem dificuldades em dormir?', 43, 'O sono � carne para os famintos, bebida para os sedentos, calor para os que sentem frio, e frio para os quentes.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (51, NULL, 'g75 22/9 p. 7 A arte da conversa��o', 47, 'A boa palestra � como o bom cen�rio - cont�nua, por�m constantemente variada, e cheia do encanto da novidade e da surpresa.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (52, NULL, 'g74 8/3 p. 7 Problemas que confrontam os que ainda freq�entam a igreja', 48, 'Devemos estar totalmente dispostos a abandonar nossa religi�o se resultar ser qualquer coisa que n�o a verdade.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (53, NULL, 'Ruborizar-se - exclusividade humana', 49, 'O rubor serve como guardi�o da consci�ncia, que diz ao homem que ele n�o deve enganar os outros. Quando viola o que sabe ou pensa ser certo, ele fica ruborizado; isso lhe far� sentir vergonha.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (54, NULL, 'g74 8/11 p. 26 Ruborizar-se - exclusividade humana', 49, 'Ruborizar-se � uma de suas d�divas ao homem a fim de ajud�-lo a acatar a voz de sua consci�ncia, para sua pr�pria felicidade e bem-estar.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (55, NULL, 'g73 22/6 p. 4 A alegria de ser altru�sta', 50, 'O ego�smo � o �nico ate�smo real; a aspira��o, o altru�smo, a �nica religi�o real.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (56, NULL, 'g71 22/6 p. 28 ''N�o deves desejar egoisticamente as posses de outrem''', 51, 'A cobi�a, que era pecado mortal nos dias de nossos ancestrais medievais, � agora uma das virtudes cardinais (prim�rias).', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (57, NULL, 'g71 8/8 p. 4 Ser� que seu emprego � o seu dono?', 52, 'O que est�o vivas s�o as organiza��es, as m�quinas;  . . . o homem se tornou seu escravo, ao inv�s de ser seu amo.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (58, NULL, 'g70 8/2 p. 4 Altru�smo - chave para o casamento bem sucedido', 53, 'Todos os �xitos t�m seu pre�o. Quanto mais digna a consecu��o, tanto mais, usualmente, a pessoa tem de pagar por ela no sentido de esfor�o.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (59, NULL, 'g70 8/2 p. 5 Altru�smo - chave para o casamento bem sucedido', 53, 'A id�ia de que � poss�vel obter-se cada vez mais para si mesmo simplesmente por tir�-lo de outrem tem sido uma forma de estupidez psicol�gica e de doen�a emocional da ra�a humana desde os dias de Caim e Abel.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (60, NULL, 'Dress for Success (Vestir-se Para Ter �xito)', 54, 'Nossa maneira de vestir exerce not�vel impacto sobre as pessoas com quem entramos em contato, e influi grandemente no modo como nos tratam.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (61, NULL, 'sl p. 381 An�ncios', 49, 'A melhor maneira de avaliar um livro � l�-lo, e a melhor maneira de chegar a conhecer um autor � familiarizar-se com as suas obras.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (62, NULL, 'w00 15/3 p. 22 A mod�stia � uma qualidade que promove a paz', 55, 'Nada � mais agrad�vel do que a verdadeira mod�stia.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (63, NULL, 'w00 1/12 p. 21 Como fazer amigos', 56, 'Todos os que teriam alegria tamb�m t�m de compartilh�-la.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (64, NULL, 'w99 1/10 p. 3 Por que temos t�o pouco tempo?', 57, 'O tempo passa, voc� diz? N�o � assim! Ora, o tempo fica, n�s � que passamos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (65, NULL, 'w98 1/4 p. 8 A fam�lia, uma necessidade humana', 58, 'Mais feliz, rei ou campon�s, � quem encontra felicidade no lar.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (66, NULL, 'w95 15/6 p. 11 A paci�ncia: por que � t�o rara?', 59, 'Tamb�m est�o servindo os que apenas perseveram e esperam.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (67, NULL, 'w93 15/11 p. 32 Qual �rvore *', 60, 'POEMAS s�o feitos por tolos como eu, mas s� Deus pode fazer uma �rvore.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (68, NULL, 'w93 15/12 p. 28 Mantenhamos o olho "singelo" fixado na obra do Reino', 58, 'Ningu�m � mais escravo do que aquele que se julga livre sem s�-lo.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (69, NULL, 'w91 15/10 p. 4 Acidentes - destino ou circunst�ncias?', 5, 'O elemento tr�gico mais amargo da vida � a cren�a numa Sina ou Destino brutal.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (70, NULL, 'w90 15/1 p. 3 As ora��es de quem s�o respondidas?', 62, 'Mediante a ora��o se conseguem mais coisas do que este mundo imagina.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (71, NULL, 'w89 15/10 p. 10 Guarde-se contra a tagarelice prejudicial!', 63, 'Quem furta de mim o meu bom nome rouba-me aquilo que n�o o enriquece, mas que deveras me empobrece.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (72, NULL, 'w89 15/10 p. 10 Guarde-se contra a tagarelice prejudicial!', 64, 'A cal�nia � o pior de todos os venenos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (73, NULL, 'w89 1/11 p. 10 A pureza moral � a beleza da juventude', 65, 'A JUVENTUDE, o entusiasmo e o frescor s�o como os dias da primavera. Em vez de lamentar. . . a sua curta dura��o, tente usufru�-los.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (74, NULL, 'w88 1/9 p. 15 Mantenha-se firme contra as maquina��es de Satan�s', 66, 'Quem dera que, por algum poder, dons nos fossem dados, de olharmos para n�s mesmos assim como somos olhados! De quantos erros ser�amos poupados!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (75, NULL, 'w87 15/9 p. 5 Como granjear verdadeiros amigos', 5, 'A �NICA maneira de se ter um amigo � ser amigo.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (76, NULL, 'w86 15/11 p. 28 Procura algu�m com quem compartilhar a vida?', 0, 'Senhoritas! falar-lhes quero

Da li��o que preciso dar -

N�o escolham s� o companheiro,

Mas o tempo certo para casar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (77, NULL, 'w85 15/11 p. 7 Por que revestir-se da brandura?', 67, 'A ira � uma loucura breve, portanto, controle sua paix�o ou ela o controlar�.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (78, NULL, 'w84 1/9 p. 4 Desumanidade - seu fim est� � vista!', 68, 'UMA coisa bela alegra para sempre.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (79, NULL, 'w83 15/7 p. 3 De que tipo de m�sica gosta?', 69, 'De m�sica e de medicina todos sabem um pouco.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (80, NULL, 'w83 15/7 p. 3 De que tipo de m�sica gosta?', 70, 'A m�sica � a linguagem universal da humanidade.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (81, NULL, 'w83 1/12 p. 17 Marido, mostre amor abnegado', 71, 'O CASAMENTO! Nenhuma outra coisa exige tanto do homem!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (82, NULL, 'w82 1/7 p. 8 Jovens, � a moralidade b�blica o modo melhor?', 0, 'OS DIAS de nossa juventude s�o os dias de nossa gl�ria.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (83, NULL, 'w81 15/8 p. 5 Existe Deus realmente?', 72, 'Tudo o que vemos � um milagre, mas visto t�o [regularmente], todo o milagre � em v�o.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (84, NULL, NULL, 73, 'A ESPERAN�A brota eternamente no peito humano.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (85, NULL, 'w81 15/10 p. 3 Todos precisam de esperan�a', 74, 'Enquanto h� vida, h� esperan�a.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (86, NULL, 'Ecl. 9:4, Mission�rios Capuchinhos.', 75, 'Enquanto um homem permanece entre os vivos, h� esperan�a.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (87, NULL, 'w78 15/9 p. 4 Aprenda a viver com o imut�vel', 0, 'Miseric�rdia h� em toda a parte, E isso d� anima��o, Ajudando ao homem a que suporte E se conforme com seu quinh�o.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (88, NULL, 'w76 1/2 p. 95 Por que n�o s�o perdo�veis certos pecados?', 73, 'Errar � humano; perdoar � divino.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (89, NULL, 'w73 15/2 p. 100 Sente-se frustrado?', 0, 'Basta fazer o melhor que puder. Assim o louvor ou a culpa que receber ter�o o mesmo valor.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (90, NULL, 'The Need for Words (Por que Precisamos de Palavras)', 0, 'A poesia nada mais � que palavras organizadas para produzir um impacto forte e imediato. Isso em parte explica por que os grandes poemas . . . s�o inesquec�veis.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (91, NULL, 'g98 22/10 p. 18 Cartografia ? uma chave para se conhecer o mundo', 76, 'Os mapas mentem, mas nunca contam piadas.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (92, NULL, 'g97 8/3 p. 8 Por que o crime organizado prospera', 77, 'A t�tica mais esperta do Diabo � persuadir voc� de que ele n�o existe.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (93, NULL, 'g96 22/6 p. 4 Pronto para as f�rias?', 25, 'O homem que viaja tem de levar conhecimento consigo, se � que trar� conhecimento para casa.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (94, NULL, 'g95 22/1 p. 6 Existe solu��o f�cil para o t�dio?', 27, '� o melhor livro (A B�blia) que j� existiu ou existir� no mundo, porque lhe ensina as melhores li��es pelas quais qualquer criatura humana . . . poder� ser guiada.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (95, NULL, 'g94 8/3 p. 26 Ajuda para superar o pesar', 5, 'A TRISTEZA FAZ QUE TODOS VOLTEMOS A SER CRIAN�AS; DESTR�I TODAS AS DIFEREN�AS INTELECTUAIS. O MAIS S�BIO NADA SABE.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (96, NULL, 'g94 22/5 p. 27 Ponha humor na sua vida', 78, 'Como uma agrad�vel chuva de ver�o, o humor pode subitamente purificar e refrescar a terra, o ar e voc�.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (97, NULL, 'g92 22/11 p. 31 A salva��o de uma ilha', 79, 'NENHUM homem � uma ilha.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (98, NULL, 'g90 8/4 p. 18 Para onde vai o movimento trabalhista?', 0, 'A RIQUEZA se acumula, e os homens degeneram.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (99, NULL, 'g90 22/9 p. 14 Parte 4: "N�s, o povo"', 80, 'A maioria pode errar t�o flagrantemente quanto a minoria.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (100, NULL, 'g89 22/4 p. 15 Parte 8: c. 563 AEC em diante - uma ilumina��o que prometia liberta��o', 5, 'O teste de uma religi�o ou filosofia � o n�mero de coisas que esta consegue explicar.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (101, NULL, 'g89 8/11 p. 19 Parte 21: De 1900 em diante - saias salpicadas de sangue', 63, 'N�o h� s�lida funda��o assentada em sangue.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (102, NULL, 'g89 22/12 p. 16 Parte 24: Agora e para sempre - as belezas eternas da religi�o verdadeira', 72, 'A religi�o, se de verdades celestes adornada, basta ser vista para ser admirada.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (103, NULL, 'g85 8/6 p. 27 O rock - m�sica boa ou prejudicial?', 81, 'O ardil mais engenhoso do Diabo � fazer os homens acreditarem que ele n�o existe.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (104, NULL, 'g85 8/7 p. 21 � a fatalidade que molda o seu futuro?', 82, 'Sou dono de meu pr�prio destino; sou o capit�o de minha pr�pria alma.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (105, NULL, 'g84 22/2 p. 13 Como enfrentar o desapontamento?', 83, 'N�o existe desapontamento que suportamos que chegue a ter metade do tamanho daqueles que causamos a n�s pr�prios.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (106, NULL, 'g84 8/12 p. 29 Observando o Mundo', 84, 'O nacionalismo � o arquivil�o de todos os males. Divide as pessoas, destr�i o lado bom da natureza humana, conduz a desigualdades na distribui��o das riquezas.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (107, NULL, 'g83 22/12 p. 22 Acrescente ''sabor'' � sua vida', 72, 'A VARIEDADE � o pr�prio condimento da vida, que lhe confere todo aquele seu sabor.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (108, NULL, 'g80 8/12 p. 11 A economia de movimentos poupa dinheiro, energia e tempo', 85, 'A procrastina��o � o ladr�o de tempo.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (109, NULL, 'g77 8/7 p. 8 Achar um c�njuge adequado', 0, 'Se quer casar-se sabiamente, case-se com algu�m semelhante a voc�.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (110, NULL, 'g71 22/3 p. 17 Diminui a semana de trabalho', 86, 'N�O h� substituto para o trabalho �rduo, O g�nio � um por cento de inspira��o e noventa e nove de transpira��o.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (111, NULL, 'Prov�rbios 10:19', 75, 'Na abund�ncia de palavras n�o falta transgress�o, mas quem refreia seus l�bios age com discri��o.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (112, NULL, 'iT-2 p. 715', 87, 'Longanimide: Significa suportar pacientemente o mal ou a provoca��o, junto com a recusa de perder a esperan�a de haver melhora no relacionamento perturbado. Portanto, a longanimidade tem um objetivo, visando especialmente o bem-estar daquele que causa a situa��o desagrad�vel. No entanto, isto n�o significa fechar os olhos ao mal. Quando se alcan�a o objetivo da longanimidade, ou quando de nada adianta ag�entar mais tal situa��o, a longanimidade cessa. Ela cessa quer quando resulta em bem para os que causam a provoca��o, quer com uma a��o contra os malfeitores. De qualquer modo, aquele que usa de longanimidade n�o � espiritualmente prejudicado.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (113, NULL, 'sapo.pt', 88, 'Os poderosos podem matar uma, duas ou at� tr�s rosas, mas jamais poder�o deter a primavera.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (114, NULL, 'sapo.pt', 89, 'Se choras porque n�o consegues ver o Sol, as tuas l�grimas impedir-te-�o de ver as estrelas.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (115, NULL, 'sapo.pt', 90, 'Mesmo as noites totalmente sem estrelas podem anunciar a aurora de uma grande realiza��o.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (116, NULL, 'sapo.pt', 91, 'A esperan�a n�o � um sonho, mas uma maneira de traduzir os sonhos em realidade.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (117, NULL, 'sapo.pt', 63, 'Choramos ao nascer porque chegamos a este imenso cen�rio de dementes.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (118, NULL, 'sapo.pt', 92, 'O homem � a �guia que voa(...)  a mulher � o rouxinol que canta, voar � dominar o espa�o, cantar � conquistar a alma... Enfim! O homem est� colocado onde acaba a terra; a mulher onde come�a o c�u.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (119, NULL, 'sapo.pt', 92, 'O cora��o da mulher aperfei�oa-se porque d�; o cora��o do homem desliga-se porque recebe.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (120, NULL, 'sapo.pt', 93, 'Conhece-te a ti mesmo.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (121, NULL, 'sapo.pt', 94, 'Ningu�m � igual a ningu�m. Todo ser humano  � um estranho �mpar.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (122, NULL, 'sapo.pt', 58, 'Quando um homem n�o se encontra a si mesmo, n�o encontra nada.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (123, NULL, 'internet', 0, 'N�o podemos evitar que os p�ssaros da amargura voem sobre nossas cabe�as, mas podemos evitar que eles fa�am ninhos em nossos cabelos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (124, NULL, 'internet', 95, 'Aprendi atrav�s da experi�ncia amarga a suprema li��o: controlar minha ira e torn�-la como o calor que � convertido em energia. Nossa ira controlada pode ser convertida numa for�a capaz de mover o mundo.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (125, NULL, 'internet', 96, 'A vida � uma pedra de amolar: desgasta-nos ou afia-nos, conforme o metal de que somos feitos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (126, NULL, 'internet', 97, 'N�o existe verdadeira intelig�ncia sem bondade.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (127, NULL, 'internet', 98, 'Rir de tudo � coisa dos tontos, mas n�o rir de nada � coisa dos est�pidos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (128, NULL, 'internet', 99, 'Todos os erros humanos s�o impaci�ncia, uma interrup��o prematura de um trabalho met�dico.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (129, NULL, 'internet', 100, 'O homem � mortal por seus temores e imortal por seus desejos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (130, NULL, 'Awake!  22/11/81 p. 3', 96, 'Temo o sucesso. Ter alcan�ado sucesso � ter terminado sua tarefa na terra . . . Gosto de um estado de cont�nuo vir a ser, com um alvo � frente e n�o atr�s.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (131, NULL, 'internet', 101, 'N�s geralmente descobrimos o que fazer percebendo aquilo que n�o devemos fazer. E provavelmente aquele que nunca cometeu um erro nunca fez uma descoberta.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (132, NULL, 'internet', 95, 'A alegria est� na luta, na tentativa, no sofrimento envolvido. N�o na vit�ria propriamente dita.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (133, NULL, 'internet', 102, 'Toma conselhos com o vinho, mas toma decis�es com a �gua.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (134, NULL, 'internet', 103, 'A mis�ria da condi��o humana � tal que a dor � seu sentimento mais vivo.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (135, NULL, 'internet', 95, 'Um homem n�o pode fazer o certo numa �rea da vida, enquanto est� ocupado em fazer o errado em outra. A vida � um todo indivis�vel.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (136, NULL, 'internet', 95, 'A n�o-viol�ncia e a covardia n�o combinam. Posso imaginar um homem armado at� os dentes que no fundo � um covarde. A posse de armas insinua um elemento de medo, se n�o mesmo de covardia. Mas a verdadeira n�o-viol�ncia � uma impossibilidade sem a posse de um destemor inflex�vel.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (137, NULL, 'internet', 15, 'Os princ�pios mais importantes podem e devem ser inflex�veis.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (138, NULL, 'internet', 104, 'O homem vale tanto quanto o valor que d� a si pr�prio.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (139, NULL, 'internet', 105, 'Se julgarmos o amor pela maioria de seus efeitos, ele se parecer� mais ao �dio do que � amizade.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (140, NULL, 'internet', 105, 'A aus�ncia diminui as pequenas paix�es e aumenta as grandes, da mesma forma que o vento apaga as velas e aviva as fogueiras.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (141, NULL, 'internet', 105, 'As desaven�as n�o durariam muito se o erro fosse s� de uma das partes.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (142, NULL, 'internet', 105, 'O amor � como guerra: f�cil de come�ar, mas muito dif�cil de terminar.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (143, NULL, 'internet', 106, 'A preocupa��o deveria levar-nos � a��o e n�o � depress�o.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (144, NULL, 'internet', 96, 'A puni��o do mentiroso n�o � de afinal ningu�m acreditar nele, mas de ele n�o poder acreditar mais em ningu�m.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (145, NULL, 'internet', 107, 'N�o h� excesso de liberdade se aqueles que s�o livres s�o respons�veis.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (146, NULL, 'internet', 108, 'Os males de que padece o ser humano, em seu maior n�mero, v�m dele mesmo.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (147, NULL, 'internet', 109, 'A vida n�o consiste em ter boas cartas na m�o e sim em jogar bem as que se tem.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (148, NULL, 'internet', 109, 'O sil�ncio � um dos argumentos mais dif�ceis de refutar.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (149, NULL, 'internet', 100, 'Educai as crian�as, para que n�o seja necess�rio punir os adultos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (150, NULL, 'internet', 110, 'Nossos pensamentos mais importantes s�o os que contradizem nossos sentimentos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (151, NULL, 'internet', 111, 'Todo erro se apoia numa verdade da qual se tem abusado.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (152, NULL, 'internet', 0, 'Um grama de exemplos, vale mais que uma tonelada de conselhos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (153, NULL, 'internet', 112, 'Chega um dia em que se o homem n�o deixar tudo para tr�s n�o vai para a frente.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (154, NULL, 'internet', 112, 'Desisti de ser feliz. Agora me sinto muito menos infeliz.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (155, NULL, 'internet', 0, 'Quanto mais os gatos brigam, mais gatinhos aparecem.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (156, NULL, 'Prov. 18:12', 75, 'Antes da derrocada, o cora��o do homem � soberbo, e antes da gl�ria h� humildade.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (157, NULL, 'w080 1/5 p. 29', 113, 'Seja apreciativo. Valorize o que tem, e n�o lamente o que n�o tem.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (158, NULL, 'Prov. 16:18', 75, 'O orgulho vem antes da derrocada e o esp�rito soberbo antes do trope�o.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (159, NULL, 'Prov. 10:19', 75, 'Na abund�ncia de palavras n�o falta transgress�o, mas quem refreia seus l�bios age com discri��o.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (160, NULL, 'Prov. 14:30', 75, 'O cora��o calmo � a vida do organismo carnal, mas o ci�me � podrid�o para os ossos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (161, NULL, 'Prov. 17:1', 75, 'Melhor um peda�o de p�o seco com tranq�ilidade, do que uma casa cheia dos sacrif�cios da alterca��o.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (162, NULL, 'Prov. 26:12', 75, 'Viste um homem s�bio aos seus pr�prios olhos? H� mais esperan�a para o est�pido do que para ele.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (163, NULL, 'Prov. 26:20', 75, 'Onde n�o h� lenha, apaga-se o fogo, e onde n�o h� caluniador, aquieta-se a contenda.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (164, NULL, 'Prov. 26:21', 75, 'Como o carv�o de lenha para as brasas e a lenha para o fogo, assim � o homem contencioso por tornar acesa a alterca��o.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (165, NULL, 'it-3 p. 262', 87, 'A perspic�cia, essencialmente, � a capacidade de fazer um exame sagaz duma situa��o. Agir com perspic�cia � agir com prud�ncia, bom crit�rio.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (166, NULL, 'it-3 p. 476', 87, 'Baseado em conhecimento e entendimento; a faculdade de usar o conhecimento e o entendimento com bom �xito para solucionar problemas, evitar ou prevenir perigos, atingir certos objetivos ou aconselhar outros neste sentido. Ela � o oposto da tolice, da estupidez e da estult�cia, com que freq�entemente � contrastada.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (167, NULL, 'w00 1/8 p. 14', 113, 'A mod�stia � o contr�rio da presun��o. Quem � modesto encara de modo equilibrado suas habilidades e seu valor, e est� livre de convencimento ou vaidade. Em vez de ser orgulhoso, jactancioso ou ambicioso, quem � modesto sempre se apercebe das suas limita��es. Por isso respeita e leva em conta os sentimentos e os conceitos dos outros.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (168, NULL, 'Prov. 11:2', 75, 'Chegou a presun��o? Ent�o chegar� a desonra; mas a sabedoria est� com os modestos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (169, NULL, 'G�latas 6:3', 114, 'Pois, se algu�m acha que ele � alguma coisa, quando n�o � nada, est� enganando a sua pr�pria mente.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (170, NULL, 'Prov. 27:2', 75, 'Louve-te o estranho e n�o a tua pr�pria boca; fa�a-o o estrangeiro e n�o os teus pr�prios l�bios.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (171, NULL, 'it-3 p. 477', 87, 'A discri��o subentende prud�ncia e pode expressar-se em cautela, autodom�nio, modera��o ou comedimento. O "homem discretos constr�i sua casa sobre a rocha, prevendo a possibilidade de temporais; o homem tolo constr�i a sua sobre areia e sofre desastre".', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (172, NULL, 'Prov. 17:27-28', 75, 'Quem refreia as suas declara��es � possu�do de conhecimento e o homem de discernimento � de esp�rito frio. At� mesmo o tolo, quando fica calado, � tido por s�bio; aquele que fecha os seus pr�prios l�bios, por entendido.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (173, 'be estudo 33 p. 197', NULL, 0, 'TATO � a habilidade de lidar com as pessoas sem dar motivos para se ofenderem. � saber como e quando dizer as coisas. Isso n�o significa transigir no que � direito nem distorcer os fatos. N�o se deve confundir tato com medo do homem.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (174, 'be estudo 33 p. 197', NULL, 0, 'A pessoa bondosa age com brandura e cortesia. Quem � pac�fico procura meios de promover boas rela��es com outros. Quem � long�nime permanece calmo mesmo quando outros o tratam de modo rude.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (175, NULL, 'Rom. 12:18', 114, 'Se poss�vel, no que depender de v�s, sede pac�ficos para com todos os homens.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (176, NULL, 'it-2 p. 353', 97, 'Humildade: Aus�ncia de orgulho ou arrog�ncia; despretens�o. N�o se trata duma fraqueza, mas dum estado mental agrad�vel.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (177, NULL, 'w00 15/1 p. 22', 113, 'Os que n�o se julgam importantes demais t�m mais facilidade de fazer boas amizades. A mod�stia e a humildade evitar�o que desenvolvamos um esp�rito competitivo e tentemos ser melhores do que os outros, n�o s� no que diz respeito �s coisas que fazemos, mas tamb�m com rela��o �s coisas que possu�mos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (178, NULL, 'w00 15/1 p. 22', 113, 'Quando as pessoas sentem que s�o tratadas com amor e bondade, geralmente reagem de maneira favor�vel. E n�o � verdade que esse relacionamento altru�sta serve de base para amizades verdadeiras? Essa � uma das b�n��os que teremos por cultivar a mod�stia e n�o nos julgar mais importantes do que somos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (179, NULL, 'w00 15/1 p. 22', 113, 'Quando temos um conceito equilibrado sobre n�s mesmos fica mais f�cil admitir que erramos quando ofendemos algu�m. Isso resulta em melhores relacionamentos, e abre o caminho para nos reconciliarmos com as pessoas e termos respeito m�tuo.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (180, NULL, 'w94 1/9 p. 20', 113, 'Por via de regra, a jact�ncia - a s�rio ou de brincadeira - faz os outros sentirem-se tensos, aborrecidos e talvez invejosos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (181, NULL, 'w94 1/9 p. 20', 113, 'As pessoas n�o t�m dons iguais. O que para um � relativamente f�cil, simplesmente n�o � poss�vel para outro. O amor induzir� a pessoa a tratar com empatia aqueles que n�o s�o dotados das habilidades que ela tem.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (182, NULL, 'w94 1/9 p. 20', 36, 'S� mais s�bio que os outros se podes, mas n�o o digas.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (183, NULL, 'w94 1/9 p. 20', 116, 'Todos sabem no �ntimo que a jact�ncia usualmente � ind�cio de algumas pat�ticas fraquezas pessoais.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (184, NULL, 'w94 1/9 p. 21', 113, 'Os talentos e as capacidades em geral tornam-se conhecidos sem que algu�m se exiba indevidamente. Quando outros reconhecem e elogiam suas qualidades ou realiza��es, isso reflete melhor sobre ele.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (185, NULL, 'w94 1/9 p. 21', 5, 'Todo homem que encontro � de algum modo superior a mim. Assim, eu aprendo dele.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (186, NULL, NULL, 0, NULL, 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (187, NULL, 'w99 1/12 p. 26', 113, 'Algu�m que gosta muito do trabalho que faz pode facilmente transformar essa qualidade numa fraqueza, tornando-se trabalhador compulsivo. Uma pessoa cautelosa pode n�o ser facilmente enganada, mas pode ser t�o cautelosa a ponto de nunca tomar decis�es.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (188, NULL, 'w99 1/12 p. 26', 113, 'A efici�ncia � uma qualidade excelente, mas se levada a extremos e ignorar o elemento humano, pode gerar um ambiente frio e inflex�vel, e trazer infelicidade. Por isso, pare um pouco e analise suas qualidades. Voc� as controla bem? S�o ben�ficas para outras pessoas?', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (189, NULL, 'w99 1/12 p. 26', 113, 'A capacidade intelectual agu�ada � algo excelente. Mas poderia tornar-se uma fraqueza caso nos levasse a ter excesso de confian�a ou a desenvolver um conceito elevado sobre n�s mesmos, principalmente se outros nos elogiam demais ou nos bajulam.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (190, NULL, NULL, 117, 'Nada iguala o sabor do p�o compartilhado.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (191, NULL, NULL, 0, 'Pare de exigir das pessoas aquilo que nem voce conquistou ainda.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (192, NULL, NULL, 0, 'Critique menos, trabalhe mais.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (193, NULL, NULL, 118, 'A grandeza n�o consiste em receber honras, mas em merec�-las.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (194, NULL, NULL, 0, 'A palavra paix�o origina-se do termo "pathos", que derivou o termo patologia, ou doen�a.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1153, NULL, NULL, NULL, 'Sabe o qual a diferen�a do trabalho entre; Sonhar grande e sonhar pequeno? Somente o resultado!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1154, NULL, NULL, NULL, 'Respeitar a op��o do pr�ximo, em qualquer aspecto, � uma das maiores virtudes que um ser humano pode ter', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1155, NULL, NULL, NULL, 'Reaja inteligentemente mesmo a um tratamento n�o inteligente', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1156, NULL, NULL, NULL, 'Recompensa com uma fonte inesgot�vel a quem te presenteou com uma gota de �gua', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1157, NULL, NULL, NULL, 'Querer vencer significa j� ter percorrido metade do caminho da vit�ria', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1158, NULL, NULL, NULL, 'Querendo, mentalizamos; Mentalizando, agimos; Agindo, atra�mos e realizamos. Como voc� pensa, voc� cr�, e como voc� cr�, ser�', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1159, NULL, NULL, NULL, 'Quer ser feliz agora? Te vinga. Quer ser feliz sempre? Perdoa', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1160, NULL, NULL, NULL, 'Quer fazer um neg�cio soberbo? Compre todas as consci�ncias pelo que elas valem, e torne a vend�-las pelo que elas julgam valer', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1161, NULL, NULL, NULL, 'Quem recebe um benef�cio, n�o deve esquece-lo, quem o faz, n�o deve lembra-lo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1162, NULL, NULL, NULL, 'Quem quer ser amado ama. E quem � amado tudo alcan�a, sobretudo dos jovens', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1163, NULL, NULL, NULL, 'Quem olha para fora sonha: Quem olha para dentro, desperta', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1164, NULL, NULL, NULL, 'Quem n�o pode mudar a pr�pria contextura do seu pensamento, nunca ser� capaz de alterar a realidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1165, NULL, NULL, NULL, 'Quem n�o espera vencer, j� est� vencido', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1166, NULL, NULL, NULL, 'Quem n�o est� preparado para a eternidade, n�o est� preparado para a vida', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1167, NULL, NULL, NULL, 'Quem luta pela vida pode n�o vencer, mas certamente n�o ser� culpado pela derrota', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1168, NULL, NULL, NULL, 'Quem jamais amou v� com maus olhos as coisas do amor', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1169, NULL, NULL, NULL, 'Quem � bom membro de fam�lia � tamb�m bom cidad�o', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1170, NULL, NULL, NULL, 'Quem come�a a entender o amor, a explic�-lo, a qualific�-lo e quantific�-lo, j� n�o est� amando', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1171, NULL, NULL, NULL, 'Quase todos os homens s�o capazes de suportar adversidades, mas se quiser por � prova o car�ter de um homem, d�-lhe poder', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1172, NULL, NULL, NULL, 'Qu�o maravilhosas as pessoas que n�o conhecemos bem', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1173, NULL, NULL, NULL, 'Quanto mais velho se fica, melhor se compreende que a bondade � sin�nima de felicidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1174, NULL, NULL, NULL, 'Quanto mais se semeiam desejos, menos se colhe felicidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1175, NULL, NULL, NULL, 'Quanto maior for a cren�a em seus objetivos, mais depressa voc� os conquistar�!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1176, NULL, NULL, NULL, 'Quantas coisas perdemos por medo de perder', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1177, NULL, NULL, NULL, 'Quando voc� tem que fazer uma escolha e voc� n�o a faz, isto j� � uma escolha', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1178, NULL, NULL, NULL, 'Quando voc� estiver zangado, conte at� dez antes de falar. Quanto estiver muito zangado, conte at� cem, e em seguida, n�o fale', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1179, NULL, NULL, NULL, 'Quando todos os homens abrirem as portas de seus cora��es desaparecer�o as trevas que envolvem este mundo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1180, NULL, NULL, NULL, 'Quando sozinhos, vigiemos nossos pensamentos; em fam�lia, o nosso g�nio; em sociedade, a nossa l�gua', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1181, NULL, NULL, NULL, 'Quando n�o encontramos o repouso em n�s pr�prios, � in�til ir procura-lo em outro lugar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1182, NULL, NULL, NULL, 'Quando minha escolha � consciente, nenhuma repercuss�o me assusta. Quando n�o �, qualquer coment�rio me balan�a', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1183, NULL, NULL, NULL, 'Quando falares, cuida para que tuas palavras sejam melhores que o sil�ncio', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1184, NULL, NULL, NULL, 'Quando duas pessoas se amam, elas n�o se submetem e n�o se dominam, apenas se completam', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1185, NULL, NULL, NULL, 'Quando algu�m o abra�a, n�o seja voc� o primeiro a soltar os bra�os', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1186, NULL, NULL, NULL, 'Quaisquer que sejam as circunst�ncias, a vida somente ajuda-o a se desenvolver', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1187, NULL, NULL, NULL, 'Procure descobrir o seu caminho na vida. Ningu�m � respons�vel por nosso destino, a n�o ser n�s mesmos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1188, NULL, NULL, NULL, 'Preste aten��o: Problemas s�o mensagens!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1189, NULL, NULL, NULL, 'Procurar o significado da vida, � dar-lhe um significado', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1190, NULL, NULL, NULL, 'Prefira um preju�zo a um lucro desonesto; o primeiro causa afli��o no momento, o outro no resto da vida', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1191, NULL, NULL, NULL, 'Por que ter medo da morte? Enquanto somos, a morte n�o existe, e quando ela passa existir, n�s deixamos de ser', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1192, NULL, NULL, NULL, 'Podes ser somente uma pessoa para o mundo, mas para alguma pessoa tu �s o mundo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1193, NULL, NULL, NULL, 'Podemos escolher o que semear, mas obrigados a colher aquilo que plantamos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1194, NULL, NULL, NULL, 'Pequenas a��es que realizamos s�o melhores do que as grandes que planejamos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1195, NULL, NULL, NULL, 'Pecar pelo sil�ncio, quando deve protestar, faz do homem um covarde', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1196, NULL, NULL, NULL, 'Pense no passado... Viva o presente... Acredite no futuro!!!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1197, NULL, NULL, NULL, 'Para viver intensamente � necess�rio conviver com os riscos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1198, NULL, NULL, NULL, 'Para ser feliz, � preciso amar, sem que a valoriza��o da vida pessoal signifique um retorno', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1199, NULL, NULL, NULL, 'Para realizar grandes feitos, precisamos n�o somente agir, mas tamb�m sonhar, n�o somente planejar, mas tamb�m acreditar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1200, NULL, NULL, NULL, 'Para realizar grandes coisas, precisamos viver como se nunca tiv�ssemos que morrer', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1201, NULL, NULL, NULL, 'Para os que cr�em, nenhuma explica��o � necess�ria', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1202, NULL, NULL, NULL, 'Para amar o pr�ximo � preciso amar a si mesmo. A insatisfa��o pr�pria gera uma eterna incapacidade de amar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1203, NULL, NULL, NULL, 'Para alcan�armos a nascente, temos que nadar contra a correnteza', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1204, NULL, NULL, NULL, 'Palavras n�o s�o pedras, mas quando atiradas com for�a, machucam', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1205, NULL, NULL, NULL, 'Outra vez ou�o som de alegria...Ainda que a vida tenha me quebrado; Eu serei feliz de novo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1206, NULL, NULL, NULL, 'Os vencedores sempre fazem mais, muito mais do que o suficiente', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1207, NULL, NULL, NULL, 'Os tristes dizem que os ventos gemem, os alegres acham que cantam', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1208, NULL, NULL, NULL, 'Os poderosos poder�o matar uma, duas at� tr�s rosas, mas jamais poder�o deter a primavera', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1209, NULL, NULL, NULL, 'Os pequenos atos que se executa, s�o melhores do que os grandes que apenas se planeja', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1210, NULL, NULL, NULL, 'Os homens poderiam fazer mais coisas, se n�o as achassem imposs�veis', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1211, NULL, NULL, NULL, 'Os males de que padece o ser humano, em seu maior n�mero, v�m dele mesmo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1212, NULL, NULL, NULL, 'Os homens n�o s�o fantoches do destino e sim construtores dele', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1213, NULL, NULL, NULL, 'Os homens fariam muitas coisas, se n�o julgassem tantas coisas imposs�veis', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1214, NULL, NULL, NULL, 'Os homens de m�rito n�o precisam cuidar da sua fama; a inveja dos tolos e dos petulantes se encarrega de propag�-la', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1215, NULL, NULL, NULL, 'Os grandes navegadores devem sua reputa��o aos temporais e tempestades', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1216, NULL, NULL, NULL, 'Os esp�ritos med�ocres geralmente condenam tudo quanto ultrapasse sua pequenina estatura', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1217, NULL, NULL, NULL, 'Os espinhos que me feriram foram produzidos pelo arbusto que plantei', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1218, NULL, NULL, NULL, 'Os erros s�o, no m�nimo, um sinal de que estamos saindo da estrada principal e experimentando outros caminhos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1219, NULL, NULL, NULL, 'Onde quer que se encontre um homem bom, � necess�rio estender-lhe a m�o e apert�-lo contra o cora��o', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1220, NULL, NULL, NULL, 'Obst�culos s�o aquelas coisas medonhas que voc� v� quando tira os olhos de seu objetivo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1221, NULL, NULL, NULL, 'O vitorioso tem muitos amigos, mas o vencido tem bons amigos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1222, NULL, NULL, NULL, 'O verdadeiro hero�smo consiste em persistir por mais um momento quando tudo parece perdido', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1223, NULL, NULL, NULL, 'O verdadeiro amigo � aquele que n�o desculpa nada mas perdoa tudo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1224, NULL, NULL, NULL, 'O verdadeiro amigo � aquele que chega quando o restante j� se foi', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1225, NULL, NULL, NULL, 'O vento pode apagar uma vela, mas tamb�m ati�ar uma fogueira', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1226, NULL, NULL, NULL, 'O �nico modo de evitar os erros � adquirindo experi�ncia; mas a �nica maneira de adquirir experi�ncia � cometendo erros', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1227, NULL, NULL, NULL, 'O �nico lugar que o sucesso vem antes do trabalho � no dicion�rio', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1228, NULL, NULL, NULL, 'O tempo dura bastante para aqueles que sabem aproveit�-lo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1229, NULL, NULL, NULL, 'O sucesso de todos, depende da participa��o de cada um', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1230, NULL, NULL, NULL, 'O ser humano, se contenta com muito pouco nas ocasi�es importunas, e n�o se contenta com nada nas ocasi�es sensatas', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1231, NULL, NULL, NULL, 'O segredo da vida n�o � o que acontece com voc�, e sim o que voc� faz com o que acontece com voc�', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1232, NULL, NULL, NULL, 'O sacrif�cio de subir a montanha � compensado pela paisagem que descobrimos do alto', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1233, NULL, NULL, NULL, 'O rid�culo n�o existe; Os que ousaram desafi�-lo de frente conquistaram o mundo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1234, NULL, NULL, NULL, 'O rio atinge seus objetivos por que aprendeu a contornar os obst�culos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1235, NULL, NULL, NULL, 'O que quer que voc� seja capaz de fazer, ou imagina ser capaz, comece. Ousadia cont�m g�nio, poder e magia', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1236, NULL, NULL, NULL, 'O que n�o provoca minha morte faz com que eu fique mais forte', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1237, NULL, NULL, NULL, 'O que mais impede que sejamos naturais � o desejo de assim parecermos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1238, NULL, NULL, NULL, 'O que est� por tr�s de n�s � nada em compara��o ao que est� dentro de n�s e a nossa frente', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1239, NULL, NULL, NULL, 'O progresso come�a com a convic��o de que o que � necess�rio � poss�vel', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1240, NULL, NULL, NULL, 'O primeiro passo para promover uma mudan�a � libertar-se da imagem que voc� transmite aos outros', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1241, NULL, NULL, NULL, 'O prazer dos grandes homens consiste em tornar os outros mais felizes', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1242, NULL, NULL, NULL, 'O portador de sorrisos e de uma disposi��o am�vel dispensa apresenta��o, pois � bem-vindo em qualquer lugar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1243, NULL, NULL, NULL, 'O pensamento positivo pode vir naturalmente para alguns, mas tamb�m pode ser aprendido e cultivado, mude seus pensamentos e voc�', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1244, NULL, NULL, NULL, 'O passado sedimenta o caminho, mas � preciso olhar sempre para a frente', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1245, NULL, NULL, NULL, 'O passado � uma li��o para se meditar, n�o para se reproduzir', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1246, NULL, NULL, NULL, 'O otimista proclama que vivemos no melhor dos mundos. O pessimista teme que seja verdade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1247, NULL, NULL, NULL, 'O objetivo � sermos felizes. S� l� chegamos lentamente. Isso exige um trabalho cotidiano', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1248, NULL, NULL, NULL, 'O mundo est� violento, n�o por causa daqueles que fazem o mal, mais sim por causa daqueles que observam e deixam o mal acontecer', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1249, NULL, NULL, NULL, 'O mundo � um livro, e quem fica sentado em casa l� somente uma p�gina desse livro', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1250, NULL, NULL, NULL, 'O mole � mais forte do que o duro, a �gua e mais forte que a rocha, o amor � mais forte que a viol�ncia', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1251, NULL, NULL, NULL, 'O melhor livro de moral � a nossa consci�ncia. Temos que consult�-lo muito freq�entemente', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1252, NULL, NULL, NULL, 'O medo de amar � uma praga, uma erva daninha, que corrompe o cora��o da maioria das pessoas que vive se queixando da solid�o', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1253, NULL, NULL, NULL, 'O maravilhoso da fantasia � nossa capacidade de torn�-la realidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1254, NULL, NULL, NULL, 'O Mal de quase todos n�s � que preferimos ser arruinados pelo elogio a ser salvos pela cr�tica', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1255, NULL, NULL, NULL, 'O mais importante de tudo � poder ter a sensa��o de que viver vale a pena', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1256, NULL, NULL, NULL, 'O mais forte � o que sabe dominar-se na hora da c�lera', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1257, NULL, NULL, NULL, 'O maior erro do ser humano � dar valor as pessoas erradas, ou que n�o est�o te enxergando do mesmo modo que as enxergamos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1258, NULL, NULL, NULL, 'O limite de cada um est� no tamanho do sonho que carrega', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1259, NULL, NULL, NULL, 'O insucesso � apenas uma oportunidade para recome�ar de novo com mais intelig�ncia', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1260, NULL, NULL, NULL, 'O inferno � perder a capacidade de sorrir, acreditar e amar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1261, NULL, NULL, NULL, 'O imposs�vel n�o existe; os que ousaram desafi�-lo de frente conquistaram o mundo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1262, NULL, NULL, NULL, 'O importante n�o � ser tudo para todos em todos os lugares E sim ser algo para algu�m em algum lugar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1263, NULL, NULL, NULL, 'O importante � o que se pratica e n�o o que se pensa', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1264, NULL, NULL, NULL, 'O ideal n�o se define; enxerga-se, quando o atingimos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1265, NULL, NULL, NULL, 'O homem viaja atrav�s do mundo em busca do que deseja, e retorna ao lar para encontr�-lo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1266, NULL, NULL, NULL, 'O homem verdadeiramente prudente n�o diz tudo quanto pensa, mas pensa tudo quando diz', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1267, NULL, NULL, NULL, 'O homem n�o morre quando deixa de viver, mas sim quando deixa de acreditar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1268, NULL, NULL, NULL, 'O homem infeliz � aquele n�o cr�, porque n�o crendo, n�o tem o direito de esperar Acredite!!! Com voc� mudaremos o Brasil', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1269, NULL, NULL, NULL, 'O homem � livre; mas ele encontra a lei na sua pr�pria liberdade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1270, NULL, NULL, NULL, 'O grande vencedor se conhece n�o pelas vit�rias que alcan�a, mas pelas derrotas que assimila', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1271, NULL, NULL, NULL, 'O g�nio � composto por 2% de talento e 98% de perseverante aplica��o', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1272, NULL, NULL, NULL, 'O futuro pertence aqueles que acreditam na beleza dos seus sonhos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1273, NULL, NULL, NULL, 'O fracasso � apenas uma oportunidade para recome�ar com mais intelig�ncia', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1274, NULL, NULL, NULL, 'O futuro das organiza��es - e na��es - depender� cada vez mais de sua capacidade de aprender coletivamente', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1275, NULL, NULL, NULL, 'O essencial s�o coisas mais simples', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1276, NULL, NULL, NULL, 'O �xito � f�cil de obter. O dif�cil � merec�-lo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1277, NULL, NULL, NULL, 'O discernimento consiste em saber at� onde se pode ir', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1278, NULL, NULL, NULL, 'O dif�cil n�o � fazer, mas acreditar que � poss�vel', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1279, NULL, NULL, NULL, 'O destino n�o � uma quest�o de escolha, n�o � algo para se esperar, � algo para ser alcan�ado', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1280, NULL, NULL, NULL, 'O corpo destila as l�grimas que os olhos se recusam a verter', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1281, NULL, NULL, NULL, 'O cerebro � como um p�ra-quedas s� funciona quando est� aberto', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1282, NULL, NULL, NULL, 'O caminho para o sucesso n�o � fazer uma coisa 100% melhor � fazer 100 coisas 1% melhor', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1283, NULL, NULL, NULL, 'O caminho mais curto para fazer muitas coisas � fazer uma s� de cada vez', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1284, NULL, NULL, NULL, 'O bem que fizermos hoje, ser� nossa alegria amanh�', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1285, NULL, NULL, NULL, 'O amor tudo cr�, tudo espera, tudo suporta', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1286, NULL, NULL, NULL, 'O amor-pr�prio � fruto da disciplina; o sentimento da dignidade pessoal cresce com a capacidade de dizer n�o a si mesmo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1287, NULL, NULL, NULL, 'O amor pequeno se mostra grandioso nas cat�strofes; O amor grande se prova todos os dias nas coisas pequenas', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1288, NULL, NULL, NULL, 'O amor humano permite que se passe do amor ao �dio, enquanto que o amor divino � imut�vel', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1289, NULL, NULL, NULL, 'O amor � natural Portanto se as pessoas n�o atrapalham, ele segue seu curso com naturalidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1290, NULL, NULL, NULL, 'Nunca se percebe o que j� foi feito; a gente s� nota o que ainda est� por fazer', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1291, NULL, NULL, NULL, 'Nunca se lembre daquilo que acabou, mas sim do que foi bom enquanto durou', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1292, NULL, NULL, NULL, 'Nunca se deve engatinhar quando o impulso � voar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1293, NULL, NULL, NULL, 'Nunca se arrependa das coisas que fez e errou, mas sim do que n�o fez por medo de errar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1294, NULL, NULL, NULL, 'Nunca ore suplicando cargas mais leves e sim ombros mais fortes', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1295, NULL, NULL, NULL, 'Nunca espere governar outros, at� que tenha aprendido a governar a se mesmo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1296, NULL, NULL, NULL, 'Nunca devemos ser duros demais quando queremos que o cora��o do semelhante se abra', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1297, NULL, NULL, NULL, 'Nunca devemos nos envergonhar das nossas pr�prias lagrimas', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1298, NULL, NULL, NULL, 'Nunca devemos esquecer que nenhum homem pode fugir de si mesmo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1299, NULL, NULL, NULL, 'Nunca despreze os pequenos quando est� subindo, pois poder� encontr�-los quando estiver descendo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1300, NULL, NULL, NULL, 'Nunca desencoraje ningu�m que continuamente faz progresso, n�o importa qu�o devagar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1301, NULL, NULL, NULL, 'Nunca deixe que a tristeza de ontem e a incerteza do amanh� estraguem a felicidade de hoje', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1302, NULL, NULL, NULL, 'Nunca chegaras a convencer um rato de que um gato traz boa sorte', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1303, NULL, NULL, NULL, 'Nosso maior advers�rio est� dentro de n�s', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1304, NULL, NULL, NULL, 'Nosso c�rebro � o melhor brinquedo j� criado: nele se encontram todos os segredos, inclusive o da felicidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1305, NULL, NULL, NULL, 'Nossas d�vidas s�o traidoras e nos fazem perder o que, com freq��ncia, poder�amos ganhar, por simples medo de arriscar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1306, NULL, NULL, NULL, 'N�s somos aquilo que fazemos repetidamente. Excel�ncia portanto, n�o � um ato, mas um h�bito', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1307, NULL, NULL, NULL, 'No meio de qualquer dificuldade encontra-se a oportunidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1308, NULL, NULL, NULL, 'Nos olhos do jovem arde a chama. Nos do velho brilha a luz', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1309, NULL, NULL, NULL, 'Ningu�m pode ser bom por muito tempo se n�o houver uma demanda por bondade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1310, NULL, NULL, NULL, 'Ningu�m jamais teve um defeito que n�o lhe fosse �til em algumas coisas', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1311, NULL, NULL, NULL, 'Ningu�m est� preparado para morrer, se n�o estiver preparado para viver', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1312, NULL, NULL, NULL, 'Ningu�m � t�o grande que n�o possa aprender e nem t�o pequeno que n�o possa ensinar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1313, NULL, NULL, NULL, 'Ningu�m � perfeito. . .  � por isso que l�pis t�m borracha', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1314, NULL, NULL, NULL, 'Ningu�m avan�a na vida se n�o come�a a fazer alguma coisa pelo pr�ximo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1315, NULL, NULL, NULL, 'Nenhum homem poder� montar nas suas costas, a menos que elas j� se hajam vergado', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1316, NULL, NULL, NULL, 'Nenhum homem � bom o bastante para governar os outros sem seu consentimento', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1317, NULL, NULL, NULL, 'Nenhum de n�s � bom o suficiente como todos n�s juntos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1318, NULL, NULL, NULL, 'Nem todos os homens podem ser ilustre, mas todos podem ser bons', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1319, NULL, NULL, NULL, 'Negar as pr�prias aspira��es � um desperd�cio de energia que faz falta para suas realiza��es', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1320, NULL, NULL, NULL, 'Nas quedas � que o rio ganha energia', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1321, NULL, NULL, NULL, 'N�o vale a pena procurar culpados em erros onde o tempo n�o p�ra para podermos consert�-los', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1322, NULL, NULL, NULL, 'N�o tenhas medo das tuas fraquezas, dos teus maus pensamentos. Eles existem para estimular a tua vontade, o teu desejo de vencer', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1323, NULL, NULL, NULL, 'N�o tenha medo de dar um grande passo, caso ele seja recomend�vel, � imposs�vel atravessar um abismo com dois saltos pequenos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1324, NULL, NULL, NULL, 'N�o sobrecarregues os teus dias com preocupa��es desnecess�rias, a fim de que n�o percas a oportunidade de viver com alegria', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1325, NULL, NULL, NULL, 'N�o siga caminhos j�  tra�ados busque suas  pr�prias trilhas', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1326, NULL, NULL, NULL, 'N�o seja impaciente. A felicidade nem sempre est� longe de si', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1327, NULL, NULL, NULL, 'N�o sei o que o futuro encerra, mas sei quem encerra o futuro', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1328, NULL, NULL, NULL, 'N�o se preocupe em entender. Viver ultrapassa todo entendimento. Mergulhe no que voc� n�o conhece', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1329, NULL, NULL, NULL, 'N�o se preocupe com o fato de todos n�o concordarem com voc�. Se conseguir que um ter�o, j� pode considerar-se um vencedor', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1330, NULL, NULL, NULL, 'N�o s�o as adversidades que tornam mau o nosso dia, mas a nossa impaci�ncia', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1331, NULL, NULL, NULL, 'N�o sabemos quem realmente somos at� que possamos ver o que somos capazes de fazer', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1332, NULL, NULL, NULL, 'N�o procure saber as respostas, procure compreender as perguntas', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1333, NULL, NULL, NULL, 'N�o pretenda vencer os grandes obst�culos com os bra�os, mas sim com a cabe�a', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1334, NULL, NULL, NULL, 'N�o possuir algumas das coisas que desejamos � parte indispens�vel da felicidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1335, NULL, NULL, NULL, 'N�o podemos permitir que algu�m saia de nossa presen�a sem se sentir melhor e mais felizes', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1336, NULL, NULL, NULL, 'N�o permita que as experi�ncia endure�am seu cora��o. Ao inv�s disso, utilize-as para se tornar mais consciente e sens�vel', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1337, NULL, NULL, NULL, 'N�o olhem coisas que j� existam e perguntem: por qu�? Sonhe coisas que n�o existam e pergunte: por que n�o?', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1338, NULL, NULL, NULL, 'N�o mostre ao seu Deus o tamanho do seu problema, mostre ao seu problema o tamanho do seu Deus', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1339, NULL, NULL, NULL, 'N�o importa quem me pode apoiar quando tenho raz�o, o que quero � o apoio de algu�m quando esta me falta', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1340, NULL, NULL, NULL, 'N�o importa o qu�o dif�cil tenha sido o passado. Podemos sempre recome�ar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1341, NULL, NULL, NULL, 'N�o h� saber mais ou saber menos: h� saberes diferentes', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1342, NULL, NULL, NULL, 'N�o h� noite t�o longa que n�o encontre o dia', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1343, NULL, NULL, NULL, 'N�o h� ningu�m que precise tanto de um sorriso, como aquele que j� perdeu a vontade de sorrir', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1344, NULL, NULL, NULL, 'N�o h� nada mais fant�stico do que a realidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1345, NULL, NULL, NULL, 'N�o h� nada que melhor defina uma pessoa do que aquilo que ela faz quando tem toda a liberdade de escolha', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1346, NULL, NULL, NULL, 'N�o h� fatos eternos, como n�o h� verdades absolutas', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1347, NULL, NULL, NULL, 'N�o h� cura para o nascimento e a morte, a n�o ser usufruir o intervalo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1348, NULL, NULL, NULL, 'N�o existe inverno no reino da esperan�a', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1349, NULL, NULL, NULL, 'N�o � t�o importante ser s�rio. � importante ser s�rio nas coisas importantes', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1350, NULL, NULL, NULL, 'N�o � suficiente falar sobre a paz. � preciso acreditar nela E n�o basta acreditar nela. � preciso trabalhar para alcan�a-la', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1351, NULL, NULL, NULL, 'N�o � a quantidade de anos que vivemos, e sim o que fazemos com a vida que realmente conta', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1352, NULL, NULL, NULL, 'N�o digas que perdeu, sem pelo menos ter tentado', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1353, NULL, NULL, NULL, 'N�o despreze a opini�o daquele que se mant�m calado', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1354, NULL, NULL, NULL, 'N�o diga a Deus que voc� tem um grande problema, mas diga ao problema que voc� tem um grande Deus', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1355, NULL, NULL, NULL, 'N�o desfrute somente o sol, aprecie tamb�m a lua', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1356, NULL, NULL, NULL, 'N�o corra atr�s das borboletas. Cuide do seu jardim e elas vir�o at� voc�!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1357, NULL, NULL, NULL, 'N�o corra atr�s das borboletas, plante uma flor em seu jardim e todas as borboletas vir�o at� ela', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1358, NULL, NULL, NULL, 'N�o agarre a dor como pretexto para sofrer. Use-a para crescer !', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1359, NULL, NULL, NULL, 'N�o acrescente dias a sua vida, mas vida aos seus dias', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1360, NULL, NULL, NULL, 'N�o abras uma porta que n�o sejas capaz de voltar a fechar, nem feches uma porta que n�o sejas capaz de reabrir', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1361, NULL, NULL, NULL, 'Nada existe de permanente a n�o ser a mudan�a', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1362, NULL, NULL, NULL, 'Nada � bastante para quem considera pouco o suficiente', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1363, NULL, NULL, NULL, 'Na vida h� escadas que sobem e que descem. Os que est�o em cima dos debaixo se esquecem!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1364, NULL, NULL, NULL, 'Muitos cr�em que ter talento � uma sorte; mas ningu�m pensa que a sorte pode ser quest�o de talento', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1365, NULL, NULL, NULL, 'Muito mais vale a tristeza de ter perdido, do que a dor e a vergonha de n�o ter lutado!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1366, NULL, NULL, NULL, 'Muitas vezes uma s� hora � a representa��o de uma vida inteira', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1367, NULL, NULL, NULL, 'Muita gente vai entrar e sair da sua vida. Mas somente verdadeiros amigos deixar�o marcas em seu cora��o', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1368, NULL, NULL, NULL, 'Mesmo o amor que n�o compensa � melhor que a solid�o', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1369, NULL, NULL, NULL, 'Mesmo estando na estrada certa, voc� ser� atropelado se ficar apenas sentado nela', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1370, NULL, NULL, NULL, 'Melhor � serem dois do que um, pois se um cair o outro levanta', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1371, NULL, NULL, NULL, 'Mais vale a l�grima da derrota, do que a vergonha de n�o ter lutado!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1372, NULL, NULL, NULL, 'Mais triste do que um sorriso triste � a tristeza de n�o saber sorrir', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1373, NULL, NULL, NULL, 'Mais aprecio uma grama de bom exemplo do que cem quilos de palavras', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1374, NULL, NULL, NULL, 'Lute sempre pelo que desejares, pois s� os fracos desistem e s� quem luta � digno da vida', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1375, NULL, NULL, NULL, 'Juntos ficamos unidos, separados estamos perdidos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1376, NULL, NULL, NULL, 'Liderar n�o � impor, mas despertar nos outros a vontade de fazer', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1377, NULL, NULL, NULL, 'Jamais haver� ano novo se continuar a copiar os erros dos anos velhos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1378, NULL, NULL, NULL, 'J� que voc� tem que pensar de qualquer forma, pense grande', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1379, NULL, NULL, NULL, 'Jamais diga uma mentira que n�o possa provar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1380, NULL, NULL, NULL, 'Imposs�vel � aquilo que ningu�m fez at� que algu�m o fa�a', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1381, NULL, NULL, NULL, 'Humor n�o � um estado de esp�rito, mas uma vis�o de mundo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1382, NULL, NULL, NULL, 'Homem s�bio � aquele que renova constantemente o seu desejo de descobrir', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1383, NULL, NULL, NULL, 'Hoje sonho ser o que era quando sonhava ser o que sou', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1384, NULL, NULL, NULL, 'H� tr�s etapas na vida de um homem: - Acreditar em Papai Noel, n�o acreditar em Papai Noel e Ser o Papai Noel', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1385, NULL, NULL, NULL, 'H� tr�s coisas que nunca voltam atr�s: A flecha lan�ada, a palavra pronunciada e a oportunidade perdida', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1386, NULL, NULL, NULL, 'H� quem se fa�a rico, n�o tendo coisa alguma, e quem se fa�a pobre, tendo grande riqueza', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1387, NULL, NULL, NULL, 'H� quem passe pelo bosque e s� veja lenha para a fogueira', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1388, NULL, NULL, NULL, 'H� quedas que provocam ascens�es maiores', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1389, NULL, NULL, NULL, 'H� pessoas t�o alegres, t�o meigas, t�o felizes que ao entrar numa habita��o parece que lhe d�o luz', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1390, NULL, NULL, NULL, 'H� pessoas que vivem em solid�o, porque constru�ram pontes em torno de si, ao inv�s de pontes ligando-as a outros', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1391, NULL, NULL, NULL, 'H� pessoas que choram por saber que as rosas t�m espinhos; outras gargalham de alegria por saber que os espinhos t�m rosas', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1392, NULL, NULL, NULL, 'H� pessoas desagrad�veis, apesar de suas qualidades, e outras encantadoras, apesar de seus defeitos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1393, NULL, NULL, NULL, 'H� apenas um fim digno: amor', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1394, NULL, NULL, NULL, 'Grandes mentes discutem id�ias; Mentes medianas discutem eventos; Mentes pequenas discutem pessoas', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1395, NULL, NULL, NULL, 'Grandes esp�ritos tem metas, os outros apenas desejos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1396, NULL, NULL, NULL, 'Feliz aquele que transfere o que sabe e aprende o que ensina', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1397, NULL, NULL, NULL, 'Felicidade, muitas vezes, n�o � s� conseguir o que deseja, mas dar valor ao que se tem', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1398, NULL, NULL, NULL, 'Felicidade � o ato de aproveitar o que possu�mos sem reclamar aquilo que ainda n�o conquistamos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1399, NULL, NULL, NULL, 'Fazemos nossos caminhos e lhes chamamos destino', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1400, NULL, NULL, NULL, 'Fa�a pequenas coisas agora e maiores coisas lhe ser�o confiadas cada dia', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1401, NULL, NULL, NULL, 'Experi�ncia n�o � o que acontece com um homem; � o que um homem faz com o que lhe acontece', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1402, NULL, NULL, NULL, 'Excluindo o imposs�vel, o que restar, por mais improv�vel, deve ser a verdade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1403, NULL, NULL, NULL, 'Eu vou a qualquer lugar, contanto que seja para a frente', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1404, NULL, NULL, NULL, 'Eu sempre estou fazendo o que eu n�o posso fazer, para que eu possa aprender a fazer', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1405, NULL, NULL, NULL, 'Eu que me queixava de n�o ter sapatos, encontrei um homem feliz que n�o tinha p�s', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1406, NULL, NULL, NULL, 'Estarei destruindo meus inimigos quando os transformo em amigos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1407, NULL, NULL, NULL, 'Espere o melhor, prepare-se para o pior e receba o que vier', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1408, NULL, NULL, NULL, 'Errar � humano mas faz voc� se sentir divino', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1409, NULL, NULL, NULL, 'Enquanto voc� acreditar, o medo n�o vai se instalar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1410, NULL, NULL, NULL, 'Embora ningu�m possa voltar atr�s e fazer um novo come�o, qualquer um pode come�ar agora a fazer um novo fim', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1411, NULL, NULL, NULL, 'Em todo homem bom Deus habita', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1412, NULL, NULL, NULL, 'Em nossas ilus�es, renunciamos ao que possu�mos pelo que esperamos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1413, NULL, NULL, NULL, 'Em ess�ncia, o exerc�cio da paci�ncia nos protege da perda da confian�a', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1414, NULL, NULL, NULL, 'Eis um teste para saber se voc� terminou sua miss�o na Terra: se voc� est� vivo, n�o terminou', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1415, NULL, NULL, NULL, '� sempre melhor ser otimista do que pessimista. At� que tudo d� errado, o otimista sofreu menos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1416, NULL, NULL, NULL, '� quando fugimos que estamos mais sujeitos a trope�ar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1417, NULL, NULL, NULL, '� preciso saber lutar como um le�o, mas lutar por sonhos que valham a pena', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1418, NULL, NULL, NULL, '� preciso pensar para acertar, calar para resistir e agir para vencer', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1419, NULL, NULL, NULL, '� nada fazendo que se aprende a fazer o mal', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1420, NULL, NULL, NULL, '� muito f�cil ser pedra o dif�cil � ser vidra�a', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1421, NULL, NULL, NULL, '� melhor aproximadamente agora do que exatamente nunca', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1422, NULL, NULL, NULL, '� loucura para o carneiro promover uma confer�ncia de paz com o lobo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1423, NULL, NULL, NULL, '� justamente a possibilidade de realizar um sonho que torna a vida interessante', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1424, NULL, NULL, NULL, '� importante entender que o sofrimento quase sempre � uma op��o individual', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1425, NULL, NULL, NULL, '� bom ser importante, mas, na verdade, o importante � ser bom', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1426, NULL, NULL, NULL, '� bem mais df�cil julgar a si mesmo que julgar os outros. Se conseguirem julgar-te bem, eis um verdadeiro s�bio', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1427, NULL, NULL, NULL, 'Dois homens olharam atrav�s das grades da pris�o, um viu lama, o outro as estrelas', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1428, NULL, NULL, NULL, 'Devemos ser bons. N�o existem esfor�os in�teis quando empregados em prol da coletividade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1429, NULL, NULL, NULL, 'Deus est� nas coincid�ncias', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1430, NULL, NULL, NULL, 'Devagar! Quem mais corre, mais trope�a!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1431, NULL, NULL, NULL, 'Deus criou o homem porque gosta de hist�rias de amor', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1432, NULL, NULL, NULL, 'Destino n�o � uma quest�o de chance, � uma quest�o de escolha', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1433, NULL, NULL, NULL, 'Dentre os mais dignos predicados de um homem est� o de saber dizer a verdade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1434, NULL, NULL, NULL, 'D�-me um ponto de apoio e moverei o mundo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1435, NULL, NULL, NULL, 'Defeitos n�o fazem mal, quando h� vontade e poder de os corrigir', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1436, NULL, NULL, NULL, 'Daqui a vinte anos, voc� estar� mais desapontado com as coisas que voc� deixou de fazer do que pelos erros que cometeu', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1437, NULL, NULL, NULL, 'Cuide mais de seu car�ter, pois sua reputa��o � o que as pessoas pensam que voc� �. E o seu car�ter � o que voc� realmente �!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1438, NULL, NULL, NULL, 'Corra riscos, se voc� vencer, ficar� feliz, se perder, ficar� s�bio', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1439, NULL, NULL, NULL, 'Coragem � resist�ncia ao medo, dom�nio do medo, e n�o aus�ncia de medo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1440, NULL, NULL, NULL, 'Comemore o seu sucesso. Veja com humor os seus fracassos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1441, NULL, NULL, NULL, 'Come�ar j� � a metade de toda a��o', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1442, NULL, NULL, NULL, 'Comece fazendo o que � necess�rio, depois o que � poss�vel, e de repente voc� estar� fazendo o imposs�vel', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1443, NULL, NULL, NULL, 'Com paci�ncia o c�u se ganha', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1444, NULL, NULL, NULL, 'Chorar sobre as desgra�as passadas � a maneira mais segura de atrair outras', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1445, NULL, NULL, NULL, 'Cada qual sabe amar a seu modo, o modo pouco importa, o essencial � que saiba amar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1446, NULL, NULL, NULL, 'Cada pessoa atrai dois tipos de acontecimentos: aqueles em que ela acredita e aqueles que ela teme', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1447, NULL, NULL, NULL, 'Cada novo dia nos repete: espera o imposs�vel, fa�a o poss�vel', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1448, NULL, NULL, NULL, 'Cada minuto que passamos com raiva, perdemos sessenta felizes segundos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1449, NULL, NULL, NULL, 'Cada lar onde habitam o amor e a amizade � um lugar de ternura e afei��o, onde o cora��o pode tranq�ilamente repousar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1450, NULL, NULL, NULL, 'Cada homem tem a sua hora. Cabe a cada um escolh�-la', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1451, NULL, NULL, NULL, 'Cada crian�a, ao nascer, nos traz a mensagem de que Deus ainda n�o perdeu a esperan�a nos homens', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1452, NULL, NULL, NULL, 'Bom senso � a capacidade de ver as coisas como s�o e faz�-las como devem ser feitas', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1453, NULL, NULL, NULL, 'Bem-feito � melhor do que bem explicado', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1454, NULL, NULL, NULL, 'Assuma riscos calculados. Isto � bem diferente de ser imprudente', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1455, NULL, NULL, NULL, '�s vezes na vida � bom deixar o cora��o falar al�m da raz�o! Ou�a o seu cora��o, ele � a voz de Deus falando dentro de voc�!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1456, NULL, NULL, NULL, 'As vezes � melhor calar um sentimento do que express�-lo a quem n�o possa entend�-lo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1457, NULL, NULL, NULL, 'As pessoas podem duvidar do que voc� diz, mais acreditar�o sempre no que voc� faz', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1458, NULL, NULL, NULL, 'As pessoas est�o se esquecendo do quanto � gostoso sair s� para se divertir, conhecer gente, trocar afetos e fazer amizades', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1459, NULL, NULL, NULL, 'As pessoas costumam sofrer mais do que a situa��o exige', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1460, NULL, NULL, NULL, 'As perguntas mais simples s�o as mais profundas. Pense sobre isso, de vez em quando, e observe as suas respostas se modificarem', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1461, NULL, NULL, NULL, 'As palavras s�o como moedas: uma vale por muitas, e muitas n�o valem por uma', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1462, NULL, NULL, NULL, 'As oportunidades s�o como o nascer do sol; se voc� esperar demais vai perd�-las', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1463, NULL, NULL, NULL, 'As melhores e mais belas coisas do mundo n�o podem ser vistas nem tocadas, mas sentidas', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1464, NULL, NULL, NULL, 'As l�grimas n�o significam a fraquesa e sim a coragem de assumir um sentimento', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1465, NULL, NULL, NULL, 'As flores chegam at� a perfumar a m�o que as esmaga', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1466, NULL, NULL, NULL, 'As dificuldades n�o esmagam um homem, fazem-no', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1467, NULL, NULL, NULL, 'As adversidades s�o como as facas, que nos podem ser �teis ou nos cortar, conforme as sugeremos pela l�mina ou pelo cabo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1468, NULL, NULL, NULL, 'Artista � aquele que muitas vezes ri para que os outros n�o chorem', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1469, NULL, NULL, NULL, 'Aqueles que se respeitam e se amam a si mesmos devem estar sempre alerta, a fim de que n�o o sejam vencidos pelos maus desejos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1470, NULL, NULL, NULL, 'Aquele que se julga com direito de criticar deve ter tamb�m um cora��o bondoso para ajudar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1471, NULL, NULL, NULL, 'Aquele que pode reprimir um momento de raiva pode evitar um dia de aborrecimento', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1472, NULL, NULL, NULL, 'Aquele que caminha sozinho pode at� chegar mais rapido...Mais aquele que vai acompanhado com certeza chegar� mais longe', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1473, NULL, NULL, NULL, 'Aproveite o dia, acreditando o m�nimo poss�vel no dia de amanh�', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1474, NULL, NULL, NULL, 'Aproveite a chance enquanto o vento est� soprando favoravelmente', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1475, NULL, NULL, NULL, 'Apenas � digno da vida aquele que todos os dias parte para ela em combate', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1476, NULL, NULL, NULL, 'Antes de reagir, observe', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1477, NULL, NULL, NULL, 'Antes de perder a calma, procure seu senso de humor', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1478, NULL, NULL, NULL, 'Amizade � como m�sica: Duas cordas afinadas no mesmo tom vibram juntas', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1479, NULL, NULL, NULL, 'Amigo: algu�m que sabe de tudo a teu respeito e gosta de ti assim mesmo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1480, NULL, NULL, NULL, 'Amigos jamais se separam, apenas trilham caminhos diferentes', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1481, NULL, NULL, NULL, 'Amigo n�o � aquele que te alegra com as mentiras e sim aquele que te fere com as verdades.!!!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1482, NULL, NULL, NULL, 'Amigo � a melhor coisa que voc� pode ter, e a melhor coisa que voc� pode ser', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1483, NULL, NULL, NULL, 'Amar � encontrar na felicidade de outrem a pr�pria felicidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1484, NULL, NULL, NULL, 'Ainda n�o encontrei homem algum bem-sucedido na vida que n�o houvesse antes sofrido derrotas tempor�rias', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1488, NULL, NULL, NULL, 'A vida por fora de n�s � um reflexo daquilo que somos por dentro', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1490, NULL, NULL, NULL, 'A vida n�o � tanto uma quest�o de acharmos a n�s mesmos, e sim um processo de fazermos a n�s mesmos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1491, NULL, NULL, NULL, 'A vida n�o deixa de ser divertida quando algu�m morre, assim como n�o deixa de ser s�ria quando as pessoas riem', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1492, NULL, NULL, NULL, 'A vida � uma longa li��o de humildade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1493, NULL, NULL, NULL, 'A vida � uma com�dia para aquele que pensa, uma trag�dia para aquele que sente, e uma vit�ria para aquele que cr�', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1494, NULL, NULL, NULL, 'A vida � um peda�o de m�rmore, do qual devemos modelar, cinzelar e esculpir o nosso car�ter', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1495, NULL, NULL, NULL, 'A vida � um milh�o de novos come�os, movidos pelo desafio sempre novo de viver e fazer sonhar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1496, NULL, NULL, NULL, 'A vida � um eco. Se n�o est� gostando do que est� recebendo, observe o que est� emitindo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1497, NULL, NULL, NULL, 'A vida � como um livro que deve ser folheado p�gina por p�gina sem se consultar o �ndice', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1498, NULL, NULL, NULL, 'A vida � a arte do possivel', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1499, NULL, NULL, NULL, 'A verdade � filha do tempo, n�o da autoridade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1500, NULL, NULL, NULL, 'A verdadeira amizade � como a sa�de perfeita, seu valor raramente � reconhecido at� que seja perdida', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1501, NULL, NULL, NULL, 'A �nica maneira de ter um amigo � sendo um', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1502, NULL, NULL, NULL, 'A sutileza pode enganar-nos; a integridade, nunca', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1503, NULL, NULL, NULL, 'A saudade � a maior prova de que o passado valeu a pena', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1504, NULL, NULL, NULL, 'A probabilidade de fracassarmos na luta n�o nos deve deter no impulso de combater por uma causa justa', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1505, NULL, NULL, NULL, 'A principal maneira de algu�m conhecer sua grandeza � pela intensidade de amor que seu cora��o abriga', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1506, NULL, NULL, NULL, 'A pregui�a caminha t�o devagar que a pobreza depressa a alcan�a', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1507, NULL, NULL, NULL, 'A pior maneira de n�o chegar a determinado lugar � pensar que j� se est� l�', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1508, NULL, NULL, NULL, 'A pessoa mais pobre � aquela que s� tem dinheiro', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1509, NULL, NULL, NULL, 'A persist�ncia � o caminho do �xito', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1510, NULL, NULL, NULL, 'A ora��o � a energia da vida, permeando todo o universo e tornando-se for�a motriz para a mudan�a', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1511, NULL, NULL, NULL, 'A nossa sorte n�o se encontra fora de n�s, mas em n�s mesmos e em nossa vontade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1512, NULL, NULL, NULL, 'A natureza deu-nos orelhas e uma s� boca, para nos advertir que se imp�e mais ouvir do que falar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1513, NULL, NULL, NULL, 'A morte do homem come�a no instante em que ele desiste de aprender', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1514, NULL, NULL, NULL, 'A mente que se abre a uma nova id�ia jamais volta ao seu tamanho original', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1515, NULL, NULL, NULL, 'A melhor maneira de ser feliz � contribuir para a felicidade dos outros', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1516, NULL, NULL, NULL, 'A melhor maneira de prever o futuro � invent�-lo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1517, NULL, NULL, NULL, 'A melhor maneira de melhorar o padr�o de vida est� em melhorar o padr�o de pensamentos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1518, NULL, NULL, NULL, 'A melhor maneira de ensinar ao menino o caminho em que deve andar � n�s mesmos trilharmos esse caminho', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1520, NULL, NULL, NULL, 'A marca de uma boa a��o � que ela parece inevit�vel na retrospectiva', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1521, NULL, NULL, NULL, 'A maior virtude do homem � talvez a curiosidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1522, NULL, NULL, NULL, 'A luta � indispens�vel para realizar as metas da alma, ou seja, lutar � saud�vel quando se constr�i a felicidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1523, NULL, NULL, NULL, 'A inveja, a raiva e os insultos, quando n�o aceitos, continuam pertencendo a quem os carrega consigo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1524, NULL, NULL, NULL, 'A inspira��o chega. Mas ela tem que te encontrar trabalhando', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1525, NULL, NULL, NULL, 'A informa��o mais necess�ria � sempre a menos dispon�vel', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1526, NULL, NULL, NULL, 'A infelicidade tem isto de bom: faz-nos conhecer os verdadeiros amigos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1527, NULL, NULL, NULL, 'A ignor�ncia � uma esp�cie de b�n��o. Se voc� n�o sabe, n�o existe dor', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1528, NULL, NULL, NULL, 'A ignor�ncia nos obriga a fazer duas vezes o mesmo caminho', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1529, NULL, NULL, NULL, 'A humildade pode n�o ser a maior, mas certamente � a mais bela de todas as virtudes', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1530, NULL, NULL, NULL, 'A grandeza do mar � formada de gotas', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1531, NULL, NULL, NULL, 'A grandeza de um pa�s n�o depende da extens�o de seu territ�rio, mas do car�ter do seu povo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1532, NULL, NULL, NULL, 'A gl�ria � tanto mais tardia quanto mais duradoura h� de ser, porque todo fruto delicioso amadurece lentamente', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1533, NULL, NULL, NULL, 'A feliicidade as vezes � uma ben��o, mas geralmente � uma conquista', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1534, NULL, NULL, NULL, 'A felicidade n�o est� no fim da jornada, e sim em cada curva do caminho que percorremos para encontr�-la', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1535, NULL, NULL, NULL, 'A felicidade n�o � uma recompensa, � uma conseq��ncia', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1536, NULL, NULL, NULL, 'A felicidade n�o � uma coisa que se experimenta; � algo que se recorda', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1537, NULL, NULL, NULL, 'A felicidade n�o depende do que nos falta, mas do bom uso que fazemos do que temos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1538, NULL, NULL, NULL, 'A felicidade � uma experi�ncia ligada � sabedoria', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1539, NULL, NULL, NULL, 'A felicidade � um bem que se multiplica ao ser dividido', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1540, NULL, NULL, NULL, 'A felicidade � feita de pequenas p�rolas que voc� cultiva a cada dia, a cada hora', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1541, NULL, NULL, NULL, 'A felicidade � a �nica coisa que podemos dar sem possuir', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1542, NULL, NULL, NULL, 'A felicidade depende mais do estado de esp�rito do que das circunst�ncias exteriores', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1543, NULL, NULL, NULL, 'A f� � a for�a da vida. Se o homem vive � porque acredita em alguma coisa', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1544, NULL, NULL, NULL, 'A f� compreende o que � invis�vel', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1545, NULL, NULL, NULL, 'A esperan�a � um bom desjejum, mas um p�ssimo jantar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1546, NULL, NULL, NULL, 'A esperan�a � o sonho do homem acordado', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1547, NULL, NULL, NULL, 'A educa��o n�o � o preencher de um vaso; � o acender de uma chama', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1548, NULL, NULL, NULL, 'A desgra�a pode ser uma ponte para a felicidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1549, NULL, NULL, NULL, 'A coragem n�o � necess�ria apenas nos entreveros das batalhas, mas na hora crucial da decis�o entre o bem e o mal', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1550, NULL, NULL, NULL, 'A coragem � a primeira das qualidades humanas, porque � a que garante as outras', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1551, NULL, NULL, NULL, 'A consci�ncia � como a luz, ningu�m a nota. No entanto, ela ilumina tudo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1552, NULL, NULL, NULL, 'A cada minuto que ficamos zangados perdemos sessenta segundos de felicidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1553, NULL, NULL, NULL, 'A bondade � uma for�a invenc�vel', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1554, NULL, NULL, NULL, 'A amizade verdadeira desce abaixo das ra�zes ou se eleva acima das estrelas', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1555, NULL, NULL, NULL, 'A amizade perfeita n�o pode existir sen�o entre os bons', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1556, NULL, NULL, NULL, 'A amizade nasce no momento em que uma pessoa diz para outra: O qu�? Voc� tamb�m? Pensei que fosse o �nico!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1557, NULL, NULL, NULL, 'A amizade � uma alma com dois corpos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1558, NULL, NULL, NULL, 'A amizade � um amor que nunca morre', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1560, NULL, NULL, NULL, 'A alegria e o amor s�o duas asas para as grandes a��es', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1561, NULL, NULL, NULL, 'A adversidade apresenta o homem a si mesmo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1562, NULL, NULL, NULL, 'Frases', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1563, NULL, NULL, NULL, 'Saber ouvir quase que � responder', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1564, NULL, NULL, NULL, 'Saia primeiramente do ch�o para depois conseguir alcan�ar o topo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1565, NULL, NULL, NULL, 'S�o os nossos inimigos que nos ensinam as mais valiosas li��es de vida', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1566, NULL, NULL, NULL, 'Se a vida lhe nega tudo o que voc� quer, � porque ela tem algo melhor para lhe oferecer', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1567, NULL, NULL, NULL, 'Se deres a costas � luz nada mais ver�s do que a tua pr�pria sombra', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1568, NULL, NULL, NULL, 'Se deseja atingir o ponto mais alto, comece pelo mais baixo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1569, NULL, NULL, NULL, 'Se � a raz�o que faz o homem, � o sentimento que o conduz', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1570, NULL, NULL, NULL, 'Se fizer rir as pessoas, desperta-lhes a aten��o, podendo depois falar-lhe de quase tudo o que quiser', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1571, NULL, NULL, NULL, 'Se n�o houvesse esperan�a, n�o estar�amos lutando', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1572, NULL, NULL, NULL, 'Se n�o houvesse inverno, a primavera n�o seria t�o boa', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1573, NULL, NULL, NULL, 'Se n�o nos habituarmos a esperar o inesperado, quando ele vier n�o o reconheceremos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1574, NULL, NULL, NULL, 'Se n�o podes ser o que �s, s� com sinceridade o que podes', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1575, NULL, NULL, NULL, 'Se n�o puder se destacar pelo talento, ven�a pelo esfor�o', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1576, NULL, NULL, NULL, 'Se n�o puderes pensar bem de algu�m, esque�a-o', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1577, NULL, NULL, NULL, 'Se n�o se pode falar bem de uma pessoa � melhor que n�o se diga nada', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1578, NULL, NULL, NULL, 'Se o trov�o n�o for alto, o campon�s esquece da colheita', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1579, NULL, NULL, NULL, 'Se podemos sonhar, tamb�m podemos tornar nossos sonhos realidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1580, NULL, NULL, NULL, 'Se queres ser feliz amanh�, tenta hoje mesmo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1581, NULL, NULL, NULL, 'Se seus sonhos estiverem nas nuvens, n�o se preocupe, pois eles est�o no lugar certo; agora construa os alicerces', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1582, NULL, NULL, NULL, 'Se todos os seus esfor�os forem vistos com indiferen�a, n�o desanime, pois est� fazendo a sua parte', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1583, NULL, NULL, NULL, 'Se um homem tiver alguma grandeza dentro de si, ela aparecer� n�o em um momento espetacular, mas no registro do seu dia-a-dia', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1584, NULL, NULL, NULL, 'Se uma coisa pequena tem o poder de faz�-lo irritado, isto n�o lhe indica nada a respeito do seu pr�prio tamanho?', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1585, NULL, NULL, NULL, 'Se voc� cometeu algum erro, isso significa tempo de aprender e n�o de desistir', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1586, NULL, NULL, NULL, 'Se voc� continuar fazendo o que sempre fez, vai continuar conseguindo o que sempre conseguiu', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1587, NULL, NULL, NULL, 'Se voc� n�o tem fracassos na vida, � porque deixou de assumir os riscos que devia', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1588, NULL, NULL, NULL, 'Se voc� se contenta com menos do que pode ser, ser� infeliz pelo resto da vida', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1589, NULL, NULL, NULL, 'Se voc� se sente s� � porque construiu muro em vez de pontes', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1590, NULL, NULL, NULL, 'Sei que meu trabalho � uma gota no oceano, mas sem ele, o oceano seria menor', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1591, NULL, NULL, NULL, 'Seja forte! N�o como uma onda que tudo destr�i, mas como uma rocha que tudo suporta', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1592, NULL, NULL, NULL, 'Seja l� o que voc� possa fazer, ou sonhe que pode, comece. A ousadia tem g�nio, poder e magia dentro de si. Comece agora', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1593, NULL, NULL, NULL, 'Sejam esses tempos os melhores ou os piores, � o �nico tempo que temos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1594, NULL, NULL, NULL, 'Sempre � hora de fazer o que � certo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1595, NULL, NULL, NULL, 'Sempre tive pena de mim mesmo porque n�o tinha sapatos, at� que encontrei um homem que n�o tinha p�s', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1596, NULL, NULL, NULL, 'Sempre, sobre qualquer aspecto, irei cada vez melhor!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1597, NULL, NULL, NULL, 'Ser amigo de si pr�prio � compreender seus erros e ser seu c�mplice para enfrentar os desafios', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1598, NULL, NULL, NULL, 'Serenidade para aceitar as coisas que n�o posso mudar, coragem para mudar as que posso e sabedoria para conhecer a diferen�a', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1599, NULL, NULL, NULL, 'Sermos bons com os outros e com n�s pr�prios, ajud�-los a viver, ajudarmo-nos a viver, eis a verdadeira caridade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1600, NULL, NULL, NULL, 'S� existem 2 dias onde n�o podemos fazer nada; Ontem e amanh�!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1601, NULL, NULL, NULL, 'S� n�o erra nunca o que nunca faz nada', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1602, NULL, NULL, NULL, 'S� se v� com o cora��o. O essencial � invis�vel aos olhos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1603, NULL, NULL, NULL, 'S� uma coisa pode tornar um sonho imposs�vel: o medo de fracassar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1604, NULL, NULL, NULL, 'S� uma pessoa que nada aprendeu n�o modifica suas opini�es', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1605, NULL, NULL, NULL, 'Sofrer ou n�o � uma decis�o de cada pessoa e de mais ningu�m', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1606, NULL, NULL, NULL, 'Somente a pessoa que cr� em si mesma � capaz de crer nos outros', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1607, NULL, NULL, NULL, 'Somos anjos de uma asa s� e s� conseguiremos voar abra�ados uns aos outros', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1608, NULL, NULL, NULL, 'Somos muito mais infelizes na infelicidade do que felizes na felicidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1609, NULL, NULL, NULL, 'Somos o que fazemos, mas somos principalmente o que fazemos para mudar o que somos', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1610, NULL, NULL, NULL, 'Somos senhores das palavras que n�o pronunciamos, mas escravos das que nos escapam', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1611, NULL, NULL, NULL, 'Sonhar � acordar-se para dentro', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1612, NULL, NULL, NULL, 'Sorria para a vida a fim de que ela seja a sua pr�pria alegria de viver. A partir da�, a felicidade estar� permanentemente ao seu', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1613, NULL, NULL, NULL, 'Sua vida muda quando voc� muda', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1614, NULL, NULL, NULL, 'Supervisionar � ensinar os outros a aprender consigo mesmo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1615, NULL, NULL, NULL, 'Temos que perder para aprender', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1616, NULL, NULL, NULL, 'Tenho prazer em ser vencido quando quem me vence � a raz�o, seja quem for o seu procurador', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1617, NULL, NULL, NULL, 'Tentar e falhar �, pelo menos, aprender. N�o chegar a tentar � sofrer a inestim�vel perda do que poderia ter sido', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1618, NULL, NULL, NULL, 'Tente mover o mundo - o primeiro passo ser� mover a si mesmo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1619, NULL, NULL, NULL, 'Ter amigos � muito importante, por�m t�o importante quanto ter amigos � ser um amigo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1620, NULL, NULL, NULL, 'Todas as maravilhas que voc� precisa est�o dentro de voc�', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1621, NULL, NULL, NULL, 'Todas as pessoas do mundo sorriem no mesmo idioma', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1622, NULL, NULL, NULL, 'Todas as tentativas s�o v�lidas. Nada que se tente � in�til', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1623, NULL, NULL, NULL, 'Todo idiota procura um culpado, todo s�bio procura uma solu��o', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1624, NULL, NULL, NULL, 'Todos nascemos iguais. O que nos distingue � a virtude', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1625, NULL, NULL, NULL, 'Trate as pessoas da forma como elas devem ser e ajude-as a se tornarem o que elas s�o capazes de ser', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1626, NULL, NULL, NULL, 'Triste n�o � mudar de id�ia. Triste � n�o ter id�ia para mudar', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1627, NULL, NULL, NULL, 'Tu te tornas eternamente respons�vel por aquilo que cativas', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1628, NULL, NULL, NULL, 'Um dia percebemos que a pessoa que nunca te liga � a que mais pensa em voc�', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1629, NULL, NULL, NULL, 'Um erro reconhecido com simplicidade � uma vit�ria ganha', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1630, NULL, NULL, NULL, 'Um home prudente � como um alfinete: Sua cabeca o impede de ir muito longe', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1631, NULL, NULL, NULL, 'Um olhar carinhoso faz de um prato comum, um banquete', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1632, NULL, NULL, NULL, 'Um otimista v� uma oportunidade em cada calamidade. Um pessimista v� uma calamidade em cada oportunidade', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1633, NULL, NULL, NULL, 'Uma alegria compartilhada se transforma em dupla alegria. Um sofrimento compartilhado se transforma em meio sofrimento', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1634, NULL, NULL, NULL, 'Uma alegria partilhada � uma dupla alegria, um desgosto partilhado � meio desgosto', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1635, NULL, NULL, NULL, 'Uma das armadilhas mais comuns da infelicidade � o adiantamento', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1636, NULL, NULL, NULL, 'Uma grande fortuna se faz com sorte, uma pequena, com esfor�o', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1637, NULL, NULL, NULL, 'Uma longa caminhada sempre come�a com o primeiro passo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1638, NULL, NULL, NULL, 'Uma palavra bonita n�o custa nada, mais vale muito, use-a com sabedoria!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1639, NULL, NULL, NULL, 'Uma pessoa n�o pode acertar num segmento de vida enquanto est� ocupada errando em qualquer outro. A vida � um todo indivis�vel!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1640, NULL, NULL, NULL, 'Uma vida gasta cometendo erros n�o � mais honrada, mas � mais �til do que uma vida gasta fazendo nada', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1641, NULL, NULL, NULL, 'Vencer n�o � competir com o outro. � derrotar os seus inimigos interiores. � a propria realiza��o do ser', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1642, NULL, NULL, NULL, 'Viva o presente, pois o passado j� passou e o futuro nunca chegar�!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1643, NULL, NULL, NULL, 'Vivemos de nossos desejos mais que de nossas obras', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1644, NULL, NULL, NULL, 'Viver � a coisa mais rara do mundo. A maioria das pessoas apenas existem', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1645, NULL, NULL, NULL, 'Voc� busca o poder e se pergunta como us�-lo, o verdadeiro poder n�o � algo a ser possu�do', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1646, NULL, NULL, NULL, 'Voc� � o �nico respons�vel pelo mal ou pelo bem que acontece em sua vida', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1647, NULL, NULL, NULL, 'Voc� � o �nico respons�vel por seu destino. Supere as dificuldades, ven�a os obst�culos e construa a sua vida', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1648, NULL, NULL, NULL, 'Voc� n�o conseguir� subir uma montanha se ficar pensando que vai cair', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1649, NULL, NULL, NULL, 'Voc� n�o pode direcionar o vento, mas pode ajustar as velas do barco', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1650, NULL, NULL, NULL, 'Voc� nunca sabe o que voc� tem at� isto se ir', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1651, NULL, NULL, NULL, 'Voc� pode se pensar que pode', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1652, NULL, NULL, NULL, 'Voc� quer ser feliz um instante? Vingue-se! Voc� quer ser feliz para sempre? Perdoe!', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1653, NULL, NULL, NULL, 'Voc� tem mais valor do que qualquer cargo', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1654, NULL, NULL, NULL, 'Voltar atr�s � melhor do que perder-se no caminho', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1655, NULL, NULL, 118, 'A pior forma de desigualdade � tentar fazer duas coisas diferentes iguais.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1656, NULL, NULL, 119, 'N�o existe seguran�a neste mundo. H� apenas oportunidade.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1657, NULL, NULL, 90, 'No final, n�o lembramos as palavras dos inimigos, mas o sil�ncio dos amigos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1658, NULL, NULL, 120, 'Nunca confunda movimento com a��o.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1659, NULL, NULL, 124, 'Calados n�o temos nem que repetir nem que explicar.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1660, NULL, NULL, 121, 'A estrada ao inferno � pavimentada com boas inten��es.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1661, NULL, NULL, 122, 'O pensamento � a a��o ensaiando.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1662, NULL, NULL, 123, 'A gratid�o � o cora��o da mem�ria.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1663, NULL, NULL, 125, 'A realidade � uma ilus�o, embora bastante persistente.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1664, NULL, NULL, 126, 'Quando voc� ensina o seu filho, ensina tamb�m o filho do seu filho.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1665, NULL, NULL, 127, '� mais f�cil perdoar um inimigo do que um amigo.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1666, NULL, NULL, 128, 'O nascimento � Deus dizendo que voc� � importante.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1667, NULL, NULL, 63, 'O bobo se acha s�bio, mas o s�bio se acha bobo.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1668, NULL, NULL, 92, 'A obra-prima � uma variedade do milagre.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1669, NULL, NULL, 98, 'Quando tenho um pouco de dinheiro, compro livros; se sobrar algum, compro roupas e comida.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1670, NULL, NULL, 129, 'Onde a imprensa � livre e todo homem � capaz de ler, tudo est� a salvo.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1671, NULL, NULL, 130, 'Devemos negociar com liberdade, mas jamais negociar a liberdade.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1672, NULL, NULL, 131, '� medida que envelhe�o, presto menos aten��o ao que as pessoas dizem; simplesmente observo o que fazem.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1673, NULL, NULL, 132, 'O pre�o da grandeza � a responsabilidade.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1674, NULL, NULL, 133, 'A sorte favorece a mente bem preparada.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1675, NULL, NULL, 134, 'O dinheiro n�o necessariamente tem qualquer liga��o com a felicidade. Talvez tenha com a infelicidade.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1676, NULL, NULL, 135, 'Muitos levam uma vida vazia, n�o param num emprego, n�o t�m relacionamentos duradouros e se mudam a esmo de lugar em lugar numa �rbita isolada - e ningu�m se importa com isso. A raz�o: S�o extremamente ricos.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1677, NULL, NULL, 75, 'O p�o � para o riso dos trabalhadores, e o pr�prio vinho alegra a vida; mas o dinheiro � o que encontra resposta em todas as coisas.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1678, NULL, 'internet', 0, 'Tente n�o ser um homem de sucesso, e sim um homem de valor.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1680, NULL, NULL, 0, '� humano ter ao seu lado a for�a de Deus e sentir-se fraco.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1681, NULL, 'internet', 0, 'A verdade machuca, mas a mentira machuca mais ainda.', 0);

-- inserting data
INSERT INTO TBLCITACAO (CODCITACAO, TITULO, FONTE, CODAUTOR, CITACAO, OCULTAR)
VALUES (1683, NULL, NULL, 0, 'O amor � como um violino. A m�sica pode parar, mas as cordas duram para sempre.', 0);
-- creating sequence for autonumber column
CREATE SEQUENCE SEQ_TBLOCUPACAO INCREMENT BY 1 START WITH 1 MINVALUE 1 NOMAXVALUE NOCACHE;

-- creating table
CREATE TABLE TBLOCUPACAO (
	CODOCUPACAO NUMBER (10) NOT NULL,
	NOME VARCHAR2 (50)
);

-- adding primary key
ALTER TABLE TBLOCUPACAO
  ADD CONSTRAINT PK_TBLOCUPACAO PRIMARY KEY (CODOCUPACAO);



-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (1, 'Autor');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (2, 'Escritor');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (3, 'Fil�sofo');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (4, 'Erudito');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (5, 'Rei');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (6, 'Religioso');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (7, 'Cientista');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (8, 'Colunista');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (9, 'Estadista');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (10, 'Poeta');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (11, 'Doutor');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (12, 'Psic�logo');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (13, 'Revista');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (14, 'Historiador');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (15, 'Editor de ci�ncias');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (16, 'Orador');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (17, 'Livro');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (18, 'Professor');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (19, 'Educador');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (20, 'Dramaturgo');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (21, 'Inventor');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (22, 'Enciclop�dia');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (23, 'L�der revolucion�rio');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (24, 'L�der dos direitos civis');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (25, 'L�der religioso');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (26, 'Compositor');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (27, 'Duque');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (28, 'Psicanalista');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (29, 'Ap�stolo');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (30, 'General');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (31, 'Rabi');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (32, 'Filantropo');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (33, 'Magnata');

-- inserting data
INSERT INTO TBLOCUPACAO (CODOCUPACAO, NOME)
VALUES (34, 'Jornal');
