--------------------------------------------
--------------- Dump details ---------------
--------------------------------------------
-- Original file: C:\cnvoracle\datashare\sysdoc.mdb
-- Dump date: 12-18-2024 10:13:26
--------------------------------------------

-- creating table
CREATE TABLE ALTERACAO (
	NUMERO NUMBER (10),
	ITEM NUMBER (10),
	DIZER CLOB,
	DATA DATE,
	ID NUMBER (10) NOT NULL
);



-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (1, 1, 'Inclusao Form Altera�ao', TO_DATE ('12-12-2003 11:15:26', 'MM-DD-RRRR HH24:MI:SS'), 1);

-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (1, 2, 'Inclusao Tabelas Tipos Caracteristicas Sistema', TO_DATE ('12-12-2003 12:45:03', 'MM-DD-RRRR HH24:MI:SS'), 2);

-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (1, 3, 'Inclus�o Documenta�ao Sistema Caracteristicas', TO_DATE ('12-12-2003 13:42:58', 'MM-DD-RRRR HH24:MI:SS'), 3);

-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (1, 4, 'Inclusao do Editor de Textos', TO_DATE ('12-12-2003 17:35:25', 'MM-DD-RRRR HH24:MI:SS'), 4);

-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (1, 5, 'Inclusao de Editor de Arquivos INI', TO_DATE ('12-19-2003 19:39:52', 'MM-DD-RRRR HH24:MI:SS'), 5);

-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (1, 6, 'Documenta�ao Permite Alterar o arquivo Ini do Sistema', TO_DATE ('12-19-2003 22:14:48', 'MM-DD-RRRR HH24:MI:SS'), 6);

-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (1, 7, 'Inclusao Tabela SYSRPT', TO_DATE ('12-27-2003 13:04:40', 'MM-DD-RRRR HH24:MI:SS'), 7);

-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (1, 8, 'Cria�ao Formulario Escolha Relatorios/Documentos 1057(escgrpmain.frm)', TO_DATE ('12-27-2003 13:19:08', 'MM-DD-RRRR HH24:MI:SS'), 8);

-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (0, 0, NULL, TO_DATE ('12-27-2003 21:46:41', 'MM-DD-RRRR HH24:MI:SS'), 9);

-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (1, 9, 'Cria�ao Formul�rio Edi�ao Relat�rios/Documentos 1058 frmRptMain', TO_DATE ('12-27-2003 21:58:31', 'MM-DD-RRRR HH24:MI:SS'), 10);

-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (1, 10, 'Cria�ao Formularios Escolher Grupo Relatorios 1059 escrptgrp', TO_DATE ('12-29-2003 15:03:25', 'MM-DD-RRRR HH24:MI:SS'), 11);

-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (1, 11, 'Cria�ao Formularios Editar Grupo Relatorios 1060 frmrptgrp', TO_DATE ('12-29-2003 15:03:51', 'MM-DD-RRRR HH24:MI:SS'), 12);

-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (1, 12, 'Cria�ao Formularios Escolher Tipos Arquivos 1060 escodnome', TO_DATE ('12-29-2003 15:04:23', 'MM-DD-RRRR HH24:MI:SS'), 13);

-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (1, 13, 'Cria�ao Formularios Editar tipos arquivos 1062 frmcodnome', TO_DATE ('12-29-2003 15:04:56', 'MM-DD-RRRR HH24:MI:SS'), 14);

-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (1, 14, 'Inclusao Formulario de Senhas', TO_DATE ('02-06-2004 12:32:56', 'MM-DD-RRRR HH24:MI:SS'), 15);

-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (1, 15, 'Teste Grid', TO_DATE ('02-17-2004 17:59:30', 'MM-DD-RRRR HH24:MI:SS'), 16);

-- inserting data
INSERT INTO ALTERACAO (NUMERO, ITEM, DIZER, DATA, ID)
VALUES (5, 1, 'Integra�ao Novo Vblib2', TO_DATE ('02-18-2004 19:32:22', 'MM-DD-RRRR HH24:MI:SS'), 17);
-- creating table
CREATE TABLE BASEDADOS (
	NUMERO NUMBER (10),
	ITEM NUMBER (10),
	CAMINHO VARCHAR2 (200),
	NOME VARCHAR2 (50),
	TIPO VARCHAR2 (20),
	COGNOME VARCHAR2 (20),
	ID NUMBER (10) NOT NULL
);



-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (2, 1, 'C:\develop\os\reparar.mdb', 'Configura��o Repara��o Base de Dados', 'MDB', 'REPARAR', 1);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (1, 1, '{REPARQ}', 'Configura�ao Repara�ao Banco de Dados', 'MDB', 'REPARAR', 2);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (1, 2, '{CFG}', 'Configura�ao do Sistema', 'MDB', 'SYSCONF', 3);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (1, 3, '{SYSDOC}', 'Documenta�ao do Sistema', 'MDB', 'SYSDOC', 4);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (1, 4, '{LOG}', 'Log de Utiliza�ao do Sistema', 'MDB', 'SYSLOG', 5);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (1, 5, '{USR}', 'Configura�oes de Usuarios', 'MDB', 'SYSUSER', 6);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (1, 6, '{TAB}', 'Tabela Modulo Ordem de Servi�o', 'MDB', 'TABOS', 7);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (1, 7, '{USRTAB}', 'Tabelas Ordem Servi�o Usuario', 'MDB', 'TABOSUSR', 8);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (1, 8, '{TABSYS}', 'Tabelas do Sistema', 'MDB', 'TABSYS', 9);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (1, 9, '{USRTAB}', 'Cadastro do Usuarios', 'MDB', 'TABUSR', 10);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (4, 1, 'C:\develop\comex\comexcad.mdb', 'Cadastro', 'MDB', 'COMEXCAD', 11);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (4, 2, 'C:\develop\comex\comextab.mdb', 'Tabelas', 'MDB', 'COMEXTAB', 12);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (5, 1, 'C:\dicion\Dic.mdb', 'Configura��es dos Dicion�rios', 'MDB', 'DIC', 13);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (6, 1, 'C:\develop\MidArc\midarc.mdb', 'Cadastro', 'MDB', 'MIDARC', 14);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (6, 2, 'D:\cddb\FreeDB.mdb', 'FreeDb', 'MDB', 'FREEDB', 15);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (1, 10, '{USRCAD}', 'Cadastros dos Usuarios', 'MDB', 'USRCAD', 16);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (13, 1, 'C:\develop\aplifolha\tabfolsys.mdb', NULL, 'MDB', 'TABFOLSYS', 17);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (13, 2, 'C:\develop\aplifolha\tabusrfol.mdb', NULL, 'MDB', 'TABUSRFOL', 18);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (4, 3, 'C:\develop\comex\REPARAR.MDB', NULL, 'MDB', 'REPARAR', 19);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (5, 2, 'C:\develop\DICION\reparar.mdb', NULL, 'MDB', 'REPARAR', 20);

-- inserting data
INSERT INTO BASEDADOS (NUMERO, ITEM, CAMINHO, NOME, TIPO, COGNOME, ID)
VALUES (1, 11, '{SYSRPT}', 'Configura�ao de Relatorios', 'MDB', 'SYSRPT', 21);
-- creating table
CREATE TABLE CARACTER (
	NUMERO NUMBER (10),
	ITEM NUMBER (10),
	DATA DATE,
	TIPO VARCHAR2 (10),
	TEMP VARCHAR2 (50),
	DIZER VARCHAR2 (50),
	ID NUMBER (10) NOT NULL
);



-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 1, TO_DATE ('12-12-2003 12:48:02', 'MM-DD-RRRR HH24:MI:SS'), 'CAD', 'Clientes', 'Clientes', 1);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 2, TO_DATE ('12-12-2003 13:52:25', 'MM-DD-RRRR HH24:MI:SS'), 'CAD', 'Bancos', 'Bancos', 2);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 3, TO_DATE ('12-12-2003 13:52:54', 'MM-DD-RRRR HH24:MI:SS'), 'CAD', 'Bancos - Agencias', 'Bancos - Agencias', 3);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 4, TO_DATE ('12-12-2003 13:53:40', 'MM-DD-RRRR HH24:MI:SS'), 'CAD', 'Bancos - contas correntes', 'Bancos - contas correntes', 4);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 5, TO_DATE ('12-12-2003 13:54:15', 'MM-DD-RRRR HH24:MI:SS'), 'CAD', 'Bancos - Pra�as', 'Bancos - Pra�as', 5);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 6, TO_DATE ('12-12-2003 13:55:13', 'MM-DD-RRRR HH24:MI:SS'), 'CAD', 'cheques Recebidos/Emitidos', 'cheques Recebidos/Emitidos', 6);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 7, TO_DATE ('12-12-2003 13:56:03', 'MM-DD-RRRR HH24:MI:SS'), 'TAB', 'Codigos Devolu��o Cheques', 'Codigos Devolu��o Cheques', 7);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 8, TO_DATE ('12-12-2003 13:57:38', 'MM-DD-RRRR HH24:MI:SS'), 'TAB', 'Regioes', 'Regioes', 8);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 9, TO_DATE ('12-12-2003 13:57:54', 'MM-DD-RRRR HH24:MI:SS'), 'TAB', 'Estados', 'Estados', 9);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 10, TO_DATE ('12-12-2003 13:58:15', 'MM-DD-RRRR HH24:MI:SS'), 'TAB', 'Cidades', 'Cidades', 10);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 11, TO_DATE ('12-12-2003 13:58:54', 'MM-DD-RRRR HH24:MI:SS'), 'TAB', 'Paises', 'Paises', 11);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 12, TO_DATE ('12-12-2003 13:59:27', 'MM-DD-RRRR HH24:MI:SS'), 'TAB', 'Moedas', 'Moedas', 12);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 13, TO_DATE ('12-12-2003 13:59:53', 'MM-DD-RRRR HH24:MI:SS'), 'UTIL', 'Visualizar Imagens', 'Visualizar Imagens', 13);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (2, 1, TO_DATE ('12-12-2003 14:03:34', 'MM-DD-RRRR HH24:MI:SS'), 'SIS', 'Repara�ao Base Dados', 'Repara�ao Base Dados', 14);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (2, 2, TO_DATE ('12-12-2003 14:04:17', 'MM-DD-RRRR HH24:MI:SS'), 'SIS', 'Documenta�ao Base Dados', 'Documenta�ao Base Dados', 15);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 14, TO_DATE ('12-12-2003 14:06:24', 'MM-DD-RRRR HH24:MI:SS'), 'TAB', 'CNAB - Carteiras', 'CNAB - Carteiras', 16);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 15, TO_DATE ('12-12-2003 14:06:45', 'MM-DD-RRRR HH24:MI:SS'), 'TAB', 'CNAB - Especies', 'CNAB - Especies', 17);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 16, TO_DATE ('12-12-2003 14:07:12', 'MM-DD-RRRR HH24:MI:SS'), 'TAB', 'CNAB - Ocorrencias', 'CNAB - Ocorrencias', 18);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 17, TO_DATE ('12-12-2003 14:07:38', 'MM-DD-RRRR HH24:MI:SS'), 'CAD', 'CNAB - Instru��es', 'CNAB - Instru��es', 19);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 18, TO_DATE ('12-12-2003 14:10:21', 'MM-DD-RRRR HH24:MI:SS'), 'CON', 'Usu�rios', 'Usu�rios', 20);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 19, TO_DATE ('12-12-2003 14:10:59', 'MM-DD-RRRR HH24:MI:SS'), 'CON', 'Menus', 'Menus', 21);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 20, TO_DATE ('12-12-2003 14:11:10', 'MM-DD-RRRR HH24:MI:SS'), 'CON', 'Formul�rios', 'Formul�rios', 22);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 21, TO_DATE ('12-12-2003 14:11:22', 'MM-DD-RRRR HH24:MI:SS'), 'CON', 'Icones', 'Icones', 23);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 22, TO_DATE ('12-12-2003 14:11:36', 'MM-DD-RRRR HH24:MI:SS'), 'SIS', 'Arquivos', 'Arquivos', 24);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 23, TO_DATE ('12-12-2003 14:13:24', 'MM-DD-RRRR HH24:MI:SS'), 'SISDOC', 'Documeta��o Sistema', 'Documeta��o Sistema', 25);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 24, TO_DATE ('12-12-2003 14:13:40', 'MM-DD-RRRR HH24:MI:SS'), 'SISDOC', 'Tipos Linguagens Programa��o', 'Tipos Linguagens Programa��o', 26);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 25, TO_DATE ('12-12-2003 14:13:57', 'MM-DD-RRRR HH24:MI:SS'), 'SISDOC', 'Base de Dados', 'Base de Dados', 27);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 26, TO_DATE ('12-12-2003 14:14:55', 'MM-DD-RRRR HH24:MI:SS'), 'SISDOC', 'Tipos de Campos Base de Dados', 'Tipos de Campos Base de Dados', 28);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 27, TO_DATE ('12-12-2003 14:16:03', 'MM-DD-RRRR HH24:MI:SS'), 'SISDOC', 'Tipos de Base de Dados', 'Tipos de Base de Dados', 29);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 28, TO_DATE ('12-12-2003 14:29:15', 'MM-DD-RRRR HH24:MI:SS'), 'SISDOC', 'Relatorios', 'Relatorios', 30);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 29, TO_DATE ('12-12-2003 14:29:39', 'MM-DD-RRRR HH24:MI:SS'), 'SISDOC', 'Caracteristicas', 'Caracteristicas', 31);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 30, TO_DATE ('12-12-2003 17:35:12', 'MM-DD-RRRR HH24:MI:SS'), 'UTIL', NULL, 'Editor de Textos', 32);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (4, 1, TO_DATE ('12-12-2003 18:48:19', 'MM-DD-RRRR HH24:MI:SS'), 'UTIL', NULL, 'Visualizador de Imagens', 33);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (4, 2, TO_DATE ('12-12-2003 18:48:35', 'MM-DD-RRRR HH24:MI:SS'), 'UTIL', NULL, 'Editor de Textos', 34);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (5, 1, TO_DATE ('12-12-2003 18:49:13', 'MM-DD-RRRR HH24:MI:SS'), 'UTIL', NULL, 'Visualizador de Imagens', 35);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (5, 2, TO_DATE ('12-12-2003 18:49:40', 'MM-DD-RRRR HH24:MI:SS'), 'UTIL', NULL, 'Editor de Textos', 36);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (6, 1, TO_DATE ('12-12-2003 18:50:08', 'MM-DD-RRRR HH24:MI:SS'), 'UTIL', NULL, 'Visualizador de Imagens', 37);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (6, 2, TO_DATE ('12-12-2003 18:50:26', 'MM-DD-RRRR HH24:MI:SS'), 'UTIL', NULL, 'Editor de Textos', 38);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 31, TO_DATE ('12-19-2003 19:39:24', 'MM-DD-RRRR HH24:MI:SS'), 'UTIL', NULL, 'Editor de Arquivos INI', 39);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (4, 3, TO_DATE ('12-19-2003 19:48:37', 'MM-DD-RRRR HH24:MI:SS'), 'UTIL', NULL, 'Editor de Arquivos INI', 40);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (6, 3, TO_DATE ('12-19-2003 19:49:24', 'MM-DD-RRRR HH24:MI:SS'), 'UTIL', NULL, 'Editor de Arquivos INI', 41);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (1, 32, TO_DATE ('12-27-2003 13:20:14', 'MM-DD-RRRR HH24:MI:SS'), 'REL', NULL, 'Gerenciador de Relatorios/Documentos', 42);

-- inserting data
INSERT INTO CARACTER (NUMERO, ITEM, DATA, TIPO, TEMP, DIZER, ID)
VALUES (13, 1, TO_DATE ('02-06-2004 15:02:45', 'MM-DD-RRRR HH24:MI:SS'), NULL, NULL, NULL, 43);
-- creating table
CREATE TABLE LINGUAGEM (
	CODIGO VARCHAR2 (20),
	NOME VARCHAR2 (50),
	ID NUMBER (10) NOT NULL
);



-- inserting data
INSERT INTO LINGUAGEM (CODIGO, NOME, ID)
VALUES ('CLIPPER', 'CLIPPER', 1);

-- inserting data
INSERT INTO LINGUAGEM (CODIGO, NOME, ID)
VALUES ('VO', 'Visual Objects', 2);

-- inserting data
INSERT INTO LINGUAGEM (CODIGO, NOME, ID)
VALUES ('DELPHI', 'DELPHI', 3);

-- inserting data
INSERT INTO LINGUAGEM (CODIGO, NOME, ID)
VALUES ('VB', 'Visual Basic', 4);
-- creating table
CREATE TABLE MODASS (
	ID NUMBER (10) NOT NULL,
	MODULO NUMBER (10),
	MODASS NUMBER (10)
);


-- creating table
CREATE TABLE MODULOS (
	NUMERO NUMBER (10),
	COGNOME VARCHAR2 (20),
	EXECUTAVEL VARCHAR2 (20),
	LINGUAGEM VARCHAR2 (50),
	ARQINI VARCHAR2 (250),
	NOME VARCHAR2 (120),
	ID NUMBER (10) NOT NULL
);



-- inserting data
INSERT INTO MODULOS (NUMERO, COGNOME, EXECUTAVEL, LINGUAGEM, ARQINI, NOME, ID)
VALUES (13, 'FOLHA', NULL, 'HARBOUR', 'folha.ini', 'FOLHA', 10);

-- inserting data
INSERT INTO MODULOS (NUMERO, COGNOME, EXECUTAVEL, LINGUAGEM, ARQINI, NOME, ID)
VALUES (14, 'PONTO', NULL, 'HARBOUR', 'folha.ini', 'Ponto', 11);

-- inserting data
INSERT INTO MODULOS (NUMERO, COGNOME, EXECUTAVEL, LINGUAGEM, ARQINI, NOME, ID)
VALUES (1, 'CONTROLE', 'controle.exe', 'VB', 'controle.ini', NULL, 23);

-- inserting data
INSERT INTO MODULOS (NUMERO, COGNOME, EXECUTAVEL, LINGUAGEM, ARQINI, NOME, ID)
VALUES (2, 'WRPT', 'wrpt.exe', 'VB', 'wrpt.ini', NULL, 24);

-- inserting data
INSERT INTO MODULOS (NUMERO, COGNOME, EXECUTAVEL, LINGUAGEM, ARQINI, NOME, ID)
VALUES (3, 'WRPTX', 'wrptx.exe', 'VB', 'wrpt.inii ->wrptf.ini wrptx.ini wrpti.ini', NULL, 25);

-- inserting data
INSERT INTO MODULOS (NUMERO, COGNOME, EXECUTAVEL, LINGUAGEM, ARQINI, NOME, ID)
VALUES (4, 'IMAGENSJPG', 'imagens.exe', 'VB', 'imagens.ini', NULL, 26);

-- inserting data
INSERT INTO MODULOS (NUMERO, COGNOME, EXECUTAVEL, LINGUAGEM, ARQINI, NOME, ID)
VALUES (5, 'IMAGENSCPF', 'imgmpcpf.exe', 'VB', 'imagens.ini', NULL, 27);
-- creating table
CREATE TABLE RELATORIOS (
	NUMERO NUMBER (10),
	ITEM NUMBER (10),
	CAMINHO VARCHAR2 (200),
	NOME VARCHAR2 (50),
	ID NUMBER (10) NOT NULL
);


-- creating table
CREATE TABLE TIPOCAMPOS (
	CODIGO VARCHAR2 (20),
	NOME VARCHAR2 (50),
	ID NUMBER (10) NOT NULL
);



-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('N', 'Numerico', 1);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('D', 'Data', 2);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('C', 'Caracter', 3);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('M', 'Memo', 4);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('L', 'Logico(Boolean)', 5);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('BOOLEAN', 'Boolean(Logico)', 6);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('INTEGER', 'Integer', 7);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('LONG', 'Long', 8);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('SINGLE', 'Single Precision', 9);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('DOUBLE', 'Doble Precision', 10);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('MEMO', 'MEMO', 11);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('BYTE', 'Byte', 12);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('CURRENCY', 'Currency(Number)', 13);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('TEXT', 'Texto', 14);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('BINARY', 'Binary', 15);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('DATE/TIME', 'Data Hora', 16);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('REAL', 'REAL(SINGLE)', 17);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('SMALLINT', 'Small Integer', 18);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('VARCHAR', 'Texto Variavel', 19);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('COUNTER', 'Integer (Auto Increment)', 20);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('CHAR', 'Texto Fixo', 21);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('LONGCHAR', 'LongChar (Memo)', 22);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('VARBINARY', 'Binary Variavel', 23);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('CUID', 'Binary', 24);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('LONGBINARY', 'LongBinary (Image)', 25);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('TINYINT', 'TinyInt (Byte)', 26);

-- inserting data
INSERT INTO TIPOCAMPOS (CODIGO, NOME, ID)
VALUES ('BIT', 'BIT', 27);
-- creating table
CREATE TABLE TIPODADOS (
	CODIGO VARCHAR2 (20),
	NOME VARCHAR2 (50),
	ID NUMBER (10) NOT NULL
);



-- inserting data
INSERT INTO TIPODADOS (CODIGO, NOME, ID)
VALUES ('DBFNTX', 'Clipper DBF/DBT Indices NTX', 1);

-- inserting data
INSERT INTO TIPODADOS (CODIGO, NOME, ID)
VALUES ('DBFCDX', 'Foxpro DBF/FPT Indices CDX', 2);

-- inserting data
INSERT INTO TIPODADOS (CODIGO, NOME, ID)
VALUES ('MDB', 'Access MDB', 3);

-- inserting data
INSERT INTO TIPODADOS (CODIGO, NOME, ID)
VALUES ('MYSQL', 'MySql', 4);

-- inserting data
INSERT INTO TIPODADOS (CODIGO, NOME, ID)
VALUES ('SQL2K', 'MS Sql Server 2000', 5);

-- inserting data
INSERT INTO TIPODADOS (CODIGO, NOME, ID)
VALUES ('SQL97', 'MS SQL Server 97', 6);

-- inserting data
INSERT INTO TIPODADOS (CODIGO, NOME, ID)
VALUES ('PARADOX', 'Paradox', 7);
-- creating table
CREATE TABLE TIPOSARQ (
	CODIGO VARCHAR2 (8),
	NOME VARCHAR2 (100),
	ID NUMBER (10) NOT NULL
);



-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INI', 'Configura�ao de Inicializacao', 1);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MDB', 'Base de Dados Access', 2);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DBF', 'Tabelas Base Dados DBASE/FOXPRO', 3);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RTF', 'Rith Text Formato (Textos)', 4);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TXT', 'Arquivos de Textos', 5);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CDX', 'Arquivos de Indices FOXPRO', 6);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NTX', 'Arquivos de Indices Clipper', 7);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAN', 'Manuais Sistema Dos', 8);
-- creating table
CREATE TABLE TIPOSCARAC (
	CODIGO VARCHAR2 (20),
	NOME VARCHAR2 (50),
	ID NUMBER (10) NOT NULL
);



-- inserting data
INSERT INTO TIPOSCARAC (CODIGO, NOME, ID)
VALUES ('UTIL', 'Utilitarios', 1);

-- inserting data
INSERT INTO TIPOSCARAC (CODIGO, NOME, ID)
VALUES ('CAD', 'Cadastros', 2);

-- inserting data
INSERT INTO TIPOSCARAC (CODIGO, NOME, ID)
VALUES ('TAB', 'Tabelas', 3);

-- inserting data
INSERT INTO TIPOSCARAC (CODIGO, NOME, ID)
VALUES ('DOC', 'Documenta�ao', 4);

-- inserting data
INSERT INTO TIPOSCARAC (CODIGO, NOME, ID)
VALUES ('INT', 'Integra�ao', 5);

-- inserting data
INSERT INTO TIPOSCARAC (CODIGO, NOME, ID)
VALUES ('SIS', 'Sistema', 6);

-- inserting data
INSERT INTO TIPOSCARAC (CODIGO, NOME, ID)
VALUES ('CON', 'Configura��o', 7);

-- inserting data
INSERT INTO TIPOSCARAC (CODIGO, NOME, ID)
VALUES ('SISDOC', 'Documenta�ao do Sistema', 8);

-- inserting data
INSERT INTO TIPOSCARAC (CODIGO, NOME, ID)
VALUES ('REL', 'Relatorios/Documenta��o', 9);

-- inserting data
INSERT INTO TIPOSCARAC (CODIGO, NOME, ID)
VALUES ('IMP', 'Importa�ao', 10);
