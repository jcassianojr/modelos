--------------------------------------------
--------------- Dump details ---------------
--------------------------------------------
-- Original file: C:\cnvoracle\datashare\sysconf.mdb
-- Dump date: 12-18-2024 10:12:57
--------------------------------------------

-- creating table
CREATE TABLE BOTOES (
	INDICE NUMBER (5),
	ICONE NUMBER (5),
	NOME VARCHAR2 (50),
	TOOLTIP VARCHAR2 (50),
	FORM NUMBER (10),
	DISPONIVEL NUMBER (1) NOT NULL,
	INATIVO NUMBER (1) NOT NULL,
	REQDIR NUMBER (1) NOT NULL,
	ID NUMBER (10) NOT NULL
);



-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1017, 0, 0, 1, 1);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1017, 0, 0, 1, 2);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1017, 0, 0, 1, 3);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1017, 1, 0, 0, 4);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1017, 1, 0, 0, 5);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1017, 1, 0, 0, 6);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (10, 19, '&Sair', 'Sair/Retornar', 1017, 1, 0, 0, 7);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 7, 'Reparar', 'Reparar  o Arquivo', 1017, 0, 0, 1, 8);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (9, 10, 'Documentar', 'Documentar', 1017, 0, 0, 1, 9);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1003, 0, 0, 1, 10);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1003, 0, 0, 1, 11);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1003, 0, 0, 1, 12);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1003, 1, 0, 0, 13);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1003, 1, 0, 0, 14);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1003, 1, 0, 0, 15);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1003, 1, 0, 0, 16);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1003, 1, 0, 0, 17);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1004, 0, 0, 1, 18);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1004, 0, 0, 1, 19);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1004, 0, 0, 1, 20);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1004, 1, 0, 0, 21);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1004, 1, 0, 0, 22);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1004, 1, 0, 0, 23);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1006, 0, 0, 1, 24);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1006, 0, 0, 1, 25);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1006, 0, 0, 1, 26);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1006, 1, 0, 0, 27);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1006, 1, 0, 0, 28);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1006, 1, 0, 0, 29);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1011, 0, 0, 1, 30);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1011, 0, 0, 1, 31);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1011, 0, 0, 1, 32);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1011, 1, 0, 0, 33);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1011, 1, 0, 0, 34);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1011, 1, 0, 0, 35);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1011, 1, 0, 0, 36);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1011, 1, 0, 0, 37);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1021, 0, 0, 1, 45);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1021, 0, 0, 1, 46);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1021, 0, 0, 1, 47);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1021, 1, 0, 0, 48);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1021, 1, 0, 0, 49);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1021, 1, 0, 0, 50);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1021, 1, 0, 0, 51);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1073, 0, 0, 1, 52);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1073, 0, 0, 1, 53);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1073, 0, 0, 1, 54);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1073, 1, 0, 0, 55);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1073, 1, 0, 0, 56);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1015, 0, 0, 1, 996);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1015, 0, 0, 1, 997);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1015, 0, 0, 1, 998);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1015, 1, 0, 0, 999);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 15, '&Filtrar', 'Escolher Grupo de Exibi��o', 1015, 1, 0, 0, 1000);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 6, '&Imprimir', 'Imprimir Registro', 1015, 1, 0, 0, 1001);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1073, 1, 0, 0, 57);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1073, 1, 0, 0, 58);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1034, 0, 0, 0, 59);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1034, 0, 0, 0, 60);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1034, 0, 0, 0, 61);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1034, 0, 0, 0, 62);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1034, 0, 0, 0, 63);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1034, 0, 0, 0, 64);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 19, '&Sair', 'Sair/Retornar', 1034, 0, 0, 0, 65);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1023, 0, 0, 1, 66);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1023, 0, 0, 1, 67);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1023, 0, 0, 1, 68);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1023, 1, 0, 0, 69);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1023, 1, 0, 0, 70);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1023, 1, 0, 0, 71);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1023, 1, 0, 0, 72);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1025, 0, 0, 1, 73);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1025, 0, 0, 1, 74);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1025, 0, 0, 1, 75);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1025, 1, 0, 0, 76);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1025, 1, 0, 0, 77);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1025, 1, 0, 0, 78);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1025, 1, 0, 0, 79);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1027, 0, 0, 1, 80);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1027, 0, 0, 1, 81);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1027, 0, 0, 1, 82);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1027, 1, 0, 0, 83);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1027, 1, 0, 0, 84);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1027, 1, 0, 0, 85);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1027, 1, 0, 0, 86);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1029, 0, 0, 1, 87);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1029, 0, 0, 1, 88);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1029, 0, 0, 1, 89);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1029, 1, 0, 0, 90);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1029, 1, 0, 0, 91);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1029, 1, 0, 0, 92);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1029, 1, 0, 0, 93);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1031, 0, 0, 1, 94);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1031, 0, 0, 1, 95);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1031, 0, 0, 1, 96);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1031, 1, 0, 0, 97);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1031, 1, 0, 0, 98);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1031, 1, 0, 0, 99);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1033, 0, 0, 1, 100);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1033, 0, 0, 1, 101);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1033, 0, 0, 1, 102);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1033, 1, 0, 0, 103);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1033, 1, 0, 0, 104);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1033, 1, 0, 0, 105);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1033, 1, 0, 0, 106);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1035, 0, 0, 1, 107);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1035, 0, 0, 1, 108);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1035, 0, 0, 1, 109);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1035, 1, 0, 0, 110);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1035, 1, 0, 0, 111);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1035, 1, 0, 0, 112);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1035, 1, 0, 0, 113);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1037, 0, 0, 1, 114);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1037, 0, 0, 1, 115);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1037, 0, 0, 1, 116);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 19, '&Sair', 'Sair/Retornar', 999, 1, 0, 0, 117);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1037, 1, 0, 0, 118);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1037, 1, 0, 0, 119);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1037, 1, 0, 0, 120);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1037, 1, 0, 0, 121);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1039, 0, 0, 1, 122);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1039, 0, 0, 1, 123);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1039, 0, 0, 1, 124);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1039, 1, 0, 0, 125);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1039, 1, 0, 0, 126);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1039, 1, 0, 0, 127);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1039, 1, 0, 0, 128);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1042, 0, 0, 1, 129);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1042, 0, 0, 1, 130);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1042, 0, 0, 1, 131);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1042, 1, 0, 0, 132);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1042, 1, 0, 0, 133);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1042, 1, 0, 0, 134);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1042, 1, 0, 0, 135);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1044, 0, 0, 1, 136);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1044, 0, 0, 1, 137);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1044, 0, 0, 1, 138);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1044, 1, 0, 0, 139);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1044, 1, 0, 0, 140);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1044, 1, 0, 0, 141);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1044, 1, 0, 0, 142);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1046, 0, 0, 1, 143);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1046, 0, 0, 1, 144);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1046, 0, 0, 1, 145);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1046, 1, 0, 0, 146);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1046, 1, 0, 0, 147);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1046, 1, 0, 0, 148);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1046, 1, 0, 0, 149);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1048, 0, 0, 1, 150);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1048, 0, 0, 1, 151);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1048, 0, 0, 1, 152);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1048, 1, 0, 0, 153);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1048, 1, 0, 0, 154);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1048, 1, 0, 0, 155);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1048, 1, 0, 0, 156);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1052, 0, 0, 1, 157);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1052, 0, 0, 1, 158);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1052, 0, 0, 1, 159);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1052, 1, 0, 0, 160);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1052, 1, 0, 0, 161);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1052, 1, 0, 0, 162);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1057, 0, 0, 1, 163);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1057, 0, 0, 1, 164);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1057, 0, 0, 1, 165);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1057, 1, 0, 0, 166);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1057, 1, 0, 0, 167);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1057, 1, 0, 0, 168);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1057, 1, 0, 0, 169);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1059, 0, 0, 1, 170);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1059, 0, 0, 1, 171);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1059, 0, 0, 1, 172);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1059, 1, 0, 0, 173);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1059, 1, 0, 0, 174);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 501, 0, 0, 0, 175);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 501, 0, 0, 0, 176);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 501, 0, 0, 0, 177);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 501, 1, 0, 0, 178);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 501, 1, 0, 0, 179);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 501, 1, 0, 0, 180);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 19, '&Sair', 'Sair/Retornar', 501, 1, 0, 0, 181);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1076, 0, 0, 0, 189);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1076, 0, 0, 0, 190);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1076, 0, 0, 0, 191);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1076, 1, 0, 0, 192);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1076, 1, 0, 0, 193);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1076, 1, 0, 0, 194);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1076, 1, 0, 0, 195);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1076, 1, 0, 0, 196);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 401, 0, 0, 0, 197);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 401, 0, 0, 0, 198);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 401, 0, 0, 0, 199);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 401, 1, 0, 0, 200);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 401, 1, 0, 0, 201);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 401, 1, 0, 0, 202);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 401, 1, 0, 0, 203);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 401, 1, 0, 0, 204);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 403, 0, 0, 0, 205);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 403, 0, 0, 0, 206);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 403, 0, 0, 0, 207);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 403, 1, 0, 0, 208);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 403, 1, 0, 0, 209);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1059, 1, 0, 0, 210);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1059, 1, 0, 0, 211);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (9, 19, '&Sair', 'Sair/Retornar', 1059, 1, 0, 0, 212);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1061, 0, 0, 1, 213);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1061, 0, 0, 1, 214);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1061, 0, 0, 1, 215);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1061, 1, 0, 0, 216);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1061, 1, 0, 0, 217);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1061, 1, 0, 0, 218);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1061, 1, 0, 0, 219);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1061, 1, 0, 0, 220);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1063, 0, 0, 1, 221);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1063, 0, 0, 1, 222);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1063, 0, 0, 1, 223);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1063, 1, 0, 0, 224);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 505, 0, 0, 1, 987);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 505, 0, 0, 1, 988);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 505, 0, 0, 1, 989);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 505, 1, 0, 0, 990);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 15, '&Filtrar', 'Escolher Grupo de Exibi��o', 505, 1, 0, 0, 991);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 6, '&Imprimir', 'Imprimir Registro', 505, 1, 0, 0, 992);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 11, 'Es&colher', 'Escolher Registro', 505, 1, 0, 0, 993);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1063, 1, 0, 0, 225);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1063, 1, 0, 0, 226);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1063, 1, 0, 0, 227);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1065, 0, 0, 1, 228);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1065, 0, 0, 1, 229);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1065, 0, 0, 1, 230);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1065, 1, 0, 0, 231);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1065, 1, 0, 0, 232);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1065, 1, 0, 0, 233);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1065, 1, 0, 0, 234);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 403, 1, 0, 0, 235);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 403, 1, 0, 0, 236);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 403, 1, 0, 0, 237);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 405, 0, 0, 0, 238);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 405, 0, 0, 0, 239);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 405, 0, 0, 0, 240);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 405, 1, 0, 0, 241);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 405, 1, 0, 0, 242);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 405, 1, 0, 0, 243);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 405, 1, 0, 0, 244);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 405, 1, 0, 0, 245);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 407, 0, 0, 0, 246);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 407, 0, 0, 0, 247);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 407, 0, 0, 0, 248);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 407, 1, 0, 0, 249);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 407, 1, 0, 0, 250);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 407, 1, 0, 0, 251);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 407, 1, 0, 0, 252);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 407, 1, 0, 0, 253);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 409, 0, 0, 0, 254);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 409, 0, 0, 0, 255);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 409, 0, 0, 0, 256);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 409, 1, 0, 0, 257);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 409, 1, 0, 0, 258);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 409, 1, 0, 0, 259);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 409, 1, 0, 0, 260);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 409, 1, 0, 0, 261);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 411, 0, 0, 0, 262);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 411, 0, 0, 0, 263);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 411, 0, 0, 0, 264);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 411, 1, 0, 0, 265);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 411, 1, 0, 0, 266);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 411, 1, 0, 0, 267);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 411, 1, 0, 0, 268);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 411, 1, 0, 0, 269);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 413, 0, 0, 0, 270);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 413, 0, 0, 0, 271);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 413, 0, 0, 0, 272);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 413, 1, 0, 0, 273);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 413, 1, 0, 0, 274);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 413, 1, 0, 0, 275);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 413, 1, 0, 0, 276);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 413, 1, 0, 0, 277);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 415, 0, 0, 0, 278);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 415, 0, 0, 0, 279);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 415, 0, 0, 0, 280);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 415, 1, 0, 0, 281);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 415, 1, 0, 0, 282);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 415, 1, 0, 0, 283);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 415, 1, 0, 0, 284);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 415, 1, 0, 0, 285);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 417, 0, 0, 0, 286);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 417, 0, 0, 0, 287);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 417, 0, 0, 0, 288);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 417, 1, 0, 0, 289);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 417, 1, 0, 0, 290);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 417, 1, 0, 0, 291);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 417, 1, 0, 0, 292);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 417, 1, 0, 0, 293);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 419, 0, 0, 0, 294);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 419, 0, 0, 0, 295);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 419, 0, 0, 0, 296);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 419, 1, 0, 0, 297);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 419, 1, 0, 0, 298);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 419, 1, 0, 0, 299);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 419, 1, 0, 0, 300);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 419, 1, 0, 0, 301);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1004, 1, 0, 0, 302);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1004, 1, 0, 0, 303);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1006, 1, 0, 0, 304);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1006, 1, 0, 0, 305);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1021, 1, 0, 0, 307);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1023, 1, 0, 0, 308);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1025, 1, 0, 0, 309);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1027, 1, 0, 0, 310);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1029, 1, 0, 0, 311);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1031, 1, 0, 0, 312);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1031, 1, 0, 0, 313);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1033, 1, 0, 0, 314);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1035, 1, 0, 0, 315);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1037, 1, 0, 0, 316);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1039, 1, 0, 0, 317);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1042, 1, 0, 0, 318);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1044, 1, 0, 0, 319);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1046, 1, 0, 0, 320);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1048, 1, 0, 0, 321);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1052, 1, 0, 0, 322);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1052, 1, 0, 0, 323);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1057, 1, 0, 0, 324);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1063, 1, 0, 0, 325);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (9, 19, '&Sair', 'Sair/Retornar', 1065, 1, 0, 0, 326);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1073, 1, 0, 0, 327);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4001, 0, 0, 1, 328);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4001, 0, 0, 1, 329);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4001, 0, 0, 1, 330);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4001, 1, 0, 0, 331);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4001, 1, 0, 0, 332);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4001, 1, 0, 0, 333);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4001, 1, 0, 0, 334);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4001, 1, 0, 0, 335);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4003, 0, 0, 1, 336);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4003, 0, 0, 1, 337);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4003, 0, 0, 1, 338);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4003, 1, 0, 0, 339);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4003, 1, 0, 0, 340);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4003, 1, 0, 0, 341);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4003, 1, 0, 0, 342);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4003, 1, 0, 0, 343);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4005, 0, 0, 1, 344);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4005, 0, 0, 1, 345);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4005, 0, 0, 1, 346);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4005, 1, 0, 0, 347);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4005, 1, 0, 0, 348);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4005, 1, 0, 0, 349);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4005, 1, 0, 0, 350);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4005, 1, 0, 0, 351);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4007, 0, 0, 1, 352);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4007, 0, 0, 1, 353);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4007, 0, 0, 1, 354);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4007, 1, 0, 0, 355);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4007, 1, 0, 0, 356);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4007, 1, 0, 0, 357);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4007, 1, 0, 0, 358);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4007, 1, 0, 0, 359);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4009, 0, 0, 1, 360);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4009, 0, 0, 1, 361);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4009, 0, 0, 1, 362);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4009, 1, 0, 0, 363);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4009, 1, 0, 0, 364);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4009, 1, 0, 0, 365);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4009, 1, 0, 0, 366);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4009, 1, 0, 0, 367);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4011, 0, 0, 1, 368);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4011, 0, 0, 1, 369);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4011, 0, 0, 1, 370);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4011, 1, 0, 0, 371);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4011, 1, 0, 0, 372);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4011, 1, 0, 0, 373);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4011, 1, 0, 0, 374);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4011, 1, 0, 0, 375);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4013, 0, 0, 1, 376);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4013, 0, 0, 1, 377);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4013, 0, 0, 1, 378);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4013, 1, 0, 0, 379);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4013, 1, 0, 0, 380);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4013, 1, 0, 0, 381);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4013, 1, 0, 0, 382);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4013, 1, 0, 0, 383);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4015, 0, 0, 1, 384);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4015, 0, 0, 1, 385);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4015, 0, 0, 1, 386);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4015, 1, 0, 0, 387);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4015, 1, 0, 0, 388);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4015, 1, 0, 0, 389);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4015, 1, 0, 0, 390);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4015, 1, 0, 0, 391);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4017, 0, 0, 1, 392);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4017, 0, 0, 1, 393);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4017, 0, 0, 1, 394);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4017, 1, 0, 0, 395);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4017, 1, 0, 0, 396);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4017, 1, 0, 0, 397);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4017, 1, 0, 0, 398);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4017, 1, 0, 0, 399);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4019, 0, 0, 1, 400);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4019, 0, 0, 1, 401);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4019, 0, 0, 1, 402);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4019, 1, 0, 0, 403);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4019, 1, 0, 0, 404);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4019, 1, 0, 0, 405);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4019, 1, 0, 0, 406);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4019, 1, 0, 0, 407);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4021, 0, 0, 1, 408);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4021, 0, 0, 1, 409);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4021, 0, 0, 1, 410);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4021, 1, 0, 0, 411);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4021, 1, 0, 0, 412);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4021, 1, 0, 0, 413);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4021, 1, 0, 0, 414);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4021, 1, 0, 0, 415);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4023, 0, 0, 1, 416);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4023, 0, 0, 1, 417);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4023, 0, 0, 1, 418);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4023, 1, 0, 0, 419);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4023, 1, 0, 0, 420);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4023, 1, 0, 0, 421);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4023, 1, 0, 0, 422);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4023, 1, 0, 0, 423);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4025, 0, 0, 1, 424);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4025, 0, 0, 1, 425);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4025, 0, 0, 1, 426);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4025, 1, 0, 0, 427);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4025, 1, 0, 0, 428);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4025, 1, 0, 0, 429);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4025, 1, 0, 0, 430);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4025, 1, 0, 0, 431);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4027, 0, 0, 1, 432);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4027, 0, 0, 1, 433);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4027, 0, 0, 1, 434);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4027, 1, 0, 0, 435);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4027, 1, 0, 0, 436);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4027, 1, 0, 0, 437);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4027, 1, 0, 0, 438);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4027, 1, 0, 0, 439);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4029, 0, 0, 1, 440);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4029, 0, 0, 1, 441);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4029, 0, 0, 1, 442);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4029, 1, 0, 0, 443);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4029, 1, 0, 0, 444);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4029, 1, 0, 0, 445);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4029, 1, 0, 0, 446);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4029, 1, 0, 0, 447);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4031, 0, 0, 1, 448);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4031, 0, 0, 1, 449);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4031, 0, 0, 1, 450);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4031, 1, 0, 0, 451);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4031, 1, 0, 0, 452);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4031, 1, 0, 0, 453);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4031, 1, 0, 0, 454);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4031, 1, 0, 0, 455);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4033, 0, 0, 1, 456);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4033, 0, 0, 1, 457);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4033, 0, 0, 1, 458);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4033, 1, 0, 0, 459);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4033, 1, 0, 0, 460);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4033, 1, 0, 0, 461);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4033, 1, 0, 0, 462);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4033, 1, 0, 0, 463);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4035, 0, 0, 1, 464);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4035, 0, 0, 1, 465);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4035, 0, 0, 1, 466);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4035, 1, 0, 0, 467);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4035, 1, 0, 0, 468);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4035, 1, 0, 0, 469);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4035, 1, 0, 0, 470);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4035, 1, 0, 0, 471);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4037, 0, 0, 1, 472);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4037, 0, 0, 1, 473);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4037, 0, 0, 1, 474);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4037, 1, 0, 0, 475);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4037, 1, 0, 0, 476);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4037, 1, 0, 0, 477);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4037, 1, 0, 0, 478);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4037, 1, 0, 0, 479);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4039, 0, 0, 1, 480);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4039, 0, 0, 1, 481);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4039, 0, 0, 1, 482);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4039, 1, 0, 0, 483);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4039, 1, 0, 0, 484);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4039, 1, 0, 0, 485);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4039, 1, 0, 0, 486);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4039, 1, 0, 0, 487);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4041, 0, 0, 1, 488);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4041, 0, 0, 1, 489);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4041, 0, 0, 1, 490);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4041, 1, 0, 0, 491);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4041, 1, 0, 0, 492);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4041, 1, 0, 0, 493);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4041, 1, 0, 0, 494);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4041, 1, 0, 0, 495);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4043, 0, 0, 1, 496);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4043, 0, 0, 1, 497);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4043, 0, 0, 1, 498);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4043, 1, 0, 0, 499);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4043, 1, 0, 0, 500);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4043, 1, 0, 0, 501);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4043, 1, 0, 0, 502);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4043, 1, 0, 0, 503);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4045, 0, 0, 1, 504);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4045, 0, 0, 1, 505);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4045, 0, 0, 1, 506);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4045, 1, 0, 0, 507);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4045, 1, 0, 0, 508);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4045, 1, 0, 0, 509);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4045, 1, 0, 0, 510);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4045, 1, 0, 0, 511);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4047, 0, 0, 1, 512);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4047, 0, 0, 1, 513);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4047, 0, 0, 1, 514);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4047, 1, 0, 0, 515);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4047, 1, 0, 0, 516);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4047, 1, 0, 0, 517);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4047, 1, 0, 0, 518);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4047, 1, 0, 0, 519);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4049, 0, 0, 1, 520);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4049, 0, 0, 1, 521);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4049, 0, 0, 1, 522);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4049, 1, 0, 0, 523);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4049, 1, 0, 0, 524);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4049, 1, 0, 0, 525);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4049, 1, 0, 0, 526);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4049, 1, 0, 0, 527);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4051, 0, 0, 1, 528);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4051, 0, 0, 1, 529);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4051, 0, 0, 1, 530);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4051, 1, 0, 0, 531);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4051, 1, 0, 0, 532);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4051, 1, 0, 0, 533);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4051, 1, 0, 0, 534);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4051, 1, 0, 0, 535);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4053, 0, 0, 1, 536);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4053, 0, 0, 1, 537);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4053, 0, 0, 1, 538);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4053, 1, 0, 0, 539);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4053, 1, 0, 0, 540);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4053, 1, 0, 0, 541);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4053, 1, 0, 0, 542);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4053, 1, 0, 0, 543);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4055, 0, 0, 1, 544);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4055, 0, 0, 1, 545);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4055, 0, 0, 1, 546);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4055, 1, 0, 0, 547);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4055, 1, 0, 0, 548);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4055, 1, 0, 0, 549);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4055, 1, 0, 0, 550);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4055, 1, 0, 0, 551);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4057, 0, 0, 1, 552);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4057, 0, 0, 1, 553);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4057, 0, 0, 1, 554);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4057, 1, 0, 0, 555);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4057, 1, 0, 0, 556);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4057, 1, 0, 0, 557);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4057, 1, 0, 0, 558);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4057, 1, 0, 0, 559);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4059, 0, 0, 1, 560);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4059, 0, 0, 1, 561);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4059, 0, 0, 1, 562);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4059, 1, 0, 0, 563);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4059, 1, 0, 0, 564);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4059, 1, 0, 0, 565);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4059, 1, 0, 0, 566);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4059, 1, 0, 0, 567);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4061, 0, 0, 1, 568);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4061, 0, 0, 1, 569);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4061, 0, 0, 1, 570);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4061, 1, 0, 0, 571);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4061, 1, 0, 0, 572);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4061, 1, 0, 0, 573);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4061, 1, 0, 0, 574);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4061, 1, 0, 0, 575);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4063, 0, 0, 1, 576);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4063, 0, 0, 1, 577);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4063, 0, 0, 1, 578);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4063, 1, 0, 0, 579);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4063, 1, 0, 0, 580);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4063, 1, 0, 0, 581);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4063, 1, 0, 0, 582);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4063, 1, 0, 0, 583);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4065, 0, 0, 1, 584);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4065, 0, 0, 1, 585);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4065, 0, 0, 1, 586);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4065, 1, 0, 0, 587);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4065, 1, 0, 0, 588);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4065, 1, 0, 0, 589);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4065, 1, 0, 0, 590);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4065, 1, 0, 0, 591);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4067, 0, 0, 1, 592);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4067, 0, 0, 1, 593);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4067, 0, 0, 1, 594);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4067, 1, 0, 0, 595);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4067, 1, 0, 0, 596);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4067, 1, 0, 0, 597);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4067, 1, 0, 0, 598);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4067, 1, 0, 0, 599);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4069, 0, 0, 1, 600);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4069, 0, 0, 1, 601);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4069, 0, 0, 1, 602);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4069, 1, 0, 0, 603);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4069, 1, 0, 0, 604);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4069, 1, 0, 0, 605);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4069, 1, 0, 0, 606);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4069, 1, 0, 0, 607);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4071, 0, 0, 1, 608);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4071, 0, 0, 1, 609);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4071, 0, 0, 1, 610);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4071, 1, 0, 0, 611);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4071, 1, 0, 0, 612);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4071, 1, 0, 0, 613);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4071, 1, 0, 0, 614);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4071, 1, 0, 0, 615);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4073, 0, 0, 1, 616);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4073, 0, 0, 1, 617);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4073, 0, 0, 1, 618);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4073, 1, 0, 0, 619);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4073, 1, 0, 0, 620);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4073, 1, 0, 0, 621);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4073, 1, 0, 0, 622);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4073, 1, 0, 0, 623);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4075, 0, 0, 1, 624);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4075, 0, 0, 1, 625);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4075, 0, 0, 1, 626);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4075, 1, 0, 0, 627);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4075, 1, 0, 0, 628);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4075, 1, 0, 0, 629);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4075, 1, 0, 0, 630);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4075, 1, 0, 0, 631);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4077, 0, 0, 1, 632);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4077, 0, 0, 1, 633);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4077, 0, 0, 1, 634);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4077, 1, 0, 0, 635);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4077, 1, 0, 0, 636);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4077, 1, 0, 0, 637);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4077, 1, 0, 0, 638);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4077, 1, 0, 0, 639);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4079, 0, 0, 1, 640);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4079, 0, 0, 1, 641);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4079, 0, 0, 1, 642);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4079, 1, 0, 0, 643);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4079, 1, 0, 0, 644);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4079, 1, 0, 0, 645);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4079, 1, 0, 0, 646);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4079, 1, 0, 0, 647);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4081, 0, 0, 1, 648);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4081, 0, 0, 1, 649);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4081, 0, 0, 1, 650);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4081, 1, 0, 0, 651);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4081, 1, 0, 0, 652);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4081, 1, 0, 0, 653);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4081, 1, 0, 0, 654);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4081, 1, 0, 0, 655);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4083, 0, 0, 1, 656);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4083, 0, 0, 1, 657);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4083, 0, 0, 1, 658);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4083, 1, 0, 0, 659);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4083, 1, 0, 0, 660);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4083, 1, 0, 0, 661);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4083, 1, 0, 0, 662);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4083, 1, 0, 0, 663);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4085, 0, 0, 1, 664);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4085, 0, 0, 1, 665);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4085, 0, 0, 1, 666);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4085, 1, 0, 0, 667);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4085, 1, 0, 0, 668);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4085, 1, 0, 0, 669);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4085, 1, 0, 0, 670);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4085, 1, 0, 0, 671);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4087, 0, 0, 1, 672);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4087, 0, 0, 1, 673);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4087, 0, 0, 1, 674);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4087, 1, 0, 0, 675);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4087, 1, 0, 0, 676);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4087, 1, 0, 0, 677);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4087, 1, 0, 0, 678);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4087, 1, 0, 0, 679);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4089, 0, 0, 1, 680);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4089, 0, 0, 1, 681);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4089, 0, 0, 1, 682);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4089, 1, 0, 0, 683);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4089, 1, 0, 0, 684);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4089, 1, 0, 0, 685);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4089, 1, 0, 0, 686);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4089, 1, 0, 0, 687);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 4091, 0, 0, 1, 688);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 4091, 0, 0, 1, 689);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 4091, 0, 0, 1, 690);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 4091, 1, 0, 0, 691);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 4091, 1, 0, 0, 692);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 4091, 1, 0, 0, 693);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 4091, 1, 0, 0, 694);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 4091, 1, 0, 0, 695);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1080, 0, 0, 1, 696);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1080, 0, 0, 1, 697);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1080, 0, 0, 1, 698);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1080, 1, 0, 0, 699);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1080, 1, 0, 0, 700);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1080, 1, 0, 0, 701);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1080, 1, 0, 0, 702);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1080, 1, 0, 0, 703);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1082, 0, 0, 1, 704);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1082, 0, 0, 1, 705);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1082, 0, 0, 1, 706);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1082, 1, 0, 0, 707);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1082, 1, 0, 0, 708);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1082, 1, 0, 0, 709);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1082, 1, 0, 0, 710);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1082, 1, 0, 0, 711);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1084, 0, 0, 1, 712);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1084, 0, 0, 1, 713);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1084, 0, 0, 1, 714);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1084, 1, 0, 0, 715);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1084, 1, 0, 0, 716);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1084, 1, 0, 0, 717);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1084, 1, 0, 0, 718);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1084, 1, 0, 0, 719);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1086, 0, 0, 1, 720);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1086, 0, 0, 1, 721);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1086, 0, 0, 1, 722);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1086, 1, 0, 0, 723);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1086, 1, 0, 0, 724);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1086, 1, 0, 0, 725);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1086, 1, 0, 0, 726);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1086, 1, 0, 0, 727);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13001, 0, 0, 1, 728);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13001, 0, 0, 1, 729);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13001, 0, 0, 1, 730);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13001, 1, 0, 0, 731);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13001, 1, 0, 0, 732);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13001, 1, 0, 0, 733);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13001, 1, 0, 0, 734);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13001, 1, 0, 0, 735);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13003, 0, 0, 1, 736);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13003, 0, 0, 1, 737);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13003, 0, 0, 1, 738);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13003, 1, 0, 0, 739);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13003, 1, 0, 0, 740);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13003, 1, 0, 0, 741);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13003, 1, 0, 0, 742);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13003, 1, 0, 0, 743);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13005, 0, 0, 1, 744);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13005, 0, 0, 1, 745);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13005, 0, 0, 1, 746);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13005, 1, 0, 0, 747);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13005, 1, 0, 0, 748);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13005, 1, 0, 0, 749);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13005, 1, 0, 0, 750);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13005, 1, 0, 0, 751);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13007, 0, 0, 1, 752);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13007, 0, 0, 1, 753);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13007, 0, 0, 1, 754);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13007, 1, 0, 0, 755);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13007, 1, 0, 0, 756);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13007, 1, 0, 0, 757);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13007, 1, 0, 0, 758);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13007, 1, 0, 0, 759);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13009, 0, 0, 1, 760);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13009, 0, 0, 1, 761);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13009, 0, 0, 1, 762);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13009, 1, 0, 0, 763);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13009, 1, 0, 0, 764);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13009, 1, 0, 0, 765);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13009, 1, 0, 0, 766);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13009, 1, 0, 0, 767);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13011, 0, 0, 1, 768);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13011, 0, 0, 1, 769);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13011, 0, 0, 1, 770);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13011, 1, 0, 0, 771);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13011, 1, 0, 0, 772);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13011, 1, 0, 0, 773);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13011, 1, 0, 0, 774);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13011, 1, 0, 0, 775);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13013, 0, 0, 1, 776);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13013, 0, 0, 1, 777);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13013, 0, 0, 1, 778);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13013, 1, 0, 0, 779);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13013, 1, 0, 0, 780);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13013, 1, 0, 0, 781);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13013, 1, 0, 0, 782);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13013, 1, 0, 0, 783);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13015, 0, 0, 1, 784);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13015, 0, 0, 1, 785);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13015, 0, 0, 1, 786);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13015, 1, 0, 0, 787);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13015, 1, 0, 0, 788);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13015, 1, 0, 0, 789);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13015, 1, 0, 0, 790);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13015, 1, 0, 0, 791);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13017, 0, 0, 1, 792);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13017, 0, 0, 1, 793);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13017, 0, 0, 1, 794);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13017, 1, 0, 0, 795);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13017, 1, 0, 0, 796);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13017, 1, 0, 0, 797);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13017, 1, 0, 0, 798);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13017, 1, 0, 0, 799);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13019, 0, 0, 1, 800);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13019, 0, 0, 1, 801);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13019, 0, 0, 1, 802);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13019, 1, 0, 0, 803);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13019, 1, 0, 0, 804);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13019, 1, 0, 0, 805);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13019, 1, 0, 0, 806);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13019, 1, 0, 0, 807);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13021, 0, 0, 1, 808);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13021, 0, 0, 1, 809);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13021, 0, 0, 1, 810);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13021, 1, 0, 0, 811);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13021, 1, 0, 0, 812);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13021, 1, 0, 0, 813);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13021, 1, 0, 0, 814);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13021, 1, 0, 0, 815);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13023, 0, 0, 1, 816);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13023, 0, 0, 1, 817);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13023, 0, 0, 1, 818);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13023, 1, 0, 0, 819);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13023, 1, 0, 0, 820);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13023, 1, 0, 0, 821);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13023, 1, 0, 0, 822);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13023, 1, 0, 0, 823);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13025, 0, 0, 1, 824);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13025, 0, 0, 1, 825);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13025, 0, 0, 1, 826);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13025, 1, 0, 0, 827);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13025, 1, 0, 0, 828);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13025, 1, 0, 0, 829);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13025, 1, 0, 0, 830);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13025, 1, 0, 0, 831);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13027, 0, 0, 1, 832);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13027, 0, 0, 1, 833);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13027, 0, 0, 1, 834);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13027, 1, 0, 0, 835);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13027, 1, 0, 0, 836);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13027, 1, 0, 0, 837);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13027, 1, 0, 0, 838);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13027, 1, 0, 0, 839);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13029, 0, 0, 1, 840);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13029, 0, 0, 1, 841);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13029, 0, 0, 1, 842);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13029, 1, 0, 0, 843);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13029, 1, 0, 0, 844);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13029, 1, 0, 0, 845);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13029, 1, 0, 0, 846);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13029, 1, 0, 0, 847);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13031, 0, 0, 1, 848);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13031, 0, 0, 1, 849);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13031, 0, 0, 1, 850);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13031, 1, 0, 0, 851);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13031, 1, 0, 0, 852);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13031, 1, 0, 0, 853);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13031, 1, 0, 0, 854);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13031, 1, 0, 0, 855);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13033, 0, 0, 1, 856);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13033, 0, 0, 1, 857);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13033, 0, 0, 1, 858);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13033, 1, 0, 0, 859);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13033, 1, 0, 0, 860);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13033, 1, 0, 0, 861);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13033, 1, 0, 0, 862);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13033, 1, 0, 0, 863);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13035, 0, 0, 1, 864);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13035, 0, 0, 1, 865);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13035, 0, 0, 1, 866);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13035, 1, 0, 0, 867);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13035, 1, 0, 0, 868);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13035, 1, 0, 0, 869);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13035, 1, 0, 0, 870);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13035, 1, 0, 0, 871);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13037, 0, 0, 1, 872);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13037, 0, 0, 1, 873);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13037, 0, 0, 1, 874);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13037, 1, 0, 0, 875);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13037, 1, 0, 0, 876);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13037, 1, 0, 0, 877);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13037, 1, 0, 0, 878);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13037, 1, 0, 0, 879);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13039, 0, 0, 1, 880);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13039, 0, 0, 1, 881);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13039, 0, 0, 1, 882);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13039, 1, 0, 0, 883);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13039, 1, 0, 0, 884);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13039, 1, 0, 0, 885);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13039, 1, 0, 0, 886);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13039, 1, 0, 0, 887);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13041, 0, 0, 1, 888);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13041, 0, 0, 1, 889);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13041, 0, 0, 1, 890);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13041, 1, 0, 0, 891);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13041, 1, 0, 0, 892);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13041, 1, 0, 0, 893);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13041, 1, 0, 0, 894);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13041, 1, 0, 0, 895);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13043, 0, 0, 1, 896);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13043, 0, 0, 1, 897);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13043, 0, 0, 1, 898);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13043, 1, 0, 0, 899);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13043, 1, 0, 0, 900);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13043, 1, 0, 0, 901);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13043, 1, 0, 0, 902);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13043, 1, 0, 0, 903);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13045, 0, 0, 1, 904);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13045, 0, 0, 1, 905);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13045, 0, 0, 1, 906);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13045, 1, 0, 0, 907);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13045, 1, 0, 0, 908);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13045, 1, 0, 0, 909);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13045, 1, 0, 0, 910);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13045, 1, 0, 0, 911);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13047, 0, 0, 1, 912);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13047, 0, 0, 1, 913);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13047, 0, 0, 1, 914);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13047, 1, 0, 0, 915);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13047, 1, 0, 0, 916);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13047, 1, 0, 0, 917);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13047, 1, 0, 0, 918);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13047, 1, 0, 0, 919);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1088, 0, 0, 1, 920);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1088, 0, 0, 1, 921);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1088, 0, 0, 1, 922);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1088, 1, 0, 0, 923);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1088, 1, 0, 0, 924);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1088, 1, 0, 0, 925);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1088, 1, 0, 0, 926);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1088, 1, 0, 0, 927);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1090, 0, 0, 1, 928);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1090, 0, 0, 1, 929);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1090, 0, 0, 1, 930);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1090, 1, 0, 0, 931);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1090, 1, 0, 0, 932);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1090, 1, 0, 0, 933);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1090, 1, 0, 0, 934);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1090, 1, 0, 0, 935);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1092, 0, 0, 1, 936);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1092, 0, 0, 1, 937);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1092, 0, 0, 1, 938);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1092, 1, 0, 0, 939);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1092, 1, 0, 0, 940);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1092, 1, 0, 0, 941);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1092, 1, 0, 0, 942);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1092, 1, 0, 0, 943);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1094, 0, 0, 1, 944);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1094, 0, 0, 1, 945);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1094, 0, 0, 1, 946);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1094, 1, 0, 0, 947);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1094, 1, 0, 0, 948);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1094, 1, 0, 0, 949);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1094, 1, 0, 0, 950);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1094, 1, 0, 0, 951);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13048, 0, 0, 1, 952);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13048, 0, 0, 1, 953);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13048, 0, 0, 1, 954);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13048, 1, 0, 0, 955);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13048, 1, 0, 0, 956);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13048, 1, 0, 0, 957);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13048, 1, 0, 0, 958);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13048, 1, 0, 0, 959);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 13050, 0, 0, 1, 960);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 13050, 0, 0, 1, 961);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 13050, 0, 0, 1, 962);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 13050, 1, 0, 0, 963);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 13050, 1, 0, 0, 964);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 13050, 1, 0, 0, 965);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 13050, 1, 0, 0, 966);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 13050, 1, 0, 0, 967);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (1, 1, '&Novo', 'Incluir Registro', 1104, 0, 0, 1, 968);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (2, 13, '&Editar', 'Editar Registro', 1104, 0, 0, 1, 969);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (3, 3, 'E&xcluir', 'EXcluir Registro', 1104, 0, 0, 1, 970);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (4, 4, '&Localizar', 'Localizar Registro', 1104, 1, 0, 0, 971);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (5, 6, '&Imprimir', 'Imprimir Registro', 1104, 1, 0, 0, 972);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (6, 11, 'Es&colher', 'Escolher Registro', 1104, 1, 0, 0, 973);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 14, '&Ordenar', 'Ordenar', 1104, 1, 0, 0, 974);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 19, '&Sair', 'Sair/Retornar', 1104, 1, 0, 0, 975);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 12, 'L&iberar', 'LIberar', 1065, 0, 0, 0, 976);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 5, 'Versao Imp', 'Importar Versao Antiga do Wrpt', 1059, 0, 0, 1, 977);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 14, '&Ordenar', 'Ordenar', 505, 1, 0, 0, 994);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (9, 19, '&Sair', 'Sair/Retornar', 505, 1, 0, 0, 995);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (7, 11, 'Es&colher', 'Escolher Registro', 1015, 1, 0, 0, 1002);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (8, 14, '&Ordenar', 'Ordenar', 1015, 1, 0, 0, 1003);

-- inserting data
INSERT INTO BOTOES (INDICE, ICONE, NOME, TOOLTIP, FORM, DISPONIVEL, INATIVO, REQDIR, ID)
VALUES (9, 19, '&Sair', 'Sair/Retornar', 1015, 1, 0, 0, 1004);
-- creating table
CREATE TABLE FORMS (
	FORM NUMBER (10),
	NOMEPRG VARCHAR2 (50),
	INATIVO NUMBER (1) NOT NULL,
	DISPONIVEL NUMBER (1) NOT NULL,
	MODULO NUMBER (10),
	REQDIR NUMBER (1) NOT NULL,
	NOME VARCHAR2 (120),
	ID NUMBER (10) NOT NULL
);



-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1001, 'FrmPrincipal', 1, 0, 1, 0, 'Formulario Principal Geral', 1);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1003, 'EscIcone', 0, 0, 1, 1, 'Escolher Icone', 2);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1004, 'EscForm', 0, 0, 1, 1, 'Escolher Formularios', 3);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1005, 'FRMIMG', 0, 0, 1, 0, 'VISUALIZAR IMAGENS', 4);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1006, 'EscMenu', 0, 0, 1, 1, 'Escolher Menu', 5);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1007, 'FRMMENU', 0, 0, 1, 0, 'EDITAR MENUS', 6);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1008, 'FrmIcone', 0, 0, 1, 0, 'Editar Icones', 7);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1009, 'FrmForm', 0, 0, 1, 0, 'Editar Formularios', 8);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1010, 'FrmBotao', 0, 0, 1, 0, 'Editar Botoes', 9);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1011, 'escUser', 0, 0, 1, 1, 'Escolher Usuarios', 10);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1012, 'FrmUser', 0, 0, 1, 0, 'Editar Usuarios', 11);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1013, 'FRMUSUSENHA', 0, 0, 1, 0, 'TROCAR SENHAS', 12);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1015, 'ESCMF01', 0, 0, 1, 1, 'ESCOLHER BANCOS', 13);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1016, 'frmMF01', 0, 0, 1, 0, 'Cadastro de Bancos', 14);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1017, 'escREP', 0, 0, 1, 1, 'Manuten�ao de Arquivos', 15);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1018, 'frmReparar', 0, 0, 1, 0, 'Editar Arquivos', 16);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1019, 'frmEstMdb', 0, 0, 1, 0, 'Gerar Documenta�ao Estrutura', 17);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1020, 'frmComp', 0, 0, 1, 0, 'Pedir Competencia Firma', 18);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1021, 'escMF04', 0, 0, 1, 1, 'Escolher Pra�a', 19);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1022, 'frmMF04', 0, 0, 1, 0, 'Editar Pra�a', 20);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1023, 'escCodNome', 0, 0, 1, 1, 'Escolher Regioes', 21);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1024, 'frmCodNome', 0, 0, 1, 0, 'Editar Regioes', 22);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1025, 'escEstadis', 0, 0, 1, 1, 'Escolher Estados(UF)', 23);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1026, 'frmEstadios', 0, 0, 1, 0, 'Editar Estados', 24);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1027, 'escML03', 0, 0, 1, 1, 'Escolher Controle de Cheques', 25);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1028, 'frmML03', 0, 0, 1, 0, 'Editar Controle de cheques', 26);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1029, 'escCodNOme', 0, 0, 1, 1, 'Codigos Devolu�ao Cheques (Escolha)', 27);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1030, 'frmCodNom', 0, 0, 1, 0, 'Codigos Devolu��o Cheques (Edi�ao)', 28);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1031, 'esccodnome ', 0, 0, 1, 1, 'CNAB Especies (Escolher) ', 29);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1032, 'frmcodnome ', 0, 0, 1, 0, 'CNAB Especies Editar ', 30);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1033, 'esccodnome ', 0, 0, 1, 1, 'CNAB Ocorrencias Escolher ', 31);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1034, 'frmcodnome ', 0, 0, 1, 0, 'CNAB Ocorrencia Editar ', 32);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1035, 'escodnome ', 0, 0, 1, 1, 'CNAB Instrucoes (Escolher) ', 33);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1036, 'frmcodnome ', 0, 0, 1, 0, 'CNAB Instrucoes Editar ', 34);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1037, 'esccoddesc', 0, 0, 1, 1, 'Moeda', 35);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1038, 'frmMDMoeda', 0, 0, 1, 0, 'Moeda Editar', 36);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1039, 'EscCodDes', 0, 0, 1, 1, 'CNAB Carteira Escolher', 37);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1040, 'frmMDCobCar', 0, 0, 1, 0, 'CNAB Carteira Editar', 38);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (999, NULL, 0, 0, 1, 0, 'Toolbar Somente Botao Saida', 39);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1041, 'BrowseImg', 0, 0, 1, 0, 'Visualizar Imagens Explorar Pastas', 40);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1042, 'esccodnome', 0, 0, 1, 1, 'Tipos Linguagem Programa�ao', 41);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1043, 'frmcodnome', 0, 0, 1, 0, 'Linguagens Programa�ao (Edi�ao)', 42);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1044, 'esccodnome', 0, 0, 1, 1, 'Tipos Base Dados', 43);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1045, 'frmcodnome', 0, 0, 1, 0, 'Tipos Base Dados(Edic�o)', 44);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1046, 'esccodnome', 0, 0, 1, 1, 'Tabela Tipos de Campos', 45);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1047, 'frmcodnome', 0, 0, 1, 0, 'Tipos Campos Dados', 46);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1048, 'escnumnome', 0, 0, 1, 1, 'Modulos Documenta�ao Sistema', 47);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1049, 'frmModulos', 0, 0, 1, 0, 'Modulos Documenta�ao Sistema(Edi��o)', 48);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1050, 'frmBaseDados', 0, 0, 1, 0, 'Documenta�ao Sistema Base Dados', 49);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1051, 'FrmAlteracao', 0, 0, 1, 0, 'Mudancas no Sistema', 50);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1052, 'esccodnome', 0, 0, 1, 0, 'Tabelas Tipos Caracteristas dos Modulos', 51);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1053, 'frmcodnome', 0, 0, 1, 0, 'Tabelas Tipos Caracteriscas dos Modulos Edi�ao', 52);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1054, 'frmCaracter', 0, 0, 1, 0, 'Documenta�ao Caracteristicas do Sistema', 53);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1055, 'frmRTF', 0, 0, 1, 0, 'Editor de Textos', 54);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1056, 'frmIniEditor', 0, 0, 1, 0, 'Editor de Arquivos Ini', 55);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1057, 'escodnome', 0, 0, 1, 1, 'Relatorios/Documentos Grupo', 56);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1058, 'frmrptmain', 0, 0, 1, 0, 'Relatorios/Documentos Grupo - Edi�ao', 57);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1059, 'ESCRPTGRP', 0, 1, 1, 1, 'ESCOLHER GRUPO RELATORIOS', 58);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1060, 'FRMRPTGRP', 0, 0, 1, 0, 'GRUPO RELATORIOS EDITAR', 59);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1061, 'esccodnome', 0, 0, 1, 1, 'Tipos de Arquivos Extens�es (Escolher)', 60);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1062, 'frmcodnome', 0, 0, 1, 0, 'Tipos de Arquivos Extens�es (Editar)', 61);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1063, 'escRptExec', 0, 0, 1, 1, 'Tipos de Execu�ao Gerenciados Relatorios/Documento', 62);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1064, 'frmRptExec', 0, 0, 1, 0, 'Tipos Execu�ao Gerenciador Relatorios/Documentos E', 63);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1065, 'ESCRPT', 0, 1, 1, 1, 'ESCOLHER RELATORIO', 64);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1066, 'frmrpt', 0, 0, 1, 0, 'Edi�ao Relatorios / Documentos', 65);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1067, 'frmfiltro', 0, 0, 1, 0, 'Filtro para Relatorios', 66);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1068, 'FrmCrw', 0, 0, 1, 0, 'Crystal Report Ocx ', 67);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1069, 'FrmCrwEng', 0, 0, 1, 0, 'Crystal Report Engine', 68);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1070, 'frmSenha', 0, 0, 1, 0, 'Senha de Acessos', 69);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (500, 'frmPrincipal', 0, 0, 5, 0, 'Tela Principal Dicionarios', 70);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (501, 'escDIC', 0, 0, 5, 1, 'escolher dicionarios', 71);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (502, 'frmCon', 0, 0, 5, 0, 'Busca De Palavras', 72);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (503, 'frmexpold', 0, 0, 5, 0, 'Exportar Diconario', 73);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (504, 'frmincdic', 0, 0, 5, 0, 'Edi��o do Dicionario', 74);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (505, 'GRIDDIC', 0, 0, 5, 1, 'EDI�AO LISTA PALAVRAS DICONARIOS', 75);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1002, 'frmSplash', 0, 0, 1, 0, 'Tela de Abertura', 76);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1014, 'frmabout', 0, 0, 1, 0, 'Sobre o Sistema', 77);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1071, 'frmvid', 0, 0, 1, 0, 'Exibe Video/Anima�oes', 78);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1072, 'frmLocalizar', 0, 0, 1, 0, 'Dialogo Para Busca de Dados', 79);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1073, 'escCodNOme', 0, 0, 1, 1, 'Escolher Zonas/SubRegios', 80);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1074, 'frmZona', 0, 0, 1, 0, 'Editar Zonas / Sub Regioes', 81);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1075, 'escOrdem', 0, 0, 1, 0, 'Escolher Ordena�ao', 82);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1076, 'griCidades', 0, 0, 1, 1, 'Escolher Cidades', 83);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1077, 'frmCidades', 0, 0, 1, 0, 'Cadastro de Cidades', 84);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1078, 'frmPaises', 0, 0, 1, 0, 'Cadastro de Paies', 85);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4001, 'esccoddesc', 0, 0, 4, 1, 'Codigos Divergencia Declaracao', 86);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4002, 'frmcoddesc', 0, 0, 4, 0, 'Codigos Divergencia Declaracao', 87);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4003, 'esccoddes', 0, 0, 4, 1, 'Codigos Admissao Temporaria', 88);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4004, 'frmcoddesc', 0, 0, 4, 0, 'Codigos de Admissao Temporaria', 89);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4005, 'esccoddesc', 0, 0, 4, 1, 'Motivos sem Cobertura Cambial', 90);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4006, 'frmcoddesc', 0, 0, 4, 0, 'Motivos sem Cobertura Cambial', 91);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4007, 'esccoddes', 0, 0, 4, 1, 'fundo 39', 92);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4008, 'frmcoddesc', 0, 0, 4, 0, 'fundo 39', 93);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1079, 'frmLiberar', 0, 0, 1, 0, 'Liberacao de Direitos Usuarios', 94);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4021, 'esccoddesc', 0, 0, 4, 1, 'Unidades de Medida', 95);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4022, 'frmcoddesc', 0, 0, 4, 0, 'Unidades de Medida', 96);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4023, 'esccoddesc', 0, 0, 4, 1, 'Unidades de Medida Mercantil NBMSH', 97);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4024, 'frmcoddesc', 0, 0, 4, 0, 'Unidades de Medida Mercantil NBMSH', 98);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4025, 'esccoddesc', 0, 0, 4, 1, 'Recipiente', 99);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4009, 'esccoddesc', 0, 0, 4, 1, 'fundo 42', 100);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4010, 'frmcoddes', 0, 0, 4, 0, 'fundo42', 101);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4011, 'esccoddesc', 0, 0, 4, 1, 'Motivos fundo 72', 102);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4012, 'frmcoddesc', 0, 0, 4, 0, 'Motivos fundos 72', 103);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4013, 'esccoddesc', 0, 0, 4, 1, 'Motivos fundo 73', 104);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4014, 'frmcoddesc', 0, 0, 4, 0, 'Motivos fundo 73', 105);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4015, 'esccoddesc', 0, 0, 4, 1, 'Tabela Acrescimo Valor Aduaneira', 106);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4016, 'frmcoddesc', 0, 0, 4, 0, 'Tabela Acrescimo Valor Aduaneira', 107);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4017, 'esccoddesc', 0, 0, 4, 1, 'Tabela Deducao Valor Aduneira', 108);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4018, 'frmcoddesc', 0, 0, 4, 0, 'Tabela Deducao Valor Aduneira', 109);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4019, 'esccoddesc', 0, 0, 4, 1, 'Tabela Metodo Valor Aduaneira', 110);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4020, 'frmcoddesc', 0, 0, 4, 0, 'Tabela Metodo Valor Aduaneira', 111);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4026, 'frmcoddesc', 0, 0, 4, 0, 'Recipiente', 112);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4027, 'esccoddesc', 0, 0, 4, 1, 'Embalagem', 113);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4028, 'frmcoddesc', 0, 0, 4, 0, 'Embalagem', 114);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4029, 'esccoddesc', 0, 0, 4, 1, 'Grupos', 115);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4030, 'frmcoddesc', 0, 0, 4, 0, 'Grupos', 116);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4031, 'esccoddesc', 0, 0, 4, 1, 'Instituicao Financeira Internacional', 117);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4032, 'frmcoddesc', 0, 0, 4, 0, 'Instituicao Financeira Internacional', 118);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4033, 'esccoddesc', 0, 0, 4, 1, 'Orgao Emissor Ato Legal', 119);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4034, 'frmcoddesc', 0, 0, 4, 0, 'Orgao Emissor Ato Legal', 120);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4035, 'esccoddesc', 0, 0, 4, 1, 'RF', 121);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4036, 'frmcoddesc', 0, 0, 4, 0, 'RF', 122);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4037, 'esccoddesc', 0, 0, 4, 1, 'URF', 123);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4038, 'frmcoddesc', 0, 0, 4, 0, 'URF', 124);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4039, 'esccoddesc', 0, 0, 4, 1, 'Documento Instrucao Despacho', 125);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4040, 'frmcoddesc', 0, 0, 4, 0, 'Documento Instrucao Despacho', 126);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4041, 'esccoddesc', 0, 0, 4, 1, 'Etapas de Despacho', 127);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4042, 'frmcoddesc', 0, 0, 4, 0, 'Etapas de Despacho', 128);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4043, 'esccoddesc', 0, 0, 4, 1, 'Erros de Despacho', 129);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4044, 'frmcoddesc', 0, 0, 4, 0, 'Erros de Despacho', 130);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4045, 'esccoddesc', 0, 0, 4, 1, 'Natureza do Despacho', 131);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4046, 'frmcoddesc', 0, 0, 4, 0, 'Natureza do Despacho', 132);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4047, 'esccoddesc', 0, 0, 4, 1, 'Tipo de Despacho', 133);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4048, 'frmcoddesc', 0, 0, 4, 0, 'Tipo de Despacho', 134);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4049, 'esccoddesc', 0, 0, 4, 1, 'Administrativo', 135);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4050, 'frmcoddesc', 0, 0, 4, 0, 'Administrativo', 136);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4051, 'esccoddesc', 0, 0, 4, 1, 'Tipo Declaracao', 137);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4052, 'frmcoddesc', 0, 0, 4, 0, 'Tipo Declaracao', 138);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4053, 'esccoddesc', 0, 0, 4, 1, 'Tipo Ato Legal', 139);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4054, 'frmcoddesc', 0, 0, 4, 0, 'Tipo Ato Legal', 140);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4055, 'esccoddesc', 0, 0, 4, 1, 'Tipo Importador', 141);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4056, 'frmcoddesc', 0, 0, 4, 0, 'Tipo Importador', 142);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4057, 'esccoddesc', 0, 0, 4, 1, 'Via de Transporte', 143);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4058, 'frmcoddesc', 0, 0, 4, 0, 'Via de Transporte', 144);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4059, 'esccoddesc', 0, 0, 4, 1, 'Tipo de Documento de Carga', 145);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4060, 'frmcoddesc', 0, 0, 4, 0, 'Tipo de Documento de Carga', 146);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4061, 'esccoddesc', 0, 0, 4, 1, 'Cobertura Cambial', 147);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4062, 'frmcoddesc', 0, 0, 4, 0, 'Cobertura Cambial', 148);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4063, 'esccoddesc', 0, 0, 4, 1, 'Despesas', 149);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4064, 'frmcoddesc', 0, 0, 4, 0, 'Despesas', 150);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4065, 'esccoddesc', 0, 0, 4, 1, 'Modalidade de Pagamento', 151);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4066, 'frmcoddesc', 0, 0, 4, 0, 'Modalidade de Pagamento', 152);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4067, 'esccoddesc', 0, 0, 4, 1, 'Rec de Arrecadacao', 153);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4068, 'frmcoddesc', 0, 0, 4, 0, 'Rec de Arrecadacao', 154);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4069, 'esccoddesc', 0, 0, 4, 1, 'Posicao NCM', 155);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4070, 'frmcoddesc', 0, 0, 4, 0, 'Posicao NCM', 156);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4071, 'esccoddesc', 0, 0, 4, 1, 'Regime Tributario', 157);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4072, 'frmcoddesc', 0, 0, 4, 0, 'Regime Tributario', 158);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4073, 'esccoddesc', 0, 0, 4, 1, 'Rec Impostos', 159);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4074, 'frmcoddesc', 0, 0, 4, 0, 'Rec Impostos', 160);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4075, 'esccoddesc', 0, 0, 4, 1, 'Incoterms Venda', 161);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4076, 'frmcoddesc', 0, 0, 4, 0, 'Incoterms Venda', 162);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4077, 'esccoddesc', 0, 0, 4, 1, 'ALADI', 163);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4078, 'frmcoddesc', 0, 0, 4, 0, 'ALADI', 164);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4079, 'esccoddesc', 0, 0, 4, 1, 'Naladinca', 165);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4080, 'frmcoddesc', 0, 0, 4, 0, 'Naladincca', 166);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4081, 'esccoddesc', 0, 0, 4, 1, 'Naladish', 167);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4082, 'frmcoddesc', 0, 0, 4, 0, 'Naladish', 168);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4083, 'esccoddesc', 0, 0, 4, 1, 'Natureza Operacao', 169);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4084, 'frmcoddesc', 0, 0, 4, 0, 'Natureza Operacao', 170);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4085, 'esccoddesc', 0, 0, 4, 1, 'Atividade Economica', 171);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4086, 'frmcoddesc', 0, 0, 4, 0, 'Atividade Economica', 172);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4087, 'esccoddesc', 0, 0, 4, 1, 'Capitulo', 173);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4088, 'frmcoddesc', 0, 0, 4, 0, 'Capitulo', 174);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4089, 'esccoddesc', 0, 0, 4, 1, 'Canal', 175);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4090, 'frmcoddesc', 0, 0, 4, 0, 'Canal', 176);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4091, 'esccoddesc', 0, 0, 4, 1, 'Navio', 177);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (4092, 'frmcoddesc', 0, 0, 4, 0, 'Navio', 178);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1080, 'esccodnome', 0, 0, 1, 1, 'Tipos Pessoas Bacen', 179);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1081, 'frmcodnome', 0, 0, 1, 0, 'Tipos de Pessoas Bacen', 180);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1082, 'frmcoddesc', 0, 0, 1, 1, 'Tipos de Localidades Correio', 181);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1083, 'frmcoddesfax', 0, 0, 1, 0, 'Tipos de Localidades Correio', 182);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1084, 'frmcodDesc', 0, 0, 1, 1, 'Tipos de Localidade Correio', 183);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1085, 'frmcoddesfax', 0, 0, 1, 0, 'Tipos de Localidades Correio', 184);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1086, 'EscPaises', 0, 0, 1, 1, 'Cadastro de Paises', 185);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1087, 'FrmPegDb', 0, 0, 1, 0, 'Permite Escolher Uma Base de Dados', 186);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13001, 'esccoddesc', 0, 0, 13, 1, 'Rais Afastamentos', 187);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13002, 'frmcoddes', 0, 0, 13, 0, 'Rais Afastamentos', 188);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13003, 'esccoddes', 0, 0, 13, 1, 'rais desligamentos', 189);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13004, 'frmcoddes', 0, 0, 13, 0, 'rais desligamentos', 190);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13005, 'esccoddes', 0, 0, 13, 1, 'Rais Instru�ao', 191);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13006, 'frmcoddes', 0, 0, 13, 0, 'rais instrucao', 192);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13007, 'esccoddes', 0, 0, 13, 1, 'Rais Nacionalidade', 193);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13008, 'frmcoddes', 0, 0, 13, 0, 'Rais nacionalidade', 194);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13009, 'escoddes', 0, 0, 13, 1, 'Rais Natureza Juridica', 195);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13010, 'frmcoddes', 0, 0, 13, 0, 'Rais Natureza Juridica', 196);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13011, 'esccoddes', 0, 0, 13, 1, 'Tipos de Admissao', 197);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13012, 'frmcoddes', 0, 0, 13, 0, 'Rais Tipos de Admissao', 198);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13013, 'esccoddes', 0, 0, 13, 1, 'Rais Raca', 199);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13014, 'frmcoddes', 0, 0, 13, 0, 'Rais Raca', 200);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13015, 'esccoddes', 0, 0, 13, 1, 'Rais Tipos de Salarios', 201);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13016, 'frmcoddes', 0, 0, 13, 0, 'Rais Tipos de Salarios', 202);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13017, 'esccoddes', 0, 0, 13, 1, 'Rais Vinculos Empregaticios', 203);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13018, 'frmcoddes', 0, 0, 13, 0, 'Rais Vinculos Empregaticios', 204);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13019, 'esccoddes', 0, 0, 13, 1, 'Cbo Antigos', 205);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13020, 'frmcoddes', 0, 0, 13, 0, 'Cbo Antigos', 206);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13021, 'escoddes', 0, 0, 13, 1, 'cbo novo', 207);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13022, 'frmcoddes', 0, 0, 13, 0, 'cbo novo', 208);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13023, 'escoddes', 0, 0, 13, 1, 'cnae', 209);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13024, 'frmcoddes', 0, 0, 13, 0, 'cnae', 210);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13025, 'esccodnom', 0, 0, 13, 1, 'Codigos Pagamentos Fgts', 211);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13026, 'frmcodnom', 0, 0, 13, 0, 'Codigos Pagamentos FGTS', 212);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13027, 'esccodnome', 0, 0, 13, 1, 'Codigos Pgto IRRF', 213);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13028, 'frmccodnome', 0, 0, 13, 0, 'Codigos Pgto IRRF', 214);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13029, 'esccodnome', 0, 0, 13, 1, 'Codigos Pgto INSS', 215);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13030, 'frmcodnome', 0, 0, 13, 0, 'Codigos Pgto INSS', 216);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13031, 'esccoddes', 0, 0, 13, 1, 'Codigos de Acidente Trabalho(INSS)', 217);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13032, 'frmcoddes', 0, 0, 13, 0, 'Codigos Acd Trabalho(INSS)', 218);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13033, 'esccoddes', 0, 0, 13, 1, 'Codigos FPAS(INSS)', 219);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13034, 'frmcoddes', 0, 0, 13, 0, 'Codigos FPAS(INSS)', 220);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13035, 'esccodnome', 0, 0, 13, 1, 'Sefip Codigos Altera�ao de Cadastro', 221);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13036, 'frmcodnome', 0, 0, 13, 0, 'Sefip Codigos Altera�ao de Cadastro', 222);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13037, 'esccodnome', 0, 0, 13, 1, 'SEFIP Classes de Recolhimento', 223);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13038, 'frmcoddes', 0, 0, 13, 0, 'SEFIP Classes de Recolhimento', 224);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13039, 'esccodnome', 0, 0, 13, 1, 'Sefip Contribuintes (Emitente)', 225);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13040, 'frmcodnome', 0, 0, 13, 0, 'SEFIP Contribuintes(Emitente)', 226);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13041, 'esccodnome', 0, 0, 13, 1, 'Sefip Tipos de Contribuintes', 227);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13042, 'frmcodnome', 0, 0, 13, 0, 'Sefip Tipos de Contribuintes', 228);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13043, 'escodnome', 0, 0, 13, 1, 'SEFIP Tipos de Movimentacao', 229);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13044, 'frmcodnome', 0, 0, 13, 0, 'Sefip Tipos de Contribuintes', 230);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13045, 'esccodnome', 0, 0, 13, 1, 'SEFIP Ocorrencias', 231);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13046, 'frmcodnome', 0, 0, 13, 0, 'SEFIP Ocorrencias', 232);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13047, 'esccodnome', 0, 0, 13, 1, 'SEFIP Codigos Opcao', 233);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1088, 'escSitTribA', 0, 0, 1, 0, 'Visualizar Situa��o Tributaria-tabela A', 234);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1089, 'frmSitTribA', 0, 0, 1, 0, 'Registrar Situa��o Tributaria-tabela A', 235);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1090, 'escSitTribB', 0, 0, 1, 1, 'Visualizar Situa��o Tributaria-tabela B - Origem', 236);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1091, 'frmSitTribB', 0, 0, 1, 0, 'Registrar Situa��o Tributaria - tabela B - Origem', 237);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1092, 'gridcfop', 0, 0, 1, 1, 'Visualizar Codigo Opera��o Fiscal - CFOP', 238);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1093, 'frmcfop', 0, 0, 1, 0, 'Registrar Codigo Opera��o Fiscal ', 239);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1094, 'ESCCODFISCAL ', 0, 0, 1, 1, 'DOCUMENTOS FISCAIS', 240);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1095, 'FRMDOCFISCAL', 0, 0, 1, 0, 'DOCUMENTOS FISCAIS', 241);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13048, 'ESCCODNOME', 0, 0, 13, 1, 'CODIGOS CAGED', 242);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13049, 'FRMCODDES', 0, 0, 13, 0, 'CAGED EDICAO', 243);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13050, 'ESCNUNNOME', 0, 0, 13, 1, 'CADASTRO SINDICATOS', 244);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (13051, 'FRMSINDICAT', 0, 0, 13, 0, 'CADASTRO SINDICATOS', 245);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1104, 'GRIIPI', 0, 0, 1, 1, 'NBM/NCM', 246);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1106, 'FRMIPI', 0, 0, 1, 0, 'NCM/NBM IPI', 247);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1107, 'escimg', 0, 0, NULL, 0, NULL, 248);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1108, 'expjpg', 0, 0, 1, 0, NULL, 249);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1111, 'frmprintsetup', 0, 0, 1, 0, 'configurar impressora', 250);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1110, 'frmpicviewer', 0, 0, 1, 0, 'navegar imagens', 251);

-- inserting data
INSERT INTO FORMS (FORM, NOMEPRG, INATIVO, DISPONIVEL, MODULO, REQDIR, NOME, ID)
VALUES (1109, 'frmimagens', 0, 0, 1, 0, 'editar imagens', 252);
-- creating table
CREATE TABLE ICONES (
	INDICE NUMBER (5),
	NOME VARCHAR2 (50),
	ARQUIVO VARCHAR2 (50),
	ID NUMBER (10) NOT NULL
);



-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (1, 'Novo', 'NEW.ICO', 1);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (2, 'Gravar', 'Save.ico', 2);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (3, 'Excluir', 'DELETE.ico', 3);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (4, 'Localizar', 'find.ico', 4);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (5, 'Copiar', 'Copy.ico', 5);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (6, 'Imprimir', 'print.ico', 6);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (7, 'Setup', 'chave.ico', 7);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (8, 'Foto', 'camera.ico', 8);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (9, 'Consultar', 'Clip.ico', 9);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (10, 'Configurar Impressora', 'printcfg.ico', 10);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (11, 'Escolher', 'prop.ico', 11);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (12, 'Liberar', 'pencil.ico', 12);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (13, 'Editar', 'Open.ico', 13);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (14, 'Ordenar', 'az.ico', 14);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (15, 'Filtrar', 'filtro.ico', 15);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (16, 'Documentar', 'documen.ico', 16);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (17, 'Senha', 'Senha.ico', 17);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (18, 'Troca', 'processa.ico', 18);

-- inserting data
INSERT INTO ICONES (INDICE, NOME, ARQUIVO, ID)
VALUES (19, 'Sair', 'Sair.ico', 19);
-- creating table
CREATE TABLE MENUS (
	MENU VARCHAR2 (10),
	INDICE NUMBER (10),
	DIZER VARCHAR2 (50),
	FORM NUMBER (10),
	MODULO NUMBER (10),
	ID NUMBER (10) NOT NULL
);



-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CON', 1, 'Usuarios', 11, 1, 1);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CON', 2, 'Menus', 6, 1, 2);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CON', 3, 'Formularios', 4, 1, 3);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CON', 4, 'ICones', 3, 1, 4);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TAB', 2, 'Grupo  Tabela Banco Banco(TABBCO)', 0, 1, 5);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CADBCO', 1, 'Escolher Banco', 1015, 1, 6);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CON', 5, 'Manuten�ao de Arquivos', 1017, 1, 7);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CADBCO', 4, 'Escolher Pra�a', 1021, 1, 8);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABCID', 1, 'Escolher Regioes', 1023, 1, 9);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABCID', 2, 'Estados UF', 1025, 1, 10);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CADCHE', 1, 'Cheques Em Aberto Pagar', 1027, 1, 11);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CADCHE', 2, 'Cheques Fechados Pagar', 1027, 1, 12);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CADCHE', 3, 'Cheques Todos Pagar', 1027, 1, 13);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CADCHE', 4, 'Cheques Abertos Receber', 1027, 1, 14);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CADBCO', 2, 'Agencias', 0, 1, 15);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CADBCO', 3, 'Contas Correntes', 0, 1, 16);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABCID', 3, 'Cidades', 0, 1, 17);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABCID', 4, 'Pais', 0, 1, 18);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CADCHE', 5, 'Cheques Fechados Receber', 1027, 1, 19);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CADCHE', 6, 'Cheques Todos Receber ', 1027, 1, 20);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CADCHE', 7, 'Codigos de Devolu�ao Cheques ', 1029, 1, 21);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABBCO', 1, 'Codigos de Devolu�ao de Cheques ', 1029, 1, 22);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABBCO', 2, 'Cnab Codigos de Carteiras', 1039, 1, 23);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABBCO', 3, 'CNAB Codigos de Especies', 1031, 1, 24);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABBCO', 4, 'CNAB Codigos de Ocorrencias ', 1033, 1, 25);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TAB', 1, 'Grupo Tabela UF/Cid/Pais (TABCID) ', 0, 1, 26);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CAD', 2, 'Grupo Banco (BCO) ', 0, 1, 27);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CAD', 3, 'Grupo Cheques (CHE) ', 0, 1, 28);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABBCO', 5, 'CNAB Codigos Instru�oes', 1035, 1, 29);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABBCO', 6, 'Moedas', 1037, 1, 30);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CON', 6, 'Grupo Documenta�ao Sistema', 0, 1, 31);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CONDOC', 1, 'Modulos', 0, 1, 32);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CONDOC', 2, 'Tabela Linguagens de Programa��o', 1042, 1, 33);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CONDOC', 3, 'Tabela Tipos Base de Dados', 1044, 1, 34);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CONDOC', 4, 'Tabela Tipos Campos de Tabelas', 1046, 1, 35);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CONDOC', 5, 'Base de Dados', 0, 1, 36);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CONDOC', 6, 'Tabela Tipos Caracteristas dos Mudulos', 1052, 1, 37);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('UTI', 1, 'Visualizador de Imagens', 1041, 1, 38);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('UTI', 2, 'Editor de Textos', 1055, 1, 39);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('UTI', 3, 'Editor de Arquivos ini', 1056, 1, 40);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('PRI', 3, 'Grupo Relatorios Documentos', 1057, 1, 41);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CONREL', 1, 'Relatorios', 0, 1, 42);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CONREL', 2, 'Tipos de Arquivos (Extensoes)', 1061, 1, 43);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CONREL', 3, 'Tipos Execu�ao Relatorios/Documentos', 1063, 1, 44);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('PRI', 1, 'Principal Cadastro', NULL, 1, 45);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('PRI', 2, 'Principal Tabelas', NULL, 1, 46);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('PRI', 4, 'Utilitarios', NULL, 1, 47);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CAD', 1, 'Grupo Clientes', 0, 1, 48);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CAD', 1, NULL, NULL, 24, 49);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('CON', 7, 'Configurar Dicionarios', 501, 1, 50);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('UTI', 4, 'Consulta Dicionario', 502, 1, 51);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABBCO', 7, 'Pessoas Bacen', 1080, 1, 52);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TAB', 3, 'Grupo Tabelas Correios(TABCOR)', 0, 1, 53);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABCOR', 1, 'Tipos de Localidade', 1082, 1, 54);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABCOR', 2, 'Titulos de Localidades Correio', 1084, 1, 55);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TAB', 4, 'Grupo Tabelas Folha', 0, 1, 56);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOL', 1, 'CNAE', 13023, 1, 57);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOL', 2, 'Rais', 0, 1, 58);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOL', 3, 'Funcoes', 0, 1, 59);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOL', 4, 'FGTS/SEFIP', 0, 1, 60);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOL', 5, 'IRRF', 0, 1, 61);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOL', 6, 'INSS', 0, 1, 62);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOLFUN', 1, 'CBO Antigo', 13019, 1, 63);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOLFUN', 2, 'CBO Novo', 13021, 1, 64);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOLRAIS', 1, 'Rais Afastamento', 13001, 1, 65);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOLRAIS', 2, 'Rais Desligamentos', 13003, 1, 66);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOLRAIS', 3, 'Rais Instru�ao', 13005, 1, 67);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOLRAIS', 4, 'Rais Nacionalidade', 13007, 1, 68);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOLRAIS', 5, 'Rais Natureza Juridica', 13009, 1, 69);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOLRAIS', 6, 'Rais Tipos de Admissao', 13011, 1, 70);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOLRAIS', 7, 'Rais Tipos de Racas', 13013, 1, 71);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOLRAIS', 8, 'Tipos de Salarios', 13015, 1, 72);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOLRAIS', 9, 'Tipos de Vinculos', 13017, 1, 73);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOLIRRF', 1, 'Codigos de Pagamentos', 13027, 1, 74);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOLINSS', 1, 'Codigos de Pagamentos', 13029, 1, 75);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOLINSS', 2, 'Codigos Acidente de Trabalho', 13031, 1, 76);

-- inserting data
INSERT INTO MENUS (MENU, INDICE, DIZER, FORM, MODULO, ID)
VALUES ('TABFOLINSS', 3, 'Codigos FPAS', 13033, 1, 77);
-- creating table
CREATE TABLE RPTEXEC (
	NOME VARCHAR2 (100),
	EXECUTAR VARCHAR2 (255),
	NUMERO NUMBER (10),
	EXTENSAO VARCHAR2 (8),
	OBS CLOB,
	ID NUMBER (10) NOT NULL
);



-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Imagens Visualizador Interno', 'frmimg', 22, 'BMP', NULL, 45);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Email ', 'frmsendmail', 57, 'MAIL', '', 57);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Email - Via Shell', 'SHELL', 58, 'MAIL', '', 58);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('frmcrwcrx', 'FRMCRWcrx', 55, 'RPT', '', 10);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Visualizar Autocad ', 'frmdwG', 49, 'IPT', NULL, 18);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Visualizar Autocad ', 'frmdwG', 50, 'IPW', NULL, 19);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Mana5 dos Relatorios', 'IMPREL.EXE', 51, 'MN5', '', 20);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Manual', 'frmRTF', 52, 'MAN', '', 21);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Editor Interno Ini', 'frmIniEditor', 1, 'INI', NULL, 24);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Editor RTF Interno', 'frmRTF', 2, 'RTF', NULL, 25);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Editor Txt Interno', 'frmRTF', 3, 'TXT', NULL, 26);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('SHELL (Configura�ao do Windows)', 'SHELL', 4, 'SHELL', NULL, 27);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Ajudas Compiladas', 'hh.exe', 5, 'CHM', NULL, 28);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Ajudas 16 Bits', 'winhelp.exe', 6, 'HLP', NULL, 29);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Ajudas', 'winhlp32.exe', 7, 'HLP', NULL, 30);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Sites Internet', 'SITE', 11, 'WWW', NULL, 31);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Editor Ini Externo', 'IniEditor.EXE', 8, 'INI', NULL, 32);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Crystal Report Engine', 'FrmCrwEng', 9, 'RPT', NULL, 33);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('RPT - Crystal - Ocx', 'FrmCrw', 10, 'RPT', NULL, 34);

-- inserting data
INSERT INTO RPTEXEC (NOME, EXECUTAR, NUMERO, EXTENSAO, OBS, ID)
VALUES ('Caretrun Versao 2', 'voretrun.exe', 13, 'RET', NULL, 36);
-- creating table
CREATE TABLE TIPOSARQ (
	CODIGO VARCHAR2 (8),
	NOME VARCHAR2 (100),
	ID NUMBER (10) NOT NULL
);



-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INI', 'Configura�ao de Inicializacao', 1);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MDB', 'Base de Dados Access', 2);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DBF', 'Tabelas Base Dados DBASE/FOXPRO', 3);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RTF', 'Rith Text Formato (Textos)', 4);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TXT', 'Arquivos de Textos', 5);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CDX', 'Arquivos de Indices FOXPRO', 6);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NTX', 'Arquivos de Indices Clipper', 7);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAN', 'Manuais Sistema Dos', 8);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('*', 'Todos', 9);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CHM', 'Arquivos de Ajudas Compilados', 10);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HLP', 'Arquivos de Ajudas', 11);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WWW', 'Sites Internet', 12);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RPT', 'Crystal Report', 13);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FRM', 'FORMULARIOS', 14);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TTF', 'Fontes de Letras(TTF)', 15);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('REP', 'Report Manager', 16);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RET', 'Caret Reports', 17);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAIL', 'INTERNET EMAIL', 18);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QRP', 'QUICKREPORT/MKRREPORT', 19);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CPL', 'WINDOWS CONTROL PANEL', 20);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ASF', 'StatGraphics', 21);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ASF', 'Windows Media Player', 22);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ASH', 'Turbo Assembler', 23);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ASI', 'Turbo Assembler / C / Borland C++', 24);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ASM', 'Assembler', 25);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ASO', 'Turbo Assembler', 26);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ASP', 'ProComm Plus', 27);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ASP', 'HTML-Browser (Internet Explorer; Netscape, Opera)', 28);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AST', 'HTML-Browser (Internet Explorer; Netscape, Opera)', 29);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AU', NULL, 30);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AVI', 'Videospieler (z.B. Windows Media Player)', 31);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AXI', 'MetaTools', 32);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('B20', 'BeckView 4 Gesetzestexteviewer', 33);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('B64', 'WinZip', 34);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BAS', 'VisualBASIC', 35);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BCF', 'Adobe PageMaker', 36);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BD', 'GhostScript', 37);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BDA', '3D Live', 38);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BDY', '3D Live', 39);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BEXPX', 'PGP', 40);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BHX', 'WinZip', 41);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BK2', 'WordPerfect f�r Windows', 42);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BK3', 'WordPerfect f�r Windows', 43);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BK4', 'WordPerfect f�r Windows', 44);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BK5', 'WordPerfect f�r Windows', 45);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BK6', 'WordPerfect f�r Windows', 46);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BK7', 'WordPerfect f�r Windows', 47);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BK8', 'WordPerfect f�r Windows', 48);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BK9', 'WordPerfect f�r Windows', 49);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BKF', 'Microsoft Datensicherung', 50);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BKI', 'IBM BookManager', 51);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BKP', 'Write', 52);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('$$$', 'AutoCAD', 53);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('$A', 'AutoCAD', 54);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('$$A', 'OS/2', 55);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('$$F', 'OS/2', 56);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('$$P', 'OS/2', 57);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('$$S', 'PMSpread OS/2', 58);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('$D$', 'OS/2', 59);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('$DB', 'dBase IV', 60);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('$ED', 'Microsoft C', 61);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('$VM', 'Microsoft Windows', 62);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('~', NULL, 63);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('~MN', 'Norton Commander', 64);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('075', 'Ventura Publisher', 65);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('085', 'Ventura Publisher', 66);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('091', 'Ventura Publisher', 67);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('096', 'Ventura Publisher', 68);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('0B', 'PakeMaker', 69);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('123', 'Lotus 123', 70);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('12M', 'Lotus 123', 71);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('15U', 'PakeMaker', 72);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('1ST', NULL, 73);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('286', 'Microsoft Windows', 74);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('2GR', 'Microsoft Windows', 75);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('301', 'SuperFax 2000', 76);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('323', 'NetMeeting', 77);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('386', 'Microsoft Windows', 78);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('3DS', '3D Studio', 79);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('3FX', 'Corel CHART', 80);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('3GR', 'Microsoft Windows', 81);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('4SW', '4DOS', 82);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('4TH', 'FORTH CMP', 83);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('669', 'WinAmp', 84);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('8', 'Assembler', 85);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('8M', 'PakeMaker', 86);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('8U', 'PakeMaker', 87);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('8BA', '(z. B. PhotoShop)', 88);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('8BC', '(z. B. PhotoShop)', 89);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('8BE', '(z. B. PhotoShop)', 90);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('8BF', '(z. B. PhotoShop)', 91);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('8BI', '(z. B. PhotoShop)', 92);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('8BP', '(z. B. PhotoShop)', 93);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('8BS', '(z. B. PhotoShop)', 94);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('8BX', '(z. B. PhotoShop)', 95);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('8BY', '(z. B. PhotoShop)', 96);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('8LI', '(z. B. PhotoShop)', 97);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('A', 'ADA', 98);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('A', 'UNIX', 99);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('A_T', NULL, 100);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('A11', NULL, 101);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AB6', 'AB STAT', 102);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AB8', 'AB STAT', 103);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ABC', 'ABC Flowcharter', 104);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ABK', 'Corel DRAW', 105);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ABS', NULL, 106);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AC$', 'AutoCAD', 107);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ACA', 'Microsoft-Programm, das Agent im HTTP-Format enth�lt (z. B. MS Office)', 108);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ACG', 'Microsoft-Programm, das Agent im HHTP-Format enth�lt (z. B. MS Office)', 109);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ACM', NULL, 110);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ACS', 'Microsoft-Programm, das Agent im HHTP-Format enth�lt (z. B. Office)', 111);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ACT', 'ACTOR', 112);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ACT', 'FoxPro', 113);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ACW', 'Microsoft Windows', 114);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AD', 'AfterDark', 115);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ADA', 'ADA', 116);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ADB', 'ADA', 117);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ADD', NULL, 118);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ADD', 'Adobe PageMaker', 119);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ADE', 'Microsoft Access', 120);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ADF', NULL, 121);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ADI', 'AutoCAD', 122);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ADL', 'QEMM', 123);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ADM', 'AfterDark', 124);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ADN', 'Lotus 1-2-3', 125);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ADN', 'Microsoft Access', 126);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ADR', 'AfterDark', 127);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ADT', 'AutoCAD', 128);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ADS', 'ADA', 129);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ADX', 'Approach', 130);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AEP', 'Adobe AfterEffects', 131);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AEX', 'Adobe AfterEffects', 132);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AEXPX', 'PGP', 133);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AF2', 'ABC Flowcharter bis 2.0', 134);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AF3', 'ABC Flowcharter ab 3.0', 135);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AFL', 'Lotus 1-2-3', 136);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AFM', NULL, 137);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AFP', 'ABC Flowcharter', 138);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AFT', 'ABC Flowcharter', 139);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AFW', 'ABC Flowcharter', 140);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AI', 'Adobe Illustrator', 141);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AIA', 'Adobe Illustrator', 142);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AIF', 'ADW Knowledge Ware', 143);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AIF', 'QuickTime o.�.', 144);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AIFC', 'QuickTime o.�.', 145);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AIFF', 'QuickTime o.�.', 146);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AIM', 'AOL', 147);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AIO', NULL, 148);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AIP', 'Adobe Illustrator', 149);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AIS', NULL, 150);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AIS', 'ACDSee', 151);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('AKL', 'Adobe Acrobat', 152);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ALB', 'PhotoSoap 2', 153);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ALL', 'WordPerfect f�r Windows', 154);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ALL', 'Arts & Letters', 155);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ALT', 'WordPerfect', 156);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ANI', NULL, 157);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ANI', 'Windows; wvtl. Cursorbearbeitungsprogramm (z. B. Microangelo)', 158);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ANM', 'Deluxe Paint', 159);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ANN', 'Microsoft Windows', 160);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ANS', 'Microsoft Word f�r Windows', 161);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ANT', NULL, 162);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('APC', 'Lotus 1-2-3', 163);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('APD', 'Lotus 1-2-3', 164);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('APF', 'Lotus 1-2-3', 165);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('APF', 'Allaire HomeSite', 166);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('API', 'Lotus 1-2-3', 167);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('APLN', 'Adobe InDesign', 168);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('APP', 'Symphony', 169);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('APP', 'DR-DOS / NEXT STEP', 170);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('APP', 'FoxPro', 171);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('APR', 'Lotus Approach', 172);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('APT', 'Lotus Approach', 173);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ARC', 'Microsoft Schedule', 174);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ARC', 'WinZIP, WinRAR o. �.', 175);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ARJ', 'WinZIP, WinRAR o. �.', 176);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ART', 'Atari', 177);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ARX', 'AutoCAD', 178);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ASA', 'VisualStudio', 179);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ASC', NULL, 180);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ASC', 'PGP', 181);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ASD', 'Microsoft Word f�r Windows', 182);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ASD', 'Lotus 1-2-3', 183);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ASD', 'Microsoft NetShow Rex', 184);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ASF', 'Lotus 1-2-3', 185);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BKS', 'IBM BookManager', 186);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BLD', 'BASIC', 187);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BLK', 'WordPerfect f�r Windows', 188);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BM', NULL, 189);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BMK', 'Microsoft Windows', 190);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BMP', 'Microsoft Windows, PC Paintbrush', 191);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BNK', 'Adlib', 192);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BOO', 'IBM BookManager', 193);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BOO', 'BOO', 194);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BPT', 'Corel DRAW', 195);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BR2', 'Bryce 2', 196);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BR3', 'Bryce 3', 197);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BR4', 'Bryce 4', 198);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BRB', 'Bryce', 199);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BRI', 'Bryce', 200);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BRM', 'Bryce', 201);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BRO', 'Bryce', 202);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BRT', 'Bryce', 203);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BRW', 'RayDream', 204);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BSK', 'Bryce', 205);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BTM', '4DOS', 206);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BTN', NULL, 207);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BUP', NULL, 208);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BV1', 'WordPerfect f�r Windows', 209);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BV2', 'WordPerfect f�r Windows', 210);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BV3', 'WordPerfect f�r Windows', 211);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BV4', 'WordPerfect f�r Windows', 212);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BV5', 'WordPerfect f�r Windows', 213);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BV6', 'WordPerfect f�r Windows', 214);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BV7', 'WordPerfect f�r Windows', 215);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BV8', 'WordPerfect f�r Windows', 216);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BV9', 'WordPerfect f�r Windows', 217);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BZ', NULL, 218);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BZIP', NULL, 219);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('C', 'C-Entwicklungsumgebung', 220);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('C00', 'Ventura Publisher', 221);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('C2D', 'WinOnCD', 222);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('C3D', 'Ulead Cool 3D', 223);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('C86', NULL, 224);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CA7', 'BETA 44', 225);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CAB', 'Windows Installer, WinZIP', 226);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CAL', 'Microsoft Windows', 227);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CAL', 'SuperCalc', 228);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CAP', 'Ventura Publisher', 229);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CAP', 'Telix', 230);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CAP', 'Capella', 231);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CAT', 'dBase IV', 232);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CBL', 'COBOL', 233);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CBT', NULL, 234);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CC', 'C++', 235);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CCH', 'Corel CHART', 236);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CDA', 'WinAmp, Windows Media Player o.�.', 237);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CDB', 'Turbo C Utilities', 238);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CDC', 'Nero Burning ROM', 239);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CDR', 'Corel DRAW', 240);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CDT', 'Corel DRAW', 241);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CDF', 'Viewer f�r Channeldefinitionen', 242);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CDX', 'Visual FoxPRO', 243);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CEL', 'Autodesk Animator', 244);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CFG', NULL, 245);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CFM', 'ColdFusion', 246);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CFML', 'ColdFusion, DreamWeaver', 247);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CGA', 'Ventura Publisher', 248);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CGM', 'CGA', 249);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CH', 'Clipper 5', 250);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CH3', 'Harvard Graphics', 251);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CHI', 'CHIWriter', 252);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CHK', 'WordPerfect f�r Windows', 253);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CHK', 'Windows', 254);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CHM', 'Windows ab Version 98', 255);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CIF', 'Easy CD Creator', 256);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CIL', 'ClipGallery', 257);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CL4', 'Easy CD Creator', 258);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CLB', 'QuarkXPress', 259);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CLP', 'Windows Ablagemappe bzw. Zwischenablage', 260);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CLS', 'VisualBASIC', 261);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CLX', 'Adobe InDesign', 262);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CMX', 'CorelDRAW', 263);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CNF', 'Adobe PageMaker', 264);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CNV', 'Microsoft Word f�r Windows', 265);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CNV', 'WordPerfect f�r Windows', 266);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('COB', 'COBOL', 267);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('COD', 'Microsoft Multiplan', 268);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('COD', 'FORTRAN', 269);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('COD', 'dBASE', 270);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('COL', 'Autodesk Animator', 271);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('COL', 'Microsoft Multiplan', 272);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('COM', NULL, 273);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CON', 'ADW Knowledge Ware', 274);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('COV', 'Faxdeckblatt-Editor', 275);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CPI', NULL, 276);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CPI', NULL, 277);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CPJ', 'WinOnCD', 278);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CPL', 'Microsoft Windows', 279);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CPP', 'Visual C++', 280);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CPS', 'PCTools', 281);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CPX', 'Microsoft Windows', 282);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CRD', 'Microsoft Windows', 283);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CRT', 'Microsoft Windows', 284);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CRF', 'MS MASM / Zortech C++', 285);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CRP', 'dBase IV', 286);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CSML', 'Internet-Browser', 287);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CSQ', 'FoxPro', 288);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CSS', 'Internet-Browser', 289);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CSS1', 'Internet-Browser', 290);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CSS2', 'Internet-Browser', 291);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CSV', NULL, 292);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CTF', 'Symphony', 293);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CTL', NULL, 294);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CTL', 'Microsoft VisualBASIC', 295);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CTX', NULL, 296);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CTX', 'Microsoft VisualBASIC', 297);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CUF', 'Turbo C Utilities', 298);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CUR', 'Microsoft Windows', 299);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CUT', 'Dr. Halo', 300);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CV4', 'CodeView', 301);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CVT', 'dBase IV', 302);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CVW', 'CodeView', 303);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CXX', 'C++, ZORTECH C++', 304);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('D3D', 'Corel Dream 3D', 305);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DAT', '(viele verschiedene Programme)', 306);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DB', '(verschiedene Daten, urspr�nglich dBase)', 307);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DBC', 'Visual FoxPro', 308);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DBF', 'Visual FoxPro', 309);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DBI', 'Soap2', 310);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DBP', 'VisualStudio', 311);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DBQ', 'AutoCAD', 312);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DBT', 'AutoCAD', 313);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DBX', 'AutoCAD', 314);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DCE', 'AutoCAD', 315);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DCL', 'AutoCAD', 316);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DCT', 'Adobe Illustrator', 317);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DD', 'DiskDoubler', 318);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DDI', 'DISKDUPE', 319);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DDP', 'OS/2', 320);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DEF', NULL, 321);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DEL', NULL, 322);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DEM', NULL, 323);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DEV', NULL, 324);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DFD', 'Prosa', 325);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DFM', 'Prosa', 326);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DFV', 'Word', 327);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DHP', 'Dr. Halo', 328);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DIB', 'PhotoDraw', 329);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DIB', 'Microsoft Windows', 330);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DIC', NULL, 331);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DIF', 'VisiCalc', 332);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DIF', 'Microsoft Excel', 333);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DIF', NULL, 334);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DIM', 'Adobe Dimensions', 335);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DIR', 'ProComm Plus', 336);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DIS', 'Corel DRAW', 337);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DIZ', NULL, 338);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DL', NULL, 339);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DLD', 'Lotus 1-2-3', 340);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DLG', 'Microsoft Windows', 341);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DLL', 'Microsoft Windows / OS/2', 342);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DMO', NULL, 343);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DMP', NULL, 344);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DMS', 'Amiga', 345);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DOB', 'VisualBASIC', 346);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DOC', '(z. B. Microsoft Word)', 347);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DOS', NULL, 348);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DOT', 'Microsoft Word f�r Windows', 349);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DOT', 'Corel DRAW', 350);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DOX', 'MultiMate 4.0', 351);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DOX', 'VisualBASIC', 352);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DPR', 'Borland C++', 353);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DRS', 'WordPerfect f�r Windows', 354);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DRV', NULL, 355);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DRW', 'Micrografx Designer', 356);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DS4', 'Micrografx Designer', 357);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DSF', 'Micrografx Designer', 358);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DSK', 'Borland C++', 359);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DSP', 'Dr. Halo', 360);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DSR', 'WordPerfect f�r Windows', 361);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DTA', 'Turbo Pascal / PC-File', 362);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DTF', 'Q&A', 363);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DV', 'QuickTime', 364);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DVB', 'AutoCAD', 365);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DVC', 'Lotus 1-2-3', 366);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DVI', 'TeX', 367);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DVP', 'DESQVIEW', 368);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DVP', 'AutoCAD', 369);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DWC', NULL, 370);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DWG', 'AutoCAD', 371);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DWT', 'Dreamweaver', 372);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DXB', 'AutoCAD', 373);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DXF', 'AutoCAD', 374);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DXF', 'AutoCAD', 375);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DXX', 'AutoCAD', 376);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('DYN', 'Lotus 1-2-3', 377);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EEB', 'WordPerfect f�r Windows', 378);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EFT', 'CHIWriter', 379);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EGA', 'Ventura Publisher', 380);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ELT', 'Prosa', 381);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EM', 'Microwave Office', 382);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EMF', 'Grafiksoftware, Textverarbeitung, Satz- und Layoutsoftware (sehr verbreitetes Format)', 383);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EML', 'Microsoft Outlook', 384);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EMP', 'Microwave Office', 385);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EMS', 'PC Tools', 386);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EMU', 'IRMA Workstation f�r Windows', 387);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ENC', 'ADW Knowledge Ware', 388);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('END', 'Corel DRAW', 389);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ENG', 'Sprint', 390);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ENV', 'WordPerfect f�r Windows', 391);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ENV', 'Adobe InDesign', 392);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EPS', 'Ventura Publisher', 393);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EPS', 'Adobe Illustrator', 394);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EQN', 'WordPerfect f�r Windows', 395);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ERD', 'Prosa', 396);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ERM', 'Prosa', 397);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ERO', 'Microsoft Encarta', 398);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ERR', 'Wird durch diverse Programme erstellt', 399);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ESH', NULL, 400);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EVT', 'PC Tools', 401);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EX_', 'Installer', 402);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EX3', 'Harvard Graphics 3.0', 403);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EXC', 'QEMM', 404);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EXC', '(VM/CMS)', 405);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EXE', NULL, 406);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('EXT', 'Norton Commander', 407);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('F', 'FORTRAN', 408);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('F', 'FREEZE', 409);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('F77', 'FORTRAN 77', 410);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FAC', 'Usenix FACE', 411);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FAQ', NULL, 412);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FAR', 'WinAmp', 413);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FAS', 'AutoCAD / AutoLISP', 414);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FAV', 'Outlook', 415);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FAX', 'AutoCAD', 416);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('Fax', 'WINFax PRO', 417);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FaxG3', NULL, 418);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FBK', 'Navision Financials', 419);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FC', 'Harvard Graphics 2.0', 420);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FCT', 'FoxPro', 421);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FD', 'Microsoft FORTRAN', 422);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FD', 'DATAFLEX', 423);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FDB', 'Navision Financials', 424);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FEX', 'FOCUS', 425);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FFT', 'DISPLAYWrite', 426);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FI', 'Microsoft FORTRAN', 427);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FIF', NULL, 428);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FIL', 'dBASE', 429);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FIL', 'WordPerfect', 430);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FIN', 'Perfect WriteR / MINCE', 431);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FIT', NULL, 432);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('Fits', 'NASA', 433);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FKY', 'FoxPro', 434);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FLB', 'PAPYRUS', 435);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FLC', 'Autodesk Animator, Windows Media Player und �hnliche Programme', 436);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FLD', 'Charisma', 437);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FLF', 'Navision Financials', 438);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FLI', 'Autodesk Animator, Windows Media Player und �hnliche Programme', 439);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FLL', 'FoxPro f�r Windows', 440);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FLL', 'Micrografx Designer', 441);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FLM', 'AutoCAD', 442);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FLO', 'Micrografx FlowCharter', 443);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FLT', '(verschiedene Programme)', 444);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FLT', 'diverse', 445);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FLX', 'DataFlex', 446);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FM1', 'Lotus 1-2-3 2.x', 447);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FM3', 'Harvard Graphics 3.0', 448);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FM3', 'Lotus 1-2-3 3.x', 449);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FMB', 'WordPerfect f�r Windows', 450);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FMO', 'dBase IV', 451);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FMP', 'AutoCAD', 452);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FMT', 'Clipper 5 / dBASE IV / FoxPro', 453);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FMT', 'Sprint', 454);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FNG', 'Corel FontNavigator', 455);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FP', 'Fine Print', 456);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FPX', 'PhotoDraw', 457);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FRG', 'Microsoft Access', 458);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FRM', 'VisualBASIC', 459);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FRT', 'Visual FoxPro', 460);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FRX', 'Visual FoxPro', 461);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FST', 'FastSite', 462);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FT5', 'FreeHand 5', 463);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FT6', 'FreeHand 6', 464);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FT7', 'FreeHand 7', 465);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FT8', 'FreeHand 8', 466);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FT9', 'FreeHand 9', 467);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('FXP', 'Visual FoxPro', 468);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GBR', 'GIMP', 469);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GIcon', 'GIMP', 470);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GR2', 'Microsoft Windows', 471);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GRA', 'Microsoft', 472);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GRB', NULL, 473);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GRF', 'Charisma / GRAPH Plus', 474);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GRP', 'Microsoft Windows', 475);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GZ', 'GZIP', 476);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GED', 'Simply3D', 477);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GFA', 'Microsoft PhotoDraw', 478);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GIF', 'Bildbearbeitungsprogramm, Webbrowser', 479);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GOO', 'Kai''s Power Goo', 480);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GRA', 'MS Graph Chart', 481);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GRD', 'Adobe PhotoShop', 482);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GRP', 'Windows 3.x', 483);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GSF', 'GhostScript', 484);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('GR3', 'Windows 3.0', 485);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('H', NULL, 486);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HA', 'HA', 487);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HBK', 'MathCAD', 488);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HDB', 'Nero Burning ROM', 489);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HDL', 'ProComm Plus', 490);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HDR', 'ProComm Plus', 491);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HDR', NULL, 492);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HDX', NULL, 493);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('Header', 'C-Entwicklungsumgebung', 494);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HEX', NULL, 495);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HFI', 'GEM', 496);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HGL', NULL, 497);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HH', 'C++', 498);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HHH', 'Power C', 499);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HHP', 'ProComm Plus', 500);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HLP', NULL, 501);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HMM', 'ProComm Plus', 502);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HOF', NULL, 503);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HPF', 'PakeMaker', 504);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HPG', '(HPGL Plotter-Datei)', 505);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HPI', 'GEM', 506);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HPJ', 'Microsoft Help Compiler', 507);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HPK', 'HPACK', 508);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HPM', 'ProComm Plus', 509);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HPP', 'C++, ZORTECH C++', 510);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HQX', 'BINHEX', 511);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HRM', 'ProComm Plus', 512);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HRZ', NULL, 513);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HST', 'ProComm Plus', 514);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HTM', NULL, 515);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HTML', NULL, 516);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HTX', NULL, 517);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HWS', 'HotDog', 518);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HXM', 'ProComm Plus', 519);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HXX', 'C++', 520);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HYC', 'WordPerfect', 521);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HYD', 'WordPerfect f�r Windows', 522);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HYP', 'Adobe Illustrator', 523);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('HYP', 'HYPER', 524);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ICB', 'Adobe Photoshop', 525);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ICL', 'PC Tools', 526);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ICN', NULL, 527);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ICO', 'Microsoft Windows', 528);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ID', NULL, 529);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('IDF', NULL, 530);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('IDX', NULL, 531);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('IFF', 'Adobe Photoshop', 532);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('IFF', NULL, 533);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('IFS', 'OS/2', 534);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('IGS', NULL, 535);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('IM8', 'SUN', 536);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('IMG', 'GEM / Ventura Publisher', 537);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('IN3', 'Harvard Graphics 3.0', 538);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INC', NULL, 539);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('IND', 'dBase IV', 540);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INDD', 'Adobe InDesign', 541);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INDF', 'Adobe InDesign', 542);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INDK', 'Adobe InDesign', 543);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INDL', 'Adobe InDesign', 544);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INDT', 'Adobe InDesign', 545);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INF', 'OS/2 Buch', 546);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INF', NULL, 547);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INF', NULL, 548);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INI', NULL, 549);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INK', 'Corel DRAW', 550);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INS', 'WordPerfect', 551);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INT', 'Borland', 552);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INT', 'FoxPro', 553);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('INX', 'FoxBase', 554);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('IO', 'CPIO', 555);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ION', '4DOS und andere', 556);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('IPL', 'Corel DRAW', 557);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('IRS', 'WordPerfect', 558);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ISD', 'RapidFile', 559);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ISH', 'ISH', 560);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('IW', 'Icon Author', 561);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('IWA', 'IBM Writing Assistant', 562);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('IWP', NULL, 563);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('JAR', 'Java-Programm oder Applet', 564);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('JAS', NULL, 565);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('JAVA', 'Java-Compiler', 566);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('JFIF', 'Bildbearbeitungssoftware', 567);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('JOB', 'Beta 44', 568);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('JOBOPTIO', 'Adobe Acrobat Distiller', 569);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('JOR', 'SQL', 570);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('JPG', NULL, 571);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('JS', 'JavaScript (Webbrowser)', 572);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('JSCRIPT', 'JavaScript (Webbrowser)', 573);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('JSF', 'Fireworks', 574);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('JW', 'JustWrite', 575);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('JWL', 'JustWrite', 576);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('JZZ', 'Jazz', 577);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('KBD', 'IRMA Workstation f�r Windows', 578);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('KBM', NULL, 579);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('KEX', NULL, 580);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('KEY', NULL, 581);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('KYB', NULL, 582);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('L', NULL, 583);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('L', NULL, 584);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('L', NULL, 585);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LAB', 'Q+E f�r Microsoft Excel', 586);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LAY', 'Applause', 587);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LBG', 'dBase IV', 588);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LBL', 'dBASE IV / dBFAST / Clipper 5', 589);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LBM', 'Deluxe Paint', 590);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LBO', 'dBase IV', 591);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LBR', 'Lotus 1-2-3', 592);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LBR', 'LU', 593);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LBT', 'Visual FoxPro', 594);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LBX', 'Visual FoxPro', 595);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LCF', 'Norton Guides', 596);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LCN', 'WordPerfect', 597);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LCS', 'Lotos Organizer', 598);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LD', 'Telix', 599);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LD1', 'dBASE', 600);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LDB', 'Microsoft Access', 601);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LES', 'LESson', 602);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LEX', NULL, 603);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LFT', 'CHIWriter', 604);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LGO', 'Microsoft Windows', 605);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LHW', 'LHWARP', 606);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LIB', NULL, 607);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LIF', NULL, 608);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LIF', 'Hewlett-Packard', 609);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LIN', 'AutoCAD', 610);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LJ', NULL, 611);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LNK', NULL, 612);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LNK', 'Windows', 613);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LOG', NULL, 614);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LRF', 'Microsoft C/C++', 615);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LRS', 'WordPerfect f�r Windows', 616);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LSP', 'XLISP', 617);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LSP', 'AutoCAD', 618);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LST', 'Bryce', 619);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LST', 'MS-DOS und Andere', 620);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LST', NULL, 621);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LWP', 'Lotos WordPro', 622);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LZH', 'LHA / LHARC', 623);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LZS', 'LARC', 624);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('LZW', 'LHWARP', 625);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('M', 'Mathematica', 626);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('M', 'MatLab', 627);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('M', 'Brief', 628);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('M3', 'ModuleA 3', 629);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('M3D', NULL, 630);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MA3', 'Harvard Graphics 3.0', 631);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAC', 'MACPaint', 632);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAC', NULL, 633);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAC', 'QuickTime', 634);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAD', 'Microsoft Access', 635);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAF', 'Microsoft Access', 636);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAG', 'Microsoft Access', 637);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAK', NULL, 638);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAK', 'Visual BASIC', 639);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAM', 'Microsoft Access', 640);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAN', NULL, 641);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAP', NULL, 642);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAP', 'Micrografx Picture Publisher', 643);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAP', NULL, 644);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAQ', 'Microsoft Access', 645);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAR', 'Microsoft Access', 646);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAS', 'Focus', 647);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAT', 'MatLab', 648);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAT', 'Microsoft Access', 649);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAV', 'Microsoft Access', 650);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAX', '3Dstudio MAX', 651);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MAX', 'MAX', 652);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MB', 'Paradox', 653);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MBF', 'Microsoft Money', 654);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MBK', 'dBase IV', 655);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MCC', 'MathCAD', 656);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MCD', 'MathCAD', 657);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MCF', 'MathCAD', 658);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MCI', NULL, 659);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MCP', 'MathCAD', 660);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MCW', 'Word f�r Macintosh', 661);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MD', 'MDCD', 662);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MDB', 'Microsoft Access', 663);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MDE', 'Microsoft Access', 664);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MDM', 'Telix', 665);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MDT', 'Microsoft Access', 666);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MDW', 'Microsoft Access', 667);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MDX', 'dBase IV', 668);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MDZ', 'Microsoft Access', 669);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ME', NULL, 670);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MEB', 'WordPerfect', 671);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MED', 'WordPerfect', 672);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MEM', 'WordPerfect', 673);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MEM', 'dBASE IV / FoxPro', 674);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MEQ', 'WordPerfect', 675);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MER', 'WordPerfect', 676);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MES', 'WordPerfect', 677);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MET', 'WordPerfect', 678);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MET', NULL, 679);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MEU', NULL, 680);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MEX', 'MatLab', 681);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MF', NULL, 682);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MGF', 'Micrografx', 683);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MGX', 'Micrografx Designer', 684);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MID', 'Microsoft Windows', 685);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MIF', NULL, 686);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MIX', 'Microsoft PhotoDraw', 687);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MIX', 'POWER C', 688);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MJF', 'WinAmp', 689);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MK', NULL, 690);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MKE', 'Microsoft Windows SDK', 691);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MLB', 'Symphony, FoxPro', 692);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MLI', 'AutoCAD', 693);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MLN', 'AutoCAD', 694);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MMM', NULL, 695);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MNC', 'AutoCAD', 696);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MND', 'AutoCAD', 697);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MNL', 'AutoCAD / AutoLISP', 698);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MNO', 'Macromedia', 699);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MNR', 'AutoCAD', 700);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MNS', 'AutoCAD', 701);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MNT', 'FoxPro', 702);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MNT', 'Visual FoxPro', 703);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MNU', 'AutoCAD', 704);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MNU', 'Norton Commander', 705);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MNX', 'AutoCAD', 706);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MNX', 'Visual FoxPro', 707);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MNY', 'Microsoft Money', 708);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MOB', 'PEN Windows', 709);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MOD', 'Amiga', 710);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MOD', 'Module A-2', 711);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MOD', 'Microsoft Windows', 712);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MOV', NULL, 713);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MP', 'Multiplan', 714);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MP1', 'MPEG-Abspielsoftware (z.B. WinAmp, Windows Media Player)', 715);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MP2', 'MPEG-Abspielsoftware (z.B. WinAmp, Windows Media Player)', 716);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MP3', 'MPEG-Abspielsoftware (z.B. WinAmp, Windows Media Player)', 717);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MP4', 'MPEG-Abspielsoftware (z.B. WinAmp, Windows Media Player)', 718);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MPA', 'MPEG-Abspielsoftware (z.B. WinAmp, Windows Media Player)', 719);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MPC', 'Microsoft Project', 720);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MPD', NULL, 721);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MPD', 'Microsoft Project', 722);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MPEG', 'MPEG-Abspielsoftware (z.B. WinAmp, Windows Media Player)', 723);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MPG', 'MPEG-Abspielsoftware (z.B. WinAmp, Windows Media Player)', 724);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MPG', NULL, 725);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MPM', 'WordPerfect', 726);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MPP', 'Microsoft Project', 727);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MPP', 'Microsoft Project', 728);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MPR', 'FoxPro', 729);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MPV', 'Microsoft Project', 730);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MPW', 'Microsoft Project', 731);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MPX', 'FoxPro', 732);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MPX', 'Visual FoxPro', 733);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MRB', 'Microsoft C/C++', 734);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MRS', 'WordPerfect f�r Windows', 735);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MS', 'MS-DOS', 736);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MSG', NULL, 737);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MSI', 'Windows Installer', 738);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MSP', 'Microsoft Windows 2.x Paint', 739);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MST', 'Prosa', 740);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MST', 'Microsoft Windows SDK', 741);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MSW', 'Microsoft Word', 742);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MTH', 'Derive', 743);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MTW', 'MiniTab', 744);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MU', 'Quattro Pro', 745);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MUS', NULL, 746);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MVB', 'Microsoft Info Viewer', 747);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MVF', 'AutoCAD AutoFlix', 748);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MVI', 'AutoCAD AutoFlix', 749);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MWP', 'Lotos WordPro', 750);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('MXT', 'Microsoft C', 751);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NB', 'Nota Bene', 752);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NCD', 'Norton Commander', 753);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NDX', 'dBASE / dBFast', 754);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NET', 'Harvard Graphics f�r Windows / Paradox', 755);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NEW', NULL, 756);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NFL', 'AutoCAD', 757);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NFO', 'MSInfo', 758);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NFS', 'Lotus Notes', 759);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NFT', 'NetObjectsFusion', 760);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NG', 'Norton Guide', 761);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NLS', NULL, 762);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NOD', 'NetObjectsFusion', 763);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NOT', 'Notes, IBM BookManager', 764);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NRA', 'Nero Burning ROM', 765);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NRB', 'Nero Burning ROM', 766);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NRG', 'Nero Burning ROM', 767);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NRH', 'Nero Burning ROM', 768);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NRI', 'Nero Burning ROM', 769);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NRM', 'Nero Burning ROM', 770);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NRU', 'Nero Burning ROM', 771);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NRV', 'Nero Burning ROM', 772);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NST', NULL, 773);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NTF', 'Notes, IBM BookManager', 774);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NTS', 'Norton', 775);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NTX', 'Clipper 5', 776);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('NWS', NULL, 777);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('O', 'UNIX', 778);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('O$$', 'Sprint', 779);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OBD', 'Microsoft Samelmappe', 780);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OBJ', NULL, 781);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OBP', 'Bryce', 782);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OBT', 'Microsoft Samelmappe', 783);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OBZ', 'Microsoft Samelmappe', 784);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OCX', 'Windows', 785);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OCX', NULL, 786);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OFF', NULL, 787);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OFM', 'Adobe', 788);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OFT', 'Outlook', 789);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OLB', NULL, 790);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OLD', NULL, 791);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OLI', 'Olivetti', 792);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OPC', 'Beta 44', 793);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OPD', 'Omnipage', 794);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OPT', 'QEMM', 795);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OPX', 'Microsoft Orgchart', 796);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OR5', 'Lotos Organizer 5', 797);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OR6', 'Lotos Organizer 5', 798);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OUT', NULL, 799);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OV1', NULL, 800);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OV2', NULL, 801);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OV3', NULL, 802);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OVL', NULL, 803);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OVR', 'RayDream Studio', 804);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('OVR', NULL, 805);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('P', 'Pascal', 806);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('P', 'Applause', 807);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('P65', 'PakeMaker 6.5', 808);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PAD', 'TeleMate', 809);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PAG', 'VisualBASIC', 810);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PAK', 'PAK', 811);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PAL', 'CorelDRAW', 812);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PAL', 'Micrografx Flowcharter', 813);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PAR', 'Fractint', 814);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PAS', 'Pascal', 815);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PAT', 'AutoCAD', 816);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PAT', 'Corel DRAW', 817);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PAT', 'GIMP', 818);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PBI', 'Microsoft Source Profiler', 819);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PBL', 'Adobe Premiere', 820);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PBM', NULL, 821);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PBO', 'Microsoft Source Profiler', 822);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PBT', 'Microsoft Source Profiler', 823);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PC', 'IBM', 824);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PC3', 'Harvard Graphics 3.0', 825);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PC8', NULL, 826);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PCD', NULL, 827);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PCD', 'Corel PhotoPaint', 828);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PCF', 'Microsoft Source Profiler', 829);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PCH', NULL, 830);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PCH', 'Microsoft C/C++', 831);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PCK', 'Turbo Pascal', 832);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PCL', NULL, 833);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PCT', NULL, 834);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PCW', 'PC Write', 835);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PCX', 'Bildbearbeitungssoftware', 836);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PDB', NULL, 837);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PDF', 'Adobe Acrobat / Adobe Acrobat Reader', 838);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PDI', NULL, 839);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PDR', NULL, 840);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PDR', NULL, 841);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PDS', NULL, 842);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PDV', 'Paintbrush', 843);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PEB', 'WordPerfect', 844);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PED', 'WordPerfect', 845);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PEM', 'WordPerfect', 846);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PEQ', 'WordPerfect', 847);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PER', 'WordPerfect', 848);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PERL', 'PERL-Compiler', 849);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PES', 'WordPerfect', 850);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PET', 'WordPerfect', 851);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PF', NULL, 852);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PFA', NULL, 853);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PFB', NULL, 854);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PFK', 'XTREE PRO', 855);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PFM', NULL, 856);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PFT', 'CHIWriter', 857);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PGM', NULL, 858);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PGP', 'PGP', 859);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PGP', NULL, 860);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PH', 'PERL', 861);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PH', 'Microsoft C/C++, Microsoft Help Compiler', 862);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PIC', 'QuickTime', 863);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PIC', NULL, 864);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PICT', 'Microsoft PhotoDraw', 865);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PIF', 'Microsoft Windows', 866);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PIF', 'Microsoft Windows', 867);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PIT', 'PackIt, Macintosh', 868);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PIX', 'SGI-Workstations', 869);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PJT', 'FoxPro', 870);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PJT', 'Visual FoxPro', 871);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PJX', 'FoxPro', 872);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PJX', 'Visual FoxPro', 873);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PKA', 'PKARC', 874);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PKR', 'PGP', 875);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PL', 'Harvard Graphics f�r Windows', 876);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PL', 'PERL', 877);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PL3', 'Harvard Graphics 3.0', 878);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PLB', 'FoxPro', 879);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PLB', 'Adobe Premiere', 880);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PLC', 'Lotus 1-2-3', 881);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PLN', 'WordPerfect f�r Windows', 882);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PLS', 'WinAmp', 883);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PLT', 'AutoCAD', 884);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PLT', 'AutoCAD', 885);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PM', 'PM', 886);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PM3', 'PakeMaker 3', 887);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PM4', 'PakeMaker 4', 888);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PM5', 'PakeMaker 5', 889);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PM6', 'PakeMaker 6', 890);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PML', 'Adobe PageMaker', 891);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PMP', 'AutoCAD', 892);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PN3', 'Harvard Graphics 3.0', 893);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PNG', 'Bildbearbeitungssoftware, Webbrowser', 894);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PNM', NULL, 895);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PNT', 'Macintosh', 896);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('POP', 'dBASE', 897);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('POT', 'Microsoft PowerPoint', 898);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PP', 'PowerPacker', 899);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PP4', 'iGrafx/Micrografx', 900);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PP5', 'iGrafx/Micrografx', 901);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PPA', 'Microsoft PowerPoint', 902);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PPD', NULL, 903);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PPF', 'iGrafx/Micrografx', 904);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PPJ', 'Adobe Premiere', 905);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PPL', 'Harvard Graphics 3.0', 906);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PPM', NULL, 907);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PPO', 'Clipper 5', 908);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PPS', 'Microsoft PowerPoint', 909);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PPT', 'Microsoft PowerPoint', 910);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PPT', 'PowerPoint', 911);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PPTHTML', 'Microsoft PowerPoint', 912);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PR2', 'dBase IV', 913);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PR2', 'Aldus Persuasion 2.0', 914);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PR3', 'dBase IV', 915);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRC', NULL, 916);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRD', 'Diverse', 917);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRE', 'Microsoft C/C++', 918);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRF', 'dBase IV', 919);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRF', NULL, 920);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRG', 'Visual FoxPro', 921);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRG', 'Clipper 5 / dBASE IV / dBFAST / FoxPro', 922);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRJ', NULL, 923);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRM', 'Diverse', 924);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRM', 'Adobe Premiere', 925);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRN', 'Druckertreiber', 926);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRN', 'Lotus 1-2-3 / Symphony', 927);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRO', 'PROLOG', 928);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRS', 'Harvard Graphics', 929);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRS', 'WordPerfect f�r Windows', 930);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRS', 'dBase IV', 931);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRT', 'Dr. Halo', 932);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRT', 'IRMA Workstation f�r Windows', 933);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRVKR', 'PGP', 934);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRX', 'FoxPro', 935);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PRZ', 'Flowcharter', 936);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PS', NULL, 937);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PS', '(diverse Programme, u.a. Adobe Acrobat)', 938);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PSD', 'Adobe Photoshop', 939);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PSF', 'CHIWriter', 940);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PSF', 'AutoCAD', 941);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PSM', 'Turbo Pascal', 942);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PSP', 'Adobe Photoshop', 943);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PSQ', 'Adobe Premiere', 944);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PT3', 'Harvard Graphics 3.0', 945);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PT3', 'PakeMaker 3', 946);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PT4', 'PakeMaker 4', 947);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PT5', 'PakeMaker 5', 948);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PT6', 'PakeMaker 6', 949);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PTL', 'Adobe Premiere', 950);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PUB', 'PGP', 951);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PUB', 'Ventura Publisher', 952);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PUB', 'Microsoft Publisher', 953);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PUBKR', 'PGP', 954);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PW', 'Professional Write', 955);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PWL', NULL, 956);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PWZ', 'Microsoft PowerPoint', 957);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PX', 'Paradox', 958);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PY', 'PYTHON', 959);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PYC', 'PYTHON', 960);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PZD', 'Pizzazz Plus', 961);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('PZO', 'Pizzazz Plus', 962);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QAG', 'Norton Desktop', 963);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QBD', 'IRMA Workstation f�r Windows', 964);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QBE', 'dBASE IV / Quattro Pro', 965);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QBO', 'dBase IV', 966);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QDT', 'QuarkXPress', 967);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QEF', 'Q+E f�r Microsoft Excel', 968);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QEP', 'IRMA Workstation f�r Windows', 969);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QLB', 'Microsoft C/C++', 970);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QLC', NULL, 971);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QPR', 'Visual FoxPro', 972);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QPR', 'FoxPro', 973);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QPR', 'OS/2', 974);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QPX', 'Visual FoxPro', 975);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QRS', 'WordPerfect f�r Windows', 976);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QRT', NULL, 977);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QRY', 'dBase IV', 978);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QSF', 'Designer', 979);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QT', 'QuickTime', 980);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QTI', 'QuickTime', 981);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QTIF', 'QuickTime', 982);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QTP', 'QuickTime', 983);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QTS', 'QuickTime', 984);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QTX', 'QuickTime', 985);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QWB', 'QuickTime', 986);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QXB', 'QuarkXPress', 987);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QXD', 'QuarkXPress', 988);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QXL', 'QuarkXPress', 989);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('QXT', 'QuarkXPress', 990);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('R00', 'WinRAR', 991);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('R01', 'WinRAR', 992);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('R02', 'WinRAR', 993);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('R03', 'WinRAR', 994);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('R04', 'WinRAR', 995);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('R05', 'WinRAR', 996);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('R06', 'WinRAR', 997);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('R07', 'WinRAR', 998);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('R08', 'WinRAR', 999);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('R09', 'WinRAR', 1000);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('R10', 'WinRAR', 1001);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('R8', NULL, 1002);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RA', 'Real-Player', 1003);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RAM', 'Real-Player', 1004);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RAR', 'WinRAR', 1005);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RAS', 'iGrafx', 1006);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RAS', 'Sun', 1007);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RAW', 'Adobe PhotoShop', 1008);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RBF', 'RBase', 1009);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RC', 'Borland C++ / Microsoft C++', 1010);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RD4', 'RayDream 4', 1011);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RDS', 'RayDream 4', 1012);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RDX', 'REFLEX', 1013);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RDX', 'RayDream 4', 1014);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('REC', 'Sprint', 1015);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('REC', 'Microsoft Windows', 1016);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('REF', NULL, 1017);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('REG', 'Microsoft Windows', 1018);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('REM', NULL, 1019);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('REQ', NULL, 1020);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RES', 'dBase IV', 1021);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RES', 'Borland C++', 1022);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RES', 'Microsoft C++', 1023);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('REX', 'REXX', 1024);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('REZ', NULL, 1025);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RF', 'Real-Player', 1026);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RF', 'Sun', 1027);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RFT', 'IBM DISPLAYWrite', 1028);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RI', 'Lotus 1-2-3', 1029);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RLB', 'Harvard Graphics f�r Windows', 1030);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RLE', 'Corel PhotoPaint', 1031);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RLE', NULL, 1032);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RM', 'Real-Player', 1033);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RMI', 'Abspielsoftware', 1034);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RMK', 'RMAKE', 1035);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RMM', 'Real-Player', 1036);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RND', 'PGP', 1037);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RND', 'AutoCADE AutoShade', 1038);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RNX', 'Real-Player', 1039);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ROL', '(Roland)', 1040);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RP', 'Real-Player', 1041);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RPD', 'RAPIDFile', 1042);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RPLN', 'Adobe InDesign', 1043);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RPM', 'Real-Player', 1044);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RPT', NULL, 1045);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RR', NULL, 1046);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RSL', 'PC Tools', 1047);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RSL', 'Adobe PageMaker', 1048);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RSP', NULL, 1049);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RTF', 'Textverarbeitung', 1050);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RTL', NULL, 1051);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RTR', 'Real-Player', 1052);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RUN', 'PC Tools', 1053);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('RV', 'Real-Player', 1054);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('S$$', 'Sprint', 1055);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('S3D', 'Simply 3D', 1056);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('S3M', 'Abspielsoftware (WinAmp)', 1057);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SAM', 'Lotos WordPro', 1058);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SAM', 'AMI PRO 2.x , 3.x', 1059);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SAV', NULL, 1060);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SB', NULL, 1061);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SBP', 'SuperBase 4', 1062);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SC', 'Framework II', 1063);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SC3', 'Harvard Graphics 3.0', 1064);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCAN', 'Norton AntiVirus', 1065);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCC', 'StarOffice', 1066);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCD', NULL, 1067);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCD', 'SchedulePlus', 1068);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCH', 'SchedulePlus', 1069);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCH', 'Microsoft', 1070);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCM', 'Lotos ScreenCam', 1071);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCN', NULL, 1072);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCN', '3D Live Grafix', 1073);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCO', NULL, 1074);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCR', 'FaxVIEW', 1075);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCR', 'Microsoft Windows', 1076);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCR', NULL, 1077);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCR', NULL, 1078);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCT', 'Visual FoxPro', 1079);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCT', 'PC Tools', 1080);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCX', 'Visual FoxPro', 1081);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SCX', 'FoxPro', 1082);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SDA', 'StarDraw, StarOffice', 1083);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SDC', 'StarCalc, StarOffice', 1084);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SDD', 'StarImpress, StarOffice', 1085);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SDF', NULL, 1086);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SDS', 'StarChart, StarOffice', 1087);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SDW', 'StarWrite, StarOffice', 1088);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SEA', 'Macintosh', 1089);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SEC', NULL, 1090);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SEC', 'Pretty Good Privacy', 1091);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SEQ', 'Atari', 1092);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SET', NULL, 1093);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SF', 'OS/2', 1094);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SFI', 'Ventura Publisher', 1095);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SFL', 'Ventura Publisher', 1096);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SFP', 'Ventura Publisher', 1097);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SFS', 'StarFram, StarOffice', 1098);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SFT', 'CHIWriter', 1099);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SG', 'Micrografx FlowCharter', 1100);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SGI', NULL, 1101);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SGL', 'StarWriter, StarOffice', 1102);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SH', 'SHAR', 1103);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SH3', 'Harvard Graphics 3.0', 1104);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SHB', 'Corel SHOW', 1105);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SHF', 'PGP', 1106);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SHG', 'HOTSPOT EDITOR', 1107);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SHK', 'SHRINKIT, Apple II', 1108);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SHM', 'WordPerfect', 1109);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SHP', 'AutoCAD', 1110);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SHR', 'SHAR', 1111);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SHS', 'Microsoft Windows', 1112);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SHTM', 'Webbrowser (Internet Explorer, Netscape, Opera)', 1113);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SHTMFILE', 'Webbrowser (Internet Explorer, Netscape, Opera)', 1114);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SHTML', 'Webbrowser (Internet Explorer, Netscape, Opera)', 1115);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SHTMLFIL', 'Webbrowser (Internet Explorer, Netscape, Opera)', 1116);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SHW', 'Harvard Graphics 2.0 / Corel SHOW', 1117);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SHX', 'AutoCAD', 1118);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SIG', 'PGP', 1119);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SIK', NULL, 1120);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SIM', 'Microsoft Flight Simulator', 1121);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SIT', 'STUFFIT,  Macintosh', 1122);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SKR', 'PGP', 1123);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SL', NULL, 1124);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SLB', 'AutoCAD', 1125);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SLB', 'AutoCAD', 1126);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SLC', 'Telix', 1127);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SLD', 'AutoCAD', 1128);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SLD', 'AutoCAD', 1129);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SLG', 'AutoCAD', 1130);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SLK', 'Microsoft Excel', 1131);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SLK', 'Multiplan', 1132);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SLN', 'VisualStudio', 1133);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SLT', 'Telix', 1134);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SM', 'SMALLTALK', 1135);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SM', 'SAMNA Word', 1136);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SMC', 'Flowcharter', 1137);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SMD', 'StarMail, StarOffice', 1138);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SMF', 'StarMath, StarOffice', 1139);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SMI', 'Real-Player', 1140);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SMIL', 'Real-Player', 1141);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SMM', 'Lotos WordPro', 1142);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SMM', 'AMI PRO 2.x, 3.x', 1143);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SMP', NULL, 1144);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SND', NULL, 1145);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SNG', NULL, 1146);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SNO', 'SNOBOL', 1147);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SNP', 'MicroEyes', 1148);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SP', 'SPLINT', 1149);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPC', 'Microsoft Multiplan', 1150);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPC', 'WordPerfect f�r Windows', 1151);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPD', 'Harvard Graphics 3.0', 1152);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPD', NULL, 1153);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPG', 'Sprint', 1154);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPL', 'Sprint', 1155);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPL', 'SPLINT', 1156);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPL', 'Microsoft Windows', 1157);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPL', NULL, 1158);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPL', 'Macromedia Shockwave', 1159);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPM', 'WordPerfect', 1160);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPP', 'Sprint', 1161);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPR', 'Sprint', 1162);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPR', 'FoxPro', 1163);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPS', 'Sprint', 1164);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPT', 'Adobe PageMaker', 1165);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPT', 'SPITBOL', 1166);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SPX', 'FoxPro', 1167);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SQF', 'StarOffice', 1168);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SQL', 'SQL', 1169);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SQZ', 'SQUEEZE', 1170);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SRC', 'DATAFLEX and others', 1171);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SRF', 'Sun', 1172);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ST', 'SMALLTALK', 1173);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('STB', 'AutoCAD', 1174);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('STD', 'Prosa', 1175);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('STF', 'SHRINKTOFIT', 1176);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('STF', NULL, 1177);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('STL', 'Macromedia Fireworks', 1178);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('STM', 'Prosa', 1179);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('STR', 'dBASE', 1180);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('STS', 'Microsoft C/C++', 1181);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('STY', NULL, 1182);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SUN', 'Sun', 1183);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SunRas', 'Sun', 1184);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SUP', 'WordPerfect f�r Windows', 1185);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SV$', 'AutoCAD', 1186);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SVD', 'Microsoft Word', 1187);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SVG', 'Microsoft Word', 1188);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SVS', 'Microsoft Word', 1189);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SW', NULL, 1190);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SWF', 'Macromedia Shockwave', 1191);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SWP', 'DOS', 1192);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SWP', 'Sprint', 1193);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SY3', 'Harvard Graphics 3.0', 1194);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SYD', 'Microsoft Windows SYSEDIT.EXE', 1195);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SYM', 'Harvard Graphics', 1196);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SYM', 'Microsoft Windows SDK', 1197);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SYM', '(diverse Compiler)', 1198);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SYN', 'Microsoft Word 5', 1199);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SYS', 'Microsoft Windows', 1200);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('SYW', 'Harvard Graphics f�r Windows', 1201);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('T40', 'Adobe PageMaker 4.0', 1202);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('T50', 'Adobe PageMaker 5.0', 1203);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('T60', 'Adobe PageMaker 6.0', 1204);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('T65', 'Adobe PageMaker 6.5', 1205);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TAG', 'DATAFLEX', 1206);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TAH', 'Turbo Assembler, Borland C++', 1207);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TAR', 'WinZIP', 1208);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TAZ', 'WinZIP', 1209);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TB1', 'Borland Turbo C', 1210);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TB2', 'Borland Turbo C', 1211);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TBF', 'Visual FoxPro', 1212);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TBK', 'dBASE IV / FoxPro', 1213);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TBK', 'Asymetrix ToolBook', 1214);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TBL', 'Adobe Table', 1215);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TC', 'Borland C++ / Turbo C', 1216);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TCH', 'Borland C++ / Turbo C', 1217);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TD', 'Turbo Debugger', 1218);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TDB', NULL, 1219);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TDF', NULL, 1220);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TDH', 'Borland C++', 1221);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TDK', 'Turbo Debugger', 1222);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TDS', 'Turbo Debugger', 1223);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TDX', 'Visual FoxPro', 1224);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TEM', 'Icon Author', 1225);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TEM', 'Borland C++', 1226);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TEX', 'TeX', 1227);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TEX', 'CorelTexture', 1228);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TEXT', 'Texteditor', 1229);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TF', 'Turbo PROFileR', 1230);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TFA', 'Turbo PROFileR', 1231);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TFH', 'Borland C++', 1232);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TFS', 'Turbo PROFileR', 1233);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TGA', 'Microsoft PhotoDraw', 1234);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TGA', 'Truevision', 1235);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TGZ', 'WinZIP', 1236);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('THB', NULL, 1237);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('THM', 'Microsoft Clipart Gallery', 1238);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('THS', 'WordPerfect f�r Windows', 1239);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TIF', 'Bildbearbeitungssoftware', 1240);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TIFF', 'Bildbearbeitungssoftware', 1241);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TLB', 'Multimedia Toolbook', 1242);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TMF', 'WordPerfect f�r Windows', 1243);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TML', 'Adobe Table', 1244);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TMO', 'ZORTECH C++', 1245);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TMP', NULL, 1246);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TMS', 'TeleMate', 1247);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TOC', NULL, 1248);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TP', 'Turbo Pascal', 1249);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TP3', 'Harvard Graphics 3.0', 1250);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TPH', 'Turbo Pascal', 1251);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TPL', 'Turbo Pascal', 1252);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TPL', 'Harvard Graphics 2.0', 1253);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TPP', 'Turbo Pascal', 1254);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TPU', 'Turbo Pascal', 1255);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TPW', 'Turbo Pascal f�r Windows', 1256);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TRE', 'PC Tools', 1257);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TRM', 'Microsoft Windows', 1258);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TRN', 'QUATTRO', 1259);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TSP', 'Windows', 1260);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TST', 'WordPerfect f�r Windows', 1261);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TTF', 'Microsoft Windows', 1262);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TUT', NULL, 1263);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TX8', NULL, 1264);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TXT', NULL, 1265);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TXT', 'Texteditor', 1266);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TYM', 'PakeMaker 4 & 5', 1267);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('TZ', 'WinZIP', 1268);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('UB', NULL, 1269);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('UD', 'OmniPage', 1270);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('UDC', 'Adobe InDesign', 1271);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('UI', 'Sprint', 1272);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('UL', 'uLAW', 1273);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ULD', 'ProComm Plus', 1274);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('UNT', 'AutoCAD', 1275);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('UNX', 'UNIX specific Info', 1276);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('UPD', 'dBASE', 1277);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('UPO', 'dBASE', 1278);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('URL', 'Webbrowser, Microsoft Windows', 1279);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('USP', 'PakeMaker', 1280);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('USR', 'ProComm Plus, Turbo C++', 1281);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('UU', 'UU-Encode', 1282);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('UU', 'WinZIP', 1283);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('UUE', 'UU-Encode', 1284);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('UUE', 'WinZIP', 1285);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('UW', NULL, 1286);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VAF', 'VisualStudio Analyzer', 1287);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VAL', 'VisualStudio Analyzer', 1288);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VAL', 'dBASE', 1289);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VAP', 'VisualStudio Analyzer', 1290);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VAR', 'Icon Author', 1291);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VBG', 'VisualBASIC', 1292);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VBP', 'VisualBASIC', 1293);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VBX', 'Visual BASIC', 1294);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VC', 'VisiCalc', 1295);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VCT', 'Visual FoxPro', 1296);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VCX', 'Visual FoxPro', 1297);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VCX', 'VisiCalc', 1298);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VDA', 'Visual FoxPro', 1299);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VEW', 'Clipper 5', 1300);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VGA', 'Diverse', 1301);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VGA', 'Diverse', 1302);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VGR', 'Ventura Publisher', 1303);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VID', 'Word', 1304);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VID', 'MS-DOS Shell', 1305);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VIP', 'VisualInterDev', 1306);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VIV', 'VivoActive PowerPlayer', 1307);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VMF', 'Ventura Publisher', 1308);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VOC', NULL, 1309);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VSD', 'Visio', 1310);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VSS', 'Visio', 1311);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VST', 'Visio', 1312);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VST', 'Truevision Vista', 1313);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VSW', 'Visio', 1314);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VTM', 'Allaire HomeSite', 1315);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VUE', 'dBASE IV', 1316);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VUE', 'FoxPro', 1317);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VW', 'VOLKSWriteR', 1318);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VWR', 'PC Tools', 1319);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('VXD', 'Microsoft Windows', 1320);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('W', 'Applause', 1321);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('W30', 'Ventura Publisher', 1322);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('W40', 'Microsoft Windows 95', 1323);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WAV', '(Abspielsoftware)', 1324);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WAV', NULL, 1325);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WB2', 'QuattroPro', 1326);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WB3', 'QuattroPro', 1327);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WBF', NULL, 1328);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WBK', 'Microsoft Word', 1329);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WBK', 'WordPerfect f�r Windows', 1330);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WCD', 'WordPerfect f�r Windows', 1331);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WCM', 'Microsoft Works', 1332);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WCM', 'WordPerfect f�r Windows', 1333);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WDB', 'Microsoft Works', 1334);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WFN', 'Corel DRAW', 1335);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WFX', 'WINFax', 1336);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WI', 'Corel PhotoDraw', 1337);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WID', 'Ventura Publisher', 1338);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WIN', 'dBASE / FoxPro', 1339);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WK1', 'Lotus 1-2-3 Version 1.x', 1340);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WK2', 'Lotus 1-2-3 Version 2.x', 1341);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WK3', 'Lotus 1-2-3 Version 3.x', 1342);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WK4', 'Lotus 1-2-3 Version 4.x', 1343);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WKB', 'WordPerfect f�r Windows', 1344);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WKE', 'Lotus 1-2-3 (Student version)', 1345);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WKQ', 'Quattro Pro', 1346);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WKS', 'Lotus 1-2-3 / Symphony / Microsoft Works', 1347);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WKS', 'XLISP', 1348);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WLL', 'Microsoft Word', 1349);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WMA', 'Abspielsoftware', 1350);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WMC', 'WordPerfect f�r Windows', 1351);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WMC', 'WordMARC', 1352);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WMF', 'Microsoft Windows (Grafiksoftware, Textverarbeitung, Satz- und Layoutsoftware)', 1353);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WN', 'Write NOW', 1354);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WNF', 'Corel DRAW', 1355);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WOA', 'WebObjects', 1356);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WOD', 'WebObjects', 1357);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WOO', 'WebObjects', 1358);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WP', 'WordPerfect 4.2', 1359);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WP5', 'WordPerfect 5', 1360);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WPD', 'WordPerfect', 1361);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WPF', 'WordPerfect', 1362);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WPG', 'DRAWPerfect, WordPerfect', 1363);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WPK', 'WordPerfect f�r Windows', 1364);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WPS', 'Microsoft Works', 1365);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WQ!', 'Quattro Pro', 1366);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WQ1', 'Quattro Pro', 1367);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WR1', 'Symphony', 1368);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WRD', 'Charisma', 1369);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WRI', 'Windows Write', 1370);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WRK', 'Symphony 1.0', 1371);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WRP', 'WARP', 1372);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WRS', 'WordPerfect f�r Windows', 1373);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WS', 'WordStar 5.0+6.0', 1374);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WS2', 'WordStar 2000', 1375);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WSD', 'WordStar', 1376);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WST', 'WordStar', 1377);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('WSZ', 'WinAmp', 1378);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('X', 'LEX', 1379);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('X01', 'Paradox', 1380);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('X02', 'Paradox', 1381);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('X03', 'Paradox', 1382);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('X04', 'Paradox', 1383);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('X05', 'Paradox', 1384);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('X06', 'Paradox', 1385);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('X07', 'Paradox', 1386);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('X08', 'Paradox', 1387);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('X09', 'Paradox', 1388);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('X3D', 'Corel Dream 3D', 1389);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XAB', 'Xenix MAIL', 1390);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XBM', NULL, 1391);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XCF', 'GIMP', 1392);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XFN', 'Ventura Publisher', 1393);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XFT', 'CHIWriter', 1394);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XLA', 'Microsoft Excel', 1395);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XLB', 'Microsoft Excel', 1396);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XLC', 'Microsoft Excel', 1397);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XLD', 'Microsoft Excel', 1398);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XLG', 'Microsoft Excel', 1399);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XLK', 'Microsoft Excel', 1400);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XLL', 'Microsoft Excel', 1401);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XLM', 'Microsoft Excel', 1402);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XLS', 'Microsoft Excel', 1403);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XLS', 'Microsoft Excel', 1404);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XLT', 'Microsoft Excel', 1405);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XLT', 'Microsoft Excel', 1406);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XLT', 'Lotus 1-2-3 / Symphony', 1407);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XLV', 'Microsoft Excel', 1408);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XLW', 'Microsoft Excel', 1409);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XLW', 'Microsoft Excel', 1410);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XMX', 'AutoCAD', 1411);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XNT', 'QuarkXPress', 1412);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XPM', NULL, 1413);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XQT', 'SuperCalc', 1414);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XRF', NULL, 1415);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XTG', 'QuarkXPress', 1416);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XXT', 'QuarkXPress', 1417);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XY', 'XY Write', 1418);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XY3', 'XYWrite III', 1419);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('XYW', 'XYWrite III', 1420);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('Y', 'YABBA', 1421);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('Y01', 'Paradox', 1422);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('Y02', 'Paradox', 1423);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('Y03', 'Paradox', 1424);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('Y04', 'Paradox', 1425);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('Y05', 'Paradox', 1426);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('Y06', 'Paradox', 1427);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('Y07', 'Paradox', 1428);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('Y08', 'Paradox', 1429);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('Y09', 'Paradox', 1430);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('Z', 'Compress', 1431);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ZIP', 'PKZIP', 1432);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ZOM', 'ZOOM', 1433);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ZOO', 'ZOO', 1434);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ZON', 'OmniPage', 1435);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('ZVD', 'Z-Fax', 1436);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BAK', 'div. Programme', 1437);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('CUE', 'CueCards', 1438);

-- inserting data
INSERT INTO TIPOSARQ (CODIGO, NOME, ID)
VALUES ('BIN', 'Z. B. f�r Computerruhezustand', 1439);
