--------------------------------------------
--------------- Dump details ---------------
--------------------------------------------
-- Original file: C:\cnvoracle\datashare\reparar.mdb
-- Dump date: 12-18-2024 10:12:37
--------------------------------------------

-- creating table
CREATE TABLE REPARAR (
	ARQUIVO VARCHAR2 (50),
	CAMINHO VARCHAR2 (250),
	DIZER VARCHAR2 (150)
);



-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('CONTROLE.MDB', 'F:\ITAESBRA\CONTROLE\CONTROLE.MDB', 'Configuracao Modulo Controle');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('DESENHO.MDB', 'F:\ITAESBRA\CONTROLE\DESENHO.MDB', 'Cadastros Engenharia Modulo Controle');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('PF.MDB', 'F:\ITAESBRA\CONTROLE\PF.MDB', 'PF/PC/PPAP/FEMEA');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('PFP.MDB', 'F:\ITAESBRA\CONTROLE\PFP.MDB', 'PC Preliminar');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('POA.MDB', 'F:\ITAESBRA\CONTROLE\POA.MDB', 'Programa Olhos Abertos');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('USULOG.MDB', 'F:\ITAESBRA\LOG\USULOG.MDB', 'Arquivo de Log Inicial');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('DIC.MDB', 'F:\ITAESBRA\DICION\DIC.MDB', 'Dicionarios');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('IMAGEM.MDB', 'F:\ITAESBRA\PECAS\IMAGEM.MDB', 'Fotos Pe�as');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('IMGFER.MDB', 'F:\ITAESBRA\PECAS\IMGFER.MDB', 'Fotos Ferramentas');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('IMGME04.MDB', 'F:\ITAESBRA\PECAS\IMGME04.MDB', 'Fotos Equipamentos');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('IMGME06.MDB', 'F:\ITAESBRA\PECAS\IMGME06.MDB', 'Fotos Utilitarios');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('IMGMP04.MDB', 'F:\ITAESBRA\PECAS\IMGMP04.MDB', 'Fotos Funcionarios Matriz');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('IMGMP042.MDB', 'F:\ITAESBRA\PECAS\IMGMP042.MDB', 'Fotos Funcionarios Filial');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('IMGMR01.MDB', 'F:\ITAESBRA\PECAS\IMGMR01.MDB', 'Fotos Embalagens');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('IMGMT01.MDB', 'F:\ITAESBRA\PECAS\IMGMT01.MDB', 'Fotos Componentes');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('IMGMU01.MDB', 'F:\ITAESBRA\PECAS\IMGMU01.MDB', 'Fotos Materia Prima');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('IMGMW05.MDB', 'F:\ITAESBRA\PECAS\IMGMW05.MDB', 'Fotos Consumiveis');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('MA01LOGO.MDB', 'F:\ITAESBRA\PECAS\MA01LOGO.MDB', 'Fotos Cadastro Cliente');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('RTF.MDB', 'F:\ITAESBRA\WDOC\RTF.MDB', 'Configuracao de Documentos WRPT (WDOC)');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('RPT.MDB', 'F:\ITAESBRA\WRPT\RPT.MDB', 'Rela�ao de Relatorios WRPT');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('VORET.MDB', 'F:\ITAESBRA\WRPT\VORET.MDB', 'Configura�ao Relatorios VORET-2');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('WRPT.MDB', 'F:\ITAESBRA\WRPT\WRPT.MDB', 'Configuracao WRPT');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('USULOG.MDB', 'F:\ITAESBRA\WRPT\USULOG.MDB', 'Wrpt Log de Uso');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('IMGMQ01.MDB', 'F:\ITAESBRA\PECAS\IMGMQ01.MDB', 'Fotos Sub Produtos');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('LOGCONTROLE', 'F:\ITAESBRA\LOG\CONTROLE\LOG[MM][AAAA]..MDB', 'Log Controle Mensal');

-- inserting data
INSERT INTO REPARAR (ARQUIVO, CAMINHO, DIZER)
VALUES ('FEMEA.MDB', 'F:\ITAESBRA\CONTROLE\FEMEA.MDB', 'Femeas');
