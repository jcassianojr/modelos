--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 17:31:09 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: Alteracao
CREATE TABLE IF NOT EXISTS [Alteracao] (
	[NUMERO] int, 
	[ITEM] int, 
	[DIZER] longtext, 
	[DATA] datetime, 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: BaseDados
CREATE TABLE IF NOT EXISTS [BaseDados] (
	[NUMERO] int, 
	[ITEM] int, 
	[CAMINHO] varchar(200), 
	[NOME] varchar(50), 
	[TIPO] varchar(20), 
	[COGNOME] varchar(20), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: Caracter
CREATE TABLE IF NOT EXISTS [Caracter] (
	[NUMERO] int, 
	[ITEM] int, 
	[DATA] datetime, 
	[TIPO] varchar(10), 
	[temp] varchar(50), 
	[DIZER] varchar(50), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: LINGUAGEM
CREATE TABLE IF NOT EXISTS [LINGUAGEM] (
	[CODIGO] varchar(20), 
	[NOME] varchar(50), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: MODASS
CREATE TABLE IF NOT EXISTS [MODASS] (
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[MODULO] int, 
	[MODASS] int
);

-- Tabela: Modulos
CREATE TABLE IF NOT EXISTS [Modulos] (
	[NUMERO] int, 
	[COGNOME] varchar(20), 
	[EXECUTAVEL] varchar(20), 
	[LINGUAGEM] varchar(50), 
	[ARQINI] varchar(250), 
	[nome] varchar(120), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: Relatorios
CREATE TABLE IF NOT EXISTS [Relatorios] (
	[NUMERO] int, 
	[COGNOME] varchar(20), 
	[EXECUTAVEL] varchar(20), 
	[LINGUAGEM] varchar(50), 
	[ARQINI] varchar(250), 
	[nome] varchar(120), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: TipoCampos
CREATE TABLE IF NOT EXISTS [TipoCampos] (
	[CODIGO] varchar(20), 
	[NOME] varchar(50), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: TipoDados
CREATE TABLE IF NOT EXISTS [TipoDados] (
	[CODIGO] varchar(20), 
	[NOME] varchar(50), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: TiposArq
CREATE TABLE IF NOT EXISTS [TiposArq] (
	[CODIGO] varchar(8), 
	[NOME] varchar(100), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: TiposCarac
CREATE TABLE IF NOT EXISTS [TiposCarac] (
	[CODIGO] varchar(20), 
	[NOME] varchar(50), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- �ndice: IDXAlteracao_NUMERO
CREATE INDEX IF NOT EXISTS [IDXAlteracao_NUMERO]
	ON [Alteracao] ([NUMERO]);

-- �ndice: IDXBaseDados_NUMERO
CREATE INDEX IF NOT EXISTS [IDXBaseDados_NUMERO]
	ON [BaseDados] ([NUMERO]);

-- �ndice: IDXCaracter_NUMERO
CREATE INDEX IF NOT EXISTS [IDXCaracter_NUMERO]
	ON [Caracter] ([NUMERO]);

-- �ndice: IDXLINGUAGEM_CODIGO
CREATE INDEX IF NOT EXISTS [IDXLINGUAGEM_CODIGO]
	ON [LINGUAGEM] ([CODIGO]);

-- �ndice: IDXModulos_NUMERO
CREATE INDEX IF NOT EXISTS [IDXModulos_NUMERO]
	ON [Modulos] ([NUMERO]);

-- �ndice: IDXRelatorios_NUMERO
CREATE INDEX IF NOT EXISTS [IDXRelatorios_NUMERO]
	ON [Relatorios] ([NUMERO]);

-- �ndice: IDXTipoCampos_CODIGO
CREATE INDEX IF NOT EXISTS [IDXTipoCampos_CODIGO]
	ON [TipoCampos] ([CODIGO]);

-- �ndice: IDXTipoDados_CODIGO
CREATE INDEX IF NOT EXISTS [IDXTipoDados_CODIGO]
	ON [TipoDados] ([CODIGO]);

-- �ndice: IDXTiposArq_CODIGO
CREATE INDEX IF NOT EXISTS [IDXTiposArq_CODIGO]
	ON [TiposArq] ([CODIGO]);

-- �ndice: IDXTiposCarac_CODIGO
CREATE INDEX IF NOT EXISTS [IDXTiposCarac_CODIGO]
	ON [TiposCarac] ([CODIGO]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
