--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 17:32:33 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: USUARIO
CREATE TABLE IF NOT EXISTS [USUARIO] (
	[USUARIO] varchar(10), 
	[SENHA] varchar(8), 
	[DATAVAL] datetime, 
	[DATAULT] datetime, 
	[EQUIVALENTE] varchar(10), 
	[ATIVO] boolean NOT NULL, 
	[HORAINI] datetime, 
	[HORAFIM] datetime, 
	[WEEKEND] boolean NOT NULL, 
	[IDFOLHA] double, 
	[NOMEFOLHA] varchar(50), 
	[TROCAR] datetime, 
	[IDUSUARIO] int, 
	[id] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[postelaa] varchar(30) DEFAULT '000', 
	[postelaB] varchar(30) DEFAULT '000', 
	[CHAVEH] varchar(64), 
	[CHAVEV] varchar(64)
);

-- Tabela: USUBTN
CREATE TABLE IF NOT EXISTS [USUBTN] (
	[IDUSUARIO] int, 
	[FORM] int, 
	[INDICE] smallint, 
	[USUARIO] varchar(10), 
	[id] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: USUFORM
CREATE TABLE IF NOT EXISTS [USUFORM] (
	[IDUSUARIO] int, 
	[FORM] int, 
	[USUARIO] varchar(10), 
	[id] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: USURPT
CREATE TABLE IF NOT EXISTS [USURPT] (
	[IDUSUARIO] int, 
	[RPT] varchar(8), 
	[IMPRIME] boolean NOT NULL, 
	[EXPORTA] boolean NOT NULL, 
	[VISUALIZA] boolean NOT NULL, 
	[SALVARTF] boolean NOT NULL, 
	[SALVATXT] boolean NOT NULL, 
	[NOVO] boolean NOT NULL, 
	[ABRIR] boolean NOT NULL, 
	[EDITAR] boolean NOT NULL, 
	[CODIGO] varchar(8), 
	[ABRIRCOM] varchar(50), 
	[GRP] varchar(8), 
	[USUARIO] varchar(10), 
	[id] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- �ndice: IDXUSUARIO_IDFOLHA
CREATE INDEX IF NOT EXISTS [IDXUSUARIO_IDFOLHA]
	ON [USUARIO] ([IDFOLHA]);

-- �ndice: IDXUSUARIO_IDUSUARIO
CREATE INDEX IF NOT EXISTS [IDXUSUARIO_IDUSUARIO]
	ON [USUARIO] ([IDUSUARIO]);

-- �ndice: IDXUSUARIO_USUARIO
CREATE INDEX IF NOT EXISTS [IDXUSUARIO_USUARIO]
	ON [USUARIO] ([USUARIO]);

-- �ndice: IDXUSUBTN_FORM_IDUSUARIO_INDICE
CREATE INDEX IF NOT EXISTS [IDXUSUBTN_FORM_IDUSUARIO_INDICE]
	ON [USUBTN] ([FORM], [IDUSUARIO], [INDICE]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
