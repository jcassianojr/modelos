--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 09:53:24 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: tblAutor
CREATE TABLE IF NOT EXISTS [tblAutor] (
	[codAutor] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[Nome] varchar(80), 
	[Obs] varchar(80), 
	[codOcupacao] int DEFAULT 0, 
	[Nacionalidade] varchar(20)
);

-- Tabela: tblCitacao
CREATE TABLE IF NOT EXISTS [tblCitacao] (
	[codCitacao] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[Titulo] varchar(50), 
	[Fonte] varchar(120), 
	[codAutor] int DEFAULT 0, 
	[Citacao] longtext, 
	[ocultar] boolean NOT NULL
);

-- Tabela: tblOcupacao
CREATE TABLE IF NOT EXISTS [tblOcupacao] (
	[codOcupacao] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[Nome] varchar(50)
);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
