--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 17:30:43 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: Botoes
CREATE TABLE IF NOT EXISTS [Botoes] (
	[Indice] smallint, 
	[Icone] smallint, 
	[Nome] varchar(50), 
	[ToolTip] varchar(50), 
	[form] int, 
	[DISPONIVEL] boolean NOT NULL, 
	[INATIVO] boolean NOT NULL, 
	[reqdir] boolean NOT NULL, 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: Forms
CREATE TABLE IF NOT EXISTS [Forms] (
	[Form] int, 
	[NomePrg] varchar(50), 
	[Inativo] boolean NOT NULL, 
	[DISPONIVEL] boolean NOT NULL, 
	[modulo] int, 
	[reqdir] boolean NOT NULL, 
	[nome] varchar(120), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: icones
CREATE TABLE IF NOT EXISTS [icones] (
	[Indice] smallint, 
	[Nome] varchar(50), 
	[Arquivo] varchar(50), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: Menus
CREATE TABLE IF NOT EXISTS [Menus] (
	[Menu] varchar(10), 
	[INDICE] int, 
	[Dizer] varchar(50), 
	[Form] int, 
	[modulo] int, 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: RPTEXEC
CREATE TABLE IF NOT EXISTS [RPTEXEC] (
	[NOME] varchar(100), 
	[EXECUTAR] varchar(255), 
	[NUMERO] int, 
	[EXTENSAO] varchar(8), 
	[OBS] longtext, 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: tiposarq
CREATE TABLE IF NOT EXISTS [tiposarq] (
	[CODIGO] varchar(8), 
	[NOME] varchar(100), 
	[id] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- �ndice: IDXBotoes_form_Indice
CREATE INDEX IF NOT EXISTS [IDXBotoes_form_Indice]
	ON [Botoes] ([form], [Indice]);

-- �ndice: IDXForms_Form
CREATE INDEX IF NOT EXISTS [IDXForms_Form]
	ON [Forms] ([Form]);

-- �ndice: IDXicones_Indice
CREATE INDEX IF NOT EXISTS [IDXicones_Indice]
	ON [icones] ([Indice]);

-- �ndice: IDXMenus_Menu_INDICE
CREATE INDEX IF NOT EXISTS [IDXMenus_Menu_INDICE]
	ON [Menus] ([Menu], [INDICE]);

-- �ndice: IDXRPTEXEC_EXTENSAO
CREATE INDEX IF NOT EXISTS [IDXRPTEXEC_EXTENSAO]
	ON [RPTEXEC] ([EXTENSAO]);

-- �ndice: IDXRPTEXEC_NUMERO
CREATE INDEX IF NOT EXISTS [IDXRPTEXEC_NUMERO]
	ON [RPTEXEC] ([NUMERO]);

-- �ndice: IDXtiposarq_CODIGO
CREATE INDEX IF NOT EXISTS [IDXtiposarq_CODIGO]
	ON [tiposarq] ([CODIGO]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
