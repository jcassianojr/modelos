--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 17:33:29 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: MF02
CREATE TABLE IF NOT EXISTS [MF02] (
	[NUMERO] double, 
	[AGENCIA] varchar(12), 
	[CONTA] varchar(12), 
	[NRCONTA] double, 
	[NOMEAG] varchar(40), 
	[COGNAG] varchar(12), 
	[ENDERECO] varchar(40), 
	[BAIRRO] varchar(30), 
	[CIDADE] varchar(30), 
	[ESTADO] varchar(2), 
	[CEP] varchar(9), 
	[CXPOSTAL] varchar(5), 
	[DDD] varchar(4), 
	[TELEFONE] varchar(9), 
	[RAMAL] varchar(4), 
	[CONTATO] varchar(22), 
	[DDD1] varchar(4), 
	[TELEFONE1] varchar(9), 
	[RAMAL1] varchar(4), 
	[CONTATO1] varchar(22), 
	[DDDFAX] varchar(4), 
	[TELEFAX] varchar(9), 
	[PESSOA] varchar(1), 
	[CGC] varchar(15), 
	[INSCR] varchar(15), 
	[PRACA] varchar(12), 
	[TITULAR1] varchar(40), 
	[TITULAR2] varchar(40), 
	[TIPOCTA] varchar(1), 
	[XNDERECO1] varchar(40), 
	[XAIRRO1] varchar(30), 
	[XIDADE1] varchar(30), 
	[XSTADO1] varchar(2), 
	[XEP1] varchar(9), 
	[XXPOSTAL1] varchar(5), 
	[XDD1] varchar(4), 
	[XELEFONE1] varchar(9), 
	[XAMAL1] varchar(4), 
	[XONTATO1] varchar(22), 
	[XDF1] varchar(4), 
	[XAX1] varchar(9), 
	[XPF1] varchar(14), 
	[XNDERECO2] varchar(40), 
	[XAIRRO2] varchar(30), 
	[XIDADE2] varchar(30), 
	[XSTADO2] varchar(2), 
	[XEP2] varchar(9), 
	[XXPOSTAL2] varchar(5), 
	[XDD2] varchar(4), 
	[XELEFONE2] varchar(9), 
	[XAMAL2] varchar(4), 
	[XONTATO2] varchar(22), 
	[XDF2] varchar(4), 
	[XAX2] varchar(9), 
	[XPF2] varchar(14), 
	[id] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: MF04
CREATE TABLE IF NOT EXISTS [MF04] (
	[NUMERO] double, 
	[PRACA] varchar(12), 
	[NOMEPR] varchar(40), 
	[CIDPRA] varchar(30), 
	[ESTPRA] varchar(2), 
	[AREA1] varchar(70), 
	[AREA2] varchar(70), 
	[AREA3] varchar(70), 
	[AREA4] varchar(70), 
	[AREA5] varchar(70), 
	[CEPPRA] varchar(9), 
	[AREA] longtext, 
	[DIAFERIADO] smallint, 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[MESFERIADO] smallint
);

-- Tabela: ML03
CREATE TABLE IF NOT EXISTS [ML03] (
	[TIPFAT] varchar(1), 
	[BANCO] smallint, 
	[AGENCIA] varchar(7), 
	[CONTA] varchar(12), 
	[CHEQUE] varchar(15), 
	[DATA] datetime, 
	[VALOR] double, 
	[NRNOTA] int, 
	[PREDATADO] boolean NOT NULL, 
	[DATAPARA] datetime, 
	[VALORDES] double, 
	[VALORNEG] double, 
	[CTACUSTO] varchar(20), 
	[DEPDATA] datetime, 
	[DEPBCO] smallint, 
	[DEPAGC] varchar(7), 
	[DEPCTA] varchar(12), 
	[DEV01DATA] datetime, 
	[DEV01COD] varchar(10), 
	[REP01DATA] datetime, 
	[DEV02DATA] datetime, 
	[DEV02COD] varchar(10), 
	[COMPENSADO] datetime, 
	[OBS] longtext, 
	[FINALIZADO] boolean NOT NULL, 
	[DEV01DEP] double, 
	[DEV02DEP] double, 
	[REP02DATA] datetime, 
	[CLIENTE] int, 
	[id] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: MN03
CREATE TABLE IF NOT EXISTS [MN03] (
	[TIPFAT] varchar(1), 
	[BANCO] smallint, 
	[AGENCIA] varchar(7), 
	[CONTA] varchar(12), 
	[CHEQUE] varchar(15), 
	[DATA] datetime, 
	[VALOR] double, 
	[NRNOTA] int, 
	[PREDATADO] boolean NOT NULL, 
	[DATAPARA] datetime, 
	[VALORDES] double, 
	[VALORNEG] double, 
	[CTACUSTO] varchar(20), 
	[DEPDATA] datetime, 
	[DEPBCO] smallint, 
	[DEPAGC] varchar(7), 
	[DEPCTA] varchar(12), 
	[DEV01DATA] datetime, 
	[DEV01COD] varchar(10), 
	[REP01DATA] datetime, 
	[DEV02DATA] datetime, 
	[DEV02COD] varchar(10), 
	[COMPENSADO] datetime, 
	[OBS] longtext, 
	[FINALIZADO] boolean NOT NULL, 
	[DEV01DEP] double, 
	[DEV02DEP] double, 
	[REP02DATA] datetime, 
	[CLIENTE] int, 
	[id] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- �ndice: IDXMF04_NUMERO
CREATE INDEX IF NOT EXISTS [IDXMF04_NUMERO]
	ON [MF04] ([NUMERO]);

-- �ndice: IDXML03_NRNOTA
CREATE INDEX IF NOT EXISTS [IDXML03_NRNOTA]
	ON [ML03] ([NRNOTA]);

-- �ndice: IDXMN03_NRNOTA
CREATE INDEX IF NOT EXISTS [IDXMN03_NRNOTA]
	ON [MN03] ([NRNOTA]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
