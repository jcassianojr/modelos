BEGIN TRANSACTION;
CREATE TABLE [tblAutor] (
	[codAutor] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[Nome] varchar(80), 
	[Obs] varchar(80), 
	[codOcupacao] int DEFAULT 0, 
	[Nacionalidade] varchar(20)
);

CREATE TABLE [tblCitacao] (
	[codCitacao] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[Titulo] varchar(50), 
	[Fonte] varchar(120), 
	[codAutor] int DEFAULT 0, 
	[Citacao] longtext, 
	[ocultar] boolean NOT NULL
);

CREATE TABLE [tblOcupacao] (
	[codOcupacao] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[Nome] varchar(50)
);

COMMIT TRANSACTION;
