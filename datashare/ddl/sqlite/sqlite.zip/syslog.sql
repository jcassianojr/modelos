BEGIN TRANSACTION;
CREATE TABLE [log] (
	[user] int, 
	[form] int, 
	[opr] varchar(50), 
	[botao] int, 
	[data] datetime, 
	[OBS] longtext
);

CREATE TABLE [USULOG] (
	[IDUSUARIO] int, 
	[TIPO] tinyint, 
	[FORM] varchar(20), 
	[ACAO] tinyint, 
	[DATA] datetime, 
	[HORA] datetime
);

COMMIT TRANSACTION;
