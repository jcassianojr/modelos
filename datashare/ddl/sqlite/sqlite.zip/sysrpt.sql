BEGIN TRANSACTION;
CREATE TABLE [RPT] (
	[RPT] varchar(8), 
	[COGNOME] varchar(100), 
	[NOME] varchar(100), 
	[ARVORE] boolean NOT NULL, 
	[BUSCA] boolean NOT NULL, 
	[ARQUIVO] varchar(100), 
	[DATAIMP] datetime, 
	[UTILIZADO] int, 
	[DATACRI] datetime, 
	[SUBGRP] varchar(4), 
	[CAMINHO] varchar(200), 
	[MENSAGEM] longtext, 
	[CAMINH2] varchar(200), 
	[CAMINH3] varchar(200), 
	[CAMINH4] varchar(200), 
	[CARQUSO] varchar(8), 
	[CARQBAI] varchar(8), 
	[CARQFEC] varchar(2), 
	[CARQACU] varchar(8), 
	[COBSMSG] varchar(50), 
	[LFILTRO] boolean NOT NULL, 
	[TABALIAS] varchar(8), 
	[TABNAME] varchar(8), 
	[PREFILTRO] varchar(255), 
	[CODIGO] varchar(8), 
	[GRP] varchar(8), 
	[TITULO] varchar(255), 
	[ABRIRCOM] varchar(50), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[SQLUSO] longtext
);
CREATE INDEX [IDXRPT_CODIGO]
	ON [RPT] ([CODIGO]);
CREATE INDEX [IDXRPT_GRP]
	ON [RPT] ([GRP]);
CREATE INDEX [IDXRPT_RPT]
	ON [RPT] ([RPT]);

CREATE TABLE [RPTGRP] (
	[NOME] varchar(50), 
	[CODIGO] varchar(8), 
	[CAMINHO] varchar(255), 
	[GRP] varchar(8), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[LIBERAR] boolean NOT NULL
);
CREATE INDEX [IDXRPTGRP_CODIGO]
	ON [RPTGRP] ([CODIGO]);
CREATE INDEX [IDXRPTGRP_GRP]
	ON [RPTGRP] ([GRP]);

CREATE TABLE [RPTMAIN] (
	[NOME] varchar(50), 
	[CODIGO] varchar(8), 
	[CAMINHO] varchar(255), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[DISPONIVEL] boolean NOT NULL
);

COMMIT TRANSACTION;
