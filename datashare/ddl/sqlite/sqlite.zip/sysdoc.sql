BEGIN TRANSACTION;
CREATE TABLE [Alteracao] (
	[NUMERO] int, 
	[ITEM] int, 
	[DIZER] longtext, 
	[DATA] datetime, 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXAlteracao_NUMERO]
	ON [Alteracao] ([NUMERO]);

CREATE TABLE [BaseDados] (
	[NUMERO] int, 
	[ITEM] int, 
	[CAMINHO] varchar(200), 
	[NOME] varchar(50), 
	[TIPO] varchar(20), 
	[COGNOME] varchar(20), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXBaseDados_NUMERO]
	ON [BaseDados] ([NUMERO]);

CREATE TABLE [Caracter] (
	[NUMERO] int, 
	[ITEM] int, 
	[DATA] datetime, 
	[TIPO] varchar(10), 
	[temp] varchar(50), 
	[DIZER] varchar(50), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXCaracter_NUMERO]
	ON [Caracter] ([NUMERO]);

CREATE TABLE [LINGUAGEM] (
	[CODIGO] varchar(20), 
	[NOME] varchar(50), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXLINGUAGEM_CODIGO]
	ON [LINGUAGEM] ([CODIGO]);

CREATE TABLE [MODASS] (
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[MODULO] int, 
	[MODASS] int
);

CREATE TABLE [Modulos] (
	[NUMERO] int, 
	[COGNOME] varchar(20), 
	[EXECUTAVEL] varchar(20), 
	[LINGUAGEM] varchar(50), 
	[ARQINI] varchar(250), 
	[nome] varchar(120), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXModulos_NUMERO]
	ON [Modulos] ([NUMERO]);

CREATE TABLE [Relatorios] (
	[NUMERO] int, 
	[COGNOME] varchar(20), 
	[EXECUTAVEL] varchar(20), 
	[LINGUAGEM] varchar(50), 
	[ARQINI] varchar(250), 
	[nome] varchar(120), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
, [CAMINHO] TEXT, [ITEM] INTEGER);
CREATE INDEX [IDXRelatorios_NUMERO]
	ON [Relatorios] ([NUMERO]);

CREATE TABLE [TipoCampos] (
	[CODIGO] varchar(20), 
	[NOME] varchar(50), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXTipoCampos_CODIGO]
	ON [TipoCampos] ([CODIGO]);

CREATE TABLE [TipoDados] (
	[CODIGO] varchar(20), 
	[NOME] varchar(50), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXTipoDados_CODIGO]
	ON [TipoDados] ([CODIGO]);

CREATE TABLE [TiposArq] (
	[CODIGO] varchar(8), 
	[NOME] varchar(100), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXTiposArq_CODIGO]
	ON [TiposArq] ([CODIGO]);

CREATE TABLE [TiposCarac] (
	[CODIGO] varchar(20), 
	[NOME] varchar(50), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXTiposCarac_CODIGO]
	ON [TiposCarac] ([CODIGO]);

COMMIT TRANSACTION;
