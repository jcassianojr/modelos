BEGIN TRANSACTION;
CREATE TABLE [Botoes] (
	[Indice] smallint, 
	[Icone] smallint, 
	[Nome] varchar(50), 
	[ToolTip] varchar(50), 
	[form] int, 
	[DISPONIVEL] boolean NOT NULL, 
	[INATIVO] boolean NOT NULL, 
	[reqdir] boolean NOT NULL, 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXBotoes_form_Indice]
	ON [Botoes] ([form], [Indice]);

CREATE TABLE [Forms] (
	[Form] int, 
	[NomePrg] varchar(50), 
	[Inativo] boolean NOT NULL, 
	[DISPONIVEL] boolean NOT NULL, 
	[modulo] int, 
	[reqdir] boolean NOT NULL, 
	[nome] varchar(120), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXForms_Form]
	ON [Forms] ([Form]);

CREATE TABLE [icones] (
	[Indice] smallint, 
	[Nome] varchar(50), 
	[Arquivo] varchar(50), 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXicones_Indice]
	ON [icones] ([Indice]);

CREATE TABLE [Menus] (
	[Menu] varchar(10), 
	[INDICE] int, 
	[Dizer] varchar(50), 
	[Form] int, 
	[modulo] int, 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXMenus_Menu_INDICE]
	ON [Menus] ([Menu], [INDICE]);

CREATE TABLE [RPTEXEC] (
	[NOME] varchar(100), 
	[EXECUTAR] varchar(255), 
	[NUMERO] int, 
	[EXTENSAO] varchar(8), 
	[OBS] longtext, 
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXRPTEXEC_NUMERO]
	ON [RPTEXEC] ([NUMERO]);
CREATE INDEX [IDXRPTEXEC_EXTENSAO]
	ON [RPTEXEC] ([EXTENSAO]);

CREATE TABLE [tiposarq] (
	[CODIGO] varchar(8), 
	[NOME] varchar(100), 
	[id] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);
CREATE INDEX [IDXtiposarq_CODIGO]
	ON [tiposarq] ([CODIGO]);

COMMIT TRANSACTION;
