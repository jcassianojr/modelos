--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 17:32:58 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: CODDEVCHEQUE
CREATE TABLE IF NOT EXISTS [CODDEVCHEQUE] (
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[CODIGO] varchar(2), 
	[NOME] varchar(255)
);

-- Tabela: MDCOBBCO
CREATE TABLE IF NOT EXISTS [MDCOBBCO] (
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[CODIGO] varchar(2), 
	[NOME] varchar(40)
);

-- Tabela: MDCOBCAR
CREATE TABLE IF NOT EXISTS [MDCOBCAR] (
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[CODCART] varchar(1), 
	[MOEDA] varchar(4), 
	[COD2] varchar(1), 
	[COD1] varchar(1), 
	[COD3] varchar(1), 
	[CODIGO] varchar(3), 
	[DESCRICAO] varchar(40)
);

-- Tabela: MDCOBESP
CREATE TABLE IF NOT EXISTS [MDCOBESP] (
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[CODIGO] varchar(2), 
	[NOME] varchar(20)
);

-- Tabela: MDCOBINS
CREATE TABLE IF NOT EXISTS [MDCOBINS] (
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[CODIGO] varchar(2), 
	[NOME] varchar(47)
);

-- Tabela: MDCOBOCO
CREATE TABLE IF NOT EXISTS [MDCOBOCO] (
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[CODIGO] varchar(2), 
	[NOME] varchar(40)
);

-- Tabela: MDTIP
CREATE TABLE IF NOT EXISTS [MDTIP] (
	[CODIGO] varchar(10), 
	[DESCRICAO] varchar(30), 
	[CHAVE] int, 
	[id] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: MDTIT
CREATE TABLE IF NOT EXISTS [MDTIT] (
	[CODIGO] varchar(15), 
	[DESCRICAO] varchar(30), 
	[CHAVE] int, 
	[id] integer NOT NULL PRIMARY KEY AUTOINCREMENT
);

-- Tabela: mf01
CREATE TABLE IF NOT EXISTS [mf01] (
	[NUMERO] double, 
	[COGNOME] varchar(12), 
	[NOME] varchar(40), 
	[CARTEIRA] varchar(3), 
	[FLUXODIA] varchar(1), 
	[SITE] varchar(30)
);

-- Tabela: MOEDAS
CREATE TABLE IF NOT EXISTS [MOEDAS] (
	[CODIGO] double, 
	[NOME] varchar(17), 
	[SIMBOLO] varchar(7), 
	[BACEN] double, 
	[PAIS] varchar(25), 
	[TIPO] varchar(1), 
	[DATA_EXCLU] varchar(8)
);

-- Tabela: PAISES
CREATE TABLE IF NOT EXISTS [PAISES] (
	[UF] varchar(2), 
	[NOME] varchar(35), 
	[DDD] varchar(3), 
	[DDDDIRETO] varchar(1), 
	[ISO3166A] varchar(2), 
	[ISO3166B] varchar(3), 
	[ISO3166C] varchar(3), 
	[NOMEINT] varchar(35), 
	[BACEN] double, 
	[AREA] double, 
	[PERIM] double, 
	[INDEPYEAR] double, 
	[CONTINENT] varchar(15)
);

-- Tabela: PBACEN
CREATE TABLE IF NOT EXISTS [PBACEN] (
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[CODIGO] varchar(1), 
	[NOME] varchar(50)
);

-- �ndice: IDXCODDEVCHEQUE_ID
CREATE INDEX IF NOT EXISTS [IDXCODDEVCHEQUE_ID]
	ON [CODDEVCHEQUE] ([ID]);

-- �ndice: IDXMDCOBBCO_ID
CREATE INDEX IF NOT EXISTS [IDXMDCOBBCO_ID]
	ON [MDCOBBCO] ([ID]);

-- �ndice: IDXMDCOBCAR_ID
CREATE INDEX IF NOT EXISTS [IDXMDCOBCAR_ID]
	ON [MDCOBCAR] ([ID]);

-- �ndice: IDXMDCOBESP_ID
CREATE INDEX IF NOT EXISTS [IDXMDCOBESP_ID]
	ON [MDCOBESP] ([ID]);

-- �ndice: IDXMDCOBINS_ID
CREATE INDEX IF NOT EXISTS [IDXMDCOBINS_ID]
	ON [MDCOBINS] ([ID]);

-- �ndice: IDXMDCOBOCO_ID
CREATE INDEX IF NOT EXISTS [IDXMDCOBOCO_ID]
	ON [MDCOBOCO] ([ID]);

-- �ndice: IDXPBACEN_ID
CREATE INDEX IF NOT EXISTS [IDXPBACEN_ID]
	ON [PBACEN] ([ID]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
