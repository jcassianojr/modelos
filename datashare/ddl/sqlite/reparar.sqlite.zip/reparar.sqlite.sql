--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 17:28:26 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: REPARAR
CREATE TABLE IF NOT EXISTS [REPARAR] (
	[ARQUIVO] varchar(50), 
	[CAMINHO] varchar(250), 
	[DIZER] varchar(150)
);

-- �ndice: IDXREPARAR_ARQUIVO
CREATE INDEX IF NOT EXISTS [IDXREPARAR_ARQUIVO]
	ON [REPARAR] ([ARQUIVO]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
