--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 17:33:53 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: CONDPAGTO
CREATE TABLE IF NOT EXISTS [CONDPAGTO] (
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[CODIGO] varchar(20), 
	[NOME] varchar(50), 
	[IPI] varchar(1), 
	[DESPFINANC] varchar(1), 
	[CODIGODESPFINANC] varchar(15), 
	[PARCELAS] int DEFAULT 0, 
	[QTDEDIAS] int DEFAULT 0, 
	[DIA1] smallint DEFAULT 0, 
	[DIA2] smallint DEFAULT 0, 
	[DIA3] smallint DEFAULT 0, 
	[DIA4] smallint DEFAULT 0, 
	[DIA5] smallint DEFAULT 0, 
	[DIA6] smallint DEFAULT 0, 
	[DIA7] smallint DEFAULT 0, 
	[DIA8] smallint DEFAULT 0, 
	[DIA9] smallint DEFAULT 0, 
	[DIA10] smallint DEFAULT 0, 
	[POR1] smallint DEFAULT 0, 
	[POR2] smallint DEFAULT 0, 
	[POR3] smallint DEFAULT 0, 
	[POR4] smallint DEFAULT 0, 
	[POR5] smallint DEFAULT 0, 
	[POR6] smallint DEFAULT 0, 
	[POR7] smallint DEFAULT 0, 
	[POR8] smallint DEFAULT 0, 
	[POR9] smallint DEFAULT 0, 
	[POR10] smallint DEFAULT 0, 
	[DADATA] varchar(1), 
	[CAI1] smallint DEFAULT 0, 
	[CAI2] smallint DEFAULT 0, 
	[CAI3] smallint DEFAULT 0, 
	[CAI4] smallint DEFAULT 0, 
	[SEMANA] varchar(2), 
	[PADRAO] varchar(1)
);

-- Tabela: RAMO
CREATE TABLE IF NOT EXISTS [RAMO] (
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[CODIGO] varchar(10), 
	[NOME] varchar(50), 
	[PADRAO] varchar(1), 
	[CONTATOS] int DEFAULT 0
);

-- Tabela: ZONAS
CREATE TABLE IF NOT EXISTS [ZONAS] (
	[ID] integer NOT NULL PRIMARY KEY AUTOINCREMENT, 
	[CODIGO] varchar(20), 
	[NOME] varchar(30), 
	[QTDE] int DEFAULT 0
);

-- �ndice: IDXRAMO_CODIGO
CREATE INDEX IF NOT EXISTS [IDXRAMO_CODIGO]
	ON [RAMO] ([CODIGO]);

-- �ndice: IDXZONAS_ID
CREATE INDEX IF NOT EXISTS [IDXZONAS_ID]
	ON [ZONAS] ([ID]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
