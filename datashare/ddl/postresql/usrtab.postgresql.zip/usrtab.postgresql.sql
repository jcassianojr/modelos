--
-- DUMP FILE
--
-- Database is ported from MS Access
--------------------------------------------------------------------
-- Created using "MS Access to PostgreSQL" form http://www.bullzip.com
-- Program Version 5.5.281
--
-- OPTIONS:
--   sourcefilename=C:/Users/jcass/Downloads/usrtab.mdb
--   sourceusername=
--   sourcepassword=
--   sourcesystemdatabase=
--   destinationserver=localhost
--   destinationdatabase=usrtab
--   maintenancedb=postgres
--   dropdatabase=0
--   createtables=1
--   unicode=0
--   autocommit=1
--   transferdefaultvalues=1
--   transferindexes=1
--   transferautonumbers=1
--   transferrecords=0
--   columnlist=1
--   tableprefix=
--   negativeboolean=0
--   ignorelargeblobs=0
--   memotype=TEXT
--   datetimetype=TIMESTAMP
--

CREATE DATABASE "usrtab";

-- NOTICE: At this place you need to connect to the new database and run the rest of the statements.

--
-- Table structure for table 'CONDPAGTO'
--

DROP TABLE IF EXISTS "CONDPAGTO";

CREATE TABLE "CONDPAGTO" (
  "ID" SERIAL NOT NULL, 
  "CODIGO" VARCHAR(20), 
  "NOME" VARCHAR(50), 
  "IPI" VARCHAR(1), 
  "DESPFINANC" VARCHAR(1), 
  "CODIGODESPFINANC" VARCHAR(15), 
  "PARCELAS" INTEGER DEFAULT 0, 
  "QTDEDIAS" INTEGER DEFAULT 0, 
  "DIA1" INTEGER DEFAULT 0, 
  "DIA2" INTEGER DEFAULT 0, 
  "DIA3" INTEGER DEFAULT 0, 
  "DIA4" INTEGER DEFAULT 0, 
  "DIA5" INTEGER DEFAULT 0, 
  "DIA6" INTEGER DEFAULT 0, 
  "DIA7" INTEGER DEFAULT 0, 
  "DIA8" INTEGER DEFAULT 0, 
  "DIA9" INTEGER DEFAULT 0, 
  "DIA10" INTEGER DEFAULT 0, 
  "POR1" INTEGER DEFAULT 0, 
  "POR2" INTEGER DEFAULT 0, 
  "POR3" INTEGER DEFAULT 0, 
  "POR4" INTEGER DEFAULT 0, 
  "POR5" INTEGER DEFAULT 0, 
  "POR6" INTEGER DEFAULT 0, 
  "POR7" INTEGER DEFAULT 0, 
  "POR8" INTEGER DEFAULT 0, 
  "POR9" INTEGER DEFAULT 0, 
  "POR10" INTEGER DEFAULT 0, 
  "DADATA" VARCHAR(1), 
  "CAI1" INTEGER DEFAULT 0, 
  "CAI2" INTEGER DEFAULT 0, 
  "CAI3" INTEGER DEFAULT 0, 
  "CAI4" INTEGER DEFAULT 0, 
  "SEMANA" VARCHAR(2), 
  "PADRAO" VARCHAR(1), 
  PRIMARY KEY ("ID")
);

--
-- Table structure for table 'RAMO'
--

DROP TABLE IF EXISTS "RAMO";

CREATE TABLE "RAMO" (
  "ID" SERIAL NOT NULL, 
  "CODIGO" VARCHAR(10), 
  "NOME" VARCHAR(50), 
  "PADRAO" VARCHAR(1), 
  "CONTATOS" INTEGER DEFAULT 0, 
  PRIMARY KEY ("ID")
);

--
-- Table structure for table 'ZONAS'
--

DROP TABLE IF EXISTS "ZONAS";

CREATE TABLE "ZONAS" (
  "ID" SERIAL NOT NULL, 
  "CODIGO" VARCHAR(20), 
  "NOME" VARCHAR(30), 
  "QTDE" INTEGER DEFAULT 0, 
  PRIMARY KEY ("ID")
);

