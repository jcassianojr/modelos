--
-- DUMP FILE
--
-- Database is ported from MS Access
--------------------------------------------------------------------
-- Created using "MS Access to PostgreSQL" form http://www.bullzip.com
-- Program Version 5.5.281
--
-- OPTIONS:
--   sourcefilename=C:/Users/jcass/Downloads/usrcad.mdb
--   sourceusername=
--   sourcepassword=
--   sourcesystemdatabase=
--   destinationserver=localhost
--   destinationdatabase=usrcad
--   maintenancedb=postgres
--   dropdatabase=0
--   createtables=1
--   unicode=0
--   autocommit=1
--   transferdefaultvalues=1
--   transferindexes=1
--   transferautonumbers=1
--   transferrecords=0
--   columnlist=1
--   tableprefix=
--   negativeboolean=0
--   ignorelargeblobs=0
--   memotype=TEXT
--   datetimetype=TIMESTAMP
--

CREATE DATABASE "usrcad";

-- NOTICE: At this place you need to connect to the new database and run the rest of the statements.

--
-- Table structure for table 'MF02'
--

DROP TABLE IF EXISTS "MF02";

CREATE TABLE "MF02" (
  "NUMERO" DOUBLE PRECISION NULL, 
  "AGENCIA" VARCHAR(12), 
  "CONTA" VARCHAR(12), 
  "NRCONTA" DOUBLE PRECISION NULL, 
  "NOMEAG" VARCHAR(40), 
  "COGNAG" VARCHAR(12), 
  "ENDERECO" VARCHAR(40), 
  "BAIRRO" VARCHAR(30), 
  "CIDADE" VARCHAR(30), 
  "ESTADO" VARCHAR(2), 
  "CEP" VARCHAR(9), 
  "CXPOSTAL" VARCHAR(5), 
  "DDD" VARCHAR(4), 
  "TELEFONE" VARCHAR(9), 
  "RAMAL" VARCHAR(4), 
  "CONTATO" VARCHAR(22), 
  "DDD1" VARCHAR(4), 
  "TELEFONE1" VARCHAR(9), 
  "RAMAL1" VARCHAR(4), 
  "CONTATO1" VARCHAR(22), 
  "DDDFAX" VARCHAR(4), 
  "TELEFAX" VARCHAR(9), 
  "PESSOA" VARCHAR(1), 
  "CGC" VARCHAR(15), 
  "INSCR" VARCHAR(15), 
  "PRACA" VARCHAR(12), 
  "TITULAR1" VARCHAR(40), 
  "TITULAR2" VARCHAR(40), 
  "TIPOCTA" VARCHAR(1), 
  "XNDERECO1" VARCHAR(40), 
  "XAIRRO1" VARCHAR(30), 
  "XIDADE1" VARCHAR(30), 
  "XSTADO1" VARCHAR(2), 
  "XEP1" VARCHAR(9), 
  "XXPOSTAL1" VARCHAR(5), 
  "XDD1" VARCHAR(4), 
  "XELEFONE1" VARCHAR(9), 
  "XAMAL1" VARCHAR(4), 
  "XONTATO1" VARCHAR(22), 
  "XDF1" VARCHAR(4), 
  "XAX1" VARCHAR(9), 
  "XPF1" VARCHAR(14), 
  "XNDERECO2" VARCHAR(40), 
  "XAIRRO2" VARCHAR(30), 
  "XIDADE2" VARCHAR(30), 
  "XSTADO2" VARCHAR(2), 
  "XEP2" VARCHAR(9), 
  "XXPOSTAL2" VARCHAR(5), 
  "XDD2" VARCHAR(4), 
  "XELEFONE2" VARCHAR(9), 
  "XAMAL2" VARCHAR(4), 
  "XONTATO2" VARCHAR(22), 
  "XDF2" VARCHAR(4), 
  "XAX2" VARCHAR(9), 
  "XPF2" VARCHAR(14), 
  "id" SERIAL
);

--
-- Table structure for table 'MF04'
--

DROP TABLE IF EXISTS "MF04";

CREATE TABLE "MF04" (
  "NUMERO" DOUBLE PRECISION NULL, 
  "PRACA" VARCHAR(12), 
  "NOMEPR" VARCHAR(40), 
  "CIDPRA" VARCHAR(30), 
  "ESTPRA" VARCHAR(2), 
  "AREA1" VARCHAR(70), 
  "AREA2" VARCHAR(70), 
  "AREA3" VARCHAR(70), 
  "AREA4" VARCHAR(70), 
  "AREA5" VARCHAR(70), 
  "CEPPRA" VARCHAR(9), 
  "AREA" TEXT, 
  "DIAFERIADO" INTEGER, 
  "ID" SERIAL, 
  "MESFERIADO" INTEGER
);

--
-- Table structure for table 'ML03'
--

DROP TABLE IF EXISTS "ML03";

CREATE TABLE "ML03" (
  "TIPFAT" VARCHAR(1), 
  "BANCO" INTEGER, 
  "AGENCIA" VARCHAR(7), 
  "CONTA" VARCHAR(12), 
  "CHEQUE" VARCHAR(15), 
  "DATA" TIMESTAMP, 
  "VALOR" DOUBLE PRECISION NULL, 
  "NRNOTA" INTEGER, 
  "PREDATADO" BOOLEAN, 
  "DATAPARA" TIMESTAMP, 
  "VALORDES" DOUBLE PRECISION NULL, 
  "VALORNEG" DOUBLE PRECISION NULL, 
  "CTACUSTO" VARCHAR(20), 
  "DEPDATA" TIMESTAMP, 
  "DEPBCO" INTEGER, 
  "DEPAGC" VARCHAR(7), 
  "DEPCTA" VARCHAR(12), 
  "DEV01DATA" TIMESTAMP, 
  "DEV01COD" VARCHAR(10), 
  "REP01DATA" TIMESTAMP, 
  "DEV02DATA" TIMESTAMP, 
  "DEV02COD" VARCHAR(10), 
  "COMPENSADO" TIMESTAMP, 
  "OBS" TEXT, 
  "FINALIZADO" BOOLEAN, 
  "DEV01DEP" DOUBLE PRECISION NULL, 
  "DEV02DEP" DOUBLE PRECISION NULL, 
  "REP02DATA" TIMESTAMP, 
  "CLIENTE" INTEGER, 
  "id" SERIAL
);

--
-- Table structure for table 'MN03'
--

DROP TABLE IF EXISTS "MN03";

CREATE TABLE "MN03" (
  "TIPFAT" VARCHAR(1), 
  "BANCO" INTEGER, 
  "AGENCIA" VARCHAR(7), 
  "CONTA" VARCHAR(12), 
  "CHEQUE" VARCHAR(15), 
  "DATA" TIMESTAMP, 
  "VALOR" DOUBLE PRECISION NULL, 
  "NRNOTA" INTEGER, 
  "PREDATADO" BOOLEAN, 
  "DATAPARA" TIMESTAMP, 
  "VALORDES" DOUBLE PRECISION NULL, 
  "VALORNEG" DOUBLE PRECISION NULL, 
  "CTACUSTO" VARCHAR(20), 
  "DEPDATA" TIMESTAMP, 
  "DEPBCO" INTEGER, 
  "DEPAGC" VARCHAR(7), 
  "DEPCTA" VARCHAR(12), 
  "DEV01DATA" TIMESTAMP, 
  "DEV01COD" VARCHAR(10), 
  "REP01DATA" TIMESTAMP, 
  "DEV02DATA" TIMESTAMP, 
  "DEV02COD" VARCHAR(10), 
  "COMPENSADO" TIMESTAMP, 
  "OBS" TEXT, 
  "FINALIZADO" BOOLEAN, 
  "DEV01DEP" DOUBLE PRECISION NULL, 
  "DEV02DEP" DOUBLE PRECISION NULL, 
  "REP02DATA" TIMESTAMP, 
  "CLIENTE" INTEGER, 
  "id" SERIAL
);

