--
-- DUMP FILE
--
-- Database is ported from MS Access
--------------------------------------------------------------------
-- Created using "MS Access to PostgreSQL" form http://www.bullzip.com
-- Program Version 5.5.281
--
-- OPTIONS:
--   sourcefilename=C:/Users/jcass/Downloads/reparar.mdb
--   sourceusername=
--   sourcepassword=
--   sourcesystemdatabase=
--   destinationserver=localhost
--   destinationdatabase=reparar
--   maintenancedb=postgres
--   dropdatabase=0
--   createtables=1
--   unicode=0
--   autocommit=1
--   transferdefaultvalues=1
--   transferindexes=1
--   transferautonumbers=1
--   transferrecords=1
--   columnlist=1
--   tableprefix=
--   negativeboolean=0
--   ignorelargeblobs=0
--   memotype=TEXT
--   datetimetype=TIMESTAMP
--

CREATE DATABASE "reparar";

-- NOTICE: At this place you need to connect to the new database and run the rest of the statements.

--
-- Table structure for table 'REPARAR'
--

DROP TABLE IF EXISTS "REPARAR";

CREATE TABLE "REPARAR" (
  "ARQUIVO" VARCHAR(50), 
  "CAMINHO" VARCHAR(250), 
  "DIZER" VARCHAR(150)
);

--
-- Dumping data for table 'REPARAR'
--

INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'CONTROLE.MDB', E'F:\\ITAESBRA\\CONTROLE\\CONTROLE.MDB', E'Configuracao Modulo Controle');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'DESENHO.MDB', E'F:\\ITAESBRA\\CONTROLE\\DESENHO.MDB', E'Cadastros Engenharia Modulo Controle');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'PF.MDB', E'F:\\ITAESBRA\\CONTROLE\\PF.MDB', E'PF/PC/PPAP/FEMEA');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'PFP.MDB', E'F:\\ITAESBRA\\CONTROLE\\PFP.MDB', E'PC Preliminar');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'POA.MDB', E'F:\\ITAESBRA\\CONTROLE\\POA.MDB', E'Programa Olhos Abertos');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'USULOG.MDB', E'F:\\ITAESBRA\\LOG\\USULOG.MDB', E'Arquivo de Log Inicial');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'DIC.MDB', E'F:\\ITAESBRA\\DICION\\DIC.MDB', E'Dicionarios');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'IMAGEM.MDB', E'F:\\ITAESBRA\\PECAS\\IMAGEM.MDB', E'Fotos Peças');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'IMGFER.MDB', E'F:\\ITAESBRA\\PECAS\\IMGFER.MDB', E'Fotos Ferramentas');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'IMGME04.MDB', E'F:\\ITAESBRA\\PECAS\\IMGME04.MDB', E'Fotos Equipamentos');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'IMGME06.MDB', E'F:\\ITAESBRA\\PECAS\\IMGME06.MDB', E'Fotos Utilitarios');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'IMGMP04.MDB', E'F:\\ITAESBRA\\PECAS\\IMGMP04.MDB', E'Fotos Funcionarios Matriz');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'IMGMP042.MDB', E'F:\\ITAESBRA\\PECAS\\IMGMP042.MDB', E'Fotos Funcionarios Filial');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'IMGMR01.MDB', E'F:\\ITAESBRA\\PECAS\\IMGMR01.MDB', E'Fotos Embalagens');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'IMGMT01.MDB', E'F:\\ITAESBRA\\PECAS\\IMGMT01.MDB', E'Fotos Componentes');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'IMGMU01.MDB', E'F:\\ITAESBRA\\PECAS\\IMGMU01.MDB', E'Fotos Materia Prima');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'IMGMW05.MDB', E'F:\\ITAESBRA\\PECAS\\IMGMW05.MDB', E'Fotos Consumiveis');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'MA01LOGO.MDB', E'F:\\ITAESBRA\\PECAS\\MA01LOGO.MDB', E'Fotos Cadastro Cliente');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'RTF.MDB', E'F:\\ITAESBRA\\WDOC\\RTF.MDB', E'Configuracao de Documentos WRPT (WDOC)');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'RPT.MDB', E'F:\\ITAESBRA\\WRPT\\RPT.MDB', E'Relaçao de Relatorios WRPT');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'VORET.MDB', E'F:\\ITAESBRA\\WRPT\\VORET.MDB', E'Configuraçao Relatorios VORET-2');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'WRPT.MDB', E'F:\\ITAESBRA\\WRPT\\WRPT.MDB', E'Configuracao WRPT');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'USULOG.MDB', E'F:\\ITAESBRA\\WRPT\\USULOG.MDB', E'Wrpt Log de Uso');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'IMGMQ01.MDB', E'F:\\ITAESBRA\\PECAS\\IMGMQ01.MDB', E'Fotos Sub Produtos');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'LOGCONTROLE', E'F:\\ITAESBRA\\LOG\\CONTROLE\\LOG[MM][AAAA]..MDB', E'Log Controle Mensal');
INSERT INTO "REPARAR" ("ARQUIVO", "CAMINHO", "DIZER") VALUES (E'FEMEA.MDB', E'F:\\ITAESBRA\\CONTROLE\\FEMEA.MDB', E'Femeas');
-- 26 records

CREATE INDEX "REPARAR_ARQUIVO" ON "REPARAR" ("ARQUIVO");

