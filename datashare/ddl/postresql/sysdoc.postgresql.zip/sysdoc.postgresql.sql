--
-- DUMP FILE
--
-- Database is ported from MS Access
--------------------------------------------------------------------
-- Created using "MS Access to PostgreSQL" form http://www.bullzip.com
-- Program Version 5.5.281
--
-- OPTIONS:
--   sourcefilename=C:/Users/jcass/Downloads/sysdoc.mdb
--   sourceusername=
--   sourcepassword=
--   sourcesystemdatabase=
--   destinationserver=localhost
--   destinationdatabase=sysdoc
--   maintenancedb=postgres
--   dropdatabase=0
--   createtables=1
--   unicode=0
--   autocommit=1
--   transferdefaultvalues=1
--   transferindexes=1
--   transferautonumbers=1
--   transferrecords=1
--   columnlist=1
--   tableprefix=
--   negativeboolean=0
--   ignorelargeblobs=0
--   memotype=TEXT
--   datetimetype=TIMESTAMP
--

CREATE DATABASE "sysdoc";

-- NOTICE: At this place you need to connect to the new database and run the rest of the statements.

--
-- Table structure for table 'Alteracao'
--

DROP TABLE IF EXISTS "Alteracao";

CREATE TABLE "Alteracao" (
  "NUMERO" INTEGER, 
  "ITEM" INTEGER, 
  "DIZER" TEXT, 
  "DATA" TIMESTAMP, 
  "ID" SERIAL
);

--
-- Dumping data for table 'Alteracao'
--

INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (1, 1, E'Inclusao Form Alteraçao', '2003-12-12 11:15:26', 1);
INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (1, 2, E'Inclusao Tabelas Tipos Caracteristicas Sistema', '2003-12-12 12:45:03', 2);
INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (1, 3, E'Inclusão Documentaçao Sistema Caracteristicas', '2003-12-12 13:42:58', 3);
INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (1, 4, E'Inclusao do Editor de Textos', '2003-12-12 17:35:25', 4);
INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (1, 5, E'Inclusao de Editor de Arquivos INI', '2003-12-19 19:39:52', 5);
INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (1, 6, E'Documentaçao Permite Alterar o arquivo Ini do Sistema', '2003-12-19 22:14:48', 6);
INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (1, 7, E'Inclusao Tabela SYSRPT', '2003-12-27 13:04:40', 7);
INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (1, 8, E'Criaçao Formulario Escolha Relatorios/Documentos 1057(escgrpmain.frm)', '2003-12-27 13:19:08', 8);
INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (0, 0, NULL, '2003-12-27 21:46:41', 9);
INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (1, 9, E'Criaçao Formulário Ediçao Relatórios/Documentos 1058 frmRptMain', '2003-12-27 21:58:31', 10);
INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (1, 10, E'Criaçao Formularios Escolher Grupo Relatorios 1059 escrptgrp', '2003-12-29 15:03:25', 11);
INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (1, 11, E'Criaçao Formularios Editar Grupo Relatorios 1060 frmrptgrp', '2003-12-29 15:03:51', 12);
INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (1, 12, E'Criaçao Formularios Escolher Tipos Arquivos 1060 escodnome', '2003-12-29 15:04:23', 13);
INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (1, 13, E'Criaçao Formularios Editar tipos arquivos 1062 frmcodnome', '2003-12-29 15:04:56', 14);
INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (1, 14, E'Inclusao Formulario de Senhas', '2004-02-06 12:32:56', 15);
INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (1, 15, E'Teste Grid', '2004-02-17 17:59:30', 16);
INSERT INTO "Alteracao" ("NUMERO", "ITEM", "DIZER", "DATA", "ID") VALUES (5, 1, E'Integraçao Novo Vblib2', '2004-02-18 19:32:22', 17);
-- 17 records

SELECT setval('"Alteracao_ID_seq"', MAX("ID")) FROM "Alteracao";

CREATE INDEX "Alteracao_NUMERO" ON "Alteracao" ("NUMERO");

--
-- Table structure for table 'BaseDados'
--

DROP TABLE IF EXISTS "BaseDados";

CREATE TABLE "BaseDados" (
  "NUMERO" INTEGER, 
  "ITEM" INTEGER, 
  "CAMINHO" VARCHAR(200), 
  "NOME" VARCHAR(50), 
  "TIPO" VARCHAR(20), 
  "COGNOME" VARCHAR(20), 
  "ID" SERIAL
);

--
-- Dumping data for table 'BaseDados'
--

INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (2, 1, E'C:\\develop\\os\\reparar.mdb', E'Configuração Reparação Base de Dados', E'MDB', E'REPARAR', 1);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (1, 1, E'{REPARQ}', E'Configuraçao Reparaçao Banco de Dados', E'MDB', E'REPARAR', 2);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (1, 2, E'{CFG}', E'Configuraçao do Sistema', E'MDB', E'SYSCONF', 3);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (1, 3, E'{SYSDOC}', E'Documentaçao do Sistema', E'MDB', E'SYSDOC', 4);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (1, 4, E'{LOG}', E'Log de Utilizaçao do Sistema', E'MDB', E'SYSLOG', 5);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (1, 5, E'{USR}', E'Configuraçoes de Usuarios', E'MDB', E'SYSUSER', 6);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (1, 6, E'{TAB}', E'Tabela Modulo Ordem de Serviço', E'MDB', E'TABOS', 7);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (1, 7, E'{USRTAB}', E'Tabelas Ordem Serviço Usuario', E'MDB', E'TABOSUSR', 8);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (1, 8, E'{TABSYS}', E'Tabelas do Sistema', E'MDB', E'TABSYS', 9);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (1, 9, E'{USRTAB}', E'Cadastro do Usuarios', E'MDB', E'TABUSR', 10);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (4, 1, E'C:\\develop\\comex\\comexcad.mdb', E'Cadastro', E'MDB', E'COMEXCAD', 11);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (4, 2, E'C:\\develop\\comex\\comextab.mdb', E'Tabelas', E'MDB', E'COMEXTAB', 12);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (5, 1, E'C:\\dicion\\Dic.mdb', E'Configurações dos Dicionários', E'MDB', E'DIC', 13);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (6, 1, E'C:\\develop\\MidArc\\midarc.mdb', E'Cadastro', E'MDB', E'MIDARC', 14);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (6, 2, E'D:\\cddb\\FreeDB.mdb', E'FreeDb', E'MDB', E'FREEDB', 15);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (1, 10, E'{USRCAD}', E'Cadastros dos Usuarios', E'MDB', E'USRCAD', 16);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (13, 1, E'C:\\develop\\aplifolha\\tabfolsys.mdb', NULL, E'MDB', E'TABFOLSYS', 17);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (13, 2, E'C:\\develop\\aplifolha\\tabusrfol.mdb', NULL, E'MDB', E'TABUSRFOL', 18);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (4, 3, E'C:\\develop\\comex\\REPARAR.MDB', NULL, E'MDB', E'REPARAR', 19);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (5, 2, E'C:\\develop\\DICION\\reparar.mdb', NULL, E'MDB', E'REPARAR', 20);
INSERT INTO "BaseDados" ("NUMERO", "ITEM", "CAMINHO", "NOME", "TIPO", "COGNOME", "ID") VALUES (1, 11, E'{SYSRPT}', E'Configuraçao de Relatorios', E'MDB', E'SYSRPT', 21);
-- 21 records

SELECT setval('"BaseDados_ID_seq"', MAX("ID")) FROM "BaseDados";

CREATE INDEX "BaseDados_NUMERO" ON "BaseDados" ("NUMERO");

--
-- Table structure for table 'Caracter'
--

DROP TABLE IF EXISTS "Caracter";

CREATE TABLE "Caracter" (
  "NUMERO" INTEGER, 
  "ITEM" INTEGER, 
  "DATA" TIMESTAMP, 
  "TIPO" VARCHAR(10), 
  "temp" VARCHAR(50), 
  "DIZER" VARCHAR(50), 
  "ID" SERIAL
);

--
-- Dumping data for table 'Caracter'
--

INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 1, '2003-12-12 12:48:02', E'CAD', E'Clientes', E'Clientes', 1);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 2, '2003-12-12 13:52:25', E'CAD', E'Bancos', E'Bancos', 2);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 3, '2003-12-12 13:52:54', E'CAD', E'Bancos - Agencias', E'Bancos - Agencias', 3);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 4, '2003-12-12 13:53:40', E'CAD', E'Bancos - contas correntes', E'Bancos - contas correntes', 4);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 5, '2003-12-12 13:54:15', E'CAD', E'Bancos - Praças', E'Bancos - Praças', 5);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 6, '2003-12-12 13:55:13', E'CAD', E'cheques Recebidos/Emitidos', E'cheques Recebidos/Emitidos', 6);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 7, '2003-12-12 13:56:03', E'TAB', E'Codigos Devolução Cheques', E'Codigos Devolução Cheques', 7);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 8, '2003-12-12 13:57:38', E'TAB', E'Regioes', E'Regioes', 8);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 9, '2003-12-12 13:57:54', E'TAB', E'Estados', E'Estados', 9);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 10, '2003-12-12 13:58:15', E'TAB', E'Cidades', E'Cidades', 10);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 11, '2003-12-12 13:58:54', E'TAB', E'Paises', E'Paises', 11);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 12, '2003-12-12 13:59:27', E'TAB', E'Moedas', E'Moedas', 12);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 13, '2003-12-12 13:59:53', E'UTIL', E'Visualizar Imagens', E'Visualizar Imagens', 13);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (2, 1, '2003-12-12 14:03:34', E'SIS', E'Reparaçao Base Dados', E'Reparaçao Base Dados', 14);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (2, 2, '2003-12-12 14:04:17', E'SIS', E'Documentaçao Base Dados', E'Documentaçao Base Dados', 15);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 14, '2003-12-12 14:06:24', E'TAB', E'CNAB - Carteiras', E'CNAB - Carteiras', 16);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 15, '2003-12-12 14:06:45', E'TAB', E'CNAB - Especies', E'CNAB - Especies', 17);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 16, '2003-12-12 14:07:12', E'TAB', E'CNAB - Ocorrencias', E'CNAB - Ocorrencias', 18);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 17, '2003-12-12 14:07:38', E'CAD', E'CNAB - Instruções', E'CNAB - Instruções', 19);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 18, '2003-12-12 14:10:21', E'CON', E'Usuários', E'Usuários', 20);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 19, '2003-12-12 14:10:59', E'CON', E'Menus', E'Menus', 21);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 20, '2003-12-12 14:11:10', E'CON', E'Formulários', E'Formulários', 22);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 21, '2003-12-12 14:11:22', E'CON', E'Icones', E'Icones', 23);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 22, '2003-12-12 14:11:36', E'SIS', E'Arquivos', E'Arquivos', 24);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 23, '2003-12-12 14:13:24', E'SISDOC', E'Documetação Sistema', E'Documetação Sistema', 25);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 24, '2003-12-12 14:13:40', E'SISDOC', E'Tipos Linguagens Programação', E'Tipos Linguagens Programação', 26);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 25, '2003-12-12 14:13:57', E'SISDOC', E'Base de Dados', E'Base de Dados', 27);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 26, '2003-12-12 14:14:55', E'SISDOC', E'Tipos de Campos Base de Dados', E'Tipos de Campos Base de Dados', 28);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 27, '2003-12-12 14:16:03', E'SISDOC', E'Tipos de Base de Dados', E'Tipos de Base de Dados', 29);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 28, '2003-12-12 14:29:15', E'SISDOC', E'Relatorios', E'Relatorios', 30);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 29, '2003-12-12 14:29:39', E'SISDOC', E'Caracteristicas', E'Caracteristicas', 31);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 30, '2003-12-12 17:35:12', E'UTIL', NULL, E'Editor de Textos', 32);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (4, 1, '2003-12-12 18:48:19', E'UTIL', NULL, E'Visualizador de Imagens', 33);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (4, 2, '2003-12-12 18:48:35', E'UTIL', NULL, E'Editor de Textos', 34);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (5, 1, '2003-12-12 18:49:13', E'UTIL', NULL, E'Visualizador de Imagens', 35);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (5, 2, '2003-12-12 18:49:40', E'UTIL', NULL, E'Editor de Textos', 36);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (6, 1, '2003-12-12 18:50:08', E'UTIL', NULL, E'Visualizador de Imagens', 37);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (6, 2, '2003-12-12 18:50:26', E'UTIL', NULL, E'Editor de Textos', 38);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 31, '2003-12-19 19:39:24', E'UTIL', NULL, E'Editor de Arquivos INI', 39);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (4, 3, '2003-12-19 19:48:37', E'UTIL', NULL, E'Editor de Arquivos INI', 40);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (6, 3, '2003-12-19 19:49:24', E'UTIL', NULL, E'Editor de Arquivos INI', 41);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (1, 32, '2003-12-27 13:20:14', E'REL', NULL, E'Gerenciador de Relatorios/Documentos', 42);
INSERT INTO "Caracter" ("NUMERO", "ITEM", "DATA", "TIPO", "temp", "DIZER", "ID") VALUES (13, 1, '2004-02-06 15:02:45', NULL, NULL, NULL, 43);
-- 43 records

SELECT setval('"Caracter_ID_seq"', MAX("ID")) FROM "Caracter";

CREATE INDEX "Caracter_NUMERO" ON "Caracter" ("NUMERO");

--
-- Table structure for table 'LINGUAGEM'
--

DROP TABLE IF EXISTS "LINGUAGEM";

CREATE TABLE "LINGUAGEM" (
  "CODIGO" VARCHAR(20), 
  "NOME" VARCHAR(50), 
  "ID" SERIAL
);

--
-- Dumping data for table 'LINGUAGEM'
--

INSERT INTO "LINGUAGEM" ("CODIGO", "NOME", "ID") VALUES (E'CLIPPER', E'CLIPPER', 1);
INSERT INTO "LINGUAGEM" ("CODIGO", "NOME", "ID") VALUES (E'VO', E'Visual Objects', 2);
INSERT INTO "LINGUAGEM" ("CODIGO", "NOME", "ID") VALUES (E'DELPHI', E'DELPHI', 3);
INSERT INTO "LINGUAGEM" ("CODIGO", "NOME", "ID") VALUES (E'VB', E'Visual Basic', 4);
-- 4 records

SELECT setval('"LINGUAGEM_ID_seq"', MAX("ID")) FROM "LINGUAGEM";

CREATE INDEX "LINGUAGEM_CODIGO" ON "LINGUAGEM" ("CODIGO");

--
-- Table structure for table 'MODASS'
--

DROP TABLE IF EXISTS "MODASS";

CREATE TABLE "MODASS" (
  "ID" SERIAL, 
  "MODULO" INTEGER, 
  "MODASS" INTEGER
);

--
-- Dumping data for table 'MODASS'
--

-- 0 records

SELECT setval('"MODASS_ID_seq"', MAX("ID")) FROM "MODASS";

--
-- Table structure for table 'Modulos'
--

DROP TABLE IF EXISTS "Modulos";

CREATE TABLE "Modulos" (
  "NUMERO" INTEGER, 
  "COGNOME" VARCHAR(20), 
  "EXECUTAVEL" VARCHAR(20), 
  "LINGUAGEM" VARCHAR(50), 
  "ARQINI" VARCHAR(250), 
  "nome" VARCHAR(120), 
  "ID" SERIAL
);

--
-- Dumping data for table 'Modulos'
--

INSERT INTO "Modulos" ("NUMERO", "COGNOME", "EXECUTAVEL", "LINGUAGEM", "ARQINI", "nome", "ID") VALUES (13, E'FOLHA', NULL, E'HARBOUR', E'folha.ini', E'FOLHA', 10);
INSERT INTO "Modulos" ("NUMERO", "COGNOME", "EXECUTAVEL", "LINGUAGEM", "ARQINI", "nome", "ID") VALUES (14, E'PONTO', NULL, E'HARBOUR', E'folha.ini', E'Ponto', 11);
INSERT INTO "Modulos" ("NUMERO", "COGNOME", "EXECUTAVEL", "LINGUAGEM", "ARQINI", "nome", "ID") VALUES (1, E'CONTROLE', E'controle.exe', E'VB', E'controle.ini', NULL, 23);
INSERT INTO "Modulos" ("NUMERO", "COGNOME", "EXECUTAVEL", "LINGUAGEM", "ARQINI", "nome", "ID") VALUES (2, E'WRPT', E'wrpt.exe', E'VB', E'wrpt.ini', NULL, 24);
INSERT INTO "Modulos" ("NUMERO", "COGNOME", "EXECUTAVEL", "LINGUAGEM", "ARQINI", "nome", "ID") VALUES (3, E'WRPTX', E'wrptx.exe', E'VB', E'wrpt.inii ->wrptf.ini wrptx.ini wrpti.ini', NULL, 25);
INSERT INTO "Modulos" ("NUMERO", "COGNOME", "EXECUTAVEL", "LINGUAGEM", "ARQINI", "nome", "ID") VALUES (4, E'IMAGENSJPG', E'imagens.exe', E'VB', E'imagens.ini', NULL, 26);
INSERT INTO "Modulos" ("NUMERO", "COGNOME", "EXECUTAVEL", "LINGUAGEM", "ARQINI", "nome", "ID") VALUES (5, E'IMAGENSCPF', E'imgmpcpf.exe', E'VB', E'imagens.ini', NULL, 27);
-- 7 records

SELECT setval('"Modulos_ID_seq"', MAX("ID")) FROM "Modulos";

CREATE INDEX "Modulos_NUMERO" ON "Modulos" ("NUMERO");

--
-- Table structure for table 'Relatorios'
--

DROP TABLE IF EXISTS "Relatorios";

CREATE TABLE "Relatorios" (
  "NUMERO" INTEGER, 
  "ITEM" INTEGER, 
  "CAMINHO" VARCHAR(200), 
  "NOME" VARCHAR(50), 
  "ID" SERIAL
);

--
-- Dumping data for table 'Relatorios'
--

-- 0 records

SELECT setval('"Relatorios_ID_seq"', MAX("ID")) FROM "Relatorios";

CREATE INDEX "Relatorios_NUMERO" ON "Relatorios" ("NUMERO");

--
-- Table structure for table 'TipoCampos'
--

DROP TABLE IF EXISTS "TipoCampos";

CREATE TABLE "TipoCampos" (
  "CODIGO" VARCHAR(20), 
  "NOME" VARCHAR(50), 
  "ID" SERIAL
);

--
-- Dumping data for table 'TipoCampos'
--

INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'N', E'Numerico', 1);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'D', E'Data', 2);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'C', E'Caracter', 3);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'M', E'Memo', 4);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'L', E'Logico(Boolean)', 5);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'BOOLEAN', E'Boolean(Logico)', 6);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'INTEGER', E'Integer', 7);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'LONG', E'Long', 8);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'SINGLE', E'Single Precision', 9);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'DOUBLE', E'Doble Precision', 10);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'MEMO', E'MEMO', 11);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'BYTE', E'Byte', 12);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'CURRENCY', E'Currency(Number)', 13);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'TEXT', E'Texto', 14);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'BINARY', E'Binary', 15);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'DATE/TIME', E'Data Hora', 16);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'REAL', E'REAL(SINGLE)', 17);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'SMALLINT', E'Small Integer', 18);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'VARCHAR', E'Texto Variavel', 19);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'COUNTER', E'Integer (Auto Increment)', 20);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'CHAR', E'Texto Fixo', 21);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'LONGCHAR', E'LongChar (Memo)', 22);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'VARBINARY', E'Binary Variavel', 23);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'CUID', E'Binary', 24);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'LONGBINARY', E'LongBinary (Image)', 25);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'TINYINT', E'TinyInt (Byte)', 26);
INSERT INTO "TipoCampos" ("CODIGO", "NOME", "ID") VALUES (E'BIT', E'BIT', 27);
-- 27 records

SELECT setval('"TipoCampos_ID_seq"', MAX("ID")) FROM "TipoCampos";

CREATE INDEX "TipoCampos_CODIGO" ON "TipoCampos" ("CODIGO");

--
-- Table structure for table 'TipoDados'
--

DROP TABLE IF EXISTS "TipoDados";

CREATE TABLE "TipoDados" (
  "CODIGO" VARCHAR(20), 
  "NOME" VARCHAR(50), 
  "ID" SERIAL
);

--
-- Dumping data for table 'TipoDados'
--

INSERT INTO "TipoDados" ("CODIGO", "NOME", "ID") VALUES (E'DBFNTX', E'Clipper DBF/DBT Indices NTX', 1);
INSERT INTO "TipoDados" ("CODIGO", "NOME", "ID") VALUES (E'DBFCDX', E'Foxpro DBF/FPT Indices CDX', 2);
INSERT INTO "TipoDados" ("CODIGO", "NOME", "ID") VALUES (E'MDB', E'Access MDB', 3);
INSERT INTO "TipoDados" ("CODIGO", "NOME", "ID") VALUES (E'MYSQL', E'MySql', 4);
INSERT INTO "TipoDados" ("CODIGO", "NOME", "ID") VALUES (E'SQL2K', E'MS Sql Server 2000', 5);
INSERT INTO "TipoDados" ("CODIGO", "NOME", "ID") VALUES (E'SQL97', E'MS SQL Server 97', 6);
INSERT INTO "TipoDados" ("CODIGO", "NOME", "ID") VALUES (E'PARADOX', E'Paradox', 7);
-- 7 records

SELECT setval('"TipoDados_ID_seq"', MAX("ID")) FROM "TipoDados";

CREATE INDEX "TipoDados_CODIGO" ON "TipoDados" ("CODIGO");

--
-- Table structure for table 'TiposArq'
--

DROP TABLE IF EXISTS "TiposArq";

CREATE TABLE "TiposArq" (
  "CODIGO" VARCHAR(8), 
  "NOME" VARCHAR(100), 
  "ID" SERIAL
);

--
-- Dumping data for table 'TiposArq'
--

INSERT INTO "TiposArq" ("CODIGO", "NOME", "ID") VALUES (E'INI', E'Configuraçao de Inicializacao', 1);
INSERT INTO "TiposArq" ("CODIGO", "NOME", "ID") VALUES (E'MDB', E'Base de Dados Access', 2);
INSERT INTO "TiposArq" ("CODIGO", "NOME", "ID") VALUES (E'DBF', E'Tabelas Base Dados DBASE/FOXPRO', 3);
INSERT INTO "TiposArq" ("CODIGO", "NOME", "ID") VALUES (E'RTF', E'Rith Text Formato (Textos)', 4);
INSERT INTO "TiposArq" ("CODIGO", "NOME", "ID") VALUES (E'TXT', E'Arquivos de Textos', 5);
INSERT INTO "TiposArq" ("CODIGO", "NOME", "ID") VALUES (E'CDX', E'Arquivos de Indices FOXPRO', 6);
INSERT INTO "TiposArq" ("CODIGO", "NOME", "ID") VALUES (E'NTX', E'Arquivos de Indices Clipper', 7);
INSERT INTO "TiposArq" ("CODIGO", "NOME", "ID") VALUES (E'MAN', E'Manuais Sistema Dos', 8);
-- 8 records

SELECT setval('"TiposArq_ID_seq"', MAX("ID")) FROM "TiposArq";

CREATE INDEX "TiposArq_CODIGO" ON "TiposArq" ("CODIGO");

--
-- Table structure for table 'TiposCarac'
--

DROP TABLE IF EXISTS "TiposCarac";

CREATE TABLE "TiposCarac" (
  "CODIGO" VARCHAR(20), 
  "NOME" VARCHAR(50), 
  "ID" SERIAL
);

--
-- Dumping data for table 'TiposCarac'
--

INSERT INTO "TiposCarac" ("CODIGO", "NOME", "ID") VALUES (E'UTIL', E'Utilitarios', 1);
INSERT INTO "TiposCarac" ("CODIGO", "NOME", "ID") VALUES (E'CAD', E'Cadastros', 2);
INSERT INTO "TiposCarac" ("CODIGO", "NOME", "ID") VALUES (E'TAB', E'Tabelas', 3);
INSERT INTO "TiposCarac" ("CODIGO", "NOME", "ID") VALUES (E'DOC', E'Documentaçao', 4);
INSERT INTO "TiposCarac" ("CODIGO", "NOME", "ID") VALUES (E'INT', E'Integraçao', 5);
INSERT INTO "TiposCarac" ("CODIGO", "NOME", "ID") VALUES (E'SIS', E'Sistema', 6);
INSERT INTO "TiposCarac" ("CODIGO", "NOME", "ID") VALUES (E'CON', E'Configuração', 7);
INSERT INTO "TiposCarac" ("CODIGO", "NOME", "ID") VALUES (E'SISDOC', E'Documentaçao do Sistema', 8);
INSERT INTO "TiposCarac" ("CODIGO", "NOME", "ID") VALUES (E'REL', E'Relatorios/Documentação', 9);
INSERT INTO "TiposCarac" ("CODIGO", "NOME", "ID") VALUES (E'IMP', E'Importaçao', 10);
-- 10 records

SELECT setval('"TiposCarac_ID_seq"', MAX("ID")) FROM "TiposCarac";

CREATE INDEX "TiposCarac_CODIGO" ON "TiposCarac" ("CODIGO");

