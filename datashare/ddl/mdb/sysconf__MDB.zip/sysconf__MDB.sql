-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: ORIGEM (MDB)
-- Gerado em: 17/05/2026 09:29:29
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: Botoes
-- --------------------------------------------------
CREATE TABLE [Botoes] ([Indice] SHORT, [Icone] SHORT, [Nome] TEXT(50), [ToolTip] TEXT(50), [form] LONG, [DISPONIVEL] BIT, [INATIVO] BIT, [reqdir] BIT, [ID] LONG);
CREATE INDEX [FormIndice] ON [Botoes] ([form], [Indice]);

-- --------------------------------------------------
-- Estrutura da Tabela: Forms
-- --------------------------------------------------
CREATE TABLE [Forms] ([Form] LONG, [NomePrg] TEXT(50), [Inativo] BIT, [DISPONIVEL] BIT, [modulo] LONG, [reqdir] BIT, [nome] TEXT(120), [ID] LONG);
CREATE INDEX [Form] ON [Forms] ([Form]);

-- --------------------------------------------------
-- Estrutura da Tabela: icones
-- --------------------------------------------------
CREATE TABLE [icones] ([Indice] SHORT, [Nome] TEXT(50), [Arquivo] TEXT(50), [ID] LONG);
CREATE INDEX [Indice] ON [icones] ([Indice]);

-- --------------------------------------------------
-- Estrutura da Tabela: Menus
-- --------------------------------------------------
CREATE TABLE [Menus] ([Menu] TEXT(10), [INDICE] LONG, [Dizer] TEXT(50), [Form] LONG, [modulo] LONG, [ID] LONG);
CREATE INDEX [MenuIndice] ON [Menus] ([Menu], [INDICE]);

-- --------------------------------------------------
-- Estrutura da Tabela: RPTEXEC
-- --------------------------------------------------
CREATE TABLE [RPTEXEC] ([NOME] TEXT(100), [EXECUTAR] TEXT(255), [NUMERO] LONG, [EXTENSAO] TEXT(8), [OBS] MEMO, [ID] LONG);
CREATE INDEX [EXTENSAO] ON [RPTEXEC] ([EXTENSAO]);
CREATE INDEX [NUMERO] ON [RPTEXEC] ([NUMERO]);

-- --------------------------------------------------
-- Estrutura da Tabela: tiposarq
-- --------------------------------------------------
CREATE TABLE [tiposarq] ([CODIGO] TEXT(8), [NOME] TEXT(100), [id] LONG);
CREATE INDEX [CODIGO] ON [tiposarq] ([CODIGO]);

-- Fim do Script de ORIGEM (MDB)
