-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: ORIGEM (MDB)
-- Gerado em: 17/05/2026 09:29:30
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: RPT
-- --------------------------------------------------
CREATE TABLE [RPT] ([RPT] TEXT(8), [COGNOME] TEXT(100), [NOME] TEXT(100), [ARVORE] BIT, [BUSCA] BIT, [ARQUIVO] TEXT(100), [DATAIMP] DATETIME, [UTILIZADO] LONG, [DATACRI] DATETIME, [SUBGRP] TEXT(4), [CAMINHO] TEXT(200), [MENSAGEM] MEMO, [CAMINH2] TEXT(200), [CAMINH3] TEXT(200), [CAMINH4] TEXT(200), [CARQUSO] TEXT(8), [CARQBAI] TEXT(8), [CARQFEC] TEXT(2), [CARQACU] TEXT(8), [COBSMSG] TEXT(50), [LFILTRO] BIT, [TABALIAS] TEXT(8), [TABNAME] TEXT(8), [PREFILTRO] TEXT(255), [CODIGO] TEXT(8), [GRP] TEXT(8), [TITULO] TEXT(255), [ABRIRCOM] TEXT(50), [ID] LONG, [SQLUSO] MEMO);
CREATE INDEX [CODIGO] ON [RPT] ([CODIGO]);
CREATE INDEX [GRP] ON [RPT] ([GRP]);
CREATE INDEX [RPT] ON [RPT] ([RPT]);

-- --------------------------------------------------
-- Estrutura da Tabela: RPTGRP
-- --------------------------------------------------
CREATE TABLE [RPTGRP] ([NOME] TEXT(50), [CODIGO] TEXT(8), [CAMINHO] TEXT(255), [GRP] TEXT(8), [ID] LONG, [LIBERAR] BIT);
CREATE INDEX [CODIGO] ON [RPTGRP] ([CODIGO]);
CREATE INDEX [GRP] ON [RPTGRP] ([GRP]);

-- --------------------------------------------------
-- Estrutura da Tabela: RPTMAIN
-- --------------------------------------------------
CREATE TABLE [RPTMAIN] ([NOME] TEXT(50), [CODIGO] TEXT(8), [CAMINHO] TEXT(255), [ID] LONG, [DISPONIVEL] BIT);

-- Fim do Script de ORIGEM (MDB)
