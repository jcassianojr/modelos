-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: ORIGEM (MDB)
-- Gerado em: 17/05/2026 09:29:28
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: REPARAR
-- --------------------------------------------------
CREATE TABLE [REPARAR] ([ARQUIVO] TEXT(50), [CAMINHO] TEXT(250), [DIZER] TEXT(150));
CREATE INDEX [ARQUIVO] ON [REPARAR] ([ARQUIVO]);

-- Fim do Script de ORIGEM (MDB)
