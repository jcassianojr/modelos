-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: ORIGEM (MDB)
-- Gerado em: 17/05/2026 09:29:29
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: Alteracao
-- --------------------------------------------------
CREATE TABLE [Alteracao] ([NUMERO] LONG, [ITEM] LONG, [DIZER] MEMO, [DATA] DATETIME, [ID] LONG);
CREATE INDEX [NUMERO] ON [Alteracao] ([NUMERO]);

-- --------------------------------------------------
-- Estrutura da Tabela: BaseDados
-- --------------------------------------------------
CREATE TABLE [BaseDados] ([NUMERO] LONG, [ITEM] LONG, [CAMINHO] TEXT(200), [NOME] TEXT(50), [TIPO] TEXT(20), [COGNOME] TEXT(20), [ID] LONG);
CREATE INDEX [NUMERO] ON [BaseDados] ([NUMERO]);

-- --------------------------------------------------
-- Estrutura da Tabela: Caracter
-- --------------------------------------------------
CREATE TABLE [Caracter] ([NUMERO] LONG, [ITEM] LONG, [DATA] DATETIME, [TIPO] TEXT(10), [temp] TEXT(50), [DIZER] TEXT(50), [ID] LONG);
CREATE INDEX [NUMERO] ON [Caracter] ([NUMERO]);

-- --------------------------------------------------
-- Estrutura da Tabela: LINGUAGEM
-- --------------------------------------------------
CREATE TABLE [LINGUAGEM] ([CODIGO] TEXT(20), [NOME] TEXT(50), [ID] LONG);
CREATE INDEX [CODIGO] ON [LINGUAGEM] ([CODIGO]);

-- --------------------------------------------------
-- Estrutura da Tabela: MODASS
-- --------------------------------------------------
CREATE TABLE [MODASS] ([ID] LONG, [MODULO] LONG, [MODASS] LONG);

-- --------------------------------------------------
-- Estrutura da Tabela: Modulos
-- --------------------------------------------------
CREATE TABLE [Modulos] ([NUMERO] LONG, [COGNOME] TEXT(20), [EXECUTAVEL] TEXT(20), [LINGUAGEM] TEXT(50), [ARQINI] TEXT(250), [nome] TEXT(120), [ID] LONG);
CREATE INDEX [NUMERO] ON [Modulos] ([NUMERO]);

-- --------------------------------------------------
-- Estrutura da Tabela: Relatorios
-- --------------------------------------------------
CREATE TABLE [Relatorios] ([NUMERO] LONG, [ITEM] LONG, [CAMINHO] TEXT(200), [NOME] TEXT(50), [ID] LONG);
CREATE INDEX [NUMERO] ON [Relatorios] ([NUMERO]);

-- --------------------------------------------------
-- Estrutura da Tabela: TipoCampos
-- --------------------------------------------------
CREATE TABLE [TipoCampos] ([CODIGO] TEXT(20), [NOME] TEXT(50), [ID] LONG);
CREATE INDEX [CODIGO] ON [TipoCampos] ([CODIGO]);

-- --------------------------------------------------
-- Estrutura da Tabela: TipoDados
-- --------------------------------------------------
CREATE TABLE [TipoDados] ([CODIGO] TEXT(20), [NOME] TEXT(50), [ID] LONG);
CREATE INDEX [CODIGO] ON [TipoDados] ([CODIGO]);

-- --------------------------------------------------
-- Estrutura da Tabela: TiposArq
-- --------------------------------------------------
CREATE TABLE [TiposArq] ([CODIGO] TEXT(8), [NOME] TEXT(100), [ID] LONG);
CREATE INDEX [CODIGO] ON [TiposArq] ([CODIGO]);

-- --------------------------------------------------
-- Estrutura da Tabela: TiposCarac
-- --------------------------------------------------
CREATE TABLE [TiposCarac] ([CODIGO] TEXT(20), [NOME] TEXT(50), [ID] LONG);
CREATE INDEX [CODIGO] ON [TiposCarac] ([CODIGO]);

-- Fim do Script de ORIGEM (MDB)
