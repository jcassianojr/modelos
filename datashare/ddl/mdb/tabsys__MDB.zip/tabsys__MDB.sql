-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: ORIGEM (MDB)
-- Gerado em: 17/05/2026 09:29:31
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: CODDEVCHEQUE
-- --------------------------------------------------
CREATE TABLE [CODDEVCHEQUE] ([ID] LONG, [CODIGO] TEXT(2), [NOME] TEXT(255));
CREATE INDEX [ID] ON [CODDEVCHEQUE] ([ID]);
ALTER TABLE [CODDEVCHEQUE] ADD CONSTRAINT [PrimaryKey] PRIMARY KEY ([ID]);

-- --------------------------------------------------
-- Estrutura da Tabela: MDCOBBCO
-- --------------------------------------------------
CREATE TABLE [MDCOBBCO] ([ID] LONG, [CODIGO] TEXT(2), [NOME] TEXT(40));
CREATE INDEX [ID] ON [MDCOBBCO] ([ID]);
ALTER TABLE [MDCOBBCO] ADD CONSTRAINT [PrimaryKey] PRIMARY KEY ([ID]);

-- --------------------------------------------------
-- Estrutura da Tabela: MDCOBCAR
-- --------------------------------------------------
CREATE TABLE [MDCOBCAR] ([ID] LONG, [CODCART] TEXT(1), [MOEDA] TEXT(4), [COD2] TEXT(1), [COD1] TEXT(1), [COD3] TEXT(1), [CODIGO] TEXT(3), [DESCRICAO] TEXT(40));
CREATE INDEX [ID] ON [MDCOBCAR] ([ID]);

-- --------------------------------------------------
-- Estrutura da Tabela: MDCOBESP
-- --------------------------------------------------
CREATE TABLE [MDCOBESP] ([ID] LONG, [CODIGO] TEXT(2), [NOME] TEXT(20));
CREATE INDEX [ID] ON [MDCOBESP] ([ID]);
ALTER TABLE [MDCOBESP] ADD CONSTRAINT [PrimaryKey] PRIMARY KEY ([ID]);

-- --------------------------------------------------
-- Estrutura da Tabela: MDCOBINS
-- --------------------------------------------------
CREATE TABLE [MDCOBINS] ([ID] LONG, [CODIGO] TEXT(2), [NOME] TEXT(47));
CREATE INDEX [ID] ON [MDCOBINS] ([ID]);
ALTER TABLE [MDCOBINS] ADD CONSTRAINT [PrimaryKey] PRIMARY KEY ([ID]);

-- --------------------------------------------------
-- Estrutura da Tabela: MDCOBOCO
-- --------------------------------------------------
CREATE TABLE [MDCOBOCO] ([ID] LONG, [CODIGO] TEXT(2), [NOME] TEXT(40));
CREATE INDEX [ID] ON [MDCOBOCO] ([ID]);
ALTER TABLE [MDCOBOCO] ADD CONSTRAINT [PrimaryKey] PRIMARY KEY ([ID]);

-- --------------------------------------------------
-- Estrutura da Tabela: MOEDAS
-- --------------------------------------------------
CREATE TABLE [MOEDAS] ([CODIGO] DOUBLE, [NOME] TEXT(17), [SIMBOLO] TEXT(7), [BACEN] DOUBLE, [PAIS] TEXT(25), [TIPO] TEXT(1), [DATA_EXCLU] TEXT(8));

-- --------------------------------------------------
-- Estrutura da Tabela: PBACEN
-- --------------------------------------------------
CREATE TABLE [PBACEN] ([ID] LONG, [CODIGO] TEXT(1), [NOME] TEXT(50));
CREATE INDEX [ID] ON [PBACEN] ([ID]);
ALTER TABLE [PBACEN] ADD CONSTRAINT [PrimaryKey] PRIMARY KEY ([ID]);

-- Fim do Script de ORIGEM (MDB)
