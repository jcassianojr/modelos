CREATE TABLE tblAutor (
	codAutor COUNTER NOT NULL,
	codOcupacao LONG DEFAULT 0,
	Nacionalidade TEXT (20),
	Nome TEXT (80),
	Obs TEXT (80)
);

ALTER TABLE tblAutor
  ADD PRIMARY KEY (codAutor);

CREATE TABLE tblCitacao (
	Citacao MEMO,
	codAutor LONG DEFAULT 0,
	codCitacao COUNTER NOT NULL,
	Fonte TEXT (120),
	ocultar YESNO NOT NULL,
	Titulo TEXT (50)
);

ALTER TABLE tblCitacao
  ADD PRIMARY KEY (codCitacao);

CREATE TABLE tblOcupacao (
	codOcupacao COUNTER NOT NULL,
	Nome TEXT (50)
);

ALTER TABLE tblOcupacao
  ADD PRIMARY KEY (codOcupacao);

