--
-- Arquivo gerado com SQLiteStudio v3.4.4 em sex ago 2 19:51:52 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: aut
CREATE TABLE IF NOT EXISTS [aut] ([aut] REAL NOT NULL, [usada] BIT NOT NULL, [user] REAL NOT NULL, [motivo] TEXT(150) NOT NULL, [motiv2] TEXT(150) NOT NULL, [carta] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [databx] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [datacr] SHORTDATE NOT NULL, [fisobs01] TEXT(80) NOT NULL, [fisobs02] TEXT(80) NOT NULL, [fisobs03] TEXT(80) NOT NULL, [libpor] TEXT(15) NOT NULL, [libfiscal] TEXT(1) NOT NULL);

-- Tabela: crgec
CREATE TABLE IF NOT EXISTS [crgec] ([crgex] REAL NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(20) NOT NULL, [nota] TEXT(50) NOT NULL, [pesonf] REAL NOT NULL, [pesoec] REAL NOT NULL, [pesolq] REAL NOT NULL, [percex] REAL NOT NULL);

-- Tabela: crgex
CREATE TABLE IF NOT EXISTS [crgex] ([crgex] REAL NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(20) NOT NULL, [nota] TEXT(50) NOT NULL, [pesonf] REAL NOT NULL, [pesoec] REAL NOT NULL, [pesolq] REAL NOT NULL, [percex] REAL NOT NULL);

-- Tabela: crm
CREATE TABLE IF NOT EXISTS [crm] ([crm] REAL NOT NULL, [tipcad] TEXT(1) NOT NULL, [clifor] REAL NOT NULL, [cognome] TEXT(15) NOT NULL, [data] SHORTDATE NOT NULL, [tipoe] TEXT(1) NOT NULL, [descri] TEXT(40) NOT NULL, [pedido] TEXT(20) NOT NULL, [nrnota] REAL NOT NULL, [nrnotb] REAL NOT NULL, [qtde] REAL NOT NULL, [qtdea] REAL NOT NULL, [qtdeb] REAL NOT NULL, [nivel] TEXT(10) NOT NULL, [insp] TEXT(1) NOT NULL, [laudo] TEXT(1) NOT NULL, [tecnico] REAL NOT NULL, [obs] TEXT(100) NOT NULL, [cbusca] TEXT(24) NOT NULL, [nomef] TEXT(40) NOT NULL, [unid] TEXT(4) NOT NULL, [rist] REAL NOT NULL, [rirm] REAL NOT NULL, [aplicacao] TEXT(30) NOT NULL, [produto] TEXT(24) NOT NULL, [valor] REAL NOT NULL, [gravou] TEXT(1) NOT NULL, [gravouy] TEXT(1) NOT NULL, [programa] REAL NOT NULL, [gravaup] TEXT(1) NOT NULL, [prped] REAL NOT NULL, [prite] REAL NOT NULL, [prcli] REAL NOT NULL, [peped] REAL NOT NULL, [peite] REAL NOT NULL, [cert] TEXT(40) NOT NULL, [pereq] REAL NOT NULL, [aut] REAL NOT NULL, [usernm] TEXT(10) NOT NULL, [userdt] SHORTDATE NOT NULL, [userht] TEXT(8) NOT NULL, [nrdata] SHORTDATE NOT NULL, [rastro] TEXT(12) NOT NULL, [preco] REAL NOT NULL, [precopr] REAL NOT NULL, [preconf] REAL NOT NULL, [clotecrt] TEXT(1) NOT NULL, [precook] TEXT(1) NOT NULL, [qtdeped] REAL NOT NULL, [pesonfa] REAL NOT NULL, [pesonfb] REAL NOT NULL, [pedcli] TEXT(1) NOT NULL, [entrega] SHORTDATE NOT NULL, [entreg2] SHORTDATE NOT NULL, [triangular] TEXT(1) NOT NULL);

-- Tabela: crm3l
CREATE TABLE IF NOT EXISTS [crm3l] ([codigo] TEXT(24) NOT NULL, [nvezes] REAL NOT NULL, [racf] REAL NOT NULL, [desc01] TEXT(90) NOT NULL, [desc02] TEXT(90) NOT NULL, [desc03] TEXT(90) NOT NULL, [desc04] TEXT(90) NOT NULL, [desc05] TEXT(90) NOT NULL);

-- Tabela: crma
CREATE TABLE IF NOT EXISTS [crma] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tipoent] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [fornecedo] REAL NOT NULL, [cogfor] TEXT(15) NOT NULL, [nf] REAL NOT NULL, [produto] TEXT(24) NOT NULL, [cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [rastroa] TEXT(12) NOT NULL, [rastrook] TEXT(12) NOT NULL, [dataok] SHORTDATE NOT NULL, [motivo] TEXT(3) NOT NULL, [crm] REAL NOT NULL);

-- Tabela: crmar
CREATE TABLE IF NOT EXISTS [crmar] ([tipoent] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(100) NOT NULL, [nrnota] REAL NOT NULL, [data] SHORTDATE NOT NULL, [qtde] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [crm] REAL NOT NULL, [ar] REAL NOT NULL, [item] REAL NOT NULL, [rirm] REAL NOT NULL, [rist] REAL NOT NULL, [codforn] TEXT(18) NOT NULL, [empresa] TEXT(2) NOT NULL, [codigoint] TEXT(24) NOT NULL, [mc] REAL NOT NULL);

-- Tabela: crmcesp
CREATE TABLE IF NOT EXISTS [crmcesp] ([numero] REAL NOT NULL, [nome] TEXT(100) NOT NULL, [tipoent] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL);

-- Tabela: crmdev
CREATE TABLE IF NOT EXISTS [crmdev] ([crm] REAL NOT NULL, [tipcad] TEXT(1) NOT NULL, [clifor] REAL NOT NULL, [cognome] TEXT(15) NOT NULL, [data] SHORTDATE NOT NULL, [tipoe] TEXT(1) NOT NULL, [descri] TEXT(40) NOT NULL, [pedido] TEXT(20) NOT NULL, [nrnota] REAL NOT NULL, [nrnotb] REAL NOT NULL, [qtde] REAL NOT NULL, [qtdea] REAL NOT NULL, [qtdeb] REAL NOT NULL, [nivel] TEXT(10) NOT NULL, [insp] TEXT(1) NOT NULL, [laudo] TEXT(1) NOT NULL, [tecnico] REAL NOT NULL, [obs] TEXT(100) NOT NULL, [cbusca] TEXT(24) NOT NULL, [nomef] TEXT(40) NOT NULL, [unid] TEXT(4) NOT NULL, [rist] REAL NOT NULL, [rirm] REAL NOT NULL, [aplicacao] TEXT(30) NOT NULL, [produto] TEXT(24) NOT NULL, [valor] REAL NOT NULL, [gravou] TEXT(1) NOT NULL, [gravouy] TEXT(1) NOT NULL, [programa] REAL NOT NULL, [gravaup] TEXT(1) NOT NULL, [prped] REAL NOT NULL, [prite] REAL NOT NULL, [prcli] REAL NOT NULL, [peped] REAL NOT NULL, [peite] REAL NOT NULL, [cert] TEXT(40) NOT NULL, [pereq] REAL NOT NULL, [aut] REAL NOT NULL, [usernm] TEXT(10) NOT NULL, [userdt] SHORTDATE NOT NULL, [userht] TEXT(8) NOT NULL, [nrdata] SHORTDATE NOT NULL, [rastro] TEXT(12) NOT NULL, [preco] REAL NOT NULL, [precopr] REAL NOT NULL, [preconf] REAL NOT NULL, [clotecrt] TEXT(1) NOT NULL, [precook] TEXT(1) NOT NULL, [qtdeped] REAL NOT NULL, [pesonfa] REAL NOT NULL, [pesonfb] REAL NOT NULL, [pedcli] TEXT(1) NOT NULL, [entrega] SHORTDATE NOT NULL, [entreg2] SHORTDATE NOT NULL, [triangular] TEXT(1) NOT NULL);

-- Tabela: crme01
CREATE TABLE IF NOT EXISTS [crme01] ([rastro] TEXT(10) NOT NULL, [data] SHORTDATE NOT NULL);

-- Tabela: crme02
CREATE TABLE IF NOT EXISTS [crme02] ([rastro] TEXT(12) NOT NULL, [data] SHORTDATE NOT NULL, [nome] TEXT(30) NOT NULL, [nom2] TEXT(35) NOT NULL, [nom3] TEXT(35) NOT NULL, [aplicacao] TEXT(50) NOT NULL, [fornecedor] REAL NOT NULL, [respo] TEXT(40) NOT NULL, [nrnota] REAL NOT NULL, [nrnotb] REAL NOT NULL, [pesonfa] REAL NOT NULL, [pesonfb] REAL NOT NULL, [qtdea] REAL NOT NULL, [qtdeb] REAL NOT NULL, [pos] TEXT(11) NOT NULL, [codigo] TEXT(24) NOT NULL, [cert] TEXT(50) NOT NULL);

-- Tabela: crme03
CREATE TABLE IF NOT EXISTS [crme03] ([espe] TEXT(80) NOT NULL, [usuario] TEXT(10) NOT NULL, [setor] TEXT(30) NOT NULL, [data] SHORTDATE NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [ncli] REAL NOT NULL, [cliente] TEXT(30) NOT NULL, [rastro] TEXT(12) NOT NULL, [qtamo] REAL NOT NULL, [refnum] REAL NOT NULL, [cert] TEXT(50) NOT NULL);

-- Tabela: crmebx
CREATE TABLE IF NOT EXISTS [crmebx] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [serie] TEXT(3) NOT NULL, [datafat] SHORTDATE NOT NULL, [osini] REAL NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pesoref] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [preco] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [obs] TEXT(30) NOT NULL, [rastro] TEXT(12) NOT NULL, [difsaldo] REAL NOT NULL, [local] TEXT(7) NOT NULL, [qtdeemb] REAL NOT NULL);

-- Tabela: crmens
CREATE TABLE IF NOT EXISTS [crmens] ([codigo] TEXT(10) NOT NULL, [nome] TEXT(40) NOT NULL, [valor] REAL NOT NULL);

-- Tabela: crmest
CREATE TABLE IF NOT EXISTS [crmest] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [serie] TEXT(3) NOT NULL, [datafat] SHORTDATE NOT NULL, [osini] REAL NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pesoref] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [preco] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [obs] TEXT(30) NOT NULL, [rastro] TEXT(12) NOT NULL, [difsaldo] REAL NOT NULL, [local] TEXT(7) NOT NULL, [qtdeemb] REAL NOT NULL);

-- Tabela: crmfn
CREATE TABLE IF NOT EXISTS [crmfn] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [rastro] TEXT(12) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [codigo] TEXT(24) NOT NULL, [cliente] REAL NOT NULL, [pesouni] REAL NOT NULL, [codmr01] TEXT(10) NOT NULL, [nommr01] TEXT(30) NOT NULL, [pcemb] REAL NOT NULL, [pcembq] REAL NOT NULL, [qtdekg] REAL NOT NULL, [qtdepc] REAL NOT NULL);

-- Tabela: crmgp12
CREATE TABLE IF NOT EXISTS [crmgp12] ([codigo] TEXT(24) NOT NULL);

-- Tabela: crml
CREATE TABLE IF NOT EXISTS [crml] ([clifor] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [lote] REAL NOT NULL);

-- Tabela: crmmot
CREATE TABLE IF NOT EXISTS [crmmot] ([codigo] TEXT(2) NOT NULL, [dizer] TEXT(50) NOT NULL);

-- Tabela: crmnf
CREATE TABLE IF NOT EXISTS [crmnf] ([fornecedo] REAL NOT NULL, [nrnota] REAL NOT NULL, [data] SHORTDATE NOT NULL);

-- Tabela: crmr
CREATE TABLE IF NOT EXISTS [crmr] ([rastro] TEXT(10) NOT NULL, [rastron] REAL NOT NULL, [rastroa] REAL NOT NULL, [crm] REAL NOT NULL, [rirm] REAL NOT NULL, [rist] REAL NOT NULL, [dataf] SHORTDATE NOT NULL, [obs] TEXT(100) NOT NULL, [data] SHORTDATE NOT NULL, [produto] TEXT(50) NOT NULL);

-- Tabela: crmss
CREATE TABLE IF NOT EXISTS [crmss] ([numero] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [codigoint] TEXT(24) NOT NULL, [norma] TEXT(14) NOT NULL, [aplicacao] TEXT(30) NOT NULL, [fornecedo] REAL NOT NULL, [fornome] TEXT(40) NOT NULL, [espe] TEXT(60) NOT NULL, [rastro] TEXT(12) NOT NULL, [data] SHORTDATE NOT NULL, [rist] REAL NOT NULL, [ar] REAL NOT NULL, [item] REAL NOT NULL, [dataenv] SHORTDATE NOT NULL, [horaenv] TEXT(5) NOT NULL);

-- Tabela: mp01i
CREATE TABLE IF NOT EXISTS [mp01i] ([codigo] TEXT(12) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL);

-- Tabela: mp01r
CREATE TABLE IF NOT EXISTS [mp01r] ([codigo] TEXT(12) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL, [checado] TEXT(1) NOT NULL);

-- Tabela: mp02i
CREATE TABLE IF NOT EXISTS [mp02i] ([codigo] TEXT(12) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL);

-- Tabela: mp02r
CREATE TABLE IF NOT EXISTS [mp02r] ([codigo] TEXT(12) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL, [checado] TEXT(1) NOT NULL);

-- Tabela: mp03i
CREATE TABLE IF NOT EXISTS [mp03i] ([codigo] TEXT(24) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL);

-- Tabela: mp03r
CREATE TABLE IF NOT EXISTS [mp03r] ([codigo] TEXT(24) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL, [checado] TEXT(1) NOT NULL);

-- Tabela: mq01i
CREATE TABLE IF NOT EXISTS [mq01i] ([codigo] TEXT(10) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL);

-- Tabela: mq01r
CREATE TABLE IF NOT EXISTS [mq01r] ([codigo] TEXT(10) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL, [checado] TEXT(1) NOT NULL);

-- Tabela: mr01i
CREATE TABLE IF NOT EXISTS [mr01i] ([codigo] TEXT(10) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL);

-- Tabela: mr01r
CREATE TABLE IF NOT EXISTS [mr01r] ([codigo] TEXT(10) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL, [checado] TEXT(1) NOT NULL);

-- Tabela: ms01i
CREATE TABLE IF NOT EXISTS [ms01i] ([codigo] TEXT(24) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL);

-- Tabela: ms01r
CREATE TABLE IF NOT EXISTS [ms01r] ([codigo] TEXT(24) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL, [checado] TEXT(1) NOT NULL);

-- Tabela: mt01i
CREATE TABLE IF NOT EXISTS [mt01i] ([codigo] TEXT(10) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL);

-- Tabela: mt01r
CREATE TABLE IF NOT EXISTS [mt01r] ([codigo] TEXT(10) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL, [checado] TEXT(1) NOT NULL);

-- Tabela: mu01i
CREATE TABLE IF NOT EXISTS [mu01i] ([codigo] TEXT(10) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL);

-- Tabela: mu01r
CREATE TABLE IF NOT EXISTS [mu01r] ([codigo] TEXT(10) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL, [checado] TEXT(1) NOT NULL);

-- Tabela: rirm
CREATE TABLE IF NOT EXISTS [rirm] ([rirm] REAL NOT NULL, [classi] TEXT(1) NOT NULL, [rastro] TEXT(12) NOT NULL, [desenho] TEXT(24) NOT NULL, [descr] TEXT(40) NOT NULL, [instru] TEXT(40) NOT NULL, [nforn] REAL NOT NULL, [forne] TEXT(40) NOT NULL, [pedido] TEXT(8) NOT NULL, [nrnota] REAL NOT NULL, [nrnotb] REAL NOT NULL, [datanf] SHORTDATE NOT NULL, [qtde] REAL NOT NULL, [cert] TEXT(40) NOT NULL, [laudof] TEXT(1) NOT NULL, [datal] SHORTDATE NOT NULL, [obs01] TEXT(80) NOT NULL, [obs02] TEXT(80) NOT NULL, [obs03] TEXT(80) NOT NULL, [obs04] TEXT(80) NOT NULL, [unid] TEXT(4) NOT NULL, [tipoent] TEXT(1) NOT NULL, [aplicacao] TEXT(30) NOT NULL, [area] TEXT(2) NOT NULL, [cargo] TEXT(40) NOT NULL, [respo] TEXT(40) NOT NULL, [clotecrt] TEXT(1) NOT NULL, [crm] REAL NOT NULL, [data] SHORTDATE NOT NULL, [llaudo] BIT NOT NULL, [contig] BIT NOT NULL, [qtamo] REAL NOT NULL, [insp] TEXT(1) NOT NULL);

-- Tabela: rirmi
CREATE TABLE IF NOT EXISTS [rirmi] ([rirm] REAL NOT NULL, [item] REAL NOT NULL, [tipa] TEXT(3) NOT NULL, [qtitem] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(40) NOT NULL, [laudo] TEXT(1) NOT NULL, [uniitem] TEXT(4) NOT NULL, [pulaapu] TEXT(1) NOT NULL);

-- Tabela: rist
CREATE TABLE IF NOT EXISTS [rist] ([rist] REAL NOT NULL, [rastro] TEXT(12) NOT NULL, [tipo] TEXT(1) NOT NULL, [nforn] REAL NOT NULL, [forne] TEXT(30) NOT NULL, [classi] TEXT(1) NOT NULL, [nf] REAL NOT NULL, [nfb] REAL NOT NULL, [datanf] SHORTDATE NOT NULL, [cert] TEXT(40) NOT NULL, [codigo] TEXT(24) NOT NULL, [deno] TEXT(40) NOT NULL, [ncli] REAL NOT NULL, [cliente] TEXT(30) NOT NULL, [os] TEXT(8) NOT NULL, [insp] TEXT(1) NOT NULL, [nivel] TEXT(5) NOT NULL, [qtamo] REAL NOT NULL, [corpo] TEXT(1) NOT NULL, [laudof] TEXT(1) NOT NULL, [datal] SHORTDATE NOT NULL, [obs01] TEXT(60) NOT NULL, [obs02] TEXT(60) NOT NULL, [data] SHORTDATE NOT NULL, [unid] TEXT(4) NOT NULL, [aplicacao] TEXT(25) NOT NULL, [area] TEXT(2) NOT NULL, [cargo] TEXT(25) NOT NULL, [respo] TEXT(40) NOT NULL, [clotecrt] TEXT(1) NOT NULL, [crm] REAL NOT NULL, [llaudo] BIT NOT NULL, [qtde] REAL NOT NULL, [contig] BIT NOT NULL);

-- Tabela: risti
CREATE TABLE IF NOT EXISTS [risti] ([rist] REAL NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(45) NOT NULL, [laudo] TEXT(1) NOT NULL, [tipa] TEXT(3) NOT NULL, [dataenv] SHORTDATE NOT NULL, [horaenv] TEXT(5) NOT NULL, [datalau] SHORTDATE NOT NULL, [pulaapu] TEXT(1) NOT NULL);

-- �ndice: idx_aut_aut
CREATE INDEX IF NOT EXISTS [idx_aut_aut] ON [aut] ([aut]);

-- �ndice: idx_crgex_crgex
CREATE INDEX IF NOT EXISTS [idx_crgex_crgex] ON [crgex] ([crgex]);

-- �ndice: idx_crm3l_crm3l
CREATE INDEX IF NOT EXISTS [idx_crm3l_crm3l] ON [crm3l] ([codigo]);

-- �ndice: idx_crm_crm
CREATE INDEX IF NOT EXISTS [idx_crm_crm] ON [crm] ([crm]);

-- �ndice: idx_crm_crm-2
CREATE INDEX IF NOT EXISTS [idx_crm_crm-2] ON [crm] ([data]);

-- �ndice: idx_crm_crm-3
CREATE INDEX IF NOT EXISTS [idx_crm_crm-3] ON [crm] ([rastro]);

-- �ndice: idx_crm_crm-4
CREATE INDEX IF NOT EXISTS [idx_crm_crm-4] ON [crm] ([nrnota], [clifor]);

-- �ndice: idx_crm_crm-5
CREATE INDEX IF NOT EXISTS [idx_crm_crm-5] ON [crm] ([nrnotb], [clifor]);

-- �ndice: idx_crma_crma-1
CREATE INDEX IF NOT EXISTS [idx_crma_crma-1] ON [crma] ([numero]);

-- �ndice: idx_crma_crma-2
CREATE INDEX IF NOT EXISTS [idx_crma_crma-2] ON [crma] ([rastroa]);

-- �ndice: idx_crmar_crmar-1
CREATE INDEX IF NOT EXISTS [idx_crmar_crmar-1] ON [crmar] ([empresa], [ar], [item]);

-- �ndice: idx_crmar_crmar-2
CREATE INDEX IF NOT EXISTS [idx_crmar_crmar-2] ON [crmar] ([nrnota], [fornecedo], [codigo]);

-- �ndice: idx_crmar_crmar-3
CREATE INDEX IF NOT EXISTS [idx_crmar_crmar-3] ON [crmar] ([codigoint]);

-- �ndice: idx_crmcesp_crmcesp
CREATE INDEX IF NOT EXISTS [idx_crmcesp_crmcesp] ON [crmcesp] ([numero]);

-- �ndice: idx_crmcesp_crmcesp2
CREATE INDEX IF NOT EXISTS [idx_crmcesp_crmcesp2] ON [crmcesp] ([nome]);

-- �ndice: idx_crmcesp_crmcesp3
CREATE INDEX IF NOT EXISTS [idx_crmcesp_crmcesp3] ON [crmcesp] ([codigo]);

-- �ndice: idx_crmdev_crm
CREATE INDEX IF NOT EXISTS [idx_crmdev_crm] ON [crmdev] ([crm]);

-- �ndice: idx_crmdev_crm-2
CREATE INDEX IF NOT EXISTS [idx_crmdev_crm-2] ON [crmdev] ([data]);

-- �ndice: idx_crmdev_crm-3
CREATE INDEX IF NOT EXISTS [idx_crmdev_crm-3] ON [crmdev] ([rastro]);

-- �ndice: idx_crmdev_crm-4
CREATE INDEX IF NOT EXISTS [idx_crmdev_crm-4] ON [crmdev] ([nrnota], [clifor]);

-- �ndice: idx_crmdev_crm-5
CREATE INDEX IF NOT EXISTS [idx_crmdev_crm-5] ON [crmdev] ([nrnotb], [clifor]);

-- �ndice: idx_crmebx_crmebx-1
CREATE INDEX IF NOT EXISTS [idx_crmebx_crmebx-1] ON [crmebx] ([codigo], [nrnotaini], [digctr]);

-- �ndice: idx_crmebx_crmebx-2
CREATE INDEX IF NOT EXISTS [idx_crmebx_crmebx-2] ON [crmebx] ([nrnotaini], [codigo]);

-- �ndice: idx_crmebx_crmebx-3
CREATE INDEX IF NOT EXISTS [idx_crmebx_crmebx-3] ON [crmebx] ([nrnotaini]);

-- �ndice: idx_crmebx_crmebx-5
CREATE INDEX IF NOT EXISTS [idx_crmebx_crmebx-5] ON [crmebx] ([osini]);

-- �ndice: idx_crmebx_crrebx-4
CREATE INDEX IF NOT EXISTS [idx_crmebx_crrebx-4] ON [crmebx] ([cliente]);

-- �ndice: idx_crmens_crmens
CREATE INDEX IF NOT EXISTS [idx_crmens_crmens] ON [crmens] ([codigo]);

-- �ndice: idx_crmest_crmest-1
CREATE INDEX IF NOT EXISTS [idx_crmest_crmest-1] ON [crmest] ([codigo], [nrnotaini], [digctr]);

-- �ndice: idx_crmest_crmest-2
CREATE INDEX IF NOT EXISTS [idx_crmest_crmest-2] ON [crmest] ([nrnotaini], [codigo]);

-- �ndice: idx_crmest_crmest-3
CREATE INDEX IF NOT EXISTS [idx_crmest_crmest-3] ON [crmest] ([nrnotaini]);

-- �ndice: idx_crmest_crmest-4
CREATE INDEX IF NOT EXISTS [idx_crmest_crmest-4] ON [crmest] ([cliente]);

-- �ndice: idx_crmest_crmest-5
CREATE INDEX IF NOT EXISTS [idx_crmest_crmest-5] ON [crmest] ([osini]);

-- �ndice: idx_crmfn_crmfn
CREATE INDEX IF NOT EXISTS [idx_crmfn_crmfn] ON [crmfn] ([numero]);

-- �ndice: idx_crmfn_crmfn-2
CREATE INDEX IF NOT EXISTS [idx_crmfn_crmfn-2] ON [crmfn] ([data]);

-- �ndice: idx_crmfn_crmfn-3
CREATE INDEX IF NOT EXISTS [idx_crmfn_crmfn-3] ON [crmfn] ([rastro]);

-- �ndice: idx_crmgp12_crmgp12
CREATE INDEX IF NOT EXISTS [idx_crmgp12_crmgp12] ON [crmgp12] ([codigo]);

-- �ndice: idx_crml_crml
CREATE INDEX IF NOT EXISTS [idx_crml_crml] ON [crml] ([clifor], [codigo]);

-- �ndice: idx_crmmot_crmmot
CREATE INDEX IF NOT EXISTS [idx_crmmot_crmmot] ON [crmmot] ([codigo]);

-- �ndice: idx_crmnf_crmnf
CREATE INDEX IF NOT EXISTS [idx_crmnf_crmnf] ON [crmnf] ([fornecedo]);

-- �ndice: idx_crmr_crmr
CREATE INDEX IF NOT EXISTS [idx_crmr_crmr] ON [crmr] ([rastron]);

-- �ndice: idx_crmss_crmss-1
CREATE INDEX IF NOT EXISTS [idx_crmss_crmss-1] ON [crmss] ([numero]);

-- �ndice: idx_crmss_crmss-2
CREATE INDEX IF NOT EXISTS [idx_crmss_crmss-2] ON [crmss] ([rastro]);

-- �ndice: idx_crmss_crmss-3
CREATE INDEX IF NOT EXISTS [idx_crmss_crmss-3] ON [crmss] ([codigo]);

-- �ndice: idx_mp01i_mp01i-1
CREATE INDEX IF NOT EXISTS [idx_mp01i_mp01i-1] ON [mp01i] ([codigo], [item]);

-- �ndice: idx_mp01r_mp01r-1
CREATE INDEX IF NOT EXISTS [idx_mp01r_mp01r-1] ON [mp01r] ([codigo], [item]);

-- �ndice: idx_mp02i_mp02i-1
CREATE INDEX IF NOT EXISTS [idx_mp02i_mp02i-1] ON [mp02i] ([codigo], [item]);

-- �ndice: idx_mp02r_mp02r-1
CREATE INDEX IF NOT EXISTS [idx_mp02r_mp02r-1] ON [mp02r] ([codigo], [item]);

-- �ndice: idx_mp03i_mp03i-1
CREATE INDEX IF NOT EXISTS [idx_mp03i_mp03i-1] ON [mp03i] ([codigo], [item]);

-- �ndice: idx_mp03r_mp03r-1
CREATE INDEX IF NOT EXISTS [idx_mp03r_mp03r-1] ON [mp03r] ([codigo], [item]);

-- �ndice: idx_mq01i_mq01i-1
CREATE INDEX IF NOT EXISTS [idx_mq01i_mq01i-1] ON [mq01i] ([codigo], [item]);

-- �ndice: idx_mq01r_mq01r-1
CREATE INDEX IF NOT EXISTS [idx_mq01r_mq01r-1] ON [mq01r] ([codigo], [item]);

-- �ndice: idx_mr01i_mr01i-1
CREATE INDEX IF NOT EXISTS [idx_mr01i_mr01i-1] ON [mr01i] ([codigo], [item]);

-- �ndice: idx_mr01r_mr01r-1
CREATE INDEX IF NOT EXISTS [idx_mr01r_mr01r-1] ON [mr01r] ([codigo], [item]);

-- �ndice: idx_ms01i_ms01i-1
CREATE INDEX IF NOT EXISTS [idx_ms01i_ms01i-1] ON [ms01i] ([codigo], [item]);

-- �ndice: idx_ms01r_ms01r-1
CREATE INDEX IF NOT EXISTS [idx_ms01r_ms01r-1] ON [ms01r] ([codigo], [item]);

-- �ndice: idx_mt01i_mt01i-1
CREATE INDEX IF NOT EXISTS [idx_mt01i_mt01i-1] ON [mt01i] ([codigo], [item]);

-- �ndice: idx_mt01r_mt01r-1
CREATE INDEX IF NOT EXISTS [idx_mt01r_mt01r-1] ON [mt01r] ([codigo], [item]);

-- �ndice: idx_mu01i_mu01i-1
CREATE INDEX IF NOT EXISTS [idx_mu01i_mu01i-1] ON [mu01i] ([codigo], [item]);

-- �ndice: idx_mu01r_mu01r-1
CREATE INDEX IF NOT EXISTS [idx_mu01r_mu01r-1] ON [mu01r] ([codigo], [item]);

-- �ndice: idx_rirm_rirm
CREATE INDEX IF NOT EXISTS [idx_rirm_rirm] ON [rirm] ([rirm]);

-- �ndice: idx_rirm_rirm-2
CREATE INDEX IF NOT EXISTS [idx_rirm_rirm-2] ON [rirm] ([rastro]);

-- �ndice: idx_rirm_rirm-3
CREATE INDEX IF NOT EXISTS [idx_rirm_rirm-3] ON [rirm] ([desenho]);

-- �ndice: idx_rirm_rirm-4
CREATE INDEX IF NOT EXISTS [idx_rirm_rirm-4] ON [rirm] ([nrnota]);

-- �ndice: idx_rirm_rirm-5
CREATE INDEX IF NOT EXISTS [idx_rirm_rirm-5] ON [rirm] ([data]);

-- �ndice: idx_rirmi_rirmi
CREATE INDEX IF NOT EXISTS [idx_rirmi_rirmi] ON [rirmi] ([rirm]);

-- �ndice: idx_rist
CREATE INDEX IF NOT EXISTS [idx_rist] ON [risti] ([rist]);

-- �ndice: idx_rist_rist
CREATE INDEX IF NOT EXISTS [idx_rist_rist] ON [rist] ([rist]);

-- �ndice: idx_rist_rist-2
CREATE INDEX IF NOT EXISTS [idx_rist_rist-2] ON [rist] ([rastro]);

-- �ndice: idx_rist_rist-3
CREATE INDEX IF NOT EXISTS [idx_rist_rist-3] ON [rist] ([codigo]);

-- �ndice: idx_rist_rist-4
CREATE INDEX IF NOT EXISTS [idx_rist_rist-4] ON [rist] ([nf]);

-- �ndice: idx_rist_rist-5
CREATE INDEX IF NOT EXISTS [idx_rist_rist-5] ON [rist] ([data]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
