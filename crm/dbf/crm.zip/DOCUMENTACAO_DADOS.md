# 🗄️ Dicionario de Estruturas de Dados do Projeto
> Varredura automatica realizada em: 05/12/26

## 📋 Tabela DBF: `aut.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| AUT | N | 8 | 0 |
| USADA | L | 1 | 0 |
| USER | N | 8 | 0 |
| MOTIVO | C | 150 | 0 |
| MOTIV2 | C | 150 | 0 |
| CARTA | C | 1 | 0 |
| DATA | D | 8 | 0 |
| DATABX | D | 8 | 0 |
| CRM | N | 8 | 0 |
| DATACR | D | 8 | 0 |
| FISOBS01 | C | 80 | 0 |
| FISOBS02 | C | 80 | 0 |
| FISOBS03 | C | 80 | 0 |
| LIBPOR | C | 15 | 0 |
| LIBFISCAL | C | 1 | 0 |

**Índices vinculados:**
- Tag: `AUT` Expressão: `AUT`

---
## 📋 Tabela DBF: `crgec.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CRGEX | N | 8 | 0 |
| DATA | D | 8 | 0 |
| FORNECEDO | N | 8 | 0 |
| COGNOME | C | 20 | 0 |
| NOTA | C | 50 | 0 |
| PESONF | N | 6 | 0 |
| PESOEC | N | 6 | 0 |
| PESOLQ | N | 6 | 0 |
| PERCEX | N | 8 | 3 |

**Índices vinculados:**
- Tag: `CRGEX` Expressão: `CRGEX`

---
## 📋 Tabela DBF: `crgex.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CRGEX | N | 8 | 0 |
| DATA | D | 8 | 0 |
| FORNECEDO | N | 8 | 0 |
| COGNOME | C | 20 | 0 |
| NOTA | C | 50 | 0 |
| PESONF | N | 6 | 0 |
| PESOEC | N | 6 | 0 |
| PESOLQ | N | 6 | 0 |
| PERCEX | N | 8 | 3 |

**Índices vinculados:**
- Tag: `CRGEX` Expressão: `CRGEX`

---
## 📋 Tabela DBF: `crm.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CRM | N | 8 | 0 |
| TIPCAD | C | 1 | 0 |
| CLIFOR | N | 8 | 0 |
| COGNOME | C | 15 | 0 |
| DATA | D | 8 | 0 |
| TIPOE | C | 1 | 0 |
| DESCRI | C | 40 | 0 |
| PEDIDO | C | 20 | 0 |
| NRNOTA | N | 8 | 0 |
| NRNOTB | N | 8 | 0 |
| QTDE | N | 12 | 3 |
| QTDEA | N | 12 | 3 |
| QTDEB | N | 12 | 3 |
| NIVEL | C | 10 | 0 |
| INSP | C | 1 | 0 |
| LAUDO | C | 1 | 0 |
| TECNICO | N | 8 | 0 |
| OBS | C | 100 | 0 |
| CBUSCA | C | 24 | 0 |
| NOMEF | C | 40 | 0 |
| UNID | C | 4 | 0 |
| RIST | N | 8 | 0 |
| RIRM | N | 8 | 0 |
| APLICACAO | C | 30 | 0 |
| PRODUTO | C | 24 | 0 |
| VALOR | N | 12 | 2 |
| GRAVOU | C | 1 | 0 |
| GRAVOUY | C | 1 | 0 |
| PROGRAMA | N | 8 | 2 |
| GRAVAUP | C | 1 | 0 |
| PRPED | N | 5 | 0 |
| PRITE | N | 2 | 0 |
| PRCLI | N | 8 | 0 |
| PEPED | N | 8 | 0 |
| PEITE | N | 3 | 0 |
| CERT | C | 40 | 0 |
| PEREQ | N | 8 | 0 |
| AUT | N | 8 | 0 |
| USERNM | C | 10 | 0 |
| USERDT | D | 8 | 0 |
| USERHT | C | 8 | 0 |
| NRDATA | D | 8 | 0 |
| RASTRO | C | 12 | 0 |
| PRECO | N | 15 | 6 |
| PRECOPR | N | 15 | 6 |
| PRECONF | N | 15 | 6 |
| CLOTECRT | C | 1 | 0 |
| PRECOOK | C | 1 | 0 |
| QTDEPED | N | 12 | 3 |
| PESONFA | N | 9 | 3 |
| PESONFB | N | 9 | 3 |
| PEDCLI | C | 1 | 0 |
| ENTREGA | D | 8 | 0 |
| ENTREG2 | D | 8 | 0 |
| TRIANGULAR | C | 1 | 0 |

**Índices vinculados:**
- Tag: `CRM` Expressão: `CRM`
- Tag: `CRM-2` Expressão: `DATA`
- Tag: `CRM-3` Expressão: `RASTRO`
- Tag: `CRM-4` Expressão: `STR(NRNOTA,8)+STR(CLIFOR,8)`
- Tag: `CRM-5` Expressão: `STR(NRNOTB,8)+STR(CLIFOR,8)`

---
## 📋 Tabela DBF: `crm3l.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 24 | 0 |
| NVEZES | N | 2 | 0 |
| RACF | N | 8 | 0 |
| DESC01 | C | 90 | 0 |
| DESC02 | C | 90 | 0 |
| DESC03 | C | 90 | 0 |
| DESC04 | C | 90 | 0 |
| DESC05 | C | 90 | 0 |

**Índices vinculados:**
- Tag: `CRM3L` Expressão: `CODIGO`

---
## 📋 Tabela DBF: `crma.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| NUMERO | N | 8 | 0 |
| DATA | D | 8 | 0 |
| TIPOENT | C | 1 | 0 |
| CODIGO | C | 24 | 0 |
| FORNECEDO | N | 8 | 0 |
| COGFOR | C | 15 | 0 |
| NF | N | 8 | 0 |
| PRODUTO | C | 24 | 0 |
| CLIENTE | N | 8 | 0 |
| COGCLI | C | 12 | 0 |
| RASTROA | C | 12 | 0 |
| RASTROOK | C | 12 | 0 |
| DATAOK | D | 8 | 0 |
| MOTIVO | C | 3 | 0 |
| CRM | N | 8 | 0 |

**Índices vinculados:**
- Tag: `CRMA-1` Expressão: `NUMERO`
- Tag: `CRMA-2` Expressão: `RASTROA`

---
## 📋 Tabela DBF: `crmar.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| TIPOENT | C | 1 | 0 |
| CODIGO | C | 24 | 0 |
| UNIDADE | C | 2 | 0 |
| NOME | C | 100 | 0 |
| NRNOTA | N | 8 | 0 |
| DATA | D | 8 | 0 |
| QTDE | N | 6 | 0 |
| TIPOCLI | C | 1 | 0 |
| FORNECEDO | N | 5 | 0 |
| COGNOME | C | 12 | 0 |
| CRM | N | 8 | 0 |
| AR | N | 8 | 0 |
| ITEM | N | 2 | 0 |
| RIRM | N | 8 | 0 |
| RIST | N | 8 | 0 |
| CODFORN | C | 18 | 0 |
| EMPRESA | C | 2 | 0 |
| CODIGOINT | C | 24 | 0 |
| MC | N | 8 | 0 |

**Índices vinculados:**
- Tag: `CRMAR-1` Expressão: `EMPRESA+STR(AR,8)+STR(ITEM,2)`
- Tag: `CRMAR-2` Expressão: `STR(NRNOTA,8)+STR(FORNECEDO,8)+CODIGO`
- Tag: `CRMAR-3` Expressão: `CODIGOINT`

---
## 📋 Tabela DBF: `crmcesp.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| NUMERO | N | 8 | 0 |
| NOME | C | 100 | 0 |
| TIPOENT | C | 1 | 0 |
| CODIGO | C | 24 | 0 |

**Índices vinculados:**
- Tag: `CRMCESP` Expressão: `NUMERO`
- Tag: `CRMCESP2` Expressão: `NOME`
- Tag: `CRMCESP3` Expressão: `CODIGO`

---
## 📋 Tabela DBF: `crmdev.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CRM | N | 8 | 0 |
| TIPCAD | C | 1 | 0 |
| CLIFOR | N | 8 | 0 |
| COGNOME | C | 15 | 0 |
| DATA | D | 8 | 0 |
| TIPOE | C | 1 | 0 |
| DESCRI | C | 40 | 0 |
| PEDIDO | C | 20 | 0 |
| NRNOTA | N | 8 | 0 |
| NRNOTB | N | 8 | 0 |
| QTDE | N | 12 | 3 |
| QTDEA | N | 12 | 3 |
| QTDEB | N | 12 | 3 |
| NIVEL | C | 10 | 0 |
| INSP | C | 1 | 0 |
| LAUDO | C | 1 | 0 |
| TECNICO | N | 8 | 0 |
| OBS | C | 100 | 0 |
| CBUSCA | C | 24 | 0 |
| NOMEF | C | 40 | 0 |
| UNID | C | 4 | 0 |
| RIST | N | 8 | 0 |
| RIRM | N | 8 | 0 |
| APLICACAO | C | 30 | 0 |
| PRODUTO | C | 24 | 0 |
| VALOR | N | 12 | 2 |
| GRAVOU | C | 1 | 0 |
| GRAVOUY | C | 1 | 0 |
| PROGRAMA | N | 8 | 2 |
| GRAVAUP | C | 1 | 0 |
| PRPED | N | 5 | 0 |
| PRITE | N | 2 | 0 |
| PRCLI | N | 8 | 0 |
| PEPED | N | 8 | 0 |
| PEITE | N | 3 | 0 |
| CERT | C | 40 | 0 |
| PEREQ | N | 8 | 0 |
| AUT | N | 8 | 0 |
| USERNM | C | 10 | 0 |
| USERDT | D | 8 | 0 |
| USERHT | C | 8 | 0 |
| NRDATA | D | 8 | 0 |
| RASTRO | C | 12 | 0 |
| PRECO | N | 15 | 6 |
| PRECOPR | N | 15 | 6 |
| PRECONF | N | 15 | 6 |
| CLOTECRT | C | 1 | 0 |
| PRECOOK | C | 1 | 0 |
| QTDEPED | N | 12 | 3 |
| PESONFA | N | 9 | 3 |
| PESONFB | N | 9 | 3 |
| PEDCLI | C | 1 | 0 |
| ENTREGA | D | 8 | 0 |
| ENTREG2 | D | 8 | 0 |
| TRIANGULAR | C | 1 | 0 |

**Índices vinculados:**
- Tag: `CRM` Expressão: `CRM`
- Tag: `CRM-2` Expressão: `DATA`
- Tag: `CRM-3` Expressão: `RASTRO`
- Tag: `CRM-4` Expressão: `STR(NRNOTA,8)+STR(CLIFOR,8)`
- Tag: `CRM-5` Expressão: `STR(NRNOTB,8)+STR(CLIFOR,8)`

---
## 📋 Tabela DBF: `crme01.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| RASTRO | C | 10 | 0 |
| DATA | D | 8 | 0 |

---
## 📋 Tabela DBF: `crme02.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| RASTRO | C | 12 | 0 |
| DATA | D | 8 | 0 |
| NOME | C | 30 | 0 |
| NOM2 | C | 35 | 0 |
| NOM3 | C | 35 | 0 |
| APLICACAO | C | 50 | 0 |
| FORNECEDOR | N | 8 | 0 |
| RESPO | C | 40 | 0 |
| NRNOTA | N | 8 | 0 |
| NRNOTB | N | 8 | 0 |
| PESONFA | N | 9 | 3 |
| PESONFB | N | 9 | 3 |
| QTDEA | N | 12 | 3 |
| QTDEB | N | 12 | 3 |
| POS | C | 11 | 0 |
| CODIGO | C | 24 | 0 |
| CERT | C | 50 | 0 |

---
## 📋 Tabela DBF: `crme03.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| ESPE | C | 80 | 0 |
| USUARIO | C | 10 | 0 |
| SETOR | C | 30 | 0 |
| DATA | D | 8 | 0 |
| CODIGO | C | 24 | 0 |
| NOME | C | 40 | 0 |
| NCLI | N | 8 | 0 |
| CLIENTE | C | 30 | 0 |
| RASTRO | C | 12 | 0 |
| QTAMO | N | 12 | 0 |
| REFNUM | N | 8 | 0 |
| CERT | C | 50 | 0 |

---
## 📋 Tabela DBF: `crmebx.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 24 | 0 |
| UNIDADE | C | 2 | 0 |
| NOME | C | 30 | 0 |
| NRNOTAINI | N | 8 | 0 |
| DIGCTR | C | 1 | 0 |
| SERIE | C | 3 | 0 |
| DATAFAT | D | 8 | 0 |
| OSINI | N | 8 | 2 |
| VALORINI | N | 10 | 2 |
| TOTKGINI | N | 9 | 2 |
| NRNOTASAI | N | 8 | 0 |
| TOTKGANT | N | 9 | 2 |
| TOTKGSAI | N | 9 | 2 |
| TOTKGEST | N | 9 | 2 |
| TIPOCLI | C | 1 | 0 |
| CLIENTE | N | 5 | 0 |
| COGNOME | C | 12 | 0 |
| DATASAI | D | 8 | 0 |
| CRM | N | 8 | 0 |
| PESOREF | N | 12 | 5 |
| CLASSIPI | C | 14 | 0 |
| PRECO | N | 10 | 2 |
| TIPOENT | C | 1 | 0 |
| OBS | C | 30 | 0 |
| RASTRO | C | 12 | 0 |
| DIFSALDO | N | 9 | 2 |
| LOCAL | C | 7 | 0 |
| QTDEEMB | N | 2 | 0 |

**Índices vinculados:**
- Tag: `CRMEBX-1` Expressão: `CODIGO+STR(NRNOTAINI,8)+DIGCTR`
- Tag: `CRMEBX-2` Expressão: `STR(NRNOTAINI,8)+CODIGO`
- Tag: `CRMEBX-3` Expressão: `NRNOTAINI`
- Tag: `CRREBX-4` Expressão: `CLIENTE`
- Tag: `CRMEBX-5` Expressão: `OSINI`

---
## 📋 Tabela DBF: `crmens.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 10 | 0 |
| NOME | C | 40 | 0 |
| VALOR | N | 12 | 8 |

**Índices vinculados:**
- Tag: `CRMENS` Expressão: `CODIGO`

---
## 📋 Tabela DBF: `crmest.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 24 | 0 |
| UNIDADE | C | 2 | 0 |
| NOME | C | 30 | 0 |
| NRNOTAINI | N | 8 | 0 |
| DIGCTR | C | 1 | 0 |
| SERIE | C | 3 | 0 |
| DATAFAT | D | 8 | 0 |
| OSINI | N | 8 | 2 |
| VALORINI | N | 10 | 2 |
| TOTKGINI | N | 9 | 2 |
| NRNOTASAI | N | 8 | 0 |
| TOTKGANT | N | 9 | 2 |
| TOTKGSAI | N | 9 | 2 |
| TOTKGEST | N | 9 | 2 |
| TIPOCLI | C | 1 | 0 |
| CLIENTE | N | 5 | 0 |
| COGNOME | C | 12 | 0 |
| DATASAI | D | 8 | 0 |
| CRM | N | 8 | 0 |
| PESOREF | N | 12 | 5 |
| CLASSIPI | C | 14 | 0 |
| PRECO | N | 10 | 2 |
| TIPOENT | C | 1 | 0 |
| OBS | C | 30 | 0 |
| RASTRO | C | 12 | 0 |
| DIFSALDO | N | 9 | 2 |
| LOCAL | C | 7 | 0 |
| QTDEEMB | N | 2 | 0 |

**Índices vinculados:**
- Tag: `CRMEST-1` Expressão: `CODIGO+STR(NRNOTAINI,8)+DIGCTR`
- Tag: `CRMEST-2` Expressão: `STR(NRNOTAINI,8)+CODIGO`
- Tag: `CRMEST-3` Expressão: `NRNOTAINI`
- Tag: `CRMEST-4` Expressão: `CLIENTE`
- Tag: `CRMEST-5` Expressão: `OSINI`

---
## 📋 Tabela DBF: `crmfn.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| NUMERO | N | 8 | 0 |
| DATA | D | 8 | 0 |
| RASTRO | C | 12 | 0 |
| FORNECEDO | N | 8 | 0 |
| COGNOME | C | 12 | 0 |
| CODIGO | C | 24 | 0 |
| CLIENTE | N | 8 | 0 |
| PESOUNI | N | 7 | 3 |
| CODMR01 | C | 10 | 0 |
| NOMMR01 | C | 30 | 0 |
| PCEMB | N | 7 | 0 |
| PCEMBQ | N | 7 | 0 |
| QTDEKG | N | 9 | 3 |
| QTDEPC | N | 9 | 0 |

**Índices vinculados:**
- Tag: `CRMFN` Expressão: `NUMERO`
- Tag: `CRMFN-2` Expressão: `DATA`
- Tag: `CRMFN-3` Expressão: `RASTRO`

---
## 📋 Tabela DBF: `crmgp12.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 24 | 0 |

**Índices vinculados:**
- Tag: `CRMGP12` Expressão: `CODIGO`

---
## 📋 Tabela DBF: `crml.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CLIFOR | N | 8 | 0 |
| CODIGO | C | 24 | 0 |
| LOTE | N | 3 | 0 |

**Índices vinculados:**
- Tag: `CRML` Expressão: `STR(CLIFOR,8)+CODIGO`

---
## 📋 Tabela DBF: `crmmot.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 2 | 0 |
| DIZER | C | 50 | 0 |

**Índices vinculados:**
- Tag: `CRMMOT` Expressão: `CODIGO`

---
## 📋 Tabela DBF: `crmnf.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| FORNECEDO | N | 8 | 0 |
| NRNOTA | N | 8 | 0 |
| DATA | D | 8 | 0 |

**Índices vinculados:**
- Tag: `CRMNF` Expressão: `FORNECEDO`

---
## 📋 Tabela DBF: `crmr.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| RASTRO | C | 10 | 0 |
| RASTRON | N | 8 | 0 |
| RASTROA | N | 4 | 0 |
| CRM | N | 8 | 0 |
| RIRM | N | 8 | 0 |
| RIST | N | 8 | 0 |
| DATAF | D | 8 | 0 |
| OBS | C | 100 | 0 |
| DATA | D | 8 | 0 |
| PRODUTO | C | 50 | 0 |

**Índices vinculados:**
- Tag: `CRMR` Expressão: `RASTRON`

---
## 📋 Tabela DBF: `crmss.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| NUMERO | N | 8 | 0 |
| CODIGO | C | 24 | 0 |
| CODIGOINT | C | 24 | 0 |
| NORMA | C | 14 | 0 |
| APLICACAO | C | 30 | 0 |
| FORNECEDO | N | 8 | 0 |
| FORNOME | C | 40 | 0 |
| ESPE | C | 60 | 0 |
| RASTRO | C | 12 | 0 |
| DATA | D | 8 | 0 |
| RIST | N | 8 | 0 |
| AR | N | 8 | 0 |
| ITEM | N | 3 | 0 |
| DATAENV | D | 8 | 0 |
| HORAENV | C | 5 | 0 |

**Índices vinculados:**
- Tag: `CRMSS-1` Expressão: `NUMERO`
- Tag: `CRMSS-2` Expressão: `RASTRO`
- Tag: `CRMSS-3` Expressão: `CODIGO`

---
## 📋 Tabela DBF: `mp01i.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 12 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 60 | 0 |
| VALPAD | N | 8 | 2 |
| VALMAX | N | 8 | 2 |
| VALMIN | N | 8 | 2 |
| TOLMAX | N | 8 | 2 |
| TOLMIN | N | 8 | 2 |
| UNIDADE | C | 3 | 0 |
| TIPA | C | 3 | 0 |
| UNIDREF | C | 4 | 0 |
| QTDEREF | N | 8 | 2 |

**Índices vinculados:**
- Tag: `MP01I-1` Expressão: `CODIGO+STR(ITEM,3)`

---
## 📋 Tabela DBF: `mp01r.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 12 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 60 | 0 |
| VALPAD | N | 8 | 2 |
| VALMAX | N | 8 | 2 |
| VALMIN | N | 8 | 2 |
| TOLMAX | N | 8 | 2 |
| TOLMIN | N | 8 | 2 |
| UNIDADE | C | 3 | 0 |
| TIPA | C | 3 | 0 |
| UNIDREF | C | 4 | 0 |
| QTDEREF | N | 8 | 2 |
| CHECADO | C | 1 | 0 |

**Índices vinculados:**
- Tag: `MP01R-1` Expressão: `CODIGO+STR(ITEM,3)`

---
## 📋 Tabela DBF: `mp02i.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 12 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 60 | 0 |
| VALPAD | N | 8 | 2 |
| VALMAX | N | 8 | 2 |
| VALMIN | N | 8 | 2 |
| TOLMAX | N | 8 | 2 |
| TOLMIN | N | 8 | 2 |
| UNIDADE | C | 3 | 0 |
| TIPA | C | 3 | 0 |
| UNIDREF | C | 4 | 0 |
| QTDEREF | N | 8 | 2 |

**Índices vinculados:**
- Tag: `MP02I-1` Expressão: `CODIGO+STR(ITEM,3)`

---
## 📋 Tabela DBF: `mp02r.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 12 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 60 | 0 |
| VALPAD | N | 8 | 2 |
| VALMAX | N | 8 | 2 |
| VALMIN | N | 8 | 2 |
| TOLMAX | N | 8 | 2 |
| TOLMIN | N | 8 | 2 |
| UNIDADE | C | 3 | 0 |
| TIPA | C | 3 | 0 |
| UNIDREF | C | 4 | 0 |
| QTDEREF | N | 8 | 2 |
| CHECADO | C | 1 | 0 |

**Índices vinculados:**
- Tag: `MP02R-1` Expressão: `CODIGO+STR(ITEM,3)`

---
## 📋 Tabela DBF: `mp03i.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 24 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 60 | 0 |
| VALPAD | N | 8 | 2 |
| VALMAX | N | 8 | 2 |
| VALMIN | N | 8 | 2 |
| TOLMAX | N | 8 | 2 |
| TOLMIN | N | 8 | 2 |
| UNIDADE | C | 3 | 0 |
| TIPA | C | 3 | 0 |
| UNIDREF | C | 4 | 0 |
| QTDEREF | N | 8 | 2 |

**Índices vinculados:**
- Tag: `MP03I-1` Expressão: `CODIGO+STR(ITEM,3)`

---
## 📋 Tabela DBF: `mp03r.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 24 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 60 | 0 |
| VALPAD | N | 8 | 2 |
| VALMAX | N | 8 | 2 |
| VALMIN | N | 8 | 2 |
| TOLMAX | N | 8 | 2 |
| TOLMIN | N | 8 | 2 |
| UNIDADE | C | 3 | 0 |
| TIPA | C | 3 | 0 |
| UNIDREF | C | 4 | 0 |
| QTDEREF | N | 8 | 2 |
| CHECADO | C | 1 | 0 |

**Índices vinculados:**
- Tag: `MP03R-1` Expressão: `CODIGO+STR(ITEM,3)`

---
## 📋 Tabela DBF: `mq01i.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 10 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 60 | 0 |
| VALPAD | N | 8 | 2 |
| VALMAX | N | 8 | 2 |
| VALMIN | N | 8 | 2 |
| TOLMAX | N | 8 | 2 |
| TOLMIN | N | 8 | 2 |
| UNIDADE | C | 3 | 0 |
| TIPA | C | 3 | 0 |
| UNIDREF | C | 4 | 0 |
| QTDEREF | N | 8 | 2 |

**Índices vinculados:**
- Tag: `MQ01I-1` Expressão: `CODIGO+STR(ITEM,3)`

---
## 📋 Tabela DBF: `mq01r.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 10 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 60 | 0 |
| VALPAD | N | 8 | 2 |
| VALMAX | N | 8 | 2 |
| VALMIN | N | 8 | 2 |
| TOLMAX | N | 8 | 2 |
| TOLMIN | N | 8 | 2 |
| UNIDADE | C | 3 | 0 |
| TIPA | C | 3 | 0 |
| UNIDREF | C | 4 | 0 |
| QTDEREF | N | 8 | 2 |
| CHECADO | C | 1 | 0 |

**Índices vinculados:**
- Tag: `MQ01R-1` Expressão: `CODIGO+STR(ITEM,3)`

---
## 📋 Tabela DBF: `mr01i.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 10 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 60 | 0 |
| VALPAD | N | 8 | 2 |
| VALMAX | N | 8 | 2 |
| VALMIN | N | 8 | 2 |
| TOLMAX | N | 8 | 2 |
| TOLMIN | N | 8 | 2 |
| UNIDADE | C | 3 | 0 |
| TIPA | C | 3 | 0 |
| UNIDREF | C | 4 | 0 |
| QTDEREF | N | 8 | 2 |

**Índices vinculados:**
- Tag: `MR01I-1` Expressão: `CODIGO+STR(ITEM,3)`

---
## 📋 Tabela DBF: `mr01r.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 10 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 60 | 0 |
| VALPAD | N | 8 | 2 |
| VALMAX | N | 8 | 2 |
| VALMIN | N | 8 | 2 |
| TOLMAX | N | 8 | 2 |
| TOLMIN | N | 8 | 2 |
| UNIDADE | C | 3 | 0 |
| TIPA | C | 3 | 0 |
| UNIDREF | C | 4 | 0 |
| QTDEREF | N | 8 | 2 |
| CHECADO | C | 1 | 0 |

**Índices vinculados:**
- Tag: `MR01R-1` Expressão: `CODIGO+STR(ITEM,3)`

---
## 📋 Tabela DBF: `ms01i.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 24 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 60 | 0 |
| VALPAD | N | 8 | 2 |
| VALMAX | N | 8 | 2 |
| VALMIN | N | 8 | 2 |
| TOLMAX | N | 8 | 2 |
| TOLMIN | N | 8 | 2 |
| UNIDADE | C | 3 | 0 |
| TIPA | C | 3 | 0 |
| UNIDREF | C | 4 | 0 |
| QTDEREF | N | 8 | 2 |

**Índices vinculados:**
- Tag: `MS01I-1` Expressão: `CODIGO+STR(ITEM,3)`

---
## 📋 Tabela DBF: `ms01r.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 24 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 60 | 0 |
| VALPAD | N | 8 | 2 |
| VALMAX | N | 8 | 2 |
| VALMIN | N | 8 | 2 |
| TOLMAX | N | 8 | 2 |
| TOLMIN | N | 8 | 2 |
| UNIDADE | C | 3 | 0 |
| TIPA | C | 3 | 0 |
| UNIDREF | C | 4 | 0 |
| QTDEREF | N | 8 | 2 |
| CHECADO | C | 1 | 0 |

**Índices vinculados:**
- Tag: `MS01R-1` Expressão: `CODIGO+STR(ITEM,3)`

---
## 📋 Tabela DBF: `mt01i.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 10 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 60 | 0 |
| VALPAD | N | 8 | 2 |
| VALMAX | N | 8 | 2 |
| VALMIN | N | 8 | 2 |
| TOLMAX | N | 8 | 2 |
| TOLMIN | N | 8 | 2 |
| UNIDADE | C | 3 | 0 |
| TIPA | C | 3 | 0 |
| UNIDREF | C | 4 | 0 |
| QTDEREF | N | 8 | 2 |

**Índices vinculados:**
- Tag: `MT01I-1` Expressão: `CODIGO+STR(ITEM,3)`

---
## 📋 Tabela DBF: `mt01r.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 10 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 60 | 0 |
| VALPAD | N | 8 | 2 |
| VALMAX | N | 8 | 2 |
| VALMIN | N | 8 | 2 |
| TOLMAX | N | 8 | 2 |
| TOLMIN | N | 8 | 2 |
| UNIDADE | C | 3 | 0 |
| TIPA | C | 3 | 0 |
| UNIDREF | C | 4 | 0 |
| QTDEREF | N | 8 | 2 |
| CHECADO | C | 1 | 0 |

**Índices vinculados:**
- Tag: `MT01R-1` Expressão: `CODIGO+STR(ITEM,3)`

---
## 📋 Tabela DBF: `mu01i.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 10 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 60 | 0 |
| VALPAD | N | 8 | 2 |
| VALMAX | N | 8 | 2 |
| VALMIN | N | 8 | 2 |
| TOLMAX | N | 8 | 2 |
| TOLMIN | N | 8 | 2 |
| UNIDADE | C | 3 | 0 |
| TIPA | C | 3 | 0 |
| UNIDREF | C | 4 | 0 |
| QTDEREF | N | 8 | 2 |

**Índices vinculados:**
- Tag: `MU01I-1` Expressão: `CODIGO+STR(ITEM,3)`

---
## 📋 Tabela DBF: `mu01r.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| CODIGO | C | 10 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 60 | 0 |
| VALPAD | N | 8 | 2 |
| VALMAX | N | 8 | 2 |
| VALMIN | N | 8 | 2 |
| TOLMAX | N | 8 | 2 |
| TOLMIN | N | 8 | 2 |
| UNIDADE | C | 3 | 0 |
| TIPA | C | 3 | 0 |
| UNIDREF | C | 4 | 0 |
| QTDEREF | N | 8 | 2 |
| CHECADO | C | 1 | 0 |

**Índices vinculados:**
- Tag: `MU01R-1` Expressão: `CODIGO+STR(ITEM,3)`

---
## 📋 Tabela DBF: `rirm.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| RIRM | N | 8 | 0 |
| CLASSI | C | 1 | 0 |
| RASTRO | C | 12 | 0 |
| DESENHO | C | 24 | 0 |
| DESCR | C | 40 | 0 |
| INSTRU | C | 40 | 0 |
| NFORN | N | 8 | 0 |
| FORNE | C | 40 | 0 |
| PEDIDO | C | 8 | 0 |
| NRNOTA | N | 8 | 0 |
| NRNOTB | N | 8 | 0 |
| DATANF | D | 8 | 0 |
| QTDE | N | 12 | 3 |
| CERT | C | 40 | 0 |
| LAUDOF | C | 1 | 0 |
| DATAL | D | 8 | 0 |
| OBS01 | C | 80 | 0 |
| OBS02 | C | 80 | 0 |
| OBS03 | C | 80 | 0 |
| OBS04 | C | 80 | 0 |
| UNID | C | 4 | 0 |
| TIPOENT | C | 1 | 0 |
| APLICACAO | C | 30 | 0 |
| AREA | C | 2 | 0 |
| CARGO | C | 40 | 0 |
| RESPO | C | 40 | 0 |
| CLOTECRT | C | 1 | 0 |
| CRM | N | 8 | 0 |
| DATA | D | 8 | 0 |
| LLAUDO | L | 1 | 0 |
| CONTIG | L | 1 | 0 |
| QTAMO | N | 4 | 0 |
| INSP | C | 1 | 0 |

**Índices vinculados:**
- Tag: `RIRM` Expressão: `RIRM`
- Tag: `RIRM-2` Expressão: `RASTRO`
- Tag: `RIRM-3` Expressão: `DESENHO`
- Tag: `RIRM-4` Expressão: `NRNOTA`
- Tag: `RIRM-5` Expressão: `DATA`

---
## 📋 Tabela DBF: `rirmi.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| RIRM | N | 8 | 0 |
| ITEM | N | 3 | 0 |
| TIPA | C | 3 | 0 |
| QTITEM | N | 4 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 40 | 0 |
| LAUDO | C | 1 | 0 |
| UNIITEM | C | 4 | 0 |
| PULAAPU | C | 1 | 0 |

**Índices vinculados:**
- Tag: `RIRMI` Expressão: `RIRM`

---
## 📋 Tabela DBF: `rist.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| RIST | N | 8 | 0 |
| RASTRO | C | 12 | 0 |
| TIPO | C | 1 | 0 |
| NFORN | N | 8 | 0 |
| FORNE | C | 30 | 0 |
| CLASSI | C | 1 | 0 |
| NF | N | 8 | 0 |
| NFB | N | 8 | 0 |
| DATANF | D | 8 | 0 |
| CERT | C | 40 | 0 |
| CODIGO | C | 24 | 0 |
| DENO | C | 40 | 0 |
| NCLI | N | 8 | 0 |
| CLIENTE | C | 30 | 0 |
| OS | C | 8 | 0 |
| INSP | C | 1 | 0 |
| NIVEL | C | 5 | 0 |
| QTAMO | N | 5 | 0 |
| CORPO | C | 1 | 0 |
| LAUDOF | C | 1 | 0 |
| DATAL | D | 8 | 0 |
| OBS01 | C | 60 | 0 |
| OBS02 | C | 60 | 0 |
| DATA | D | 8 | 0 |
| UNID | C | 4 | 0 |
| APLICACAO | C | 25 | 0 |
| AREA | C | 2 | 0 |
| CARGO | C | 25 | 0 |
| RESPO | C | 40 | 0 |
| CLOTECRT | C | 1 | 0 |
| CRM | N | 8 | 0 |
| LLAUDO | L | 1 | 0 |
| QTDE | N | 10 | 3 |
| CONTIG | L | 1 | 0 |

**Índices vinculados:**
- Tag: `RIST` Expressão: `RIST`
- Tag: `RIST-2` Expressão: `RASTRO`
- Tag: `RIST-3` Expressão: `CODIGO`
- Tag: `RIST-4` Expressão: `NF`
- Tag: `RIST-5` Expressão: `DATA`

---
## 📋 Tabela DBF: `risti.dbf`
| Campo | Tipo | Tam | Dec |
| :--- | :--- | :--- | :--- |
| RIST | N | 8 | 0 |
| ITEM | N | 3 | 0 |
| ESPE | C | 60 | 0 |
| ENCO | C | 45 | 0 |
| LAUDO | C | 1 | 0 |
| TIPA | C | 3 | 0 |
| DATAENV | D | 8 | 0 |
| HORAENV | C | 5 | 0 |
| DATALAU | D | 8 | 0 |
| PULAAPU | C | 1 | 0 |

**Índices vinculados:**
- Tag: `RIST` Expressão: `RIST`

---
