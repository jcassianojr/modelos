--
-- Arquivo gerado com SQLiteStudio v3.4.4 em ter ago 6 17:29:14 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: configu
CREATE TABLE IF NOT EXISTS [configu] ([help] TEXT(8) NOT NULL, [arq] TEXT(8) NOT NULL, [arq1] TEXT(8) NOT NULL, [dirc] TEXT(60) NOT NULL, [diri] TEXT(60) NOT NULL, [dirp] TEXT(60) NOT NULL, [dire] TEXT(60) NOT NULL, [dirb] TEXT(60) NOT NULL, [dira] TEXT(60) NOT NULL, [moeda01] TEXT(20) NOT NULL, [moeda02] TEXT(20) NOT NULL, [moeda03] TEXT(20) NOT NULL, [moeda04] TEXT(20) NOT NULL, [moeda05] TEXT(20) NOT NULL, [moeda06] TEXT(20) NOT NULL, [manual] TEXT(8) NOT NULL, [achesc] TEXT(1) NOT NULL, [arqhis] TEXT(8) NOT NULL, [multiemp] TEXT(1) NOT NULL, [arqfon] TEXT(8) NOT NULL, [imppad] TEXT(12) NOT NULL, [inxcgcma] REAL NOT NULL, [inxcgcmb] REAL NOT NULL, [reccom] REAL NOT NULL, [driver] TEXT(8) NOT NULL);

-- Tabela: manemp
CREATE TABLE IF NOT EXISTS [manemp] ([numero] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [nome] TEXT(40) NOT NULL, [endereco] TEXT(40) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(35) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [cxpostal] TEXT(5) NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [ramal] TEXT(4) NOT NULL, [contato] TEXT(22) NOT NULL, [ddd1] TEXT(4) NOT NULL, [telefone1] TEXT(9) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(22) NOT NULL, [dddfax] TEXT(4) NOT NULL, [telefax] TEXT(9) NOT NULL, [pessoa] TEXT(1) NOT NULL, [cgc] TEXT(18) NOT NULL, [inscr] TEXT(15) NOT NULL, [cusfrete] REAL NOT NULL, [media] REAL NOT NULL, [nivel1] REAL NOT NULL, [nivel2] REAL NOT NULL, [nivel3] REAL NOT NULL, [nivel4] REAL NOT NULL, [nivel5] REAL NOT NULL, [nivel6] REAL NOT NULL, [nivel7] REAL NOT NULL, [nivel8] REAL NOT NULL, [nivel9] REAL NOT NULL, [reduzido] TEXT(1) NOT NULL, [bate] REAL NOT NULL, [posi] REAL NOT NULL, [lanc] REAL NOT NULL, [co01] REAL NOT NULL, [co02] REAL NOT NULL, [co03] REAL NOT NULL, [co04] REAL NOT NULL, [co05] REAL NOT NULL, [co06] REAL NOT NULL, [co07] REAL NOT NULL, [co08] REAL NOT NULL, [co09] REAL NOT NULL, [co10] REAL NOT NULL, [jucespc] TEXT(15) NOT NULL, [jucespd] SHORTDATE NOT NULL, [imunici] TEXT(15) NOT NULL, [pedcom] REAL NOT NULL, [objlin1] TEXT(78) NOT NULL, [objlin2] TEXT(78) NOT NULL, [objlin3] TEXT(78) NOT NULL, [objlin4] TEXT(78) NOT NULL, [objlin5] TEXT(78) NOT NULL, [dataub] SHORTDATE NOT NULL, [dataup] SHORTDATE NOT NULL, [datae] SHORTDATE NOT NULL, [reccom] REAL NOT NULL, [rnc] REAL NOT NULL, [racf] REAL NOT NULL, [crm] REAL NOT NULL, [contma01] TEXT(80) NOT NULL, [contmb01] TEXT(80) NOT NULL, [contma01d] TEXT(80) NOT NULL, [contmb01d] TEXT(80) NOT NULL, [perpis] REAL NOT NULL, [perfin] REAL NOT NULL, [site] TEXT(30) NOT NULL, [email] TEXT(30) NOT NULL, [respf] TEXT(30) NOT NULL, [cargor] TEXT(30) NOT NULL, [codempmig] TEXT(2) NOT NULL, [imgcon] TEXT(8) NOT NULL);

-- Tabela: manhel
CREATE TABLE IF NOT EXISTS [manhel] ([dbf] TEXT(8) NOT NULL, [campo] TEXT(10) NOT NULL, [dado] TEXT(40) NOT NULL, [arquivo] TEXT(12) NOT NULL, [descricao] TEXT(2147483647) NOT NULL, [seq] REAL NOT NULL, [prelan] TEXT(20) NOT NULL, [condicao] TEXT(20) NOT NULL);

-- �ndice: idx_manemp_manemp
CREATE INDEX IF NOT EXISTS [idx_manemp_manemp] ON [manemp] ([numero]);

-- �ndice: idx_manhel
CREATE INDEX IF NOT EXISTS [idx_manhel] ON [manhel] ([dbf], [campo]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
