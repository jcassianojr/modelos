--
-- Arquivo gerado com SQLiteStudio v3.4.4 em ter ago 6 17:31:58 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: agenda
CREATE TABLE IF NOT EXISTS [agenda] ([cddata] SHORTDATE NOT NULL, [obs1] TEXT(60) NOT NULL, [obs2] TEXT(60) NOT NULL, [obs3] TEXT(60) NOT NULL, [obs4] TEXT(60) NOT NULL, [obs5] TEXT(60) NOT NULL, [obs6] TEXT(60) NOT NULL, [obs7] TEXT(60) NOT NULL, [obs8] TEXT(60) NOT NULL);

-- Tabela: apucfo
CREATE TABLE IF NOT EXISTS [apucfo] ([cfo] TEXT(3) NOT NULL, [cfonew] TEXT(4) NOT NULL, [subcfo] TEXT(1) NOT NULL, [descricao] TEXT(40) NOT NULL, [contabil] REAL NOT NULL, [base] REAL NOT NULL, [valor] REAL NOT NULL, [isenta] REAL NOT NULL, [outra] REAL NOT NULL, [obs] REAL NOT NULL);

-- Tabela: apucfouf
CREATE TABLE IF NOT EXISTS [apucfouf] ([cfo] TEXT(3) NOT NULL, [cfonew] TEXT(4) NOT NULL, [subcfo] TEXT(1) NOT NULL, [uf] TEXT(2) NOT NULL, [descricao] TEXT(40) NOT NULL, [contabil] REAL NOT NULL, [base] REAL NOT NULL, [valor] REAL NOT NULL, [isenta] REAL NOT NULL, [outra] REAL NOT NULL, [obs] REAL NOT NULL, [ufgia] TEXT(2) NOT NULL);

-- Tabela: apucfozf
CREATE TABLE IF NOT EXISTS [apucfozf] ([nf] REAL NOT NULL, [data] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [cnpj] TEXT(18) NOT NULL, [codmun] TEXT(5) NOT NULL);

-- Tabela: apuita
CREATE TABLE IF NOT EXISTS [apuita] ([mes] REAL NOT NULL, [ano] REAL NOT NULL, [saldo] REAL NOT NULL);

-- Tabela: apura
CREATE TABLE IF NOT EXISTS [apura] ([fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [grupoemp] TEXT(12) NOT NULL, [prod] REAL NOT NULL, [ferra] REAL NOT NULL, [moprod] REAL NOT NULL, [moferra] REAL NOT NULL, [serv] REAL NOT NULL, [totalmer] REAL NOT NULL, [porcento] REAL NOT NULL, [total] REAL NOT NULL, [mes] REAL NOT NULL, [prod2] REAL NOT NULL, [ferra2] REAL NOT NULL, [moprod2] REAL NOT NULL, [moferra2] REAL NOT NULL, [serv2] REAL NOT NULL, [totdev] REAL NOT NULL, [totdevnf] REAL NOT NULL);

-- Tabela: apura2
CREATE TABLE IF NOT EXISTS [apura2] ([fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [grupoemp] TEXT(12) NOT NULL, [prod] REAL NOT NULL, [ferra] REAL NOT NULL, [moprod] REAL NOT NULL, [moferra] REAL NOT NULL, [serv] REAL NOT NULL, [totalmer] REAL NOT NULL, [porcento] REAL NOT NULL, [total] REAL NOT NULL, [mes] REAL NOT NULL, [prod2] REAL NOT NULL, [ferra2] REAL NOT NULL, [moprod2] REAL NOT NULL, [moferra2] REAL NOT NULL, [serv2] REAL NOT NULL, [totdev] REAL NOT NULL, [totdevnf] REAL NOT NULL, [abadev] REAL NOT NULL, [aba] REAL NOT NULL, [dev] REAL NOT NULL);

-- Tabela: apura2c
CREATE TABLE IF NOT EXISTS [apura2c] ([fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [grupoemp] TEXT(12) NOT NULL, [prod] REAL NOT NULL, [ferra] REAL NOT NULL, [moprod] REAL NOT NULL, [moferra] REAL NOT NULL, [serv] REAL NOT NULL, [totalmer] REAL NOT NULL, [porcento] REAL NOT NULL, [total] REAL NOT NULL, [mes] REAL NOT NULL, [prod2] REAL NOT NULL, [ferra2] REAL NOT NULL, [moprod2] REAL NOT NULL, [moferra2] REAL NOT NULL, [serv2] REAL NOT NULL, [totdev] REAL NOT NULL, [totdevnf] REAL NOT NULL, [abadev] REAL NOT NULL, [aba] REAL NOT NULL, [dev] REAL NOT NULL);

-- Tabela: apura5
CREATE TABLE IF NOT EXISTS [apura5] ([cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [grupo] TEXT(12) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [icm] REAL NOT NULL, [parti] REAL NOT NULL, [pplan] REAL NOT NULL, [pplanl] TEXT(1) NOT NULL, [ppcal] REAL NOT NULL, [qtdde] REAL NOT NULL, [valormer] REAL NOT NULL, [valortot] REAL NOT NULL, [precom] REAL NOT NULL, [percli] REAL NOT NULL, [perluc] REAL NOT NULL, [valluc] REAL NOT NULL, [difluc] REAL NOT NULL, [subger] TEXT(2) NOT NULL, [clitotper] REAL NOT NULL, [clitotval] REAL NOT NULL);

-- Tabela: apura5a
CREATE TABLE IF NOT EXISTS [apura5a] ([cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [valortot] REAL NOT NULL, [percli] REAL NOT NULL, [perpro] REAL NOT NULL, [intperc] REAL NOT NULL, [tgrupo] TEXT(1) NOT NULL, [lexporta] BIT NOT NULL, [valorexp] REAL NOT NULL, [subger] TEXT(2) NOT NULL);

-- Tabela: apura5b
CREATE TABLE IF NOT EXISTS [apura5b] ([cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [parti] REAL NOT NULL, [pplan] REAL NOT NULL, [qtdde] REAL NOT NULL, [valormer] REAL NOT NULL, [valortot] REAL NOT NULL, [precom] REAL NOT NULL, [percli] REAL NOT NULL, [intcom] REAL NOT NULL, [intcli] REAL NOT NULL, [junto] TEXT(40) NOT NULL);

-- Tabela: apura5d
CREATE TABLE IF NOT EXISTS [apura5d] ([junto] TEXT(40) NOT NULL, [perluc] REAL NOT NULL, [intper] REAL NOT NULL);

-- Tabela: apuser
CREATE TABLE IF NOT EXISTS [apuser] ([cliente] REAL NOT NULL, [ano] REAL NOT NULL, [mes] REAL NOT NULL, [valor] REAL NOT NULL, [semnota] TEXT(1) NOT NULL);

-- Tabela: cnab400r
CREATE TABLE IF NOT EXISTS [cnab400r] ([titemp] TEXT(25) NOT NULL, [titban] TEXT(20) NOT NULL, [codreg] TEXT(3) NOT NULL, [indope] TEXT(24) NOT NULL, [codcar] TEXT(2) NOT NULL, [codoco] TEXT(2) NOT NULL, [dataoco] SHORTDATE NOT NULL, [seunum] TEXT(10) NOT NULL, [dataven] SHORTDATE NOT NULL, [valtit] REAL NOT NULL, [codbco] TEXT(3) NOT NULL, [agcbco] TEXT(5) NOT NULL, [esptit] TEXT(2) NOT NULL, [valdep] REAL NOT NULL, [valiof] REAL NOT NULL, [valabt] REAL NOT NULL, [valdes] REAL NOT NULL, [valpag] REAL NOT NULL, [valjur] REAL NOT NULL, [valmul] REAL NOT NULL, [codmod] TEXT(1) NOT NULL, [credata] SHORTDATE NOT NULL, [seqarq] REAL NOT NULL, [valdepout] REAL NOT NULL, [valjuratr] REAL NOT NULL, [motpro] TEXT(1) NOT NULL, [motreg01] TEXT(2) NOT NULL, [motreg02] TEXT(2) NOT NULL, [motreg03] TEXT(2) NOT NULL, [motreg04] TEXT(2) NOT NULL, [motreg05] TEXT(2) NOT NULL, [liqdata] SHORTDATE NOT NULL);

-- Tabela: dipam
CREATE TABLE IF NOT EXISTS [dipam] ([fornecedo] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [classipi] TEXT(14) NOT NULL, [valormer] REAL NOT NULL, [nome] TEXT(40) NOT NULL);

-- Tabela: dipam2
CREATE TABLE IF NOT EXISTS [dipam2] ([fornecedo] REAL NOT NULL, [valormer] REAL NOT NULL);

-- Tabela: dipam3
CREATE TABLE IF NOT EXISTS [dipam3] ([classipi] TEXT(14) NOT NULL, [valormer] REAL NOT NULL, [nome] TEXT(40) NOT NULL);

-- Tabela: eti
CREATE TABLE IF NOT EXISTS [eti] ([codigo] TEXT(12) NOT NULL, [nome] TEXT(100) NOT NULL, [nom2] TEXT(10) NOT NULL, [camada] TEXT(50) NOT NULL, [salto] TEXT(50) NOT NULL, [espe] TEXT(50) NOT NULL, [supe] TEXT(50) NOT NULL, [ccm] REAL NOT NULL, [ultprc] REAL NOT NULL, [ultund] TEXT(2) NOT NULL, [ultdata] SHORTDATE NOT NULL, [redicm] REAL NOT NULL, [rev] REAL NOT NULL, [revdata] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [custf] REAL NOT NULL, [codmw] TEXT(3) NOT NULL, [leadtime] REAL NOT NULL, [cognome] TEXT(10) NOT NULL, [piscon] TEXT(1) NOT NULL, [ninterno] REAL NOT NULL);

-- Tabela: fo_chis
CREATE TABLE IF NOT EXISTS [fo_chis] ([numero] REAL NOT NULL, [nome] TEXT(40) NOT NULL, [admissao] SHORTDATE NOT NULL, [demissao] SHORTDATE NOT NULL, [arquivo] TEXT(20) NOT NULL, [obs] TEXT(40) NOT NULL);

-- Tabela: irrf
CREATE TABLE IF NOT EXISTS [irrf] ([cpf] TEXT(18) NOT NULL, [nome] TEXT(40) NOT NULL, [v401] REAL NOT NULL, [v402] REAL NOT NULL, [v403] REAL NOT NULL, [v404] REAL NOT NULL, [v405] REAL NOT NULL, [v501] REAL NOT NULL, [v502] REAL NOT NULL, [v503] REAL NOT NULL, [v504] REAL NOT NULL, [v605] REAL NOT NULL, [v606] REAL NOT NULL, [v611] REAL NOT NULL, [v602] REAL NOT NULL);

-- Tabela: irrf01
CREATE TABLE IF NOT EXISTS [irrf01] ([numero] REAL NOT NULL, [darf] TEXT(4) NOT NULL, [documento] TEXT(20) NOT NULL, [ano] REAL NOT NULL, [cgc] TEXT(18) NOT NULL, [pessoa] TEXT(1) NOT NULL, [nome] TEXT(40) NOT NULL, [endereco] TEXT(40) NOT NULL, [cidade] TEXT(30) NOT NULL, [estado] TEXT(2) NOT NULL, [bairro] TEXT(30) NOT NULL, [cep] TEXT(9) NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [contato] TEXT(12) NOT NULL);

-- Tabela: irrf02
CREATE TABLE IF NOT EXISTS [irrf02] ([numero] REAL NOT NULL, [item] REAL NOT NULL, [mes] REAL NOT NULL, [darf] TEXT(4) NOT NULL, [natureza] TEXT(20) NOT NULL, [renda] REAL NOT NULL, [aliquota] REAL NOT NULL, [irrf] REAL NOT NULL);

-- Tabela: ma01
CREATE TABLE IF NOT EXISTS [ma01] ([numero] REAL NOT NULL, [cnumero] TEXT(8) NOT NULL, [cognome] TEXT(12) NOT NULL, [nome] TEXT(50) NOT NULL, [endereco] TEXT(40) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(30) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [cxpostal] TEXT(5) NOT NULL, [ddd] TEXT(2) NOT NULL, [telefone] TEXT(12) NOT NULL, [ramal] TEXT(4) NOT NULL, [contato] TEXT(22) NOT NULL, [ddd1] TEXT(2) NOT NULL, [telefone1] TEXT(12) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(22) NOT NULL, [dddfax] TEXT(2) NOT NULL, [telefax] TEXT(12) NOT NULL, [cgc] TEXT(18) NOT NULL, [inscr] TEXT(18) NOT NULL, [vendedor] TEXT(5) NOT NULL, [codigo] TEXT(15) NOT NULL, [transporte] REAL NOT NULL, [zona] TEXT(6) NOT NULL, [endereco2] TEXT(40) NOT NULL, [bairro2] TEXT(30) NOT NULL, [cidade2] TEXT(30) NOT NULL, [estado2] TEXT(2) NOT NULL, [cep2] TEXT(9) NOT NULL, [ddd2] TEXT(2) NOT NULL, [telefone2] TEXT(12) NOT NULL, [ramal2] TEXT(4) NOT NULL, [contato2] TEXT(22) NOT NULL, [dddfax2] TEXT(2) NOT NULL, [telefax2] TEXT(12) NOT NULL, [condpag] TEXT(2) NOT NULL, [tipocob] TEXT(2) NOT NULL, [conceito] TEXT(10) NOT NULL, [limite] REAL NOT NULL, [limiteacu] REAL NOT NULL, [nome3] TEXT(50) NOT NULL, [endereco3] TEXT(40) NOT NULL, [bairro3] TEXT(30) NOT NULL, [cidade3] TEXT(30) NOT NULL, [estado3] TEXT(2) NOT NULL, [cep3] TEXT(9) NOT NULL, [ddd3] TEXT(2) NOT NULL, [telefone3] TEXT(12) NOT NULL, [ramal3] TEXT(4) NOT NULL, [contato3] TEXT(22) NOT NULL, [dddfax3] TEXT(3) NOT NULL, [telefax3] TEXT(9) NOT NULL, [cgc3] TEXT(18) NOT NULL, [inscr3] TEXT(16) NOT NULL, [totdev] REAL NOT NULL, [ramo] TEXT(2) NOT NULL, [dtcad] SHORTDATE NOT NULL, [dt1com] SHORTDATE NOT NULL, [vl1cru] REAL NOT NULL, [vl1dol] REAL NOT NULL, [dtmcom] SHORTDATE NOT NULL, [vlmcru] REAL NOT NULL, [vlmdol] REAL NOT NULL, [dtucom] SHORTDATE NOT NULL, [vlucru] REAL NOT NULL, [vludol] REAL NOT NULL, [diaatra] REAL NOT NULL, [vlacru] REAL NOT NULL, [vladol] REAL NOT NULL, [pessoa] TEXT(1) NOT NULL, [ctacontb] TEXT(11) NOT NULL, [zonarot] TEXT(10) NOT NULL, [zonaseq] REAL NOT NULL, [km] REAL NOT NULL, [condconc] TEXT(2) NOT NULL, [grupoemp] TEXT(12) NOT NULL, [codconc] TEXT(2) NOT NULL, [comprador] TEXT(5) NOT NULL, [lucro] REAL NOT NULL, [tabcob] TEXT(2) NOT NULL, [tabesp] TEXT(1) NOT NULL, [doca] TEXT(14) NOT NULL, [planta] TEXT(3) NOT NULL, [sisco] TEXT(5) NOT NULL, [mo02lista] REAL NOT NULL, [contacre] TEXT(11) NOT NULL, [contadeb] TEXT(11) NOT NULL, [contrcre] REAL NOT NULL, [contrdeb] REAL NOT NULL, [tipoger] TEXT(2) NOT NULL, [subger] TEXT(2) NOT NULL, [padhis] TEXT(3) NOT NULL, [geraae] TEXT(1) NOT NULL, [temicms] TEXT(1) NOT NULL, [temipi] TEXT(1) NOT NULL, [imunicipi] TEXT(20) NOT NULL, [cgccomp] TEXT(18) NOT NULL, [clicomp] TEXT(15) NOT NULL, [clientr] TEXT(15) NOT NULL, [ativo] TEXT(1) NOT NULL, [bcocob] REAL NOT NULL, [tempisfin] TEXT(1) NOT NULL, [email] TEXT(50) NOT NULL, [codigoint] TEXT(20) NOT NULL, [cnae] TEXT(7) NOT NULL, [suframa] TEXT(9) NOT NULL);

-- Tabela: mala
CREATE TABLE IF NOT EXISTS [mala] ([numero] REAL NOT NULL, [nome] TEXT(50) NOT NULL, [endlog] TEXT(12) NOT NULL, [endrua] TEXT(49) NOT NULL, [endnum] TEXT(5) NOT NULL, [endereco] TEXT(68) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(35) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [ramal] TEXT(4) NOT NULL, [datacontat] SHORTDATE NOT NULL, [contato] TEXT(10) NOT NULL, [imprime] TEXT(1) NOT NULL, [obs] TEXT(2147483647) NOT NULL);

-- Tabela: malaconf
CREATE TABLE IF NOT EXISTS [malaconf] ([codigo] REAL NOT NULL, [descricao] TEXT(60) NOT NULL, [dbf] TEXT(8) NOT NULL);

-- Tabela: manerr
CREATE TABLE IF NOT EXISTS [manerr] ([usuario] TEXT(10) NOT NULL, [data] SHORTDATE NOT NULL, [hora] TEXT(8) NOT NULL, [erro] TEXT(40) NOT NULL, [opr] TEXT(3) NOT NULL, [arquivo] TEXT(8) NOT NULL);

-- Tabela: manivers
CREATE TABLE IF NOT EXISTS [manivers] ([nome] TEXT(30) NOT NULL, [apelido] TEXT(20) NOT NULL, [data] SHORTDATE NOT NULL, [firma] TEXT(40) NOT NULL);

-- Tabela: mb01
CREATE TABLE IF NOT EXISTS [mb01] ([cognome] TEXT(15) NOT NULL, [nome] TEXT(40) NOT NULL, [endereco] TEXT(40) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(30) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [ramal] TEXT(4) NOT NULL, [contato] TEXT(22) NOT NULL, [dddfax] TEXT(4) NOT NULL, [telefax] TEXT(9) NOT NULL, [cgc] TEXT(18) NOT NULL, [iestadual] TEXT(16) NOT NULL, [ddd1] TEXT(4) NOT NULL, [telefone1] TEXT(9) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(22) NOT NULL, [nomemat] TEXT(40) NOT NULL, [pessoa] TEXT(1) NOT NULL, [codmat] TEXT(4) NOT NULL, [ctacontb] TEXT(11) NOT NULL, [condpag] TEXT(2) NOT NULL, [vendedor] TEXT(5) NOT NULL, [banco] TEXT(3) NOT NULL, [agencia] TEXT(6) NOT NULL, [conta] TEXT(8) NOT NULL, [conceito] TEXT(2) NOT NULL, [qualifi] TEXT(12) NOT NULL, [zona] TEXT(6) NOT NULL, [tippag] TEXT(2) NOT NULL, [site] TEXT(30) NOT NULL, [email] TEXT(30) NOT NULL, [respf] TEXT(30) NOT NULL, [cargor] TEXT(30) NOT NULL, [contacre] TEXT(11) NOT NULL, [contadeb] TEXT(11) NOT NULL, [contrcre] REAL NOT NULL, [contrdeb] REAL NOT NULL, [dddpcp] TEXT(4) NOT NULL, [telpcp] TEXT(9) NOT NULL, [rampcp] TEXT(4) NOT NULL, [conpcp] TEXT(24) NOT NULL, [dddfaxpcp] TEXT(4) NOT NULL, [telfaxpcp] TEXT(9) NOT NULL, [emailpcp] TEXT(50) NOT NULL, [padhis] TEXT(3) NOT NULL, [resppcp] TEXT(30) NOT NULL, [cargopcp] TEXT(30) NOT NULL, [numero] REAL NOT NULL, [imunicipi] TEXT(20) NOT NULL, [nfsesp] TEXT(5) NOT NULL, [nfscod] TEXT(5) NOT NULL, [nfsser] TEXT(5) NOT NULL, [subramo] TEXT(3) NOT NULL, [codigoint] TEXT(15) NOT NULL, [cnae] TEXT(7) NOT NULL, [suframa] TEXT(9) NOT NULL);

-- Tabela: mc01
CREATE TABLE IF NOT EXISTS [mc01] ([numero] TEXT(5) NOT NULL, [cognome] TEXT(12) NOT NULL, [nome] TEXT(40) NOT NULL, [endereco] TEXT(40) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(35) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [ramal] TEXT(4) NOT NULL, [contato] TEXT(22) NOT NULL, [ddd1] TEXT(4) NOT NULL, [telefone1] TEXT(9) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(22) NOT NULL, [celular] TEXT(9) NOT NULL, [dddfax] TEXT(4) NOT NULL, [telefax] TEXT(9) NOT NULL, [cgc] TEXT(18) NOT NULL, [iestadual] TEXT(15) NOT NULL, [observa] TEXT(30) NOT NULL, [zona] TEXT(6) NOT NULL, [datanasc] SHORTDATE NOT NULL, [pessoa] TEXT(1) NOT NULL, [porcomis] REAL NOT NULL, [cota] REAL NOT NULL, [banco] TEXT(3) NOT NULL, [agencia] TEXT(7) NOT NULL, [conta] TEXT(12) NOT NULL, [dddbip] TEXT(4) NOT NULL, [telbip] TEXT(9) NOT NULL, [codbip] TEXT(12) NOT NULL, [vengru] TEXT(4) NOT NULL, [venhie] TEXT(2) NOT NULL);

-- Tabela: mc01r
CREATE TABLE IF NOT EXISTS [mc01r] ([numero] REAL NOT NULL, [nome] TEXT(40) NOT NULL, [cognome] TEXT(12) NOT NULL, [endereco] TEXT(40) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(35) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [ramal] TEXT(4) NOT NULL, [dddfax] TEXT(4) NOT NULL, [telefax] TEXT(9) NOT NULL, [cgc] TEXT(18) NOT NULL, [iestadual] TEXT(15) NOT NULL, [contato] TEXT(20) NOT NULL, [ddd1] TEXT(4) NOT NULL, [telefone1] TEXT(9) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(20) NOT NULL, [nomemat] TEXT(20) NOT NULL, [pessoa] TEXT(1) NOT NULL, [codmat] TEXT(4) NOT NULL, [ctacontb] TEXT(11) NOT NULL, [condpag] TEXT(2) NOT NULL, [banco] REAL NOT NULL, [agencia] TEXT(6) NOT NULL, [conta] TEXT(8) NOT NULL, [conceito] TEXT(2) NOT NULL, [qualifi] TEXT(12) NOT NULL, [tippag] TEXT(2) NOT NULL, [vendedor] TEXT(5) NOT NULL, [zona] TEXT(6) NOT NULL, [email] TEXT(30) NOT NULL, [site] TEXT(30) NOT NULL, [respf] TEXT(30) NOT NULL, [cargor] TEXT(30) NOT NULL);

-- Tabela: mc02
CREATE TABLE IF NOT EXISTS [mc02] ([numero] TEXT(5) NOT NULL, [cognome] TEXT(12) NOT NULL, [nome] TEXT(40) NOT NULL, [endereco] TEXT(40) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(35) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [ramal] TEXT(4) NOT NULL, [contato] TEXT(22) NOT NULL, [ddd1] TEXT(4) NOT NULL, [telefone1] TEXT(9) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(22) NOT NULL, [celular] TEXT(9) NOT NULL, [dddfax] TEXT(4) NOT NULL, [telefax] TEXT(9) NOT NULL, [cgc] TEXT(18) NOT NULL, [iestadual] TEXT(15) NOT NULL, [observa] TEXT(30) NOT NULL, [zona] TEXT(6) NOT NULL, [datanasc] SHORTDATE NOT NULL, [pessoa] TEXT(1) NOT NULL, [porcomis] REAL NOT NULL, [cota] REAL NOT NULL, [banco] TEXT(3) NOT NULL, [agencia] TEXT(7) NOT NULL, [conta] TEXT(12) NOT NULL, [dddbip] TEXT(4) NOT NULL, [telbip] TEXT(9) NOT NULL, [codbip] TEXT(12) NOT NULL, [vengru] TEXT(4) NOT NULL, [venhie] TEXT(2) NOT NULL);

-- Tabela: mc03
CREATE TABLE IF NOT EXISTS [mc03] ([numero] TEXT(5) NOT NULL, [cognome] TEXT(12) NOT NULL, [nome] TEXT(40) NOT NULL, [endereco] TEXT(40) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(35) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [ramal] TEXT(4) NOT NULL, [contato] TEXT(22) NOT NULL, [ddd1] TEXT(4) NOT NULL, [telefone1] TEXT(9) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(22) NOT NULL, [celular] TEXT(9) NOT NULL, [dddfax] TEXT(4) NOT NULL, [telefax] TEXT(9) NOT NULL, [cgc] TEXT(18) NOT NULL, [iestadual] TEXT(15) NOT NULL, [observa] TEXT(30) NOT NULL, [zona] TEXT(6) NOT NULL, [datanasc] SHORTDATE NOT NULL, [pessoa] TEXT(1) NOT NULL, [porcomis] REAL NOT NULL, [cota] REAL NOT NULL, [banco] TEXT(3) NOT NULL, [agencia] TEXT(7) NOT NULL, [conta] TEXT(12) NOT NULL, [dddbip] TEXT(4) NOT NULL, [telbip] TEXT(9) NOT NULL, [codbip] TEXT(12) NOT NULL, [vengru] TEXT(4) NOT NULL, [venhie] TEXT(2) NOT NULL);

-- Tabela: mc04
CREATE TABLE IF NOT EXISTS [mc04] ([numero] TEXT(5) NOT NULL, [cognome] TEXT(12) NOT NULL, [nome] TEXT(40) NOT NULL, [endereco] TEXT(40) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(35) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [ramal] TEXT(4) NOT NULL, [contato] TEXT(22) NOT NULL, [ddd1] TEXT(4) NOT NULL, [telefone1] TEXT(9) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(22) NOT NULL, [celular] TEXT(9) NOT NULL, [dddfax] TEXT(4) NOT NULL, [telefax] TEXT(9) NOT NULL, [cgc] TEXT(18) NOT NULL, [iestadual] TEXT(15) NOT NULL, [observa] TEXT(30) NOT NULL, [zona] TEXT(6) NOT NULL, [datanasc] SHORTDATE NOT NULL, [pessoa] TEXT(1) NOT NULL, [porcomis] REAL NOT NULL, [cota] REAL NOT NULL, [banco] TEXT(3) NOT NULL, [agencia] TEXT(7) NOT NULL, [conta] TEXT(12) NOT NULL, [dddbip] TEXT(4) NOT NULL, [telbip] TEXT(9) NOT NULL, [codbip] TEXT(12) NOT NULL, [vengru] TEXT(4) NOT NULL, [venhie] TEXT(2) NOT NULL);

-- Tabela: mc05
CREATE TABLE IF NOT EXISTS [mc05] ([numero] TEXT(5) NOT NULL, [cognome] TEXT(12) NOT NULL, [nome] TEXT(40) NOT NULL, [endereco] TEXT(40) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(35) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [ddd] TEXT(2) NOT NULL, [telefone] TEXT(12) NOT NULL, [ramal] TEXT(4) NOT NULL, [contato] TEXT(22) NOT NULL, [ddd1] TEXT(2) NOT NULL, [telefone1] TEXT(12) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(22) NOT NULL, [celular] TEXT(9) NOT NULL, [dddfax] TEXT(2) NOT NULL, [telefax] TEXT(12) NOT NULL, [cgc] TEXT(18) NOT NULL, [iestadual] TEXT(15) NOT NULL, [observa] TEXT(30) NOT NULL, [zona] TEXT(6) NOT NULL, [datanasc] SHORTDATE NOT NULL, [pessoa] TEXT(1) NOT NULL, [porcomis] REAL NOT NULL, [cota] REAL NOT NULL, [banco] TEXT(3) NOT NULL, [agencia] TEXT(7) NOT NULL, [conta] TEXT(12) NOT NULL, [dddbip] TEXT(2) NOT NULL, [telbip] TEXT(12) NOT NULL, [codbip] TEXT(12) NOT NULL, [vengru] TEXT(4) NOT NULL, [venhie] TEXT(2) NOT NULL, [email] TEXT(50) NOT NULL);

-- Tabela: mcarta
CREATE TABLE IF NOT EXISTS [mcarta] ([arquivo] TEXT(8) NOT NULL, [nome] TEXT(50) NOT NULL, [setup] TEXT(20) NOT NULL, [marsup] REAL NOT NULL, [marinf] REAL NOT NULL, [mardir] REAL NOT NULL, [maresq] REAL NOT NULL, [marcol] REAL NOT NULL, [marlin] REAL NOT NULL);

-- Tabela: mcopia
CREATE TABLE IF NOT EXISTS [mcopia] ([nome] TEXT(6) NOT NULL, [diretorio] TEXT(50) NOT NULL, [descricao] TEXT(50) NOT NULL, [arq01] TEXT(12) NOT NULL, [arq02] TEXT(12) NOT NULL, [arq03] TEXT(12) NOT NULL, [arq04] TEXT(12) NOT NULL, [arq05] TEXT(12) NOT NULL, [arq06] TEXT(12) NOT NULL, [arq07] TEXT(12) NOT NULL, [arq08] TEXT(12) NOT NULL, [arq09] TEXT(12) NOT NULL, [arq10] TEXT(12) NOT NULL, [arq11] TEXT(12) NOT NULL, [arq12] TEXT(12) NOT NULL, [arq13] TEXT(12) NOT NULL, [arq14] TEXT(12) NOT NULL, [arq15] TEXT(12) NOT NULL, [arq16] TEXT(12) NOT NULL, [arq17] TEXT(12) NOT NULL, [arq18] TEXT(12) NOT NULL, [arq19] TEXT(12) NOT NULL, [arq20] TEXT(12) NOT NULL, [arq21] TEXT(12) NOT NULL, [arq22] TEXT(12) NOT NULL, [arq23] TEXT(12) NOT NULL, [arq24] TEXT(12) NOT NULL, [arq25] TEXT(12) NOT NULL, [arq26] TEXT(12) NOT NULL, [arq27] TEXT(12) NOT NULL, [arq28] TEXT(12) NOT NULL, [arq29] TEXT(12) NOT NULL, [arq30] TEXT(12) NOT NULL, [arq31] TEXT(12) NOT NULL, [arq32] TEXT(12) NOT NULL, [arq33] TEXT(12) NOT NULL, [arq34] TEXT(12) NOT NULL, [arq35] TEXT(12) NOT NULL, [arq36] TEXT(12) NOT NULL, [arq37] TEXT(12) NOT NULL, [arq38] TEXT(12) NOT NULL, [arq39] TEXT(12) NOT NULL, [arq40] TEXT(12) NOT NULL);

-- Tabela: md01
CREATE TABLE IF NOT EXISTS [md01] ([codigo] TEXT(12) NOT NULL, [nome] TEXT(40) NOT NULL, [tipo] TEXT(1) NOT NULL, [grupo] TEXT(2) NOT NULL);

-- Tabela: md02
CREATE TABLE IF NOT EXISTS [md02] ([codigo] TEXT(12) NOT NULL, [codigo1] TEXT(12) NOT NULL, [descricao] TEXT(100) NOT NULL, [data] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [variacao] REAL NOT NULL, [acumulado] REAL NOT NULL, [acumulanu] REAL NOT NULL, [acumugera] REAL NOT NULL, [codigo2] TEXT(12) NOT NULL, [codigo3] TEXT(12) NOT NULL);

-- Tabela: md03
CREATE TABLE IF NOT EXISTS [md03] ([codigo] TEXT(2) NOT NULL, [classific] TEXT(14) NOT NULL, [descricao] TEXT(50) NOT NULL, [aliquota] REAL NOT NULL, [aliquotar] REAL NOT NULL, [aliquotai] REAL NOT NULL, [dsta] TEXT(1) NOT NULL, [dipipi] TEXT(1) NOT NULL, [dipicm] TEXT(1) NOT NULL);

-- Tabela: md06
CREATE TABLE IF NOT EXISTS [md06] ([mes] REAL NOT NULL, [ano] REAL NOT NULL, [fin01] REAL NOT NULL, [fin02] REAL NOT NULL, [fin03] REAL NOT NULL, [fin04] REAL NOT NULL, [fin05] REAL NOT NULL, [fin06] REAL NOT NULL, [fin07] REAL NOT NULL, [fin08] REAL NOT NULL, [fin09] REAL NOT NULL, [fin10] REAL NOT NULL, [fin11] REAL NOT NULL, [fin12] REAL NOT NULL, [fin13] REAL NOT NULL, [fin14] REAL NOT NULL, [fin15] REAL NOT NULL, [fin16] REAL NOT NULL, [fin17] REAL NOT NULL, [fin18] REAL NOT NULL, [fin19] REAL NOT NULL, [fin20] REAL NOT NULL, [fin21] REAL NOT NULL, [fin22] REAL NOT NULL, [fin23] REAL NOT NULL, [fin24] REAL NOT NULL, [fin25] REAL NOT NULL, [fin26] REAL NOT NULL, [fin27] REAL NOT NULL, [fin28] REAL NOT NULL, [fin29] REAL NOT NULL, [fin30] REAL NOT NULL, [fin31] REAL NOT NULL, [fin32] REAL NOT NULL, [fin33] REAL NOT NULL, [fin34] REAL NOT NULL, [fin35] REAL NOT NULL, [fin36] REAL NOT NULL, [fin37] REAL NOT NULL, [fin38] REAL NOT NULL, [fin39] REAL NOT NULL, [fin40] REAL NOT NULL, [fin41] REAL NOT NULL, [fin42] REAL NOT NULL, [fin43] REAL NOT NULL, [fin44] REAL NOT NULL, [fin45] REAL NOT NULL, [fin46] REAL NOT NULL, [fin47] REAL NOT NULL, [fin48] REAL NOT NULL, [fin49] REAL NOT NULL, [fin50] REAL NOT NULL, [fin51] REAL NOT NULL, [fin52] REAL NOT NULL, [fin53] REAL NOT NULL, [fin54] REAL NOT NULL, [fin55] REAL NOT NULL, [fin56] REAL NOT NULL, [fin57] REAL NOT NULL, [fin58] REAL NOT NULL, [fin59] REAL NOT NULL, [fin60] REAL NOT NULL);

-- Tabela: md07
CREATE TABLE IF NOT EXISTS [md07] ([unidade] TEXT(3) NOT NULL, [uniddes] TEXT(60) NOT NULL, [uniddec] TEXT(1) NOT NULL);

-- Tabela: md08
CREATE TABLE IF NOT EXISTS [md08] ([sedext] TEXT(1) NOT NULL, [kilo] REAL NOT NULL, [rj] REAL NOT NULL, [sp] REAL NOT NULL, [mt] REAL NOT NULL, [rs] REAL NOT NULL, [ac] REAL NOT NULL, [al] REAL NOT NULL, [ap] REAL NOT NULL, [am] REAL NOT NULL, [ba] REAL NOT NULL, [ce] REAL NOT NULL, [df] REAL NOT NULL, [es] REAL NOT NULL, [go] REAL NOT NULL, [ma] REAL NOT NULL, [mg] REAL NOT NULL, [ms] REAL NOT NULL, [pa] REAL NOT NULL, [pb] REAL NOT NULL, [pr] REAL NOT NULL, [pe] REAL NOT NULL, [pi] REAL NOT NULL, [rn] REAL NOT NULL, [rr] REAL NOT NULL, [ro] REAL NOT NULL, [sc] REAL NOT NULL, [se] REAL NOT NULL, [to] REAL NOT NULL, [xx] REAL NOT NULL, [fn] REAL NOT NULL);

-- Tabela: md09
CREATE TABLE IF NOT EXISTS [md09] ([codigo] TEXT(4) NOT NULL, [descricao] TEXT(50) NOT NULL);

-- Tabela: mdchedev
CREATE TABLE IF NOT EXISTS [mdchedev] ([codigo] TEXT(2) NOT NULL, [nome] TEXT(255) NOT NULL);

-- Tabela: mdmoeda
CREATE TABLE IF NOT EXISTS [mdmoeda] ([codigo] TEXT(3) NOT NULL, [descricao] TEXT(30) NOT NULL, [pais] TEXT(3) NOT NULL, [paisnome] TEXT(35) NOT NULL, [simbolo] TEXT(5) NOT NULL);

-- Tabela: me01
CREATE TABLE IF NOT EXISTS [me01] ([numero] TEXT(4) NOT NULL, [contabil] TEXT(8) NOT NULL, [nome] TEXT(40) NOT NULL, [localiza] TEXT(3) NOT NULL, [numfab] TEXT(8) NOT NULL, [fabricante] TEXT(20) NOT NULL, [modelo] TEXT(20) NOT NULL, [motorcv] REAL NOT NULL, [kwh] REAL NOT NULL, [especifi] TEXT(100) NOT NULL, [especifi1] TEXT(100) NOT NULL, [especifi2] TEXT(100) NOT NULL, [especifi3] TEXT(100) NOT NULL, [especifi4] TEXT(100) NOT NULL, [especifi5] TEXT(100) NOT NULL, [especifi6] TEXT(100) NOT NULL, [setor] TEXT(10) NOT NULL, [tipo] TEXT(1) NOT NULL, [qtde] REAL NOT NULL, [ano] REAL NOT NULL, [nrforne] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [data] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [tabela] TEXT(12) NOT NULL, [valor_conv] REAL NOT NULL, [meses] REAL NOT NULL, [observa] TEXT(40) NOT NULL, [grupo] TEXT(3) NOT NULL, [cht] TEXT(1) NOT NULL, [chm] REAL NOT NULL, [chs] REAL NOT NULL, [ch1] REAL NOT NULL, [ch2] REAL NOT NULL, [ch3] REAL NOT NULL, [ch4] REAL NOT NULL, [ch5] REAL NOT NULL, [ch6] REAL NOT NULL, [ch7] REAL NOT NULL, [codmp01] TEXT(12) NOT NULL, [ativa] TEXT(1) NOT NULL, [setcod] TEXT(1) NOT NULL, [apuefi] TEXT(1) NOT NULL, [aplicacao] TEXT(20) NOT NULL, [situacao] TEXT(1) NOT NULL, [dataatv] SHORTDATE NOT NULL, [datades] SHORTDATE NOT NULL, [datadev] SHORTDATE NOT NULL, [dataout] SHORTDATE NOT NULL, [qtdebase] REAL NOT NULL, [qtdesaldo] REAL NOT NULL, [qtdeped] REAL NOT NULL, [qtdeurg] REAL NOT NULL, [datasaldo] SHORTDATE NOT NULL, [dataped] SHORTDATE NOT NULL, [dataurg] SHORTDATE NOT NULL, [qtdetot] REAL NOT NULL, [hrbas] REAL NOT NULL, [hrtot] REAL NOT NULL, [hrpre] REAL NOT NULL, [hrurg] REAL NOT NULL, [hrsal] REAL NOT NULL, [dathped] SHORTDATE NOT NULL, [dathurg] SHORTDATE NOT NULL, [dathsal] SHORTDATE NOT NULL, [grupoutl] TEXT(3) NOT NULL, [prever] TEXT(1) NOT NULL, [lubri] BIT NOT NULL, [lub01] BIT NOT NULL, [lub02] BIT NOT NULL, [lub03] BIT NOT NULL, [lub04] BIT NOT NULL, [lub05] BIT NOT NULL, [vdbas] REAL NOT NULL, [vdpre] REAL NOT NULL, [vdurg] REAL NOT NULL, [vddpre] SHORTDATE NOT NULL, [vddurg] SHORTDATE NOT NULL, [vdhbas] REAL NOT NULL, [vdhpre] REAL NOT NULL, [vdhurg] REAL NOT NULL, [vdhdpre] SHORTDATE NOT NULL, [vdhdurg] SHORTDATE NOT NULL, [propria] TEXT(1) NOT NULL, [naempresa] TEXT(1) NOT NULL, [visualnum] REAL NOT NULL, [visualnom] TEXT(40) NOT NULL, [visualobs] TEXT(100) NOT NULL, [meda] REAL NOT NULL, [medb] REAL NOT NULL, [medc] REAL NOT NULL, [medd] REAL NOT NULL, [medh] REAL NOT NULL, [peso] REAL NOT NULL, [femea] REAL NOT NULL);

-- Tabela: me01inv
CREATE TABLE IF NOT EXISTS [me01inv] ([contabil] TEXT(8) NOT NULL, [nome] TEXT(40) NOT NULL, [nrforne] REAL NOT NULL, [cognome] TEXT(12) NOT NULL);

-- Tabela: me02
CREATE TABLE IF NOT EXISTS [me02] ([numero] TEXT(4) NOT NULL, [seq] REAL NOT NULL, [codmp01] TEXT(12) NOT NULL, [nommp01] TEXT(30) NOT NULL);

-- Tabela: me03
CREATE TABLE IF NOT EXISTS [me03] ([numero] TEXT(4) NOT NULL, [data] SHORTDATE NOT NULL, [estqini] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqsal] REAL NOT NULL);

-- Tabela: me03a
CREATE TABLE IF NOT EXISTS [me03a] ([numero] TEXT(4) NOT NULL, [of] REAL NOT NULL, [data] SHORTDATE NOT NULL, [qtdde] REAL NOT NULL, [codmp01] TEXT(12) NOT NULL, [codres] TEXT(1) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [qtdpec] REAL NOT NULL);

-- Tabela: me04
CREATE TABLE IF NOT EXISTS [me04] ([codigo] TEXT(8) NOT NULL, [cadtip] TEXT(1) NOT NULL, [tipo] TEXT(30) NOT NULL, [marca] TEXT(20) NOT NULL, [capaci] TEXT(30) NOT NULL, [divi] TEXT(10) NOT NULL, [nomtipo] TEXT(30) NOT NULL, [codtipo] TEXT(3) NOT NULL, [codfor] REAL NOT NULL, [cogfor] TEXT(12) NOT NULL, [compra] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [situacao] TEXT(1) NOT NULL, [datauso] SHORTDATE NOT NULL, [datafim] SHORTDATE NOT NULL, [norma] TEXT(30) NOT NULL, [aplic] TEXT(30) NOT NULL, [tipcal] TEXT(1) NOT NULL, [calibrar] REAL NOT NULL, [ativo] TEXT(8) NOT NULL, [erroadm] TEXT(15) NOT NULL, [obs01] TEXT(70) NOT NULL, [obs02] TEXT(70) NOT NULL, [obs03] TEXT(70) NOT NULL, [modelo] TEXT(20) NOT NULL, [calult] SHORTDATE NOT NULL, [calpro] SHORTDATE NOT NULL, [dime] TEXT(40) NOT NULL, [material] TEXT(30) NOT NULL, [cara] TEXT(50) NOT NULL);

-- Tabela: me04c
CREATE TABLE IF NOT EXISTS [me04c] ([occ] REAL NOT NULL, [codigo] TEXT(10) NOT NULL, [data] SHORTDATE NOT NULL, [codfor] REAL NOT NULL, [cogfor] TEXT(12) NOT NULL, [certifi] TEXT(10) NOT NULL);

-- Tabela: me04ci
CREATE TABLE IF NOT EXISTS [me04ci] ([occ] REAL NOT NULL, [item] REAL NOT NULL, [especi] TEXT(30) NOT NULL, [enctr] TEXT(10) NOT NULL, [desvio] TEXT(10) NOT NULL, [inctot] TEXT(10) NOT NULL, [laudo] TEXT(2) NOT NULL);

-- Tabela: me04d
CREATE TABLE IF NOT EXISTS [me04d] ([ocd] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [motivo] TEXT(1) NOT NULL, [obs01] TEXT(50) NOT NULL, [obs02] TEXT(50) NOT NULL, [obs03] TEXT(50) NOT NULL, [invalida] TEXT(1) NOT NULL, [verifi] TEXT(20) NOT NULL, [inspecao] TEXT(1) NOT NULL, [codigos] TEXT(40) NOT NULL, [clinome] TEXT(40) NOT NULL, [nf] TEXT(30) NOT NULL, [acli01] TEXT(50) NOT NULL, [acli02] TEXT(50) NOT NULL, [incide] TEXT(1) NOT NULL, [freq1] TEXT(20) NOT NULL, [freq2] TEXT(20) NOT NULL, [acor01] TEXT(50) NOT NULL, [acor02] TEXT(50) NOT NULL, [acor03] TEXT(50) NOT NULL, [acor04] TEXT(50) NOT NULL, [respon] TEXT(30) NOT NULL, [dataocd] SHORTDATE NOT NULL);

-- Tabela: me04r
CREATE TABLE IF NOT EXISTS [me04r] ([numero] REAL NOT NULL, [codigo] TEXT(8) NOT NULL, [codoper] REAL NOT NULL, [saida] SHORTDATE NOT NULL, [horasai] REAL NOT NULL, [devolucao] SHORTDATE NOT NULL, [horadev] REAL NOT NULL, [setor] TEXT(3) NOT NULL, [area] TEXT(2) NOT NULL);

-- Tabela: me05
CREATE TABLE IF NOT EXISTS [me05] ([ddd] TEXT(4) NOT NULL, [numero] TEXT(9) NOT NULL, [tipot] TEXT(12) NOT NULL, [hexa] TEXT(12) NOT NULL, [modelo] TEXT(30) NOT NULL);

-- Tabela: metiq
CREATE TABLE IF NOT EXISTS [metiq] ([codigo] TEXT(6) NOT NULL, [nome] TEXT(50) NOT NULL, [linha1] TEXT(75) NOT NULL, [linha2] TEXT(75) NOT NULL, [linha3] TEXT(75) NOT NULL, [linha4] TEXT(75) NOT NULL, [linha5] TEXT(75) NOT NULL, [linha6] TEXT(75) NOT NULL, [linha7] TEXT(75) NOT NULL, [linha8] TEXT(75) NOT NULL, [nlin] REAL NOT NULL, [ncol] REAL NOT NULL, [ncar] REAL NOT NULL, [setup] TEXT(20) NOT NULL, [setupfim] TEXT(20) NOT NULL, [arquivo] TEXT(8) NOT NULL, [indice] REAL NOT NULL, [filtro] TEXT(50) NOT NULL, [arqgra] TEXT(8) NOT NULL, [pind] TEXT(1) NOT NULL, [nind] REAL NOT NULL, [tipfil] TEXT(1) NOT NULL, [confil] TEXT(50) NOT NULL, [pfil] TEXT(1) NOT NULL);

-- Tabela: mf01
CREATE TABLE IF NOT EXISTS [mf01] ([numero] TEXT(3) NOT NULL, [digito] TEXT(1) NOT NULL, [cognome] TEXT(12) NOT NULL, [nome] TEXT(60) NOT NULL, [banco] REAL NOT NULL, [carteira] TEXT(3) NOT NULL, [fluxodia] TEXT(1) NOT NULL, [site] TEXT(50) NOT NULL, [ispb] TEXT(8) NOT NULL, [cnpj] TEXT(18) NOT NULL, [nomecomp] TEXT(80) NOT NULL);

-- Tabela: mf02
CREATE TABLE IF NOT EXISTS [mf02] ([numero] REAL NOT NULL, [agencia] TEXT(12) NOT NULL, [conta] TEXT(12) NOT NULL, [nrconta] REAL NOT NULL, [nomeag] TEXT(40) NOT NULL, [cognag] TEXT(12) NOT NULL, [endereco] TEXT(40) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(30) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [cxpostal] TEXT(5) NOT NULL, [ddd] TEXT(2) NOT NULL, [telefone] TEXT(12) NOT NULL, [ramal] TEXT(4) NOT NULL, [contato] TEXT(22) NOT NULL, [ddd1] TEXT(2) NOT NULL, [telefone1] TEXT(12) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(22) NOT NULL, [dddfax] TEXT(4) NOT NULL, [telefax] TEXT(12) NOT NULL, [pessoa] TEXT(1) NOT NULL, [cgc] TEXT(18) NOT NULL, [inscr] TEXT(16) NOT NULL, [praca] TEXT(12) NOT NULL, [titular1] TEXT(40) NOT NULL, [titular2] TEXT(40) NOT NULL, [tipocta] TEXT(1) NOT NULL, [xndereco1] TEXT(40) NOT NULL, [xairro1] TEXT(30) NOT NULL, [xidade1] TEXT(30) NOT NULL, [xstado1] TEXT(2) NOT NULL, [xep1] TEXT(9) NOT NULL, [xxpostal1] TEXT(5) NOT NULL, [xdd1] TEXT(2) NOT NULL, [xelefone1] TEXT(12) NOT NULL, [xamal1] TEXT(4) NOT NULL, [xontato1] TEXT(22) NOT NULL, [xdf1] TEXT(2) NOT NULL, [xax1] TEXT(12) NOT NULL, [xpf1] TEXT(14) NOT NULL, [xndereco2] TEXT(40) NOT NULL, [xairro2] TEXT(30) NOT NULL, [xidade2] TEXT(30) NOT NULL, [xstado2] TEXT(2) NOT NULL, [xep2] TEXT(9) NOT NULL, [xxpostal2] TEXT(5) NOT NULL, [xdd2] TEXT(2) NOT NULL, [xelefone2] TEXT(12) NOT NULL, [xamal2] TEXT(4) NOT NULL, [xontato2] TEXT(22) NOT NULL, [xdf2] TEXT(2) NOT NULL, [xax2] TEXT(12) NOT NULL, [xpf2] TEXT(14) NOT NULL, [dvag] TEXT(1) NOT NULL);

-- Tabela: mf03
CREATE TABLE IF NOT EXISTS [mf03] ([numero] REAL NOT NULL, [agencia] TEXT(12) NOT NULL, [conta] TEXT(12) NOT NULL, [titular1] TEXT(40) NOT NULL, [titular2] TEXT(40) NOT NULL, [tipocta] TEXT(1) NOT NULL, [endereco1] TEXT(40) NOT NULL, [bairro1] TEXT(30) NOT NULL, [cidade1] TEXT(30) NOT NULL, [estado1] TEXT(2) NOT NULL, [cep1] TEXT(9) NOT NULL, [cxpostal1] TEXT(5) NOT NULL, [ddd1] TEXT(4) NOT NULL, [telefone1] TEXT(9) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(22) NOT NULL, [ddf1] TEXT(4) NOT NULL, [fax1] TEXT(9) NOT NULL, [cpf1] TEXT(14) NOT NULL, [endereco2] TEXT(40) NOT NULL, [bairro2] TEXT(30) NOT NULL, [cidade2] TEXT(30) NOT NULL, [estado2] TEXT(2) NOT NULL, [cep2] TEXT(9) NOT NULL, [cxpostal2] TEXT(5) NOT NULL, [ddd2] TEXT(4) NOT NULL, [telefone2] TEXT(9) NOT NULL, [ramal2] TEXT(4) NOT NULL, [contato2] TEXT(22) NOT NULL, [ddf2] TEXT(4) NOT NULL, [fax2] TEXT(9) NOT NULL, [cpf2] TEXT(14) NOT NULL);

-- Tabela: mf04
CREATE TABLE IF NOT EXISTS [mf04] ([numero] REAL NOT NULL, [praca] TEXT(12) NOT NULL, [nomepr] TEXT(40) NOT NULL, [cidpra] TEXT(30) NOT NULL, [estpra] TEXT(2) NOT NULL, [area1] TEXT(70) NOT NULL, [area2] TEXT(70) NOT NULL, [area3] TEXT(70) NOT NULL, [area4] TEXT(70) NOT NULL, [area5] TEXT(70) NOT NULL, [feriado] SHORTDATE NOT NULL, [ceppra] TEXT(9) NOT NULL);

-- Tabela: mf05
CREATE TABLE IF NOT EXISTS [mf05] ([cartao] TEXT(20) NOT NULL, [nome] TEXT(20) NOT NULL, [venc] REAL NOT NULL, [limitenac] REAL NOT NULL, [limiteint] REAL NOT NULL, [titular1] TEXT(40) NOT NULL, [titular2] TEXT(40) NOT NULL, [tipocta] TEXT(1) NOT NULL, [endereco1] TEXT(40) NOT NULL, [bairro1] TEXT(30) NOT NULL, [cidade1] TEXT(35) NOT NULL, [estado1] TEXT(2) NOT NULL, [cep1] TEXT(9) NOT NULL, [cxpostal1] TEXT(5) NOT NULL, [ddd1] TEXT(4) NOT NULL, [telefone1] TEXT(9) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(22) NOT NULL, [ddf1] TEXT(4) NOT NULL, [fax1] TEXT(9) NOT NULL, [cpf1] TEXT(14) NOT NULL, [endereco2] TEXT(40) NOT NULL, [bairro2] TEXT(30) NOT NULL, [cidade2] TEXT(35) NOT NULL, [estado2] TEXT(2) NOT NULL, [cep2] TEXT(9) NOT NULL, [cxpostal2] TEXT(5) NOT NULL, [ddd2] TEXT(4) NOT NULL, [telefone2] TEXT(9) NOT NULL, [ramal2] TEXT(4) NOT NULL, [contato2] TEXT(22) NOT NULL, [ddf2] TEXT(4) NOT NULL, [fax2] TEXT(9) NOT NULL, [cpf2] TEXT(14) NOT NULL);

-- Tabela: mf06
CREATE TABLE IF NOT EXISTS [mf06] ([conta] TEXT(12) NOT NULL, [nome] TEXT(40) NOT NULL);

-- Tabela: mg01
CREATE TABLE IF NOT EXISTS [mg01] ([numero] TEXT(5) NOT NULL, [cognome] TEXT(12) NOT NULL, [nome] TEXT(40) NOT NULL, [endereco] TEXT(40) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(35) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [cxpostal] TEXT(5) NOT NULL, [dddtlx] TEXT(4) NOT NULL, [telex] TEXT(6) NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [ramal] TEXT(4) NOT NULL, [contato] TEXT(22) NOT NULL, [ddd1] TEXT(4) NOT NULL, [telefone1] TEXT(9) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(22) NOT NULL, [dddfax] TEXT(4) NOT NULL, [telefax] TEXT(9) NOT NULL, [cgc] TEXT(18) NOT NULL, [inscr] TEXT(15) NOT NULL, [jucesp] TEXT(15) NOT NULL, [observa] TEXT(30) NOT NULL, [codmat] TEXT(5) NOT NULL, [material] TEXT(5) NOT NULL, [nomemat] TEXT(40) NOT NULL, [zona] REAL NOT NULL, [clicad] TEXT(1) NOT NULL, [cliprin] TEXT(1) NOT NULL, [pessoa] TEXT(1) NOT NULL, [chapa] TEXT(8) NOT NULL, [motorista] TEXT(30) NOT NULL, [imuni] TEXT(15) NOT NULL, [admitido] SHORTDATE NOT NULL, [demitido] SHORTDATE NOT NULL, [depende] REAL NOT NULL, [depto] REAL NOT NULL, [setor] REAL NOT NULL, [secao] REAL NOT NULL, [saljan] REAL NOT NULL, [salfev] REAL NOT NULL, [salmar] REAL NOT NULL, [salabr] REAL NOT NULL, [salmai] REAL NOT NULL, [saljun] REAL NOT NULL, [saljul] REAL NOT NULL, [salago] REAL NOT NULL, [salset] REAL NOT NULL, [salout] REAL NOT NULL, [salnov] REAL NOT NULL, [saldez] REAL NOT NULL, [hrsem] REAL NOT NULL, [tipo] TEXT(1) NOT NULL, [funcao] REAL NOT NULL, [tipser] TEXT(20) NOT NULL, [grupo] TEXT(50) NOT NULL, [situacao] TEXT(1) NOT NULL);

-- Tabela: mg02
CREATE TABLE IF NOT EXISTS [mg02] ([numero] TEXT(5) NOT NULL, [chapaf] TEXT(8) NOT NULL, [motorf] TEXT(30) NOT NULL, [obs1] TEXT(40) NOT NULL, [codemp] TEXT(12) NOT NULL, [cnh] TEXT(9) NOT NULL, [catcnh] TEXT(1) NOT NULL, [valcnh] SHORTDATE NOT NULL, [expcnh] SHORTDATE NOT NULL, [kmini] REAL NOT NULL);

-- Tabela: mg03
CREATE TABLE IF NOT EXISTS [mg03] ([numero] TEXT(5) NOT NULL, [codemp] TEXT(12) NOT NULL, [codfro] TEXT(12) NOT NULL, [chapaf] TEXT(8) NOT NULL, [profro] TEXT(10) NOT NULL, [anomod] REAL NOT NULL, [anofro] REAL NOT NULL, [kmini] REAL NOT NULL, [chassi] TEXT(22) NOT NULL, [tipfro] TEXT(20) NOT NULL, [marfro] TEXT(20) NOT NULL, [modfro] TEXT(25) NOT NULL, [comfro] TEXT(12) NOT NULL, [renavam] TEXT(9) NOT NULL, [catfro] TEXT(20) NOT NULL, [estfro] TEXT(2) NOT NULL, [cidipva] TEXT(4) NOT NULL, [cidfro] TEXT(35) NOT NULL, [espfro] TEXT(12) NOT NULL, [carfro] TEXT(20) NOT NULL, [codipva] REAL NOT NULL, [nompro] TEXT(40) NOT NULL, [endpro] TEXT(40) NOT NULL, [baipro] TEXT(30) NOT NULL, [cidpro] TEXT(35) NOT NULL, [estpro] TEXT(2) NOT NULL, [pessoa] TEXT(1) NOT NULL, [cgc] TEXT(18) NOT NULL, [ceppro] TEXT(9) NOT NULL);

-- Tabela: mg04
CREATE TABLE IF NOT EXISTS [mg04] ([cod_ipva] REAL NOT NULL, [tipo] REAL NOT NULL, [faixa_ipva] REAL NOT NULL, [linha] REAL NOT NULL, [cod_ref] REAL NOT NULL, [marca] TEXT(20) NOT NULL, [modelo] TEXT(55) NOT NULL, [origem] TEXT(3) NOT NULL, [nummarca] REAL NOT NULL, [categoria] TEXT(2) NOT NULL, [capacid] REAL NOT NULL, [codfipe] TEXT(7) NOT NULL);

-- Tabela: mg05
CREATE TABLE IF NOT EXISTS [mg05] ([numero] REAL NOT NULL, [nome] TEXT(20) NOT NULL);

-- Tabela: mh01
CREATE TABLE IF NOT EXISTS [mh01] ([numero] TEXT(6) NOT NULL, [cognome] TEXT(12) NOT NULL, [local1] TEXT(74) NOT NULL, [local2] TEXT(74) NOT NULL, [local3] TEXT(74) NOT NULL, [local4] TEXT(74) NOT NULL, [local5] TEXT(74) NOT NULL, [local6] TEXT(74) NOT NULL);

-- Tabela: mh02
CREATE TABLE IF NOT EXISTS [mh02] ([numero] TEXT(6) NOT NULL, [cognome] TEXT(12) NOT NULL, [local1] TEXT(74) NOT NULL, [local2] TEXT(74) NOT NULL, [local3] TEXT(74) NOT NULL, [local4] TEXT(74) NOT NULL, [local5] TEXT(74) NOT NULL, [local6] TEXT(74) NOT NULL);

-- Tabela: mh03
CREATE TABLE IF NOT EXISTS [mh03] ([numero] TEXT(6) NOT NULL, [cognome] TEXT(12) NOT NULL, [local1] TEXT(74) NOT NULL, [local2] TEXT(74) NOT NULL, [local3] TEXT(74) NOT NULL, [local4] TEXT(74) NOT NULL, [local5] TEXT(74) NOT NULL, [local6] TEXT(74) NOT NULL);

-- Tabela: mi01
CREATE TABLE IF NOT EXISTS [mi01] ([conta] TEXT(11) NOT NULL, [nivel] REAL NOT NULL, [tipo] TEXT(1) NOT NULL, [nome] TEXT(50) NOT NULL, [numero] REAL NOT NULL, [identifica] TEXT(1) NOT NULL, [dac] REAL NOT NULL, [sal01] REAL NOT NULL, [sal02] REAL NOT NULL, [sal03] REAL NOT NULL, [sal04] REAL NOT NULL, [sal05] REAL NOT NULL, [sal06] REAL NOT NULL, [sal07] REAL NOT NULL, [sal08] REAL NOT NULL, [sal09] REAL NOT NULL, [sal10] REAL NOT NULL, [sal11] REAL NOT NULL, [sal12] REAL NOT NULL, [sas01] REAL NOT NULL, [sas02] REAL NOT NULL, [sas03] REAL NOT NULL, [sas04] REAL NOT NULL, [sas05] REAL NOT NULL, [sas06] REAL NOT NULL, [sas07] REAL NOT NULL, [sas08] REAL NOT NULL, [sas09] REAL NOT NULL, [sas10] REAL NOT NULL, [sas11] REAL NOT NULL, [sas12] REAL NOT NULL, [sao01] REAL NOT NULL, [sao02] REAL NOT NULL, [sao03] REAL NOT NULL, [sao04] REAL NOT NULL, [sao05] REAL NOT NULL, [sao06] REAL NOT NULL, [sao07] REAL NOT NULL, [sao08] REAL NOT NULL, [sao09] REAL NOT NULL, [sao10] REAL NOT NULL, [sao11] REAL NOT NULL, [sao12] REAL NOT NULL, [contaref] TEXT(15) NOT NULL);

-- Tabela: mi02
CREATE TABLE IF NOT EXISTS [mi02] ([codigo] TEXT(3) NOT NULL, [descricao] TEXT(35) NOT NULL, [valor] REAL NOT NULL, [valor1] REAL NOT NULL, [tipo] TEXT(1) NOT NULL);

-- Tabela: mi03
CREATE TABLE IF NOT EXISTS [mi03] ([ue] TEXT(7) NOT NULL, [atividade] TEXT(50) NOT NULL, [gasto] TEXT(1) NOT NULL, [centro] TEXT(4) NOT NULL, [cfolha] REAL NOT NULL);

-- Tabela: mi04
CREATE TABLE IF NOT EXISTS [mi04] ([conta] TEXT(11) NOT NULL, [nome] TEXT(50) NOT NULL, [sairel] TEXT(1) NOT NULL);

-- Tabela: mj01
CREATE TABLE IF NOT EXISTS [mj01] ([numero] TEXT(2) NOT NULL, [nome] TEXT(40) NOT NULL, [pgipi] TEXT(1) NOT NULL, [dia1] REAL NOT NULL, [dia2] REAL NOT NULL, [dia3] REAL NOT NULL, [dia4] REAL NOT NULL, [dia5] REAL NOT NULL, [dia6] REAL NOT NULL, [dia7] REAL NOT NULL, [dia8] REAL NOT NULL, [dia9] REAL NOT NULL, [dia10] REAL NOT NULL, [por1] REAL NOT NULL, [por2] REAL NOT NULL, [por3] REAL NOT NULL, [por4] REAL NOT NULL, [por5] REAL NOT NULL, [por6] REAL NOT NULL, [por7] REAL NOT NULL, [por8] REAL NOT NULL, [por9] REAL NOT NULL, [por10] REAL NOT NULL, [data] TEXT(1) NOT NULL, [cai1] REAL NOT NULL, [cai2] REAL NOT NULL, [cai3] REAL NOT NULL, [cai4] REAL NOT NULL, [semana] REAL NOT NULL, [pagadesf] TEXT(1) NOT NULL, [jpag] REAL NOT NULL, [tpc01] TEXT(2) NOT NULL, [tpc02] TEXT(2) NOT NULL, [tpc03] TEXT(2) NOT NULL, [tpc04] TEXT(2) NOT NULL, [tpc05] TEXT(2) NOT NULL, [tpc06] TEXT(2) NOT NULL, [tpc07] TEXT(2) NOT NULL, [tpc08] TEXT(2) NOT NULL, [tpc09] TEXT(2) NOT NULL, [tpc10] TEXT(2) NOT NULL);

-- Tabela: mk01
CREATE TABLE IF NOT EXISTS [mk01] ([nrnota] REAL NOT NULL, [data] SHORTDATE NOT NULL, [dataref] SHORTDATE NOT NULL, [entrega] SHORTDATE NOT NULL, [tipocli] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [operacao] TEXT(7) NOT NULL, [cfonew] TEXT(5) NOT NULL, [cfonewb] TEXT(5) NOT NULL, [suboper] TEXT(1) NOT NULL, [viatrans] TEXT(10) NOT NULL, [icm] REAL NOT NULL, [totbicm] REAL NOT NULL, [toticm] REAL NOT NULL, [totbipi] REAL NOT NULL, [totipi] REAL NOT NULL, [totmer] REAL NOT NULL, [totnf] REAL NOT NULL, [incluso] TEXT(1) NOT NULL, [totpliq] REAL NOT NULL, [totpbru] REAL NOT NULL, [embmarca] TEXT(5) NOT NULL, [embnumero] TEXT(5) NOT NULL, [embqtdde] REAL NOT NULL, [embespec] TEXT(10) NOT NULL, [condpag] TEXT(2) NOT NULL, [taxa] REAL NOT NULL, [dat01] SHORTDATE NOT NULL, [dat02] SHORTDATE NOT NULL, [dat03] SHORTDATE NOT NULL, [dat04] SHORTDATE NOT NULL, [dat05] SHORTDATE NOT NULL, [dat06] SHORTDATE NOT NULL, [dat07] SHORTDATE NOT NULL, [dat08] SHORTDATE NOT NULL, [dat09] SHORTDATE NOT NULL, [dat10] SHORTDATE NOT NULL, [val01] REAL NOT NULL, [val02] REAL NOT NULL, [val03] REAL NOT NULL, [val04] REAL NOT NULL, [val05] REAL NOT NULL, [val06] REAL NOT NULL, [val07] REAL NOT NULL, [val08] REAL NOT NULL, [val09] REAL NOT NULL, [val10] REAL NOT NULL, [obs1] TEXT(50) NOT NULL, [obs2] TEXT(50) NOT NULL, [obs3] TEXT(50) NOT NULL, [lin01] TEXT(50) NOT NULL, [lin02] TEXT(50) NOT NULL, [lin03] TEXT(50) NOT NULL, [lin04] TEXT(50) NOT NULL, [lin05] TEXT(50) NOT NULL, [lin06] TEXT(50) NOT NULL, [lin07] TEXT(50) NOT NULL, [lin08] TEXT(50) NOT NULL, [transport] REAL NOT NULL, [nometrans] TEXT(40) NOT NULL, [endetrans] TEXT(40) NOT NULL, [bairtrans] TEXT(30) NOT NULL, [cidatrans] TEXT(30) NOT NULL, [estatrans] TEXT(2) NOT NULL, [ceptrans] TEXT(9) NOT NULL, [chapa] TEXT(8) NOT NULL, [endereco3] TEXT(40) NOT NULL, [bairro3] TEXT(30) NOT NULL, [cidade3] TEXT(30) NOT NULL, [estado3] TEXT(2) NOT NULL, [cep3] TEXT(9) NOT NULL, [cgc3] TEXT(18) NOT NULL, [insc3] TEXT(15) NOT NULL, [ordem] REAL NOT NULL, [totbasicm] REAL NOT NULL, [totvalicm] REAL NOT NULL, [totiseicm] REAL NOT NULL, [totouticm] REAL NOT NULL, [totbasipi] REAL NOT NULL, [totvalipi] REAL NOT NULL, [totiseipi] REAL NOT NULL, [totoutipi] REAL NOT NULL, [totvalnf] REAL NOT NULL, [apura] TEXT(1) NOT NULL, [isenta] REAL NOT NULL, [especie] TEXT(5) NOT NULL, [serie] TEXT(5) NOT NULL, [modelo] TEXT(2) NOT NULL, [estado] TEXT(2) NOT NULL, [cod] TEXT(3) NOT NULL, [difdup] REAL NOT NULL, [contsim] TEXT(1) NOT NULL, [obsped] TEXT(20) NOT NULL, [difpg] REAL NOT NULL, [valpis] REAL NOT NULL, [valfin] REAL NOT NULL, [totfrete] REAL NOT NULL);

-- Tabela: mk02
CREATE TABLE IF NOT EXISTS [mk02] ([nrnota] REAL NOT NULL, [item] REAL NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [cogfor] TEXT(15) NOT NULL, [operacao] TEXT(7) NOT NULL, [cfonew] TEXT(5) NOT NULL, [cfonewb] TEXT(5) NOT NULL, [suboper] TEXT(1) NOT NULL, [qtde] REAL NOT NULL, [unid] TEXT(2) NOT NULL, [peso] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [preco] REAL NOT NULL, [valormer] REAL NOT NULL, [codipi] TEXT(2) NOT NULL, [classipi] TEXT(14) NOT NULL, [ipi] REAL NOT NULL, [baseipi] REAL NOT NULL, [valoripi] REAL NOT NULL, [valortot] REAL NOT NULL, [icm] REAL NOT NULL, [baseicm] REAL NOT NULL, [valoricm] REAL NOT NULL, [somanf] TEXT(1) NOT NULL, [consumo] TEXT(1) NOT NULL, [dipicm] TEXT(1) NOT NULL, [dipipi] TEXT(1) NOT NULL, [apura] TEXT(1) NOT NULL, [valfre] REAL NOT NULL, [tiposerv] TEXT(1) NOT NULL, [compe] REAL NOT NULL, [compras] REAL NOT NULL, [comitem] REAL NOT NULL, [redicm] REAL NOT NULL, [coddep] TEXT(3) NOT NULL, [crm] REAL NOT NULL, [aut] REAL NOT NULL, [prccrm] REAL NOT NULL, [nummy04] REAL NOT NULL, [prcmy04] REAL NOT NULL, [codpgmw] TEXT(2) NOT NULL, [prcmw02] REAL NOT NULL, [pesocrm] REAL NOT NULL, [pedccrm] TEXT(1) NOT NULL, [redicmmw] REAL NOT NULL, [entrcrm] SHORTDATE NOT NULL, [piscon] TEXT(1) NOT NULL, [codicm] TEXT(3) NOT NULL, [nota_dev] REAL NOT NULL, [data_dev] SHORTDATE NOT NULL, [qtde_dev] REAL NOT NULL, [vald_dev] REAL NOT NULL, [nota_dev2] REAL NOT NULL, [data_dev2] SHORTDATE NOT NULL, [qtde_dev2] REAL NOT NULL, [vald_dev2] REAL NOT NULL, [isentaicm] REAL NOT NULL, [outraicm] REAL NOT NULL, [isentaipi] REAL NOT NULL, [outraipi] REAL NOT NULL, [indice] TEXT(12) NOT NULL, [vaipis] REAL NOT NULL, [vaifin] REAL NOT NULL);

-- Tabela: mk03
CREATE TABLE IF NOT EXISTS [mk03] ([nrnota] REAL NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [codigo] TEXT(11) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [valormes] REAL NOT NULL, [conta] TEXT(11) NOT NULL);

-- Tabela: mk04
CREATE TABLE IF NOT EXISTS [mk04] ([nrnota] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tipocli] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [centro] TEXT(4) NOT NULL, [gasto] TEXT(1) NOT NULL, [codigo] TEXT(11) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [valormes] REAL NOT NULL, [conta] TEXT(11) NOT NULL);

-- Tabela: mk05
CREATE TABLE IF NOT EXISTS [mk05] ([requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tipocli] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [conta] TEXT(11) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [valormes] REAL NOT NULL);

-- Tabela: mk06
CREATE TABLE IF NOT EXISTS [mk06] ([ordem] REAL NOT NULL, [numero] REAL NOT NULL, [item] REAL NOT NULL, [data] SHORTDATE NOT NULL, [dataref] SHORTDATE NOT NULL, [tipofor] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [doper] TEXT(3) NOT NULL, [dcfonew] TEXT(4) NOT NULL, [subdoper] TEXT(1) NOT NULL, [somanf] TEXT(1) NOT NULL, [consumo] TEXT(1) NOT NULL, [dbaseicm] REAL NOT NULL, [dicm] REAL NOT NULL, [dvalicm] REAL NOT NULL, [isentaicm] REAL NOT NULL, [outraicm] REAL NOT NULL, [dbaseipi] REAL NOT NULL, [dipi] REAL NOT NULL, [dvalipi] REAL NOT NULL, [isentaipi] REAL NOT NULL, [outraipi] REAL NOT NULL, [dclassipi] TEXT(12) NOT NULL, [dvalornf] REAL NOT NULL, [unidade] TEXT(2) NOT NULL, [quant] REAL NOT NULL, [micm01] REAL NOT NULL, [micm02] REAL NOT NULL, [micm03] REAL NOT NULL, [mipi01] REAL NOT NULL, [mipi02] REAL NOT NULL, [mipi03] REAL NOT NULL, [lote] REAL NOT NULL, [dipam] TEXT(2) NOT NULL, [especie] TEXT(3) NOT NULL, [obs] TEXT(30) NOT NULL, [obsicm] REAL NOT NULL, [obsipi] REAL NOT NULL, [dcancel] SHORTDATE NOT NULL, [dpiscon] TEXT(1) NOT NULL, [chkipi] TEXT(1) NOT NULL, [pulasin] TEXT(1) NOT NULL, [descsin] REAL NOT NULL);

-- Tabela: mk09
CREATE TABLE IF NOT EXISTS [mk09] ([ordem] REAL NOT NULL, [numero] REAL NOT NULL, [item] REAL NOT NULL, [data] SHORTDATE NOT NULL, [dataref] SHORTDATE NOT NULL, [tipofor] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [doper] TEXT(3) NOT NULL, [dcfonew] TEXT(5) NOT NULL, [subdoper] TEXT(1) NOT NULL, [somanf] TEXT(1) NOT NULL, [consumo] TEXT(1) NOT NULL, [dbaseicm] REAL NOT NULL, [dicm] REAL NOT NULL, [dvalicm] REAL NOT NULL, [isentaicm] REAL NOT NULL, [outraicm] REAL NOT NULL, [dbaseipi] REAL NOT NULL, [dipi] REAL NOT NULL, [dvalipi] REAL NOT NULL, [isentaipi] REAL NOT NULL, [outraipi] REAL NOT NULL, [dclassipi] TEXT(12) NOT NULL, [dvalornf] REAL NOT NULL, [unidade] TEXT(2) NOT NULL, [quant] REAL NOT NULL, [micm01] REAL NOT NULL, [micm02] REAL NOT NULL, [micm03] REAL NOT NULL, [mipi01] REAL NOT NULL, [mipi02] REAL NOT NULL, [mipi03] REAL NOT NULL, [lote] REAL NOT NULL, [dipam] TEXT(2) NOT NULL, [especie] TEXT(5) NOT NULL, [obs] TEXT(50) NOT NULL, [obsicm] REAL NOT NULL, [obsipi] REAL NOT NULL, [dcancel] SHORTDATE NOT NULL, [dpiscon] TEXT(1) NOT NULL, [chkipi] TEXT(1) NOT NULL, [serie] TEXT(5) NOT NULL, [situacao] TEXT(1) NOT NULL, [codrec] TEXT(5) NOT NULL, [bcpis] REAL NOT NULL, [bcali] REAL NOT NULL, [bcval] REAL NOT NULL, [coddep] TEXT(3) NOT NULL, [dat01] SHORTDATE NOT NULL, [val01] REAL NOT NULL);

-- Tabela: mk90
CREATE TABLE IF NOT EXISTS [mk90] ([ordem] REAL NOT NULL, [numero] REAL NOT NULL, [item] REAL NOT NULL, [data] SHORTDATE NOT NULL, [dataref] SHORTDATE NOT NULL, [tipofor] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [doper] TEXT(3) NOT NULL, [dcfonew] TEXT(5) NOT NULL, [subdoper] TEXT(1) NOT NULL, [somanf] TEXT(1) NOT NULL, [consumo] TEXT(1) NOT NULL, [dbaseicm] REAL NOT NULL, [dicm] REAL NOT NULL, [dvalicm] REAL NOT NULL, [isentaicm] REAL NOT NULL, [outraicm] REAL NOT NULL, [dbaseipi] REAL NOT NULL, [dipi] REAL NOT NULL, [dvalipi] REAL NOT NULL, [isentaipi] REAL NOT NULL, [outraipi] REAL NOT NULL, [dclassipi] TEXT(12) NOT NULL, [dvalornf] REAL NOT NULL, [unidade] TEXT(2) NOT NULL, [quant] REAL NOT NULL, [micm01] REAL NOT NULL, [micm02] REAL NOT NULL, [micm03] REAL NOT NULL, [mipi01] REAL NOT NULL, [mipi02] REAL NOT NULL, [mipi03] REAL NOT NULL, [lote] REAL NOT NULL, [dipam] TEXT(2) NOT NULL, [especie] TEXT(5) NOT NULL, [obs] TEXT(50) NOT NULL, [obsicm] REAL NOT NULL, [obsipi] REAL NOT NULL, [dcancel] SHORTDATE NOT NULL, [dpiscon] TEXT(1) NOT NULL, [chkipi] TEXT(1) NOT NULL, [serie] TEXT(5) NOT NULL, [situacao] TEXT(1) NOT NULL, [codrec] TEXT(5) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: mk91
CREATE TABLE IF NOT EXISTS [mk91] ([nrnota] REAL NOT NULL, [data] SHORTDATE NOT NULL, [dataref] SHORTDATE NOT NULL, [entrega] SHORTDATE NOT NULL, [tipocli] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [operacao] TEXT(7) NOT NULL, [cfonew] TEXT(5) NOT NULL, [cfonewb] TEXT(5) NOT NULL, [suboper] TEXT(1) NOT NULL, [viatrans] TEXT(10) NOT NULL, [icm] REAL NOT NULL, [totbicm] REAL NOT NULL, [toticm] REAL NOT NULL, [totbipi] REAL NOT NULL, [totipi] REAL NOT NULL, [totmer] REAL NOT NULL, [totnf] REAL NOT NULL, [incluso] TEXT(1) NOT NULL, [totpliq] REAL NOT NULL, [totpbru] REAL NOT NULL, [embmarca] TEXT(5) NOT NULL, [embnumero] TEXT(5) NOT NULL, [embqtdde] REAL NOT NULL, [embespec] TEXT(10) NOT NULL, [condpag] TEXT(2) NOT NULL, [taxa] REAL NOT NULL, [dat01] SHORTDATE NOT NULL, [dat02] SHORTDATE NOT NULL, [dat03] SHORTDATE NOT NULL, [dat04] SHORTDATE NOT NULL, [dat05] SHORTDATE NOT NULL, [dat06] SHORTDATE NOT NULL, [dat07] SHORTDATE NOT NULL, [dat08] SHORTDATE NOT NULL, [dat09] SHORTDATE NOT NULL, [dat10] SHORTDATE NOT NULL, [val01] REAL NOT NULL, [val02] REAL NOT NULL, [val03] REAL NOT NULL, [val04] REAL NOT NULL, [val05] REAL NOT NULL, [val06] REAL NOT NULL, [val07] REAL NOT NULL, [val08] REAL NOT NULL, [val09] REAL NOT NULL, [val10] REAL NOT NULL, [obs1] TEXT(50) NOT NULL, [obs2] TEXT(50) NOT NULL, [obs3] TEXT(50) NOT NULL, [lin01] TEXT(50) NOT NULL, [lin02] TEXT(50) NOT NULL, [lin03] TEXT(50) NOT NULL, [lin04] TEXT(50) NOT NULL, [lin05] TEXT(50) NOT NULL, [lin06] TEXT(50) NOT NULL, [lin07] TEXT(50) NOT NULL, [lin08] TEXT(50) NOT NULL, [transport] REAL NOT NULL, [nometrans] TEXT(40) NOT NULL, [endetrans] TEXT(40) NOT NULL, [bairtrans] TEXT(30) NOT NULL, [cidatrans] TEXT(30) NOT NULL, [estatrans] TEXT(2) NOT NULL, [ceptrans] TEXT(9) NOT NULL, [chapa] TEXT(8) NOT NULL, [endereco3] TEXT(40) NOT NULL, [bairro3] TEXT(30) NOT NULL, [cidade3] TEXT(30) NOT NULL, [estado3] TEXT(2) NOT NULL, [cep3] TEXT(9) NOT NULL, [cgc3] TEXT(18) NOT NULL, [insc3] TEXT(15) NOT NULL, [ordem] REAL NOT NULL, [totbasicm] REAL NOT NULL, [totvalicm] REAL NOT NULL, [totiseicm] REAL NOT NULL, [totouticm] REAL NOT NULL, [totbasipi] REAL NOT NULL, [totvalipi] REAL NOT NULL, [totiseipi] REAL NOT NULL, [totoutipi] REAL NOT NULL, [totvalnf] REAL NOT NULL, [apura] TEXT(1) NOT NULL, [isenta] REAL NOT NULL, [especie] TEXT(5) NOT NULL, [serie] TEXT(5) NOT NULL, [modelo] TEXT(2) NOT NULL, [estado] TEXT(2) NOT NULL, [cod] TEXT(3) NOT NULL, [difdup] REAL NOT NULL, [contsim] TEXT(1) NOT NULL, [obsped] TEXT(20) NOT NULL, [difpg] REAL NOT NULL, [valpis] REAL NOT NULL, [valfin] REAL NOT NULL, [totfrete] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: mk92
CREATE TABLE IF NOT EXISTS [mk92] ([nrnota] REAL NOT NULL, [item] REAL NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [cogfor] TEXT(15) NOT NULL, [operacao] TEXT(7) NOT NULL, [cfonew] TEXT(5) NOT NULL, [cfonewb] TEXT(5) NOT NULL, [suboper] TEXT(1) NOT NULL, [qtde] REAL NOT NULL, [unid] TEXT(2) NOT NULL, [peso] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [preco] REAL NOT NULL, [valormer] REAL NOT NULL, [codipi] TEXT(2) NOT NULL, [classipi] TEXT(14) NOT NULL, [ipi] REAL NOT NULL, [baseipi] REAL NOT NULL, [valoripi] REAL NOT NULL, [valortot] REAL NOT NULL, [icm] REAL NOT NULL, [baseicm] REAL NOT NULL, [valoricm] REAL NOT NULL, [somanf] TEXT(1) NOT NULL, [consumo] TEXT(1) NOT NULL, [dipicm] TEXT(1) NOT NULL, [dipipi] TEXT(1) NOT NULL, [apura] TEXT(1) NOT NULL, [valfre] REAL NOT NULL, [tiposerv] TEXT(1) NOT NULL, [compe] REAL NOT NULL, [compras] REAL NOT NULL, [comitem] REAL NOT NULL, [redicm] REAL NOT NULL, [coddep] TEXT(3) NOT NULL, [crm] REAL NOT NULL, [aut] REAL NOT NULL, [prccrm] REAL NOT NULL, [nummy04] REAL NOT NULL, [prcmy04] REAL NOT NULL, [codpgmw] TEXT(2) NOT NULL, [prcmw02] REAL NOT NULL, [pesocrm] REAL NOT NULL, [pedccrm] TEXT(1) NOT NULL, [redicmmw] REAL NOT NULL, [entrcrm] SHORTDATE NOT NULL, [piscon] TEXT(1) NOT NULL, [codicm] TEXT(3) NOT NULL, [nota_dev] REAL NOT NULL, [data_dev] SHORTDATE NOT NULL, [qtde_dev] REAL NOT NULL, [vald_dev] REAL NOT NULL, [nota_dev2] REAL NOT NULL, [data_dev2] SHORTDATE NOT NULL, [qtde_dev2] REAL NOT NULL, [vald_dev2] REAL NOT NULL, [isentaicm] REAL NOT NULL, [outraicm] REAL NOT NULL, [isentaipi] REAL NOT NULL, [outraipi] REAL NOT NULL, [indice] TEXT(12) NOT NULL, [vaipis] REAL NOT NULL, [vaifin] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: mk96
CREATE TABLE IF NOT EXISTS [mk96] ([ordem] REAL NOT NULL, [numero] REAL NOT NULL, [item] REAL NOT NULL, [data] SHORTDATE NOT NULL, [dataref] SHORTDATE NOT NULL, [tipofor] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [doper] TEXT(3) NOT NULL, [dcfonew] TEXT(4) NOT NULL, [subdoper] TEXT(1) NOT NULL, [somanf] TEXT(1) NOT NULL, [consumo] TEXT(1) NOT NULL, [dbaseicm] REAL NOT NULL, [dicm] REAL NOT NULL, [dvalicm] REAL NOT NULL, [isentaicm] REAL NOT NULL, [outraicm] REAL NOT NULL, [dbaseipi] REAL NOT NULL, [dipi] REAL NOT NULL, [dvalipi] REAL NOT NULL, [isentaipi] REAL NOT NULL, [outraipi] REAL NOT NULL, [dclassipi] TEXT(12) NOT NULL, [dvalornf] REAL NOT NULL, [unidade] TEXT(2) NOT NULL, [quant] REAL NOT NULL, [micm01] REAL NOT NULL, [micm02] REAL NOT NULL, [micm03] REAL NOT NULL, [mipi01] REAL NOT NULL, [mipi02] REAL NOT NULL, [mipi03] REAL NOT NULL, [lote] REAL NOT NULL, [dipam] TEXT(2) NOT NULL, [especie] TEXT(3) NOT NULL, [obs] TEXT(30) NOT NULL, [obsicm] REAL NOT NULL, [obsipi] REAL NOT NULL, [dcancel] SHORTDATE NOT NULL, [dpiscon] TEXT(1) NOT NULL, [chkipi] TEXT(1) NOT NULL, [pulasin] TEXT(1) NOT NULL, [descsin] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: mk99
CREATE TABLE IF NOT EXISTS [mk99] ([ordem] REAL NOT NULL, [numero] REAL NOT NULL, [item] REAL NOT NULL, [data] SHORTDATE NOT NULL, [dataref] SHORTDATE NOT NULL, [tipofor] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [doper] TEXT(3) NOT NULL, [dcfonew] TEXT(5) NOT NULL, [subdoper] TEXT(1) NOT NULL, [somanf] TEXT(1) NOT NULL, [consumo] TEXT(1) NOT NULL, [dbaseicm] REAL NOT NULL, [dicm] REAL NOT NULL, [dvalicm] REAL NOT NULL, [isentaicm] REAL NOT NULL, [outraicm] REAL NOT NULL, [dbaseipi] REAL NOT NULL, [dipi] REAL NOT NULL, [dvalipi] REAL NOT NULL, [isentaipi] REAL NOT NULL, [outraipi] REAL NOT NULL, [dclassipi] TEXT(12) NOT NULL, [dvalornf] REAL NOT NULL, [unidade] TEXT(2) NOT NULL, [quant] REAL NOT NULL, [micm01] REAL NOT NULL, [micm02] REAL NOT NULL, [micm03] REAL NOT NULL, [mipi01] REAL NOT NULL, [mipi02] REAL NOT NULL, [mipi03] REAL NOT NULL, [lote] REAL NOT NULL, [dipam] TEXT(2) NOT NULL, [especie] TEXT(3) NOT NULL, [obs] TEXT(50) NOT NULL, [obsicm] REAL NOT NULL, [obsipi] REAL NOT NULL, [dcancel] SHORTDATE NOT NULL, [dpiscon] TEXT(1) NOT NULL, [chkipi] TEXT(1) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: ml01
CREATE TABLE IF NOT EXISTS [ml01] ([nrnota] REAL NOT NULL, [tipfat] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [tipocli] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [pedido] REAL NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [vendedor] TEXT(5) NOT NULL, [totfat] REAL NOT NULL, [situacao] REAL NOT NULL, [cod] TEXT(3) NOT NULL, [banco] TEXT(3) NOT NULL, [nomebco] TEXT(12) NOT NULL, [docbol] REAL NOT NULL, [docdup] REAL NOT NULL, [venciment] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [nota] REAL NOT NULL, [docabate] REAL NOT NULL, [abater] REAL NOT NULL, [taxa] REAL NOT NULL, [dias] REAL NOT NULL, [juros] REAL NOT NULL, [valatual] REAL NOT NULL, [obs] TEXT(55) NOT NULL, [obs1] TEXT(70) NOT NULL, [obs2] TEXT(70) NOT NULL, [obs3] TEXT(70) NOT NULL, [obs4] TEXT(70) NOT NULL, [datapg] SHORTDATE NOT NULL, [valorpg] REAL NOT NULL, [diferenca] REAL NOT NULL, [prevatr] REAL NOT NULL, [fluxo] TEXT(1) NOT NULL, [bcodep] REAL NOT NULL, [agcdep] TEXT(6) NOT NULL, [ctadep] TEXT(8) NOT NULL, [obspg] TEXT(30) NOT NULL, [conta] TEXT(12) NOT NULL, [geracob] TEXT(1) NOT NULL, [cliente] REAL NOT NULL);

-- Tabela: ml01pg
CREATE TABLE IF NOT EXISTS [ml01pg] ([nrnota] REAL NOT NULL, [tipfat] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [tipocli] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [pedido] REAL NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [vendedor] TEXT(5) NOT NULL, [totfat] REAL NOT NULL, [situacao] REAL NOT NULL, [cod] TEXT(3) NOT NULL, [banco] TEXT(3) NOT NULL, [nomebco] TEXT(12) NOT NULL, [docbol] REAL NOT NULL, [docdup] REAL NOT NULL, [venciment] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [nota] REAL NOT NULL, [docabate] REAL NOT NULL, [abater] REAL NOT NULL, [taxa] REAL NOT NULL, [dias] REAL NOT NULL, [juros] REAL NOT NULL, [valatual] REAL NOT NULL, [obs] TEXT(55) NOT NULL, [obs1] TEXT(70) NOT NULL, [obs2] TEXT(70) NOT NULL, [obs3] TEXT(70) NOT NULL, [obs4] TEXT(70) NOT NULL, [datapg] SHORTDATE NOT NULL, [valorpg] REAL NOT NULL, [diferenca] REAL NOT NULL, [prevatr] REAL NOT NULL, [fluxo] TEXT(1) NOT NULL, [bcodep] REAL NOT NULL, [agcdep] TEXT(6) NOT NULL, [ctadep] TEXT(8) NOT NULL, [obspg] TEXT(30) NOT NULL, [conta] TEXT(12) NOT NULL, [geracob] TEXT(1) NOT NULL, [cliente] REAL NOT NULL);

-- Tabela: ml02
CREATE TABLE IF NOT EXISTS [ml02] ([nrnota] REAL NOT NULL, [tipfat] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [tipocli] TEXT(2) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [pedido] REAL NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [vendedor] TEXT(5) NOT NULL, [totfat] REAL NOT NULL, [situacao] REAL NOT NULL, [banco] TEXT(3) NOT NULL, [nomebco] TEXT(12) NOT NULL, [documento] TEXT(15) NOT NULL, [datent] REAL NOT NULL, [ventip] TEXT(1) NOT NULL, [valor] REAL NOT NULL, [juros] REAL NOT NULL, [obs] TEXT(70) NOT NULL, [obs1] TEXT(70) NOT NULL, [obs2] TEXT(70) NOT NULL, [obs3] TEXT(70) NOT NULL, [obs4] TEXT(70) NOT NULL, [fatper] REAL NOT NULL, [historico] TEXT(3) NOT NULL);

-- Tabela: ml03
CREATE TABLE IF NOT EXISTS [ml03] ([nrnota] REAL NOT NULL, [tipfat] TEXT(1) NOT NULL, [banco] TEXT(3) NOT NULL, [agencia] TEXT(7) NOT NULL, [conta] TEXT(12) NOT NULL, [cheque] TEXT(15) NOT NULL, [data] SHORTDATE NOT NULL, [datadep] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [predatado] TEXT(1) NOT NULL, [datapara] SHORTDATE NOT NULL, [valordes] REAL NOT NULL, [valorneg] REAL NOT NULL, [ctacusto] TEXT(15) NOT NULL, [depdata] SHORTDATE NOT NULL, [depbco] REAL NOT NULL, [depagc] TEXT(7) NOT NULL, [depcta] TEXT(12) NOT NULL, [dev01data] SHORTDATE NOT NULL, [dev01cod] TEXT(10) NOT NULL, [dep01data] SHORTDATE NOT NULL, [dev01dep] REAL NOT NULL, [dev02data] SHORTDATE NOT NULL, [dev02cod] TEXT(10) NOT NULL, [dev02dep] REAL NOT NULL, [rep02data] SHORTDATE NOT NULL, [compensado] SHORTDATE NOT NULL, [obs] TEXT(100) NOT NULL, [finalizado] TEXT(1) NOT NULL, [cliente] REAL NOT NULL);

-- Tabela: ml03pg
CREATE TABLE IF NOT EXISTS [ml03pg] ([nrnota] REAL NOT NULL, [tipfat] TEXT(1) NOT NULL, [banco] TEXT(3) NOT NULL, [agencia] TEXT(7) NOT NULL, [conta] TEXT(12) NOT NULL, [cheque] TEXT(15) NOT NULL, [data] SHORTDATE NOT NULL, [datadep] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [predatado] TEXT(1) NOT NULL, [datapara] SHORTDATE NOT NULL, [valordes] REAL NOT NULL, [valorneg] REAL NOT NULL, [ctacusto] TEXT(15) NOT NULL, [depdata] SHORTDATE NOT NULL, [depbco] REAL NOT NULL, [depagc] TEXT(7) NOT NULL, [depcta] TEXT(12) NOT NULL, [dev01data] SHORTDATE NOT NULL, [dev01cod] TEXT(10) NOT NULL, [dep01data] SHORTDATE NOT NULL, [dev01dep] REAL NOT NULL, [dev02data] SHORTDATE NOT NULL, [dev02cod] TEXT(10) NOT NULL, [dev02dep] REAL NOT NULL, [rep02data] SHORTDATE NOT NULL, [compensado] SHORTDATE NOT NULL, [obs] TEXT(100) NOT NULL, [finalizado] TEXT(1) NOT NULL, [cliente] REAL NOT NULL);

-- Tabela: ml91pg
CREATE TABLE IF NOT EXISTS [ml91pg] ([nrnota] REAL NOT NULL, [tipfat] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [tipocli] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [pedido] REAL NOT NULL, [ddd] TEXT(2) NOT NULL, [telefone] TEXT(12) NOT NULL, [vendedor] TEXT(5) NOT NULL, [totfat] REAL NOT NULL, [situacao] REAL NOT NULL, [cod] TEXT(3) NOT NULL, [banco] TEXT(3) NOT NULL, [nomebco] TEXT(12) NOT NULL, [docbol] REAL NOT NULL, [docdup] REAL NOT NULL, [venciment] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [nota] REAL NOT NULL, [docabate] REAL NOT NULL, [abater] REAL NOT NULL, [taxa] REAL NOT NULL, [dias] REAL NOT NULL, [juros] REAL NOT NULL, [valatual] REAL NOT NULL, [obs] TEXT(40) NOT NULL, [obs1] TEXT(40) NOT NULL, [obs2] TEXT(40) NOT NULL, [obs3] TEXT(40) NOT NULL, [obs4] TEXT(40) NOT NULL, [datapg] SHORTDATE NOT NULL, [valorpg] REAL NOT NULL, [diferenca] REAL NOT NULL, [prevatr] REAL NOT NULL, [fluxo] TEXT(1) NOT NULL, [bcodep] TEXT(3) NOT NULL, [agcdep] TEXT(6) NOT NULL, [ctadep] TEXT(8) NOT NULL, [obspg] TEXT(20) NOT NULL, [conta] TEXT(12) NOT NULL, [geracob] TEXT(1) NOT NULL, [valpis] REAL NOT NULL, [valfin] REAL NOT NULL, [valcsll] REAL NOT NULL, [valirrf] REAL NOT NULL, [valiss] REAL NOT NULL, [valinss] REAL NOT NULL, [encargos] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: ml98
CREATE TABLE IF NOT EXISTS [ml98] ([nrnota] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [tipfat] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [pedido] REAL NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(8) NOT NULL, [vendedor] TEXT(5) NOT NULL, [totfat] REAL NOT NULL, [situacao] REAL NOT NULL, [banco] TEXT(3) NOT NULL, [nomebco] TEXT(12) NOT NULL, [docbol] REAL NOT NULL, [docdup] REAL NOT NULL, [venciment] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [nota] REAL NOT NULL, [docabate] REAL NOT NULL, [abater] REAL NOT NULL, [taxa] REAL NOT NULL, [dias] REAL NOT NULL, [juros] REAL NOT NULL, [valatual] REAL NOT NULL, [obs] TEXT(55) NOT NULL, [obs1] TEXT(70) NOT NULL, [obs2] TEXT(70) NOT NULL, [obs3] TEXT(70) NOT NULL, [obs4] TEXT(70) NOT NULL, [datapg] SHORTDATE NOT NULL, [valorpg] REAL NOT NULL, [diferenca] REAL NOT NULL, [prevatr] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: ml99
CREATE TABLE IF NOT EXISTS [ml99] ([nrnota] REAL NOT NULL, [tipfat] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [tipocli] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [pedido] REAL NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [vendedor] TEXT(5) NOT NULL, [totfat] REAL NOT NULL, [situacao] REAL NOT NULL, [cod] TEXT(3) NOT NULL, [banco] TEXT(3) NOT NULL, [nomebco] TEXT(12) NOT NULL, [docbol] REAL NOT NULL, [docdup] REAL NOT NULL, [venciment] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [nota] REAL NOT NULL, [docabate] REAL NOT NULL, [abater] REAL NOT NULL, [taxa] REAL NOT NULL, [dias] REAL NOT NULL, [juros] REAL NOT NULL, [valatual] REAL NOT NULL, [obs] TEXT(55) NOT NULL, [obs1] TEXT(70) NOT NULL, [obs2] TEXT(70) NOT NULL, [obs3] TEXT(70) NOT NULL, [obs4] TEXT(70) NOT NULL, [datapg] SHORTDATE NOT NULL, [valorpg] REAL NOT NULL, [diferenca] REAL NOT NULL, [prevatr] REAL NOT NULL, [fluxo] TEXT(1) NOT NULL, [bcodep] REAL NOT NULL, [agcdep] TEXT(6) NOT NULL, [ctadep] TEXT(8) NOT NULL, [obspg] TEXT(30) NOT NULL, [conta] TEXT(12) NOT NULL, [geracob] TEXT(1) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: mm01
CREATE TABLE IF NOT EXISTS [mm01] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tiposerv] TEXT(1) NOT NULL, [tipocli] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [vendedor] TEXT(5) NOT NULL, [operacao] TEXT(7) NOT NULL, [suboper] TEXT(1) NOT NULL, [cfonew] TEXT(5) NOT NULL, [cfonewb] TEXT(5) NOT NULL, [viatrans] TEXT(20) NOT NULL, [icm] REAL NOT NULL, [totbicm] REAL NOT NULL, [toticm] REAL NOT NULL, [totbipi] REAL NOT NULL, [totipi] REAL NOT NULL, [totmer] REAL NOT NULL, [totnf] REAL NOT NULL, [totalpes] REAL NOT NULL, [totalbru] REAL NOT NULL, [marcaemb] TEXT(5) NOT NULL, [numeroemb] TEXT(8) NOT NULL, [quantemb] REAL NOT NULL, [embalagem] TEXT(15) NOT NULL, [condpag] TEXT(2) NOT NULL, [dat01] SHORTDATE NOT NULL, [dat02] SHORTDATE NOT NULL, [dat03] SHORTDATE NOT NULL, [dat04] SHORTDATE NOT NULL, [dat05] SHORTDATE NOT NULL, [dat06] SHORTDATE NOT NULL, [dat07] SHORTDATE NOT NULL, [dat08] SHORTDATE NOT NULL, [dat09] SHORTDATE NOT NULL, [dat10] SHORTDATE NOT NULL, [val01] REAL NOT NULL, [val02] REAL NOT NULL, [val03] REAL NOT NULL, [val04] REAL NOT NULL, [val05] REAL NOT NULL, [val06] REAL NOT NULL, [val07] REAL NOT NULL, [val08] REAL NOT NULL, [val09] REAL NOT NULL, [val10] REAL NOT NULL, [obs1] TEXT(70) NOT NULL, [obs2] TEXT(70) NOT NULL, [obs3] TEXT(70) NOT NULL, [lin01] TEXT(80) NOT NULL, [lin02] TEXT(80) NOT NULL, [lin03] TEXT(80) NOT NULL, [lin04] TEXT(80) NOT NULL, [lin05] TEXT(80) NOT NULL, [lin06] TEXT(80) NOT NULL, [lin07] TEXT(80) NOT NULL, [lin08] TEXT(80) NOT NULL, [transp] REAL NOT NULL, [motorista] TEXT(20) NOT NULL, [nometrans] TEXT(40) NOT NULL, [endetrans] TEXT(40) NOT NULL, [bairtrans] TEXT(30) NOT NULL, [cidatrans] TEXT(30) NOT NULL, [estatrans] TEXT(2) NOT NULL, [ceptrans] TEXT(9) NOT NULL, [cgctrans] TEXT(18) NOT NULL, [ietrans] TEXT(15) NOT NULL, [chapa] TEXT(8) NOT NULL, [endereco3] TEXT(40) NOT NULL, [bairro3] TEXT(30) NOT NULL, [cidade3] TEXT(30) NOT NULL, [estado3] TEXT(2) NOT NULL, [cep3] TEXT(9) NOT NULL, [cgc3] TEXT(18) NOT NULL, [insc3] TEXT(15) NOT NULL, [tiponf] TEXT(1) NOT NULL, [tipofr] TEXT(1) NOT NULL, [apura] TEXT(1) NOT NULL, [especie] TEXT(5) NOT NULL, [serie] TEXT(5) NOT NULL, [modelo] TEXT(2) NOT NULL, [estado] TEXT(2) NOT NULL, [ordem] REAL NOT NULL, [totbasicm] REAL NOT NULL, [totvalicm] REAL NOT NULL, [totiseicm] REAL NOT NULL, [totouticm] REAL NOT NULL, [totbasipi] REAL NOT NULL, [totvalipi] REAL NOT NULL, [totiseipi] REAL NOT NULL, [totoutipi] REAL NOT NULL, [totvalnf] REAL NOT NULL, [copia] REAL NOT NULL, [contsim] TEXT(1) NOT NULL, [cancelada] TEXT(1) NOT NULL, [geraae] TEXT(1) NOT NULL, [horaemi] TEXT(8) NOT NULL, [horaae] TEXT(8) NOT NULL, [valrem] REAL NOT NULL);

-- Tabela: mm02
CREATE TABLE IF NOT EXISTS [mm02] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [operacao] TEXT(7) NOT NULL, [suboper] TEXT(1) NOT NULL, [cfonew] TEXT(5) NOT NULL, [cfonewb] TEXT(5) NOT NULL, [tipoent] TEXT(1) NOT NULL, [tiposerv] TEXT(1) NOT NULL, [os] REAL NOT NULL, [qtde] REAL NOT NULL, [unid] TEXT(2) NOT NULL, [peso] REAL NOT NULL, [compra] TEXT(9) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(25) NOT NULL, [preco] REAL NOT NULL, [valormer] REAL NOT NULL, [codipi] TEXT(2) NOT NULL, [ipi] REAL NOT NULL, [valoripi] REAL NOT NULL, [baseipi] REAL NOT NULL, [valortot] REAL NOT NULL, [classipi] TEXT(10) NOT NULL, [icm] REAL NOT NULL, [baseicm] REAL NOT NULL, [valoricm] REAL NOT NULL, [consumo] TEXT(1) NOT NULL, [notadev] REAL NOT NULL, [docdev] REAL NOT NULL, [datadev] SHORTDATE NOT NULL, [totdev] REAL NOT NULL, [totsdev] REAL NOT NULL, [dev] REAL NOT NULL, [qtdedev] REAL NOT NULL, [unidev] TEXT(2) NOT NULL, [prcdev] REAL NOT NULL, [coddev] TEXT(10) NOT NULL, [notade2] REAL NOT NULL, [docdev2] REAL NOT NULL, [datade2] SHORTDATE NOT NULL, [totde2] REAL NOT NULL, [totsde2] REAL NOT NULL, [de2] REAL NOT NULL, [qtdede2] REAL NOT NULL, [unide2] TEXT(2) NOT NULL, [prcde2] REAL NOT NULL, [codde2] TEXT(10) NOT NULL, [alos] TEXT(1) NOT NULL, [alse] REAL NOT NULL, [alma] TEXT(1) NOT NULL, [alde] TEXT(1) NOT NULL, [mbbn] TEXT(1) NOT NULL, [mbbp] TEXT(1) NOT NULL, [codicm] TEXT(3) NOT NULL, [linadd01] TEXT(45) NOT NULL, [linadd02] TEXT(45) NOT NULL, [linadd03] TEXT(45) NOT NULL, [linadd04] TEXT(45) NOT NULL, [linadd05] TEXT(45) NOT NULL, [linadd06] TEXT(45) NOT NULL, [apura] TEXT(1) NOT NULL, [indice] TEXT(12) NOT NULL, [seq] REAL NOT NULL, [pestot] REAL NOT NULL, [especie] TEXT(5) NOT NULL, [somanf] TEXT(1) NOT NULL, [dipicm] TEXT(1) NOT NULL, [dipipi] TEXT(1) NOT NULL, [rastro] TEXT(22) NOT NULL, [rastr2] TEXT(22) NOT NULL, [pedidocli] TEXT(20) NOT NULL, [entrega] SHORTDATE NOT NULL, [qtdesal] REAL NOT NULL, [redicm] REAL NOT NULL, [avembq] REAL NOT NULL, [avembc] TEXT(24) NOT NULL, [fatbx] TEXT(1) NOT NULL, [pedido] TEXT(10) NOT NULL, [piscon] TEXT(1) NOT NULL, [impmy] BIT NOT NULL, [pedcliite] REAL NOT NULL);

-- Tabela: mm02l
CREATE TABLE IF NOT EXISTS [mm02l] ([nummens] REAL NOT NULL, [desmens] TEXT(60) NOT NULL, [lin01] TEXT(45) NOT NULL, [lin02] TEXT(45) NOT NULL, [lin03] TEXT(45) NOT NULL, [lin04] TEXT(45) NOT NULL, [lin05] TEXT(45) NOT NULL, [lin06] TEXT(45) NOT NULL, [lin07] TEXT(45) NOT NULL, [lin08] TEXT(45) NOT NULL);

-- Tabela: mm03
CREATE TABLE IF NOT EXISTS [mm03] ([nummens] REAL NOT NULL, [desmens] TEXT(60) NOT NULL, [lin01] TEXT(70) NOT NULL, [lin02] TEXT(70) NOT NULL, [lin03] TEXT(70) NOT NULL, [lin04] TEXT(70) NOT NULL, [lin05] TEXT(70) NOT NULL, [lin06] TEXT(70) NOT NULL, [lin07] TEXT(70) NOT NULL, [lin08] TEXT(70) NOT NULL);

-- Tabela: mm04
CREATE TABLE IF NOT EXISTS [mm04] ([nummens] REAL NOT NULL, [desmens] TEXT(60) NOT NULL, [lin01] TEXT(80) NOT NULL, [lin02] TEXT(80) NOT NULL, [lin03] TEXT(80) NOT NULL, [lin04] TEXT(80) NOT NULL, [lin05] TEXT(80) NOT NULL, [lin06] TEXT(80) NOT NULL, [lin07] TEXT(80) NOT NULL, [lin08] TEXT(80) NOT NULL);

-- Tabela: mm05
CREATE TABLE IF NOT EXISTS [mm05] ([operacao] TEXT(7) NOT NULL, [classipi] TEXT(14) NOT NULL, [totalmer] REAL NOT NULL, [totalipi] REAL NOT NULL, [totpeso] REAL NOT NULL);

-- Tabela: mm06
CREATE TABLE IF NOT EXISTS [mm06] ([ordem] REAL NOT NULL, [numero] REAL NOT NULL, [item] REAL NOT NULL, [data] SHORTDATE NOT NULL, [dataref] SHORTDATE NOT NULL, [tipofor] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [doper] TEXT(3) NOT NULL, [dcfonew] TEXT(4) NOT NULL, [subdoper] TEXT(1) NOT NULL, [somanf] TEXT(1) NOT NULL, [consumo] TEXT(1) NOT NULL, [dbaseicm] REAL NOT NULL, [dicm] REAL NOT NULL, [dvalicm] REAL NOT NULL, [isentaicm] REAL NOT NULL, [outraicm] REAL NOT NULL, [dbaseipi] REAL NOT NULL, [dipi] REAL NOT NULL, [dvalipi] REAL NOT NULL, [isentaipi] REAL NOT NULL, [outraipi] REAL NOT NULL, [dclassipi] TEXT(12) NOT NULL, [dvalornf] REAL NOT NULL, [unidade] TEXT(2) NOT NULL, [quant] REAL NOT NULL, [micm01] REAL NOT NULL, [micm02] REAL NOT NULL, [micm03] REAL NOT NULL, [mipi01] REAL NOT NULL, [mipi02] REAL NOT NULL, [mipi03] REAL NOT NULL, [lote] REAL NOT NULL, [dipam] TEXT(2) NOT NULL, [especie] TEXT(3) NOT NULL, [dcancel] SHORTDATE NOT NULL, [obs] TEXT(30) NOT NULL, [chkipi] TEXT(1) NOT NULL, [obsicm] REAL NOT NULL, [obsipi] REAL NOT NULL, [dpiscon] TEXT(1) NOT NULL, [pulasin] TEXT(1) NOT NULL, [descsin] REAL NOT NULL);

-- Tabela: mm07
CREATE TABLE IF NOT EXISTS [mm07] ([reqdev] REAL NOT NULL, [cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [nf] REAL NOT NULL, [nfc] REAL NOT NULL, [produto] TEXT(24) NOT NULL, [datanf] SHORTDATE NOT NULL, [datadev] SHORTDATE NOT NULL, [valor] REAL NOT NULL);

-- Tabela: mm08
CREATE TABLE IF NOT EXISTS [mm08] ([tipoent] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [fornecedo] REAL NOT NULL, [redicm] REAL NOT NULL);

-- Tabela: mm09
CREATE TABLE IF NOT EXISTS [mm09] ([ordem] REAL NOT NULL, [numero] REAL NOT NULL, [item] REAL NOT NULL, [data] SHORTDATE NOT NULL, [dataref] SHORTDATE NOT NULL, [tipofor] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [doper] TEXT(3) NOT NULL, [dcfonew] TEXT(5) NOT NULL, [subdoper] TEXT(1) NOT NULL, [somanf] TEXT(1) NOT NULL, [consumo] TEXT(1) NOT NULL, [dbaseicm] REAL NOT NULL, [dicm] REAL NOT NULL, [dvalicm] REAL NOT NULL, [isentaicm] REAL NOT NULL, [outraicm] REAL NOT NULL, [dbaseipi] REAL NOT NULL, [dipi] REAL NOT NULL, [dvalipi] REAL NOT NULL, [isentaipi] REAL NOT NULL, [outraipi] REAL NOT NULL, [dclassipi] TEXT(12) NOT NULL, [dvalornf] REAL NOT NULL, [unidade] TEXT(2) NOT NULL, [quant] REAL NOT NULL, [micm01] REAL NOT NULL, [micm02] REAL NOT NULL, [micm03] REAL NOT NULL, [mipi01] REAL NOT NULL, [mipi02] REAL NOT NULL, [mipi03] REAL NOT NULL, [lote] REAL NOT NULL, [dipam] TEXT(2) NOT NULL, [especie] TEXT(5) NOT NULL, [obs] TEXT(50) NOT NULL, [obsicm] REAL NOT NULL, [obsipi] REAL NOT NULL, [dcancel] SHORTDATE NOT NULL, [dpiscon] TEXT(1) NOT NULL, [chkipi] TEXT(1) NOT NULL, [serie] TEXT(5) NOT NULL, [situacao] TEXT(1) NOT NULL, [codrec] TEXT(5) NOT NULL);

-- Tabela: mm90
CREATE TABLE IF NOT EXISTS [mm90] ([ordem] REAL NOT NULL, [numero] REAL NOT NULL, [item] REAL NOT NULL, [data] SHORTDATE NOT NULL, [dataref] SHORTDATE NOT NULL, [tipofor] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [doper] TEXT(3) NOT NULL, [dcfonew] TEXT(5) NOT NULL, [subdoper] TEXT(1) NOT NULL, [somanf] TEXT(1) NOT NULL, [consumo] TEXT(1) NOT NULL, [dbaseicm] REAL NOT NULL, [dicm] REAL NOT NULL, [dvalicm] REAL NOT NULL, [isentaicm] REAL NOT NULL, [outraicm] REAL NOT NULL, [dbaseipi] REAL NOT NULL, [dipi] REAL NOT NULL, [dvalipi] REAL NOT NULL, [isentaipi] REAL NOT NULL, [outraipi] REAL NOT NULL, [dclassipi] TEXT(12) NOT NULL, [dvalornf] REAL NOT NULL, [unidade] TEXT(2) NOT NULL, [quant] REAL NOT NULL, [micm01] REAL NOT NULL, [micm02] REAL NOT NULL, [micm03] REAL NOT NULL, [mipi01] REAL NOT NULL, [mipi02] REAL NOT NULL, [mipi03] REAL NOT NULL, [lote] REAL NOT NULL, [dipam] TEXT(2) NOT NULL, [especie] TEXT(5) NOT NULL, [obs] TEXT(50) NOT NULL, [obsicm] REAL NOT NULL, [obsipi] REAL NOT NULL, [dcancel] SHORTDATE NOT NULL, [dpiscon] TEXT(1) NOT NULL, [chkipi] TEXT(1) NOT NULL, [serie] TEXT(5) NOT NULL, [situacao] TEXT(1) NOT NULL, [codrec] TEXT(5) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: mm91
CREATE TABLE IF NOT EXISTS [mm91] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tiposerv] TEXT(1) NOT NULL, [tipocli] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [vendedor] TEXT(5) NOT NULL, [operacao] TEXT(7) NOT NULL, [suboper] TEXT(1) NOT NULL, [cfonew] TEXT(5) NOT NULL, [cfonewb] TEXT(5) NOT NULL, [viatrans] TEXT(20) NOT NULL, [icm] REAL NOT NULL, [totbicm] REAL NOT NULL, [toticm] REAL NOT NULL, [totbipi] REAL NOT NULL, [totipi] REAL NOT NULL, [totmer] REAL NOT NULL, [totnf] REAL NOT NULL, [totalpes] REAL NOT NULL, [totalbru] REAL NOT NULL, [marcaemb] TEXT(5) NOT NULL, [numeroemb] TEXT(5) NOT NULL, [quantemb] REAL NOT NULL, [embalagem] TEXT(15) NOT NULL, [condpag] TEXT(2) NOT NULL, [dat01] SHORTDATE NOT NULL, [dat02] SHORTDATE NOT NULL, [dat03] SHORTDATE NOT NULL, [dat04] SHORTDATE NOT NULL, [dat05] SHORTDATE NOT NULL, [dat06] SHORTDATE NOT NULL, [dat07] SHORTDATE NOT NULL, [dat08] SHORTDATE NOT NULL, [dat09] SHORTDATE NOT NULL, [dat10] SHORTDATE NOT NULL, [val01] REAL NOT NULL, [val02] REAL NOT NULL, [val03] REAL NOT NULL, [val04] REAL NOT NULL, [val05] REAL NOT NULL, [val06] REAL NOT NULL, [val07] REAL NOT NULL, [val08] REAL NOT NULL, [val09] REAL NOT NULL, [val10] REAL NOT NULL, [obs1] TEXT(70) NOT NULL, [obs2] TEXT(70) NOT NULL, [obs3] TEXT(70) NOT NULL, [lin01] TEXT(80) NOT NULL, [lin02] TEXT(80) NOT NULL, [lin03] TEXT(80) NOT NULL, [lin04] TEXT(80) NOT NULL, [lin05] TEXT(80) NOT NULL, [lin06] TEXT(80) NOT NULL, [lin07] TEXT(80) NOT NULL, [lin08] TEXT(80) NOT NULL, [transp] REAL NOT NULL, [motorista] TEXT(20) NOT NULL, [nometrans] TEXT(40) NOT NULL, [endetrans] TEXT(40) NOT NULL, [bairtrans] TEXT(30) NOT NULL, [cidatrans] TEXT(30) NOT NULL, [estatrans] TEXT(2) NOT NULL, [ceptrans] TEXT(9) NOT NULL, [cgctrans] TEXT(18) NOT NULL, [ietrans] TEXT(15) NOT NULL, [chapa] TEXT(8) NOT NULL, [endereco3] TEXT(40) NOT NULL, [bairro3] TEXT(30) NOT NULL, [cidade3] TEXT(30) NOT NULL, [estado3] TEXT(2) NOT NULL, [cep3] TEXT(9) NOT NULL, [cgc3] TEXT(18) NOT NULL, [insc3] TEXT(15) NOT NULL, [tiponf] TEXT(1) NOT NULL, [tipofr] TEXT(1) NOT NULL, [apura] TEXT(1) NOT NULL, [especie] TEXT(5) NOT NULL, [serie] TEXT(5) NOT NULL, [modelo] TEXT(2) NOT NULL, [estado] TEXT(2) NOT NULL, [ordem] REAL NOT NULL, [totbasicm] REAL NOT NULL, [totvalicm] REAL NOT NULL, [totiseicm] REAL NOT NULL, [totouticm] REAL NOT NULL, [totbasipi] REAL NOT NULL, [totvalipi] REAL NOT NULL, [totiseipi] REAL NOT NULL, [totoutipi] REAL NOT NULL, [totvalnf] REAL NOT NULL, [copia] REAL NOT NULL, [contsim] TEXT(1) NOT NULL, [cancelada] TEXT(1) NOT NULL, [geraae] TEXT(1) NOT NULL, [horaemi] TEXT(8) NOT NULL, [horaae] TEXT(8) NOT NULL, [valrem] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: mm92
CREATE TABLE IF NOT EXISTS [mm92] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [operacao] TEXT(7) NOT NULL, [suboper] TEXT(1) NOT NULL, [cfonew] TEXT(5) NOT NULL, [cfonewb] TEXT(5) NOT NULL, [tipoent] TEXT(1) NOT NULL, [tiposerv] TEXT(1) NOT NULL, [os] REAL NOT NULL, [qtde] REAL NOT NULL, [unid] TEXT(2) NOT NULL, [peso] REAL NOT NULL, [compra] TEXT(9) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(25) NOT NULL, [preco] REAL NOT NULL, [valormer] REAL NOT NULL, [codipi] TEXT(2) NOT NULL, [ipi] REAL NOT NULL, [valoripi] REAL NOT NULL, [baseipi] REAL NOT NULL, [valortot] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [icm] REAL NOT NULL, [baseicm] REAL NOT NULL, [valoricm] REAL NOT NULL, [consumo] TEXT(1) NOT NULL, [notadev] REAL NOT NULL, [datadev] SHORTDATE NOT NULL, [totdev] REAL NOT NULL, [totsdev] REAL NOT NULL, [dev] REAL NOT NULL, [qtdedev] REAL NOT NULL, [unidev] TEXT(2) NOT NULL, [prcdev] REAL NOT NULL, [coddev] TEXT(10) NOT NULL, [notade2] REAL NOT NULL, [datade2] SHORTDATE NOT NULL, [totde2] REAL NOT NULL, [totsde2] REAL NOT NULL, [de2] REAL NOT NULL, [qtdede2] REAL NOT NULL, [unide2] TEXT(2) NOT NULL, [prcde2] REAL NOT NULL, [codde2] TEXT(10) NOT NULL, [alos] TEXT(6) NOT NULL, [alse] REAL NOT NULL, [alma] TEXT(8) NOT NULL, [alde] TEXT(12) NOT NULL, [mbbn] TEXT(6) NOT NULL, [mbbp] TEXT(13) NOT NULL, [codicm] TEXT(3) NOT NULL, [linadd01] TEXT(45) NOT NULL, [linadd02] TEXT(45) NOT NULL, [linadd03] TEXT(45) NOT NULL, [linadd04] TEXT(45) NOT NULL, [linadd05] TEXT(45) NOT NULL, [linadd06] TEXT(45) NOT NULL, [apura] TEXT(1) NOT NULL, [indice] TEXT(12) NOT NULL, [seq] REAL NOT NULL, [pestot] REAL NOT NULL, [especie] TEXT(5) NOT NULL, [somanf] TEXT(1) NOT NULL, [dipicm] TEXT(1) NOT NULL, [dipipi] TEXT(1) NOT NULL, [rastro] TEXT(25) NOT NULL, [rastr2] TEXT(40) NOT NULL, [pedidocli] TEXT(20) NOT NULL, [entrega] SHORTDATE NOT NULL, [qtdesal] REAL NOT NULL, [redicm] REAL NOT NULL, [avembq] REAL NOT NULL, [avembc] TEXT(24) NOT NULL, [fatbx] TEXT(1) NOT NULL, [pedido] TEXT(10) NOT NULL, [piscon] TEXT(1) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [pedcliite] REAL NOT NULL);

-- Tabela: mm96
CREATE TABLE IF NOT EXISTS [mm96] ([ordem] REAL NOT NULL, [numero] REAL NOT NULL, [item] REAL NOT NULL, [data] SHORTDATE NOT NULL, [dataref] SHORTDATE NOT NULL, [tipofor] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [doper] TEXT(3) NOT NULL, [dcfonew] TEXT(4) NOT NULL, [subdoper] TEXT(1) NOT NULL, [somanf] TEXT(1) NOT NULL, [consumo] TEXT(1) NOT NULL, [dbaseicm] REAL NOT NULL, [dicm] REAL NOT NULL, [dvalicm] REAL NOT NULL, [isentaicm] REAL NOT NULL, [outraicm] REAL NOT NULL, [dbaseipi] REAL NOT NULL, [dipi] REAL NOT NULL, [dvalipi] REAL NOT NULL, [isentaipi] REAL NOT NULL, [outraipi] REAL NOT NULL, [dclassipi] TEXT(12) NOT NULL, [dvalornf] REAL NOT NULL, [unidade] TEXT(2) NOT NULL, [quant] REAL NOT NULL, [micm01] REAL NOT NULL, [micm02] REAL NOT NULL, [micm03] REAL NOT NULL, [mipi01] REAL NOT NULL, [mipi02] REAL NOT NULL, [mipi03] REAL NOT NULL, [lote] REAL NOT NULL, [dipam] TEXT(2) NOT NULL, [especie] TEXT(3) NOT NULL, [dcancel] SHORTDATE NOT NULL, [obs] TEXT(30) NOT NULL, [chkipi] TEXT(1) NOT NULL, [obsicm] REAL NOT NULL, [obsipi] REAL NOT NULL, [dpiscon] TEXT(1) NOT NULL, [pulasin] TEXT(1) NOT NULL, [descsin] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: mm99
CREATE TABLE IF NOT EXISTS [mm99] ([ordem] REAL NOT NULL, [numero] REAL NOT NULL, [item] REAL NOT NULL, [data] SHORTDATE NOT NULL, [dataref] SHORTDATE NOT NULL, [tipofor] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [doper] TEXT(3) NOT NULL, [dcfonew] TEXT(5) NOT NULL, [subdoper] TEXT(1) NOT NULL, [somanf] TEXT(1) NOT NULL, [consumo] TEXT(1) NOT NULL, [dbaseicm] REAL NOT NULL, [dicm] REAL NOT NULL, [dvalicm] REAL NOT NULL, [isentaicm] REAL NOT NULL, [outraicm] REAL NOT NULL, [dbaseipi] REAL NOT NULL, [dipi] REAL NOT NULL, [dvalipi] REAL NOT NULL, [isentaipi] REAL NOT NULL, [outraipi] REAL NOT NULL, [dclassipi] TEXT(12) NOT NULL, [dvalornf] REAL NOT NULL, [unidade] TEXT(2) NOT NULL, [quant] REAL NOT NULL, [micm01] REAL NOT NULL, [micm02] REAL NOT NULL, [micm03] REAL NOT NULL, [mipi01] REAL NOT NULL, [mipi02] REAL NOT NULL, [mipi03] REAL NOT NULL, [lote] REAL NOT NULL, [dipam] TEXT(2) NOT NULL, [especie] TEXT(3) NOT NULL, [obs] TEXT(50) NOT NULL, [obsicm] REAL NOT NULL, [obsipi] REAL NOT NULL, [dcancel] SHORTDATE NOT NULL, [dpiscon] TEXT(1) NOT NULL, [chkipi] TEXT(1) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: mn01
CREATE TABLE IF NOT EXISTS [mn01] ([numero] REAL NOT NULL, [nrnota] REAL NOT NULL, [tipfat] TEXT(1) NOT NULL, [operacao] TEXT(21) NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [pedido] REAL NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [vendedor] TEXT(5) NOT NULL, [totnf] REAL NOT NULL, [situacao] REAL NOT NULL, [banco] TEXT(3) NOT NULL, [nomebco] TEXT(12) NOT NULL, [docbol] TEXT(15) NOT NULL, [docdup] TEXT(15) NOT NULL, [venciment] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [nota] REAL NOT NULL, [docabate] REAL NOT NULL, [abater] REAL NOT NULL, [taxa] REAL NOT NULL, [dias] REAL NOT NULL, [juros] REAL NOT NULL, [jurval] REAL NOT NULL, [valatual] REAL NOT NULL, [obs] TEXT(55) NOT NULL, [obs1] TEXT(70) NOT NULL, [obs2] TEXT(70) NOT NULL, [obs3] TEXT(70) NOT NULL, [obs4] TEXT(70) NOT NULL, [datapg] SHORTDATE NOT NULL, [valorpg] REAL NOT NULL, [diferenca] REAL NOT NULL, [nf_comple] TEXT(40) NOT NULL, [codcomp] TEXT(1) NOT NULL, [impdup] TEXT(1) NOT NULL, [prevatr] REAL NOT NULL, [fluxo] TEXT(1) NOT NULL, [tipocli] TEXT(1) NOT NULL, [bcodep] REAL NOT NULL, [agcdep] TEXT(6) NOT NULL, [ctadep] TEXT(6) NOT NULL, [conta] TEXT(12) NOT NULL, [geracob] TEXT(1) NOT NULL, [cliente] REAL NOT NULL);

-- Tabela: mn01pg
CREATE TABLE IF NOT EXISTS [mn01pg] ([numero] REAL NOT NULL, [nrnota] REAL NOT NULL, [tipfat] TEXT(1) NOT NULL, [operacao] TEXT(21) NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [pedido] REAL NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [vendedor] TEXT(5) NOT NULL, [totnf] REAL NOT NULL, [situacao] REAL NOT NULL, [banco] TEXT(3) NOT NULL, [nomebco] TEXT(12) NOT NULL, [docbol] TEXT(15) NOT NULL, [docdup] TEXT(15) NOT NULL, [venciment] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [nota] REAL NOT NULL, [docabate] REAL NOT NULL, [abater] REAL NOT NULL, [taxa] REAL NOT NULL, [dias] REAL NOT NULL, [juros] REAL NOT NULL, [jurval] REAL NOT NULL, [valatual] REAL NOT NULL, [obs] TEXT(55) NOT NULL, [obs1] TEXT(70) NOT NULL, [obs2] TEXT(70) NOT NULL, [obs3] TEXT(70) NOT NULL, [obs4] TEXT(70) NOT NULL, [datapg] SHORTDATE NOT NULL, [valorpg] REAL NOT NULL, [diferenca] REAL NOT NULL, [nf_comple] TEXT(40) NOT NULL, [codcomp] TEXT(1) NOT NULL, [impdup] TEXT(1) NOT NULL, [prevatr] REAL NOT NULL, [fluxo] TEXT(1) NOT NULL, [tipocli] TEXT(1) NOT NULL, [bcodep] REAL NOT NULL, [agcdep] TEXT(6) NOT NULL, [ctadep] TEXT(6) NOT NULL, [conta] TEXT(12) NOT NULL, [geracob] TEXT(1) NOT NULL, [cliente] REAL NOT NULL);

-- Tabela: mn02
CREATE TABLE IF NOT EXISTS [mn02] ([nrnota] REAL NOT NULL, [data] SHORTDATE NOT NULL, [cliente] REAL NOT NULL, [operacao] TEXT(7) NOT NULL, [pedido] TEXT(15) NOT NULL, [os] REAL NOT NULL, [itemfat] REAL NOT NULL, [qtde] REAL NOT NULL, [unid] TEXT(2) NOT NULL, [pesliq] REAL NOT NULL, [codigo] TEXT(7) NOT NULL, [nome] TEXT(40) NOT NULL, [preco] REAL NOT NULL, [valormer] REAL NOT NULL, [codipi] TEXT(2) NOT NULL, [classipi] TEXT(14) NOT NULL, [ipi] REAL NOT NULL, [baseipi] REAL NOT NULL, [valoripi] REAL NOT NULL, [valortot] REAL NOT NULL, [icm] REAL NOT NULL, [baseicm] REAL NOT NULL, [valoricm] REAL NOT NULL, [nota_dev] REAL NOT NULL, [data_dev] SHORTDATE NOT NULL, [qtde_dev] REAL NOT NULL, [vald_dev] REAL NOT NULL, [nota_dev2] REAL NOT NULL, [data_dev2] SHORTDATE NOT NULL, [qtde_dev2] REAL NOT NULL, [vald_dev2] REAL NOT NULL);

-- Tabela: mn03
CREATE TABLE IF NOT EXISTS [mn03] ([nrnota] REAL NOT NULL, [tipfat] TEXT(1) NOT NULL, [banco] TEXT(3) NOT NULL, [agencia] TEXT(7) NOT NULL, [conta] TEXT(12) NOT NULL, [cheque] TEXT(15) NOT NULL, [data] SHORTDATE NOT NULL, [datadep] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [predatado] TEXT(1) NOT NULL, [datapara] SHORTDATE NOT NULL, [valordes] REAL NOT NULL, [valorneg] REAL NOT NULL, [ctacusto] TEXT(15) NOT NULL, [depdata] SHORTDATE NOT NULL, [depbco] REAL NOT NULL, [depagc] TEXT(7) NOT NULL, [depcta] TEXT(12) NOT NULL, [dev01data] SHORTDATE NOT NULL, [dev01cod] TEXT(10) NOT NULL, [dep01data] SHORTDATE NOT NULL, [dev01dep] REAL NOT NULL, [dev02data] SHORTDATE NOT NULL, [dev02cod] TEXT(10) NOT NULL, [dev02dep] REAL NOT NULL, [rep02data] SHORTDATE NOT NULL, [compensado] SHORTDATE NOT NULL, [obs] TEXT(100) NOT NULL, [finalizado] TEXT(1) NOT NULL, [cliente] REAL NOT NULL);

-- Tabela: mn03pg
CREATE TABLE IF NOT EXISTS [mn03pg] ([nrnota] REAL NOT NULL, [tipfat] TEXT(1) NOT NULL, [banco] TEXT(3) NOT NULL, [agencia] TEXT(7) NOT NULL, [conta] TEXT(12) NOT NULL, [cheque] TEXT(15) NOT NULL, [data] SHORTDATE NOT NULL, [datadep] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [predatado] TEXT(1) NOT NULL, [datapara] SHORTDATE NOT NULL, [valordes] REAL NOT NULL, [valorneg] REAL NOT NULL, [ctacusto] TEXT(15) NOT NULL, [depdata] SHORTDATE NOT NULL, [depbco] REAL NOT NULL, [depagc] TEXT(7) NOT NULL, [depcta] TEXT(12) NOT NULL, [dev01data] SHORTDATE NOT NULL, [dev01cod] TEXT(10) NOT NULL, [dep01data] SHORTDATE NOT NULL, [dev01dep] REAL NOT NULL, [dev02data] SHORTDATE NOT NULL, [dev02cod] TEXT(10) NOT NULL, [dev02dep] REAL NOT NULL, [rep02data] SHORTDATE NOT NULL, [compensado] SHORTDATE NOT NULL, [obs] TEXT(100) NOT NULL, [finalizado] TEXT(1) NOT NULL, [cliente] REAL NOT NULL);

-- Tabela: mn98
CREATE TABLE IF NOT EXISTS [mn98] ([nrnota] REAL NOT NULL, [tipfat] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [pedido] REAL NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(8) NOT NULL, [vendedor] TEXT(5) NOT NULL, [totfat] REAL NOT NULL, [situacao] REAL NOT NULL, [banco] TEXT(3) NOT NULL, [nomebco] TEXT(12) NOT NULL, [docbol] REAL NOT NULL, [docdup] REAL NOT NULL, [venciment] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [nota] REAL NOT NULL, [docabate] REAL NOT NULL, [abater] REAL NOT NULL, [taxa] REAL NOT NULL, [dias] REAL NOT NULL, [juros] REAL NOT NULL, [valatual] REAL NOT NULL, [obs] TEXT(55) NOT NULL, [obs1] TEXT(70) NOT NULL, [obs2] TEXT(70) NOT NULL, [obs3] TEXT(70) NOT NULL, [obs4] TEXT(70) NOT NULL, [datapg] SHORTDATE NOT NULL, [valorpg] REAL NOT NULL, [diferenca] REAL NOT NULL, [fluxo] TEXT(1) NOT NULL, [prevatr] REAL NOT NULL, [aviso] TEXT(1) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: mn99
CREATE TABLE IF NOT EXISTS [mn99] ([numero] REAL NOT NULL, [nrnota] REAL NOT NULL, [tipfat] TEXT(1) NOT NULL, [operacao] TEXT(21) NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [pedido] REAL NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [vendedor] TEXT(5) NOT NULL, [totnf] REAL NOT NULL, [situacao] REAL NOT NULL, [banco] TEXT(3) NOT NULL, [nomebco] TEXT(12) NOT NULL, [docbol] TEXT(15) NOT NULL, [docdup] TEXT(15) NOT NULL, [venciment] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [nota] REAL NOT NULL, [docabate] REAL NOT NULL, [abater] REAL NOT NULL, [taxa] REAL NOT NULL, [dias] REAL NOT NULL, [juros] REAL NOT NULL, [jurval] REAL NOT NULL, [valatual] REAL NOT NULL, [obs] TEXT(55) NOT NULL, [obs1] TEXT(70) NOT NULL, [obs2] TEXT(70) NOT NULL, [obs3] TEXT(70) NOT NULL, [obs4] TEXT(70) NOT NULL, [datapg] SHORTDATE NOT NULL, [valorpg] REAL NOT NULL, [diferenca] REAL NOT NULL, [nf_comple] TEXT(40) NOT NULL, [codcomp] TEXT(1) NOT NULL, [impdup] TEXT(1) NOT NULL, [prevatr] REAL NOT NULL, [fluxo] TEXT(1) NOT NULL, [tipocli] TEXT(1) NOT NULL, [bcodep] REAL NOT NULL, [agcdep] TEXT(6) NOT NULL, [ctadep] TEXT(6) NOT NULL, [conta] TEXT(12) NOT NULL, [geracob] TEXT(1) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: mo01
CREATE TABLE IF NOT EXISTS [mo01] ([pedido] REAL NOT NULL, [os] REAL NOT NULL, [tiposerv] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [vendedor] TEXT(5) NOT NULL, [comissao] REAL NOT NULL, [zona] TEXT(5) NOT NULL, [database] SHORTDATE NOT NULL, [matprima] TEXT(2) NOT NULL, [condpag] TEXT(2) NOT NULL, [consumo] TEXT(1) NOT NULL, [pedidocli] TEXT(20) NOT NULL, [icm] REAL NOT NULL, [totbicm] REAL NOT NULL, [toticm] REAL NOT NULL, [totbipi] REAL NOT NULL, [totipi] REAL NOT NULL, [totmer] REAL NOT NULL, [totnf] REAL NOT NULL, [entrega] SHORTDATE NOT NULL, [baixam] TEXT(1) NOT NULL, [tipoprg] TEXT(1) NOT NULL, [pedcliite] REAL NOT NULL);

-- Tabela: mo01bx
CREATE TABLE IF NOT EXISTS [mo01bx] ([pedido] REAL NOT NULL, [os] REAL NOT NULL, [tiposerv] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [vendedor] TEXT(5) NOT NULL, [comissao] REAL NOT NULL, [zona] TEXT(5) NOT NULL, [database] SHORTDATE NOT NULL, [matprima] TEXT(2) NOT NULL, [condpag] TEXT(2) NOT NULL, [consumo] TEXT(1) NOT NULL, [pedidocli] TEXT(20) NOT NULL, [icm] REAL NOT NULL, [totbicm] REAL NOT NULL, [toticm] REAL NOT NULL, [totbipi] REAL NOT NULL, [totipi] REAL NOT NULL, [totmer] REAL NOT NULL, [totnf] REAL NOT NULL, [entrega] SHORTDATE NOT NULL, [baixam] TEXT(1) NOT NULL, [tipoprg] TEXT(1) NOT NULL, [pedcliite] REAL NOT NULL);

-- Tabela: mo02
CREATE TABLE IF NOT EXISTS [mo02] ([pedido] REAL NOT NULL, [os] REAL NOT NULL, [tiposerv] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [vendedor] TEXT(1) NOT NULL, [comissao] REAL NOT NULL, [zona] TEXT(5) NOT NULL, [database] SHORTDATE NOT NULL, [matprima] TEXT(1) NOT NULL, [consumo] TEXT(1) NOT NULL, [horaped] REAL NOT NULL, [horaent] REAL NOT NULL, [horasal] REAL NOT NULL, [horafat] REAL NOT NULL, [qtdeped] REAL NOT NULL, [qtdeent] REAL NOT NULL, [qtdesal] REAL NOT NULL, [qtdefat] REAL NOT NULL, [fabricar] REAL NOT NULL, [pesouni] REAL NOT NULL, [unid] TEXT(2) NOT NULL, [item] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [compra] TEXT(1) NOT NULL, [lista] REAL NOT NULL, [nome] TEXT(40) NOT NULL, [indice] TEXT(12) NOT NULL, [valor] REAL NOT NULL, [valind] REAL NOT NULL, [valormer] REAL NOT NULL, [codipi] TEXT(2) NOT NULL, [ipi] REAL NOT NULL, [valoripi] REAL NOT NULL, [baseipi] REAL NOT NULL, [classipi] TEXT(10) NOT NULL, [tipi] TEXT(1) NOT NULL, [icm] REAL NOT NULL, [valoricm] REAL NOT NULL, [baseicm] REAL NOT NULL, [valortot] REAL NOT NULL, [entrega] SHORTDATE NOT NULL, [observacao] TEXT(30) NOT NULL, [notadev] REAL NOT NULL, [docdev] REAL NOT NULL, [datadev] SHORTDATE NOT NULL, [totdev] REAL NOT NULL, [totsdev] REAL NOT NULL, [dev] REAL NOT NULL, [qtdedev] REAL NOT NULL, [unidev] TEXT(2) NOT NULL, [prcdev] REAL NOT NULL, [coddev] TEXT(10) NOT NULL, [notade2] REAL NOT NULL, [docdev2] REAL NOT NULL, [datade2] SHORTDATE NOT NULL, [totde2] REAL NOT NULL, [totsde2] REAL NOT NULL, [de2] REAL NOT NULL, [qtdede2] REAL NOT NULL, [unide2] TEXT(2) NOT NULL, [prcde2] REAL NOT NULL, [codde2] TEXT(10) NOT NULL, [alos] TEXT(1) NOT NULL, [alse] REAL NOT NULL, [alma] TEXT(1) NOT NULL, [alde] TEXT(1) NOT NULL, [mbbn] TEXT(1) NOT NULL, [mbbp] TEXT(1) NOT NULL, [codicm] TEXT(3) NOT NULL, [dipicm] TEXT(1) NOT NULL, [dipipi] TEXT(1) NOT NULL, [rastro] TEXT(12) NOT NULL, [rastr2] TEXT(12) NOT NULL, [geraof] TEXT(1) NOT NULL, [planta] TEXT(2) NOT NULL, [pedmen] TEXT(1) NOT NULL, [fatura] TEXT(1) NOT NULL, [avembq] REAL NOT NULL, [avembc] TEXT(24) NOT NULL, [dataimp] SHORTDATE NOT NULL, [qtdepre] REAL NOT NULL, [codmr01] TEXT(10) NOT NULL, [pcemb] REAL NOT NULL, [pcembq] REAL NOT NULL, [qtdeant] REAL NOT NULL, [horaprg] REAL NOT NULL);

-- Tabela: mo02bx
CREATE TABLE IF NOT EXISTS [mo02bx] ([pedido] REAL NOT NULL, [os] REAL NOT NULL, [tiposerv] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [vendedor] TEXT(1) NOT NULL, [comissao] REAL NOT NULL, [zona] TEXT(5) NOT NULL, [database] SHORTDATE NOT NULL, [matprima] TEXT(1) NOT NULL, [consumo] TEXT(1) NOT NULL, [horaped] REAL NOT NULL, [horaent] REAL NOT NULL, [horasal] REAL NOT NULL, [horafat] REAL NOT NULL, [qtdeped] REAL NOT NULL, [qtdeent] REAL NOT NULL, [qtdesal] REAL NOT NULL, [qtdefat] REAL NOT NULL, [fabricar] REAL NOT NULL, [pesouni] REAL NOT NULL, [unid] TEXT(2) NOT NULL, [item] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [compra] TEXT(1) NOT NULL, [lista] REAL NOT NULL, [nome] TEXT(40) NOT NULL, [indice] TEXT(12) NOT NULL, [valor] REAL NOT NULL, [valind] REAL NOT NULL, [valormer] REAL NOT NULL, [codipi] TEXT(2) NOT NULL, [ipi] REAL NOT NULL, [valoripi] REAL NOT NULL, [baseipi] REAL NOT NULL, [classipi] TEXT(10) NOT NULL, [tipi] TEXT(1) NOT NULL, [icm] REAL NOT NULL, [valoricm] REAL NOT NULL, [baseicm] REAL NOT NULL, [valortot] REAL NOT NULL, [entrega] SHORTDATE NOT NULL, [observacao] TEXT(30) NOT NULL, [notadev] REAL NOT NULL, [docdev] REAL NOT NULL, [datadev] SHORTDATE NOT NULL, [totdev] REAL NOT NULL, [totsdev] REAL NOT NULL, [dev] REAL NOT NULL, [qtdedev] REAL NOT NULL, [unidev] TEXT(2) NOT NULL, [prcdev] REAL NOT NULL, [coddev] TEXT(10) NOT NULL, [notade2] REAL NOT NULL, [docdev2] REAL NOT NULL, [datade2] SHORTDATE NOT NULL, [totde2] REAL NOT NULL, [totsde2] REAL NOT NULL, [de2] REAL NOT NULL, [qtdede2] REAL NOT NULL, [unide2] TEXT(2) NOT NULL, [prcde2] REAL NOT NULL, [codde2] TEXT(10) NOT NULL, [alos] TEXT(1) NOT NULL, [alse] REAL NOT NULL, [alma] TEXT(1) NOT NULL, [alde] TEXT(1) NOT NULL, [mbbn] TEXT(1) NOT NULL, [mbbp] TEXT(1) NOT NULL, [codicm] TEXT(3) NOT NULL, [dipicm] TEXT(1) NOT NULL, [dipipi] TEXT(1) NOT NULL, [rastro] TEXT(12) NOT NULL, [rastr2] TEXT(12) NOT NULL, [geraof] TEXT(1) NOT NULL, [planta] TEXT(2) NOT NULL, [pedmen] TEXT(1) NOT NULL, [fatura] TEXT(1) NOT NULL, [avembq] REAL NOT NULL, [avembc] TEXT(24) NOT NULL, [dataimp] SHORTDATE NOT NULL, [qtdepre] REAL NOT NULL, [codmr01] TEXT(10) NOT NULL, [pcemb] REAL NOT NULL, [pcembq] REAL NOT NULL, [qtdeant] REAL NOT NULL, [horaprg] REAL NOT NULL);

-- Tabela: mo02x
CREATE TABLE IF NOT EXISTS [mo02x] ([pedido] REAL NOT NULL, [os] REAL NOT NULL, [tiposerv] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [vendedor] TEXT(1) NOT NULL, [comissao] REAL NOT NULL, [zona] TEXT(5) NOT NULL, [database] SHORTDATE NOT NULL, [matprima] TEXT(1) NOT NULL, [consumo] TEXT(1) NOT NULL, [horaped] REAL NOT NULL, [horaent] REAL NOT NULL, [horasal] REAL NOT NULL, [horafat] REAL NOT NULL, [qtdeped] REAL NOT NULL, [qtdeent] REAL NOT NULL, [qtdesal] REAL NOT NULL, [qtdefat] REAL NOT NULL, [fabricar] REAL NOT NULL, [pesouni] REAL NOT NULL, [unid] TEXT(2) NOT NULL, [item] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [compra] TEXT(1) NOT NULL, [lista] REAL NOT NULL, [nome] TEXT(40) NOT NULL, [indice] TEXT(12) NOT NULL, [valor] REAL NOT NULL, [valind] REAL NOT NULL, [valormer] REAL NOT NULL, [codipi] TEXT(2) NOT NULL, [ipi] REAL NOT NULL, [valoripi] REAL NOT NULL, [baseipi] REAL NOT NULL, [classipi] TEXT(10) NOT NULL, [tipi] TEXT(1) NOT NULL, [icm] REAL NOT NULL, [valoricm] REAL NOT NULL, [baseicm] REAL NOT NULL, [valortot] REAL NOT NULL, [entrega] SHORTDATE NOT NULL, [observacao] TEXT(30) NOT NULL, [notadev] REAL NOT NULL, [docdev] REAL NOT NULL, [datadev] SHORTDATE NOT NULL, [totdev] REAL NOT NULL, [totsdev] REAL NOT NULL, [dev] REAL NOT NULL, [qtdedev] REAL NOT NULL, [unidev] TEXT(2) NOT NULL, [prcdev] REAL NOT NULL, [coddev] TEXT(10) NOT NULL, [notade2] REAL NOT NULL, [docdev2] REAL NOT NULL, [datade2] SHORTDATE NOT NULL, [totde2] REAL NOT NULL, [totsde2] REAL NOT NULL, [de2] REAL NOT NULL, [qtdede2] REAL NOT NULL, [unide2] TEXT(2) NOT NULL, [prcde2] REAL NOT NULL, [codde2] TEXT(10) NOT NULL, [alos] TEXT(1) NOT NULL, [alse] REAL NOT NULL, [alma] TEXT(1) NOT NULL, [alde] TEXT(1) NOT NULL, [mbbn] TEXT(1) NOT NULL, [mbbp] TEXT(1) NOT NULL, [codicm] TEXT(3) NOT NULL, [dipicm] TEXT(1) NOT NULL, [dipipi] TEXT(1) NOT NULL, [rastro] TEXT(12) NOT NULL, [rastr2] TEXT(12) NOT NULL, [geraof] TEXT(1) NOT NULL, [planta] TEXT(2) NOT NULL, [pedmen] TEXT(1) NOT NULL, [fatura] TEXT(1) NOT NULL, [avembq] REAL NOT NULL, [avembc] TEXT(24) NOT NULL, [dataimp] SHORTDATE NOT NULL, [qtdepre] REAL NOT NULL, [codmr01] TEXT(10) NOT NULL, [pcemb] REAL NOT NULL, [pcembq] REAL NOT NULL, [qtdeant] REAL NOT NULL, [horaprg] REAL NOT NULL);

-- Tabela: mofp
CREATE TABLE IF NOT EXISTS [mofp] ([fp] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [me01cod] TEXT(4) NOT NULL, [data] SHORTDATE NOT NULL, [qtdepf] REAL NOT NULL, [qtdebx] REAL NOT NULL);

-- Tabela: mosb01
CREATE TABLE IF NOT EXISTS [mosb01] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [fornecedo] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [cfonew] TEXT(4) NOT NULL, [tipofre] TEXT(1) NOT NULL);

-- Tabela: mosb02
CREATE TABLE IF NOT EXISTS [mosb02] ([numero] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [unid] TEXT(2) NOT NULL, [qtde] REAL NOT NULL, [peso] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [nome] TEXT(25) NOT NULL, [preco] REAL NOT NULL, [rastro] TEXT(25) NOT NULL, [rastr2] TEXT(40) NOT NULL, [lista] REAL NOT NULL, [tiposerv] TEXT(1) NOT NULL, [codipi] TEXT(2) NOT NULL, [piscon] TEXT(1) NOT NULL, [redicm] REAL NOT NULL, [unidtab] TEXT(2) NOT NULL, [prectab] REAL NOT NULL, [coditab] TEXT(24) NOT NULL, [obs] TEXT(60) NOT NULL, [indice] TEXT(12) NOT NULL);

-- Tabela: mp01
CREATE TABLE IF NOT EXISTS [mp01] ([codigo] TEXT(12) NOT NULL, [nome] TEXT(30) NOT NULL, [cognome] TEXT(10) NOT NULL, [unidade] TEXT(2) NOT NULL, [nom2] TEXT(200) NOT NULL, [qtdemin] REAL NOT NULL, [valor] REAL NOT NULL, [estqent] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqsal] REAL NOT NULL, [estqini] REAL NOT NULL, [estqpro] REAL NOT NULL, [subapl] TEXT(24) NOT NULL, [databalan] SHORTDATE NOT NULL, [diasent] REAL NOT NULL, [diasest] REAL NOT NULL, [estqmin] REAL NOT NULL, [saimin] REAL NOT NULL, [datmin] SHORTDATE NOT NULL, [cht] TEXT(1) NOT NULL, [chm] REAL NOT NULL, [chs] REAL NOT NULL, [chd] REAL NOT NULL, [area] TEXT(2) NOT NULL, [cccli] TEXT(20) NOT NULL, [norma] TEXT(14) NOT NULL, [aplicacao] TEXT(30) NOT NULL, [obs01] TEXT(70) NOT NULL, [obs02] TEXT(70) NOT NULL, [obs03] TEXT(70) NOT NULL, [qtdeeq] REAL NOT NULL, [ccm] REAL NOT NULL, [ultprc] REAL NOT NULL, [ultund] TEXT(2) NOT NULL, [ultdata] SHORTDATE NOT NULL, [codfolha] REAL NOT NULL, [redicm] REAL NOT NULL, [grupoutl] TEXT(3) NOT NULL, [setor] TEXT(12) NOT NULL, [tiptra] TEXT(1) NOT NULL, [codmw] TEXT(3) NOT NULL, [cogcusto] TEXT(20) NOT NULL, [leadtime] REAL NOT NULL, [piscon] TEXT(1) NOT NULL, [turno] REAL NOT NULL, [minind] REAL NOT NULL, [turn2] REAL NOT NULL, [qtdee2] REAL NOT NULL, [qtdeapu] REAL NOT NULL, [crmsel] REAL NOT NULL, [codigoint] TEXT(4) NOT NULL);

-- Tabela: mp01a
CREATE TABLE IF NOT EXISTS [mp01a] ([codigo] TEXT(12) NOT NULL, [seq] REAL NOT NULL, [codmpsb] TEXT(12) NOT NULL, [nommpsb] TEXT(30) NOT NULL);

-- Tabela: mp02
CREATE TABLE IF NOT EXISTS [mp02] ([codigo] TEXT(12) NOT NULL, [cognome] TEXT(10) NOT NULL, [nome] TEXT(30) NOT NULL, [nom2] TEXT(1) NOT NULL, [unidade] TEXT(2) NOT NULL, [qtdemin] REAL NOT NULL, [valor] REAL NOT NULL, [valorc] REAL NOT NULL, [estqent] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqsal] REAL NOT NULL, [estqini] REAL NOT NULL, [estqpro] REAL NOT NULL, [databalan] SHORTDATE NOT NULL, [diasent] REAL NOT NULL, [diasest] REAL NOT NULL, [estqmin] REAL NOT NULL, [saimin] REAL NOT NULL, [datmin] SHORTDATE NOT NULL, [cht] TEXT(1) NOT NULL, [chm] REAL NOT NULL, [chs] REAL NOT NULL, [chd] REAL NOT NULL, [area] TEXT(2) NOT NULL, [cccli] TEXT(1) NOT NULL, [norma] TEXT(1) NOT NULL, [aplicacao] TEXT(1) NOT NULL, [subapl] TEXT(1) NOT NULL, [obs01] TEXT(1) NOT NULL, [obs02] TEXT(1) NOT NULL, [obs03] TEXT(1) NOT NULL, [des01] TEXT(150) NOT NULL, [des02] TEXT(150) NOT NULL, [des03] TEXT(150) NOT NULL, [des04] TEXT(150) NOT NULL, [des05] TEXT(150) NOT NULL, [des06] TEXT(150) NOT NULL, [des07] TEXT(150) NOT NULL, [des08] TEXT(150) NOT NULL, [des09] TEXT(150) NOT NULL, [des10] TEXT(150) NOT NULL, [req01] TEXT(100) NOT NULL, [req02] TEXT(100) NOT NULL, [req03] TEXT(100) NOT NULL, [req04] TEXT(100) NOT NULL, [req05] TEXT(100) NOT NULL, [req06] TEXT(100) NOT NULL, [req07] TEXT(100) NOT NULL, [req08] TEXT(100) NOT NULL, [req09] TEXT(100) NOT NULL, [req10] TEXT(100) NOT NULL, [red01] TEXT(75) NOT NULL, [red02] TEXT(75) NOT NULL, [red03] TEXT(75) NOT NULL, [red04] TEXT(75) NOT NULL, [red05] TEXT(75) NOT NULL, [red06] TEXT(75) NOT NULL, [red07] TEXT(75) NOT NULL, [red08] TEXT(75) NOT NULL, [red09] TEXT(75) NOT NULL, [red10] TEXT(75) NOT NULL, [qtdeeq] REAL NOT NULL, [ccm] REAL NOT NULL, [ultprc] REAL NOT NULL, [ultund] TEXT(2) NOT NULL, [ultdata] SHORTDATE NOT NULL, [codfolha] REAL NOT NULL, [redicm] REAL NOT NULL, [grupoutl] TEXT(3) NOT NULL, [setor] TEXT(12) NOT NULL, [tiptra] TEXT(1) NOT NULL, [codmw] TEXT(2) NOT NULL, [datatal] SHORTDATE NOT NULL, [escola] TEXT(2) NOT NULL, [leadtime] REAL NOT NULL, [piscon] TEXT(1) NOT NULL, [turno] REAL NOT NULL, [escold] TEXT(80) NOT NULL, [supime] TEXT(30) NOT NULL, [exp01] TEXT(75) NOT NULL, [exp02] TEXT(75) NOT NULL, [exp03] TEXT(75) NOT NULL, [hab01] TEXT(75) NOT NULL, [hab02] TEXT(75) NOT NULL, [hab03] TEXT(75) NOT NULL, [datarev] SHORTDATE NOT NULL, [escola2] TEXT(2) NOT NULL, [escold2] TEXT(100) NOT NULL, [escola3] TEXT(2) NOT NULL, [escold3] TEXT(100) NOT NULL, [minind] REAL NOT NULL, [qtdee2] REAL NOT NULL, [turn2] REAL NOT NULL, [qtdeapu] REAL NOT NULL, [crmsel] REAL NOT NULL, [codigoint] TEXT(1) NOT NULL, [elanum] REAL NOT NULL, [elanom] TEXT(40) NOT NULL, [eladat] SHORTDATE NOT NULL, [ananum] REAL NOT NULL, [ananom] TEXT(40) NOT NULL, [anadat] SHORTDATE NOT NULL, [aprnum] REAL NOT NULL, [aprnom] TEXT(40) NOT NULL, [aprdat] SHORTDATE NOT NULL);

-- Tabela: mp02a
CREATE TABLE IF NOT EXISTS [mp02a] ([codigo] TEXT(12) NOT NULL, [seq] REAL NOT NULL, [codmpsb] TEXT(12) NOT NULL, [nommpsb] TEXT(30) NOT NULL);

-- Tabela: mp02tal
CREATE TABLE IF NOT EXISTS [mp02tal] ([codigo] TEXT(12) NOT NULL, [curso] TEXT(20) NOT NULL, [numfun] REAL NOT NULL, [trein] REAL NOT NULL);

-- Tabela: mp03
CREATE TABLE IF NOT EXISTS [mp03] ([codigo] TEXT(24) NOT NULL, [nome] TEXT(30) NOT NULL, [cognome] TEXT(10) NOT NULL, [unidade] TEXT(2) NOT NULL, [nom2] TEXT(200) NOT NULL, [qtdemin] REAL NOT NULL, [valor] REAL NOT NULL, [estqent] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqsal] REAL NOT NULL, [estqini] REAL NOT NULL, [estqpro] REAL NOT NULL, [databalan] SHORTDATE NOT NULL, [diasent] REAL NOT NULL, [diasest] REAL NOT NULL, [estqmin] REAL NOT NULL, [saimin] REAL NOT NULL, [datmin] SHORTDATE NOT NULL, [cht] TEXT(1) NOT NULL, [chm] REAL NOT NULL, [chs] REAL NOT NULL, [chd] REAL NOT NULL, [area] TEXT(2) NOT NULL, [cccli] TEXT(20) NOT NULL, [norma] TEXT(14) NOT NULL, [aplicacao] TEXT(30) NOT NULL, [subapl] TEXT(24) NOT NULL, [subprod] TEXT(24) NOT NULL, [obs01] TEXT(70) NOT NULL, [obs02] TEXT(70) NOT NULL, [obs03] TEXT(70) NOT NULL, [qtdeeq] REAL NOT NULL, [ultprc] REAL NOT NULL, [ultund] TEXT(2) NOT NULL, [ultdata] SHORTDATE NOT NULL, [ccm] REAL NOT NULL, [codfolha] REAL NOT NULL, [redicm] REAL NOT NULL, [grupoutl] TEXT(3) NOT NULL, [setor] TEXT(12) NOT NULL, [tiptra] TEXT(1) NOT NULL, [codmw] TEXT(3) NOT NULL, [leadtime] REAL NOT NULL, [piscon] TEXT(1) NOT NULL, [turno] REAL NOT NULL, [codipi] TEXT(2) NOT NULL, [classipi] TEXT(14) NOT NULL, [ipi] REAL NOT NULL, [minind] REAL NOT NULL, [qtdee2] REAL NOT NULL, [turn2] REAL NOT NULL, [qtdeapu] REAL NOT NULL, [crmsel] REAL NOT NULL, [ctacontb] TEXT(11) NOT NULL, [codigoint] TEXT(24) NOT NULL);

-- Tabela: mp03a
CREATE TABLE IF NOT EXISTS [mp03a] ([codigo] TEXT(12) NOT NULL, [seq] REAL NOT NULL, [codmpsb] TEXT(12) NOT NULL, [nommpsb] TEXT(30) NOT NULL);

-- Tabela: mp03x
CREATE TABLE IF NOT EXISTS [mp03x] ([codigo] TEXT(24) NOT NULL, [nome] TEXT(30) NOT NULL, [cognome] TEXT(10) NOT NULL, [unidade] TEXT(2) NOT NULL, [nom2] TEXT(200) NOT NULL, [qtdemin] REAL NOT NULL, [valor] REAL NOT NULL, [estqent] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqsal] REAL NOT NULL, [estqini] REAL NOT NULL, [estqpro] REAL NOT NULL, [databalan] SHORTDATE NOT NULL, [diasent] REAL NOT NULL, [diasest] REAL NOT NULL, [estqmin] REAL NOT NULL, [saimin] REAL NOT NULL, [datmin] SHORTDATE NOT NULL, [cht] TEXT(1) NOT NULL, [chm] REAL NOT NULL, [chs] REAL NOT NULL, [chd] REAL NOT NULL, [area] TEXT(2) NOT NULL, [cccli] TEXT(20) NOT NULL, [norma] TEXT(14) NOT NULL, [aplicacao] TEXT(30) NOT NULL, [subapl] TEXT(24) NOT NULL, [subprod] TEXT(24) NOT NULL, [obs01] TEXT(70) NOT NULL, [obs02] TEXT(70) NOT NULL, [obs03] TEXT(70) NOT NULL, [qtdeeq] REAL NOT NULL, [ultprc] REAL NOT NULL, [ultund] TEXT(2) NOT NULL, [ultdata] SHORTDATE NOT NULL, [ccm] REAL NOT NULL, [codfolha] REAL NOT NULL, [redicm] REAL NOT NULL, [grupoutl] TEXT(3) NOT NULL, [setor] TEXT(12) NOT NULL, [tiptra] TEXT(1) NOT NULL, [codmw] TEXT(3) NOT NULL, [leadtime] REAL NOT NULL, [piscon] TEXT(1) NOT NULL, [turno] REAL NOT NULL, [codipi] TEXT(2) NOT NULL, [classipi] TEXT(14) NOT NULL, [ipi] REAL NOT NULL, [minind] REAL NOT NULL, [qtdee2] REAL NOT NULL, [turn2] REAL NOT NULL, [qtdeapu] REAL NOT NULL, [crmsel] REAL NOT NULL, [ctacontb] TEXT(11) NOT NULL, [codigoint] TEXT(24) NOT NULL, [clicodint] TEXT(20) NOT NULL);

-- Tabela: mp04
CREATE TABLE IF NOT EXISTS [mp04] ([tecnico] REAL NOT NULL, [cnumero] TEXT(8) NOT NULL, [cogtec] TEXT(12) NOT NULL, [nomtec] TEXT(40) NOT NULL, [tabtec] TEXT(12) NOT NULL, [area] TEXT(2) NOT NULL, [are2] TEXT(2) NOT NULL, [setor] TEXT(12) NOT NULL, [admitido] SHORTDATE NOT NULL, [demitido] SHORTDATE NOT NULL, [aponta] TEXT(1) NOT NULL, [dataexm] SHORTDATE NOT NULL, [datahab] SHORTDATE NOT NULL, [datavis] SHORTDATE NOT NULL, [emailint] TEXT(50) NOT NULL, [emailext] TEXT(50) NOT NULL, [soldador] BIT NOT NULL, [empilhad] BIT NOT NULL, [pontorol] BIT NOT NULL, [obsescola] TEXT(50) NOT NULL, [obstecno] TEXT(50) NOT NULL, [obsuniver] TEXT(50) NOT NULL, [numfolha] REAL NOT NULL, [esccompr] BIT NOT NULL, [esccomob] TEXT(50) NOT NULL, [obspos] TEXT(50) NOT NULL, [escrais] TEXT(2) NOT NULL, [numregant] REAL NOT NULL, [numempant] REAL NOT NULL, [dattransf] SHORTDATE NOT NULL, [cpf] TEXT(14) NOT NULL);

-- Tabela: mp04a
CREATE TABLE IF NOT EXISTS [mp04a] ([tecnico] REAL NOT NULL, [curso] TEXT(20) NOT NULL, [descur] TEXT(120) NOT NULL, [trein] REAL NOT NULL, [numant] REAL NOT NULL, [carhor] REAL NOT NULL);

-- Tabela: mp04c
CREATE TABLE IF NOT EXISTS [mp04c] ([tecnico] REAL NOT NULL, [curso] TEXT(20) NOT NULL, [descur] TEXT(120) NOT NULL, [trein] REAL NOT NULL, [numant] REAL NOT NULL, [carhor] REAL NOT NULL);

-- Tabela: mp05
CREATE TABLE IF NOT EXISTS [mp05] ([codigo] TEXT(2) NOT NULL, [descri] TEXT(30) NOT NULL, [respon] TEXT(40) NOT NULL, [suple] TEXT(40) NOT NULL, [setor] TEXT(3) NOT NULL, [cargo] TEXT(40) NOT NULL, [ppap] BIT NOT NULL);

-- Tabela: mp07
CREATE TABLE IF NOT EXISTS [mp07] ([armario] REAL NOT NULL, [numero] REAL NOT NULL, [nome] TEXT(40) NOT NULL);

-- Tabela: mp08
CREATE TABLE IF NOT EXISTS [mp08] ([numero] REAL NOT NULL, [nummp04] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [qtde] REAL NOT NULL, [prazo] SHORTDATE NOT NULL, [prazod] REAL NOT NULL, [retorno] SHORTDATE NOT NULL, [prorroga] REAL NOT NULL);

-- Tabela: mp91
CREATE TABLE IF NOT EXISTS [mp91] ([arquivo] TEXT(8) NOT NULL, [documento] TEXT(40) NOT NULL, [operacao] TEXT(1) NOT NULL, [usuario] TEXT(5) NOT NULL, [qtde] REAL NOT NULL, [oldqtde] REAL NOT NULL, [data] SHORTDATE NOT NULL, [numero] REAL NOT NULL, [codigo] TEXT(10) NOT NULL, [rastro] TEXT(10) NOT NULL, [estqxxx] REAL NOT NULL, [estqyyy] REAL NOT NULL);

-- Tabela: mp92
CREATE TABLE IF NOT EXISTS [mp92] ([arquivo] TEXT(8) NOT NULL, [documento] TEXT(40) NOT NULL, [operacao] TEXT(1) NOT NULL, [usuario] TEXT(5) NOT NULL, [qtde] REAL NOT NULL, [oldqtde] REAL NOT NULL, [data] SHORTDATE NOT NULL, [numero] REAL NOT NULL, [codigo] TEXT(10) NOT NULL, [rastro] TEXT(10) NOT NULL, [estqxxx] REAL NOT NULL, [estqyyy] REAL NOT NULL);

-- Tabela: mp93
CREATE TABLE IF NOT EXISTS [mp93] ([arquivo] TEXT(8) NOT NULL, [documento] TEXT(40) NOT NULL, [operacao] TEXT(1) NOT NULL, [usuario] TEXT(5) NOT NULL, [qtde] REAL NOT NULL, [oldqtde] REAL NOT NULL, [data] SHORTDATE NOT NULL, [numero] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [rastro] TEXT(10) NOT NULL, [estqxxx] REAL NOT NULL, [estqyyy] REAL NOT NULL);

-- Tabela: mq01
CREATE TABLE IF NOT EXISTS [mq01] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(50) NOT NULL, [nom2] TEXT(50) NOT NULL, [ctacontb] TEXT(11) NOT NULL, [aplicacao] TEXT(50) NOT NULL, [locacao] TEXT(10) NOT NULL, [pesliq] REAL NOT NULL, [codipi] TEXT(2) NOT NULL, [cotdata] SHORTDATE NOT NULL, [cotforn] REAL NOT NULL, [cotcogn] TEXT(12) NOT NULL, [cotcont] TEXT(20) NOT NULL, [cotval] REAL NOT NULL, [cotin1] TEXT(12) NOT NULL, [cotin2] TEXT(12) NOT NULL, [cotda1] SHORTDATE NOT NULL, [cotda2] SHORTDATE NOT NULL, [cotco1] REAL NOT NULL, [cotco2] REAL NOT NULL, [cotiv1] REAL NOT NULL, [cotiv2] REAL NOT NULL, [databalan] SHORTDATE NOT NULL, [estqini] REAL NOT NULL, [estqent] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqsal] REAL NOT NULL, [estqmin] REAL NOT NULL, [estqpro] REAL NOT NULL, [saimin] REAL NOT NULL, [datmin] SHORTDATE NOT NULL, [diasent] REAL NOT NULL, [diasest] REAL NOT NULL, [frepes] TEXT(1) NOT NULL, [precust] REAL NOT NULL, [dimx] REAL NOT NULL, [dimy] REAL NOT NULL, [dimz] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [custf] REAL NOT NULL, [mmensal] REAL NOT NULL, [mindi] REAL NOT NULL, [minind] REAL NOT NULL, [cauto] REAL NOT NULL, [ipi] REAL NOT NULL, [cccli] TEXT(20) NOT NULL, [valinv] REAL NOT NULL, [instru] TEXT(50) NOT NULL, [ultprc] REAL NOT NULL, [ultund] TEXT(2) NOT NULL, [ultdata] SHORTDATE NOT NULL, [ccm] REAL NOT NULL, [consig] TEXT(1) NOT NULL, [codmw] TEXT(3) NOT NULL, [piscon] TEXT(1) NOT NULL);

-- Tabela: mq01i
CREATE TABLE IF NOT EXISTS [mq01i] ([codigo] TEXT(10) NOT NULL, [item] REAL NOT NULL, [espe] TEXT(60) NOT NULL, [enco] TEXT(60) NOT NULL, [valpad] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [tolmin] REAL NOT NULL, [unidade] TEXT(3) NOT NULL, [tipa] TEXT(3) NOT NULL, [unidref] TEXT(4) NOT NULL, [qtderef] REAL NOT NULL);

-- Tabela: mq01x
CREATE TABLE IF NOT EXISTS [mq01x] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(50) NOT NULL, [nom2] TEXT(50) NOT NULL, [ctacontb] TEXT(11) NOT NULL, [aplicacao] TEXT(50) NOT NULL, [locacao] TEXT(10) NOT NULL, [pesliq] REAL NOT NULL, [codipi] TEXT(2) NOT NULL, [cotdata] SHORTDATE NOT NULL, [cotforn] REAL NOT NULL, [cotcogn] TEXT(12) NOT NULL, [cotcont] TEXT(20) NOT NULL, [cotval] REAL NOT NULL, [cotin1] TEXT(12) NOT NULL, [cotin2] TEXT(12) NOT NULL, [cotda1] SHORTDATE NOT NULL, [cotda2] SHORTDATE NOT NULL, [cotco1] REAL NOT NULL, [cotco2] REAL NOT NULL, [cotiv1] REAL NOT NULL, [cotiv2] REAL NOT NULL, [databalan] SHORTDATE NOT NULL, [estqini] REAL NOT NULL, [estqent] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqsal] REAL NOT NULL, [estqmin] REAL NOT NULL, [estqpro] REAL NOT NULL, [saimin] REAL NOT NULL, [datmin] SHORTDATE NOT NULL, [diasent] REAL NOT NULL, [diasest] REAL NOT NULL, [frepes] TEXT(1) NOT NULL, [precust] REAL NOT NULL, [dimx] REAL NOT NULL, [dimy] REAL NOT NULL, [dimz] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [custf] REAL NOT NULL, [mmensal] REAL NOT NULL, [mindi] REAL NOT NULL, [minind] REAL NOT NULL, [cauto] REAL NOT NULL, [ipi] REAL NOT NULL, [cccli] TEXT(20) NOT NULL, [valinv] REAL NOT NULL, [instru] TEXT(50) NOT NULL, [ultprc] REAL NOT NULL, [ultund] TEXT(2) NOT NULL, [ultdata] SHORTDATE NOT NULL, [ccm] REAL NOT NULL, [consig] TEXT(1) NOT NULL, [codmw] TEXT(3) NOT NULL, [piscon] TEXT(1) NOT NULL, [pltinv] REAL NOT NULL, [qtdeapu] REAL NOT NULL, [crmsel] REAL NOT NULL, [codigoint] TEXT(24) NOT NULL, [clicodint] TEXT(20) NOT NULL);

-- Tabela: mq02
CREATE TABLE IF NOT EXISTS [mq02] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [cotdata] SHORTDATE NOT NULL, [cotforn] REAL NOT NULL, [cotcogn] TEXT(12) NOT NULL, [cotcont] TEXT(20) NOT NULL, [cotval] REAL NOT NULL, [cotin1] TEXT(12) NOT NULL, [cotin2] TEXT(12) NOT NULL, [cotda1] SHORTDATE NOT NULL, [cotda2] SHORTDATE NOT NULL, [cotco1] REAL NOT NULL, [cotco2] REAL NOT NULL, [cotiv1] REAL NOT NULL, [cotiv2] REAL NOT NULL, [cotm01] SHORTDATE NOT NULL, [cotm02] SHORTDATE NOT NULL, [cotm03] SHORTDATE NOT NULL, [cotm04] SHORTDATE NOT NULL, [cotm05] SHORTDATE NOT NULL, [cotm06] SHORTDATE NOT NULL, [cotm07] SHORTDATE NOT NULL, [cotm08] SHORTDATE NOT NULL, [cotm09] SHORTDATE NOT NULL, [cotm10] SHORTDATE NOT NULL, [cotm11] SHORTDATE NOT NULL, [cotm12] SHORTDATE NOT NULL, [valm01] REAL NOT NULL, [valm02] REAL NOT NULL, [valm03] REAL NOT NULL, [valm04] REAL NOT NULL, [valm05] REAL NOT NULL, [valm06] REAL NOT NULL, [valm07] REAL NOT NULL, [valm08] REAL NOT NULL, [valm09] REAL NOT NULL, [valm10] REAL NOT NULL, [valm11] REAL NOT NULL, [valm12] REAL NOT NULL, [indm01] REAL NOT NULL, [indm02] REAL NOT NULL, [indm03] REAL NOT NULL, [indm04] REAL NOT NULL, [indm05] REAL NOT NULL, [indm06] REAL NOT NULL, [indm07] REAL NOT NULL, [indm08] REAL NOT NULL, [indm09] REAL NOT NULL, [indm10] REAL NOT NULL, [indm11] REAL NOT NULL, [indm12] REAL NOT NULL, [conm01] REAL NOT NULL, [conm02] REAL NOT NULL, [conm03] REAL NOT NULL, [conm04] REAL NOT NULL, [conm05] REAL NOT NULL, [conm06] REAL NOT NULL, [conm07] REAL NOT NULL, [conm08] REAL NOT NULL, [conm09] REAL NOT NULL, [conm10] REAL NOT NULL, [conm11] REAL NOT NULL, [conm12] REAL NOT NULL);

-- Tabela: mq03
CREATE TABLE IF NOT EXISTS [mq03] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [serie] TEXT(3) NOT NULL, [datafat] SHORTDATE NOT NULL, [osini] REAL NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pesoref] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [preco] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [obs] TEXT(30) NOT NULL);

-- Tabela: mq03bx
CREATE TABLE IF NOT EXISTS [mq03bx] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [serie] TEXT(3) NOT NULL, [datafat] SHORTDATE NOT NULL, [osini] REAL NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pesoref] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [preco] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [obs] TEXT(30) NOT NULL);

-- Tabela: mq04
CREATE TABLE IF NOT EXISTS [mq04] ([codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [data] SHORTDATE NOT NULL, [historico] TEXT(30) NOT NULL, [tipoent] TEXT(1) NOT NULL, [qtdde] REAL NOT NULL, [preco] REAL NOT NULL, [totqtdde] REAL NOT NULL, [totpreco] REAL NOT NULL, [totitem] REAL NOT NULL, [medio] REAL NOT NULL);

-- Tabela: mq99
CREATE TABLE IF NOT EXISTS [mq99] ([arquivo] TEXT(8) NOT NULL, [documento] TEXT(40) NOT NULL, [operacao] TEXT(1) NOT NULL, [usuario] TEXT(5) NOT NULL, [qtde] REAL NOT NULL, [oldqtde] REAL NOT NULL, [data] SHORTDATE NOT NULL, [numero] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [rastro] TEXT(10) NOT NULL, [estqxxx] REAL NOT NULL, [estqyyy] REAL NOT NULL);

-- Tabela: mr01
CREATE TABLE IF NOT EXISTS [mr01] ([codigo] TEXT(10) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(50) NOT NULL, [nom2] TEXT(50) NOT NULL, [ctacontb] TEXT(11) NOT NULL, [aplicacao] TEXT(50) NOT NULL, [locacao] TEXT(10) NOT NULL, [pesliq] REAL NOT NULL, [codipi] TEXT(2) NOT NULL, [cotdata] SHORTDATE NOT NULL, [cotforn] REAL NOT NULL, [cotcogn] TEXT(12) NOT NULL, [cotcont] TEXT(20) NOT NULL, [cotval] REAL NOT NULL, [cotin1] TEXT(12) NOT NULL, [cotin2] TEXT(12) NOT NULL, [cotda1] SHORTDATE NOT NULL, [cotda2] SHORTDATE NOT NULL, [cotco1] REAL NOT NULL, [cotco2] REAL NOT NULL, [cotiv1] REAL NOT NULL, [cotiv2] REAL NOT NULL, [databalan] SHORTDATE NOT NULL, [estqini] REAL NOT NULL, [estqent] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqsal] REAL NOT NULL, [estqmin] REAL NOT NULL, [estqpro] REAL NOT NULL, [saimin] REAL NOT NULL, [datmin] SHORTDATE NOT NULL, [diasent] REAL NOT NULL, [diasest] REAL NOT NULL, [frepes] TEXT(1) NOT NULL, [precust] REAL NOT NULL, [dimx] REAL NOT NULL, [dimy] REAL NOT NULL, [dimz] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [custf] REAL NOT NULL, [mmensal] REAL NOT NULL, [mindi] REAL NOT NULL, [minind] REAL NOT NULL, [cauto] REAL NOT NULL, [ipi] REAL NOT NULL, [cccli] TEXT(20) NOT NULL, [valinv] REAL NOT NULL, [instru] TEXT(50) NOT NULL, [ultprc] REAL NOT NULL, [ultund] TEXT(2) NOT NULL, [ultdata] SHORTDATE NOT NULL, [ccm] REAL NOT NULL, [consig] TEXT(1) NOT NULL, [codmw] TEXT(3) NOT NULL, [piscon] TEXT(1) NOT NULL, [pltinv] REAL NOT NULL, [qtdeapu] REAL NOT NULL, [crmsel] REAL NOT NULL);

-- Tabela: mr02
CREATE TABLE IF NOT EXISTS [mr02] ([codigo] TEXT(10) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [cotdata] SHORTDATE NOT NULL, [cotforn] REAL NOT NULL, [cotcogn] TEXT(12) NOT NULL, [cotcont] TEXT(20) NOT NULL, [cotval] REAL NOT NULL, [cotin1] TEXT(12) NOT NULL, [cotin2] TEXT(12) NOT NULL, [cotda1] SHORTDATE NOT NULL, [cotda2] SHORTDATE NOT NULL, [cotco1] REAL NOT NULL, [cotco2] REAL NOT NULL, [cotiv1] REAL NOT NULL, [cotiv2] REAL NOT NULL, [cotm01] SHORTDATE NOT NULL, [cotm02] SHORTDATE NOT NULL, [cotm03] SHORTDATE NOT NULL, [cotm04] SHORTDATE NOT NULL, [cotm05] SHORTDATE NOT NULL, [cotm06] SHORTDATE NOT NULL, [cotm07] SHORTDATE NOT NULL, [cotm08] SHORTDATE NOT NULL, [cotm09] SHORTDATE NOT NULL, [cotm10] SHORTDATE NOT NULL, [cotm11] SHORTDATE NOT NULL, [cotm12] SHORTDATE NOT NULL, [valm01] REAL NOT NULL, [valm02] REAL NOT NULL, [valm03] REAL NOT NULL, [valm04] REAL NOT NULL, [valm05] REAL NOT NULL, [valm06] REAL NOT NULL, [valm07] REAL NOT NULL, [valm08] REAL NOT NULL, [valm09] REAL NOT NULL, [valm10] REAL NOT NULL, [valm11] REAL NOT NULL, [valm12] REAL NOT NULL, [indm01] REAL NOT NULL, [indm02] REAL NOT NULL, [indm03] REAL NOT NULL, [indm04] REAL NOT NULL, [indm05] REAL NOT NULL, [indm06] REAL NOT NULL, [indm07] REAL NOT NULL, [indm08] REAL NOT NULL, [indm09] REAL NOT NULL, [indm10] REAL NOT NULL, [indm11] REAL NOT NULL, [indm12] REAL NOT NULL, [conm01] REAL NOT NULL, [conm02] REAL NOT NULL, [conm03] REAL NOT NULL, [conm04] REAL NOT NULL, [conm05] REAL NOT NULL, [conm06] REAL NOT NULL, [conm07] REAL NOT NULL, [conm08] REAL NOT NULL, [conm09] REAL NOT NULL, [conm10] REAL NOT NULL, [conm11] REAL NOT NULL, [conm12] REAL NOT NULL);

-- Tabela: mr03
CREATE TABLE IF NOT EXISTS [mr03] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [serie] TEXT(3) NOT NULL, [datafat] SHORTDATE NOT NULL, [osini] REAL NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pesoref] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [preco] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [obs] TEXT(30) NOT NULL, [rastro] TEXT(12) NOT NULL, [difsaldo] REAL NOT NULL, [local] TEXT(5) NOT NULL, [qtdeemb] REAL NOT NULL);

-- Tabela: mr03bx
CREATE TABLE IF NOT EXISTS [mr03bx] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [serie] TEXT(3) NOT NULL, [datafat] SHORTDATE NOT NULL, [osini] REAL NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pesoref] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [preco] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [obs] TEXT(30) NOT NULL, [rastro] TEXT(12) NOT NULL, [difsaldo] REAL NOT NULL, [local] TEXT(5) NOT NULL, [qtdeemb] REAL NOT NULL);

-- Tabela: mr04
CREATE TABLE IF NOT EXISTS [mr04] ([codigo] TEXT(10) NOT NULL, [seq] REAL NOT NULL, [data] SHORTDATE NOT NULL, [historico] TEXT(30) NOT NULL, [tipoent] TEXT(1) NOT NULL, [qtdde] REAL NOT NULL, [preco] REAL NOT NULL, [totqtdde] REAL NOT NULL, [totpreco] REAL NOT NULL, [totitem] REAL NOT NULL, [medio] REAL NOT NULL);

-- Tabela: mr99
CREATE TABLE IF NOT EXISTS [mr99] ([arquivo] TEXT(8) NOT NULL, [documento] TEXT(40) NOT NULL, [operacao] TEXT(1) NOT NULL, [usuario] TEXT(5) NOT NULL, [qtde] REAL NOT NULL, [oldqtde] REAL NOT NULL, [data] SHORTDATE NOT NULL, [numero] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [rastro] TEXT(10) NOT NULL, [estqxxx] REAL NOT NULL, [estqyyy] REAL NOT NULL);

-- Tabela: mrms
CREATE TABLE IF NOT EXISTS [mrms] ([codms01] TEXT(24) NOT NULL, [codmr01] TEXT(10) NOT NULL, [codma01] REAL NOT NULL, [pcemb] REAL NOT NULL);

-- Tabela: ms01
CREATE TABLE IF NOT EXISTS [ms01] ([codigo] TEXT(24) NOT NULL, [fornecedo] REAL NOT NULL, [clipcp] REAL NOT NULL, [compra] TEXT(9) NOT NULL, [unid] TEXT(2) NOT NULL, [nome] TEXT(40) NOT NULL, [nom2] TEXT(1) NOT NULL, [codipi] TEXT(2) NOT NULL, [databalan] SHORTDATE NOT NULL, [estqini] REAL NOT NULL, [estqent] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqsal] REAL NOT NULL, [estqmin] REAL NOT NULL, [estqpro] REAL NOT NULL, [saimin] REAL NOT NULL, [datmin] SHORTDATE NOT NULL, [diasent] REAL NOT NULL, [diasest] REAL NOT NULL, [pesouni] REAL NOT NULL, [valdolar] REAL NOT NULL, [indice] TEXT(12) NOT NULL, [valind] REAL NOT NULL, [locacao] TEXT(20) NOT NULL, [diacom] REAL NOT NULL, [diaent] REAL NOT NULL, [pertol] REAL NOT NULL, [lminimo] REAL NOT NULL, [temp] REAL NOT NULL, [unidade] TEXT(2) NOT NULL, [parti] REAL NOT NULL, [pplan] REAL NOT NULL, [custf] REAL NOT NULL, [normat] TEXT(20) NOT NULL, [revi] TEXT(2) NOT NULL, [delivery] TEXT(16) NOT NULL, [using] TEXT(10) NOT NULL, [equip] TEXT(6) NOT NULL, [qtdeeti] REAL NOT NULL, [valinv] REAL NOT NULL, [seqarea] TEXT(10) NOT NULL, [ativo] TEXT(1) NOT NULL, [opcao] TEXT(1) NOT NULL, [pesunipf] REAL NOT NULL, [pesembpf] REAL NOT NULL, [produso] TEXT(1) NOT NULL, [imposto] TEXT(2) NOT NULL, [baixafat] TEXT(1) NOT NULL, [tipoger] TEXT(2) NOT NULL, [mind] REAL NOT NULL, [minind] REAL NOT NULL, [ccm] REAL NOT NULL, [ultprc] REAL NOT NULL, [ultund] TEXT(2) NOT NULL, [ultdata] SHORTDATE NOT NULL, [plantafab] TEXT(10) NOT NULL, [modelo] TEXT(10) NOT NULL, [part_num] TEXT(8) NOT NULL, [plt] TEXT(2) NOT NULL, [duns] TEXT(9) NOT NULL, [part_name] TEXT(50) NOT NULL, [qtdemba] REAL NOT NULL, [contner] TEXT(8) NOT NULL, [dloc] TEXT(12) NOT NULL, [dock_stck] TEXT(7) NOT NULL, [embal] TEXT(8) NOT NULL, [codmw] TEXT(3) NOT NULL, [sailista] TEXT(1) NOT NULL, [pcprgmed] REAL NOT NULL, [pcprghor] REAL NOT NULL, [ultimofa] SHORTDATE NOT NULL, [ultimonf] REAL NOT NULL, [piscon] TEXT(1) NOT NULL, [filial] REAL NOT NULL, [tipoqua] TEXT(1) NOT NULL, [ipi] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [precust] REAL NOT NULL, [pltinv] REAL NOT NULL, [valfatinv] REAL NOT NULL, [qtdeapu] REAL NOT NULL, [crmsel] REAL NOT NULL, [codigoint] TEXT(24) NOT NULL, [clicodint] TEXT(20) NOT NULL, [prifatdat] SHORTDATE NOT NULL, [prifatnf] REAL NOT NULL);

-- Tabela: ms01p
CREATE TABLE IF NOT EXISTS [ms01p] ([codigo] TEXT(24) NOT NULL, [fornecedo] REAL NOT NULL, [pplan] REAL NOT NULL);

-- Tabela: ms01x
CREATE TABLE IF NOT EXISTS [ms01x] ([codigo] TEXT(24) NOT NULL, [fornecedo] REAL NOT NULL, [clipcp] REAL NOT NULL, [compra] TEXT(9) NOT NULL, [unid] TEXT(2) NOT NULL, [nome] TEXT(40) NOT NULL, [nom2] TEXT(1) NOT NULL, [codipi] TEXT(2) NOT NULL, [databalan] SHORTDATE NOT NULL, [estqini] REAL NOT NULL, [estqent] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqsal] REAL NOT NULL, [estqmin] REAL NOT NULL, [estqpro] REAL NOT NULL, [saimin] REAL NOT NULL, [datmin] SHORTDATE NOT NULL, [diasent] REAL NOT NULL, [diasest] REAL NOT NULL, [pesouni] REAL NOT NULL, [valdolar] REAL NOT NULL, [indice] TEXT(12) NOT NULL, [valind] REAL NOT NULL, [locacao] TEXT(20) NOT NULL, [diacom] REAL NOT NULL, [diaent] REAL NOT NULL, [pertol] REAL NOT NULL, [lminimo] REAL NOT NULL, [temp] REAL NOT NULL, [unidade] TEXT(2) NOT NULL, [parti] REAL NOT NULL, [pplan] REAL NOT NULL, [custf] REAL NOT NULL, [normat] TEXT(20) NOT NULL, [revi] TEXT(2) NOT NULL, [delivery] TEXT(16) NOT NULL, [using] TEXT(10) NOT NULL, [equip] TEXT(6) NOT NULL, [qtdeeti] REAL NOT NULL, [valinv] REAL NOT NULL, [seqarea] TEXT(10) NOT NULL, [ativo] TEXT(1) NOT NULL, [opcao] TEXT(1) NOT NULL, [pesunipf] REAL NOT NULL, [pesembpf] REAL NOT NULL, [produso] TEXT(1) NOT NULL, [imposto] TEXT(2) NOT NULL, [baixafat] TEXT(1) NOT NULL, [tipoger] TEXT(2) NOT NULL, [mind] REAL NOT NULL, [minind] REAL NOT NULL, [ccm] REAL NOT NULL, [ultprc] REAL NOT NULL, [ultund] TEXT(2) NOT NULL, [ultdata] SHORTDATE NOT NULL, [plantafab] TEXT(10) NOT NULL, [modelo] TEXT(10) NOT NULL, [part_num] TEXT(8) NOT NULL, [plt] TEXT(2) NOT NULL, [duns] TEXT(9) NOT NULL, [part_name] TEXT(50) NOT NULL, [qtdemba] REAL NOT NULL, [contner] TEXT(8) NOT NULL, [dloc] TEXT(12) NOT NULL, [dock_stck] TEXT(7) NOT NULL, [embal] TEXT(8) NOT NULL, [codmw] TEXT(3) NOT NULL, [sailista] TEXT(1) NOT NULL, [pcprgmed] REAL NOT NULL, [pcprghor] REAL NOT NULL, [ultimofa] SHORTDATE NOT NULL, [ultimonf] REAL NOT NULL, [piscon] TEXT(1) NOT NULL, [filial] REAL NOT NULL, [tipoqua] TEXT(1) NOT NULL, [ipi] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [precust] REAL NOT NULL, [pltinv] REAL NOT NULL, [valfatinv] REAL NOT NULL, [qtdeapu] REAL NOT NULL, [crmsel] REAL NOT NULL, [codigoint] TEXT(24) NOT NULL, [clicodint] TEXT(20) NOT NULL, [prifatdat] SHORTDATE NOT NULL, [prifatnf] REAL NOT NULL);

-- Tabela: ms02
CREATE TABLE IF NOT EXISTS [ms02] ([codigo] TEXT(24) NOT NULL, [fornecedo] REAL NOT NULL, [compra] TEXT(9) NOT NULL, [tipocli] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [tipi] TEXT(1) NOT NULL, [valor] REAL NOT NULL, [unide] TEXT(2) NOT NULL, [coide] TEXT(2) NOT NULL, [atual] TEXT(1) NOT NULL, [clifor] REAL NOT NULL);

-- Tabela: ms03
CREATE TABLE IF NOT EXISTS [ms03] ([codigo] TEXT(24) NOT NULL, [tipoent] TEXT(1) NOT NULL, [codcomp] TEXT(24) NOT NULL, [nomecomp] TEXT(50) NOT NULL, [nomecom2] TEXT(50) NOT NULL, [qtdde] REAL NOT NULL, [preco] REAL NOT NULL, [total] REAL NOT NULL, [baixac] TEXT(1) NOT NULL, [bseq] REAL NOT NULL, [bssq] REAL NOT NULL, [opcao] TEXT(1) NOT NULL, [gerarn] TEXT(1) NOT NULL, [qpaa2] REAL NOT NULL, [qpaas] REAL NOT NULL, [qpaaa] REAL NOT NULL, [xpaa2] REAL NOT NULL, [xpaas] REAL NOT NULL, [xpaaa] REAL NOT NULL, [filial] REAL NOT NULL, [qtdepc] REAL NOT NULL, [qtdeest] REAL NOT NULL);

-- Tabela: ms04
CREATE TABLE IF NOT EXISTS [ms04] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [serie] TEXT(3) NOT NULL, [datafat] SHORTDATE NOT NULL, [osini] REAL NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pesoref] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [preco] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [obs] TEXT(30) NOT NULL, [rastro] TEXT(10) NOT NULL);

-- Tabela: ms04bx
CREATE TABLE IF NOT EXISTS [ms04bx] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [serie] TEXT(3) NOT NULL, [datafat] SHORTDATE NOT NULL, [osini] REAL NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pesoref] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [preco] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [obs] TEXT(30) NOT NULL, [rastro] TEXT(10) NOT NULL);

-- Tabela: ms05
CREATE TABLE IF NOT EXISTS [ms05] ([docodigo] TEXT(13) NOT NULL, [codigo] TEXT(13) NOT NULL, [central] TEXT(1) NOT NULL);

-- Tabela: ms06
CREATE TABLE IF NOT EXISTS [ms06] ([codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [descri] TEXT(70) NOT NULL, [codmp01] TEXT(12) NOT NULL, [codmp02] TEXT(12) NOT NULL, [codmp03] TEXT(24) NOT NULL, [codmp02b] TEXT(12) NOT NULL, [codmp02c] TEXT(12) NOT NULL, [codmp02d] TEXT(12) NOT NULL, [databalan] SHORTDATE NOT NULL, [estqini] REAL NOT NULL, [estqent] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqsal] REAL NOT NULL, [estqmin] REAL NOT NULL, [saimin] REAL NOT NULL, [daimin] SHORTDATE NOT NULL, [diasent] REAL NOT NULL, [diasest] REAL NOT NULL, [tipfec] TEXT(1) NOT NULL, [tipbai] TEXT(1) NOT NULL, [codfec] TEXT(24) NOT NULL, [fator] REAL NOT NULL, [area] TEXT(2) NOT NULL, [valinv] REAL NOT NULL, [fatbat] REAL NOT NULL, [pchora] REAL NOT NULL, [pchor2] REAL NOT NULL, [pchor3] REAL NOT NULL, [pchor4] REAL NOT NULL, [opcao] TEXT(1) NOT NULL, [pulreq] TEXT(1) NOT NULL, [ferramen] TEXT(24) NOT NULL, [ferrame2] TEXT(24) NOT NULL, [ferrame3] TEXT(24) NOT NULL, [ferrame4] TEXT(24) NOT NULL, [nomer] TEXT(10) NOT NULL, [setorop] TEXT(1) NOT NULL, [limtime] REAL NOT NULL, [pf] REAL NOT NULL, [dataini] SHORTDATE NOT NULL, [lminopr] REAL NOT NULL, [pchormed] REAL NOT NULL, [pchormeq] REAL NOT NULL, [pchordia] REAL NOT NULL, [leadcalc] REAL NOT NULL, [leadarre] REAL NOT NULL, [pchornec] REAL NOT NULL, [filial] REAL NOT NULL, [pchorax1] REAL NOT NULL, [pchorax2] REAL NOT NULL, [leadesp] REAL NOT NULL, [pchoramd] REAL NOT NULL, [parceiro] TEXT(24) NOT NULL, [ultprc] REAL NOT NULL, [pltinv] REAL NOT NULL, [codint] TEXT(24) NOT NULL);

-- Tabela: ms06bx
CREATE TABLE IF NOT EXISTS [ms06bx] ([codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [descri] TEXT(70) NOT NULL, [codmp01] TEXT(12) NOT NULL, [codmp02] TEXT(12) NOT NULL, [codmp03] TEXT(24) NOT NULL, [codmp02b] TEXT(12) NOT NULL, [codmp02c] TEXT(12) NOT NULL, [codmp02d] TEXT(12) NOT NULL, [databalan] SHORTDATE NOT NULL, [estqini] REAL NOT NULL, [estqent] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqsal] REAL NOT NULL, [estqmin] REAL NOT NULL, [saimin] REAL NOT NULL, [daimin] SHORTDATE NOT NULL, [diasent] REAL NOT NULL, [diasest] REAL NOT NULL, [tipfec] TEXT(1) NOT NULL, [tipbai] TEXT(1) NOT NULL, [codfec] TEXT(24) NOT NULL, [fator] REAL NOT NULL, [area] TEXT(2) NOT NULL, [valinv] REAL NOT NULL, [fatbat] REAL NOT NULL, [pchora] REAL NOT NULL, [pchor2] REAL NOT NULL, [pchor3] REAL NOT NULL, [pchor4] REAL NOT NULL, [opcao] TEXT(1) NOT NULL, [pulreq] TEXT(1) NOT NULL, [ferramen] TEXT(24) NOT NULL, [ferrame2] TEXT(24) NOT NULL, [ferrame3] TEXT(24) NOT NULL, [ferrame4] TEXT(24) NOT NULL, [nomer] TEXT(15) NOT NULL, [setorop] TEXT(1) NOT NULL, [limtime] REAL NOT NULL, [pf] REAL NOT NULL, [dataini] SHORTDATE NOT NULL, [lminopr] REAL NOT NULL, [pchormed] REAL NOT NULL, [pchormeq] REAL NOT NULL, [pchordia] REAL NOT NULL, [leadcalc] REAL NOT NULL, [leadarre] REAL NOT NULL, [pchornec] REAL NOT NULL, [filial] REAL NOT NULL, [pchorax1] REAL NOT NULL, [pchorax2] REAL NOT NULL, [leadesp] REAL NOT NULL, [pchoramd] REAL NOT NULL, [parceiro] TEXT(24) NOT NULL, [ultprc] REAL NOT NULL, [pltinv] REAL NOT NULL, [valiii] REAL NOT NULL);

-- Tabela: ms06req
CREATE TABLE IF NOT EXISTS [ms06req] ([numero] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [bxcod] TEXT(24) NOT NULL, [bxseq] REAL NOT NULL, [bxssq] REAL NOT NULL, [bxfat] REAL NOT NULL);

-- Tabela: ms07
CREATE TABLE IF NOT EXISTS [ms07] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [serie] TEXT(3) NOT NULL, [datafat] SHORTDATE NOT NULL, [osini] REAL NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pesoref] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [preco] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [obs] TEXT(30) NOT NULL);

-- Tabela: ms07bx
CREATE TABLE IF NOT EXISTS [ms07bx] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [serie] TEXT(3) NOT NULL, [datafat] SHORTDATE NOT NULL, [osini] REAL NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pesoref] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [preco] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [obs] TEXT(30) NOT NULL);

-- Tabela: ms96
CREATE TABLE IF NOT EXISTS [ms96] ([arquivo] TEXT(8) NOT NULL, [documento] TEXT(1) NOT NULL, [operacao] TEXT(1) NOT NULL, [usuario] TEXT(10) NOT NULL, [qtde] REAL NOT NULL, [oldqtde] REAL NOT NULL, [numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [codigo] TEXT(24) NOT NULL, [rastro] TEXT(12) NOT NULL, [estqxxx] REAL NOT NULL, [estqyyy] REAL NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL);

-- Tabela: ms99
CREATE TABLE IF NOT EXISTS [ms99] ([arquivo] TEXT(8) NOT NULL, [documento] TEXT(40) NOT NULL, [operacao] TEXT(1) NOT NULL, [usuario] TEXT(5) NOT NULL, [qtde] REAL NOT NULL, [oldqtde] REAL NOT NULL, [numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [codigo] TEXT(24) NOT NULL, [rastro] TEXT(10) NOT NULL, [estqxxx] REAL NOT NULL, [estqyyy] REAL NOT NULL);

-- Tabela: msbai
CREATE TABLE IF NOT EXISTS [msbai] ([origem] TEXT(24) NOT NULL, [destino] TEXT(24) NOT NULL, [planta] REAL NOT NULL);

-- Tabela: msinv
CREATE TABLE IF NOT EXISTS [msinv] ([cliente] REAL NOT NULL, [ano] REAL NOT NULL, [mes] REAL NOT NULL, [cognome] TEXT(15) NOT NULL, [fat] REAL NOT NULL, [mat] REAL NOT NULL, [matp] REAL NOT NULL, [com] REAL NOT NULL, [comp] REAL NOT NULL, [matcom] REAL NOT NULL, [matcomp] REAL NOT NULL, [est] REAL NOT NULL, [estp] REAL NOT NULL, [pro] REAL NOT NULL, [prop] REAL NOT NULL, [esp] REAL NOT NULL, [espp] REAL NOT NULL, [tot] REAL NOT NULL, [totp] REAL NOT NULL);

-- Tabela: msop
CREATE TABLE IF NOT EXISTS [msop] ([codigo] TEXT(24) NOT NULL, [qtde] REAL NOT NULL, [local] TEXT(10) NOT NULL, [op] REAL NOT NULL);

-- Tabela: mt01
CREATE TABLE IF NOT EXISTS [mt01] ([codigo] TEXT(10) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(50) NOT NULL, [nom2] TEXT(50) NOT NULL, [ctacontb] TEXT(11) NOT NULL, [aplicacao] TEXT(50) NOT NULL, [locacao] TEXT(10) NOT NULL, [pesliq] REAL NOT NULL, [codipi] TEXT(2) NOT NULL, [cotdata] SHORTDATE NOT NULL, [cotforn] REAL NOT NULL, [cotcogn] TEXT(12) NOT NULL, [cotcont] TEXT(20) NOT NULL, [cotval] REAL NOT NULL, [cotin1] TEXT(12) NOT NULL, [cotin2] TEXT(12) NOT NULL, [cotda1] SHORTDATE NOT NULL, [cotda2] SHORTDATE NOT NULL, [cotco1] REAL NOT NULL, [cotco2] REAL NOT NULL, [cotiv1] REAL NOT NULL, [cotiv2] REAL NOT NULL, [databalan] SHORTDATE NOT NULL, [estqini] REAL NOT NULL, [estqent] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqsal] REAL NOT NULL, [estqmin] REAL NOT NULL, [estqpro] REAL NOT NULL, [saimin] REAL NOT NULL, [datmin] SHORTDATE NOT NULL, [diasent] REAL NOT NULL, [diasest] REAL NOT NULL, [frepes] TEXT(1) NOT NULL, [precust] REAL NOT NULL, [dimx] REAL NOT NULL, [dimy] REAL NOT NULL, [dimz] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [custf] REAL NOT NULL, [mmensal] REAL NOT NULL, [mindi] REAL NOT NULL, [minind] REAL NOT NULL, [cauto] REAL NOT NULL, [ipi] REAL NOT NULL, [cccli] TEXT(20) NOT NULL, [valinv] REAL NOT NULL, [instru] TEXT(50) NOT NULL, [ultprc] REAL NOT NULL, [ultund] TEXT(2) NOT NULL, [ultdata] SHORTDATE NOT NULL, [ccm] REAL NOT NULL, [consig] TEXT(1) NOT NULL, [codmw] TEXT(3) NOT NULL, [piscon] TEXT(1) NOT NULL, [pltinv] REAL NOT NULL);

-- Tabela: mt02
CREATE TABLE IF NOT EXISTS [mt02] ([codigo] TEXT(10) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [cotdata] SHORTDATE NOT NULL, [cotforn] REAL NOT NULL, [cotcogn] TEXT(12) NOT NULL, [cotcont] TEXT(20) NOT NULL, [cotval] REAL NOT NULL, [cotin1] TEXT(12) NOT NULL, [cotin2] TEXT(12) NOT NULL, [cotda1] SHORTDATE NOT NULL, [cotda2] SHORTDATE NOT NULL, [cotco1] REAL NOT NULL, [cotco2] REAL NOT NULL, [cotiv1] REAL NOT NULL, [cotiv2] REAL NOT NULL, [cotm01] SHORTDATE NOT NULL, [cotm02] SHORTDATE NOT NULL, [cotm03] SHORTDATE NOT NULL, [cotm04] SHORTDATE NOT NULL, [cotm05] SHORTDATE NOT NULL, [cotm06] SHORTDATE NOT NULL, [cotm07] SHORTDATE NOT NULL, [cotm08] SHORTDATE NOT NULL, [cotm09] SHORTDATE NOT NULL, [cotm10] SHORTDATE NOT NULL, [cotm11] SHORTDATE NOT NULL, [cotm12] SHORTDATE NOT NULL, [valm01] REAL NOT NULL, [valm02] REAL NOT NULL, [valm03] REAL NOT NULL, [valm04] REAL NOT NULL, [valm05] REAL NOT NULL, [valm06] REAL NOT NULL, [valm07] REAL NOT NULL, [valm08] REAL NOT NULL, [valm09] REAL NOT NULL, [valm10] REAL NOT NULL, [valm11] REAL NOT NULL, [valm12] REAL NOT NULL, [indm01] REAL NOT NULL, [indm02] REAL NOT NULL, [indm03] REAL NOT NULL, [indm04] REAL NOT NULL, [indm05] REAL NOT NULL, [indm06] REAL NOT NULL, [indm07] REAL NOT NULL, [indm08] REAL NOT NULL, [indm09] REAL NOT NULL, [indm10] REAL NOT NULL, [indm11] REAL NOT NULL, [indm12] REAL NOT NULL, [conm01] REAL NOT NULL, [conm02] REAL NOT NULL, [conm03] REAL NOT NULL, [conm04] REAL NOT NULL, [conm05] REAL NOT NULL, [conm06] REAL NOT NULL, [conm07] REAL NOT NULL, [conm08] REAL NOT NULL, [conm09] REAL NOT NULL, [conm10] REAL NOT NULL, [conm11] REAL NOT NULL, [conm12] REAL NOT NULL);

-- Tabela: mt03
CREATE TABLE IF NOT EXISTS [mt03] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [serie] TEXT(3) NOT NULL, [datafat] SHORTDATE NOT NULL, [osini] REAL NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pesoref] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [preco] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [obs] TEXT(30) NOT NULL);

-- Tabela: mt03bx
CREATE TABLE IF NOT EXISTS [mt03bx] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [serie] TEXT(3) NOT NULL, [datafat] SHORTDATE NOT NULL, [osini] REAL NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pesoref] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [preco] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [obs] TEXT(30) NOT NULL);

-- Tabela: mt04
CREATE TABLE IF NOT EXISTS [mt04] ([codigo] TEXT(10) NOT NULL, [seq] REAL NOT NULL, [data] SHORTDATE NOT NULL, [historico] TEXT(30) NOT NULL, [tipoent] TEXT(1) NOT NULL, [qtdde] REAL NOT NULL, [preco] REAL NOT NULL, [totqtdde] REAL NOT NULL, [totpreco] REAL NOT NULL, [totitem] REAL NOT NULL, [medio] REAL NOT NULL);

-- Tabela: mt99
CREATE TABLE IF NOT EXISTS [mt99] ([arquivo] TEXT(8) NOT NULL, [documento] TEXT(40) NOT NULL, [operacao] TEXT(1) NOT NULL, [usuario] TEXT(5) NOT NULL, [qtde] REAL NOT NULL, [oldqtde] REAL NOT NULL, [data] SHORTDATE NOT NULL, [numero] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [rastro] TEXT(10) NOT NULL, [estqxxx] REAL NOT NULL, [estqyyy] REAL NOT NULL);

-- Tabela: mu01
CREATE TABLE IF NOT EXISTS [mu01] ([codigo] TEXT(10) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(50) NOT NULL, [nom2] TEXT(50) NOT NULL, [ctacontb] TEXT(11) NOT NULL, [aplicacao] TEXT(50) NOT NULL, [locacao] TEXT(10) NOT NULL, [pesliq] REAL NOT NULL, [codipi] TEXT(2) NOT NULL, [cotdata] SHORTDATE NOT NULL, [cotforn] REAL NOT NULL, [cotcogn] TEXT(12) NOT NULL, [cotcont] TEXT(20) NOT NULL, [cotval] REAL NOT NULL, [cotin1] TEXT(12) NOT NULL, [cotin2] TEXT(12) NOT NULL, [cotda1] SHORTDATE NOT NULL, [cotda2] SHORTDATE NOT NULL, [cotco1] REAL NOT NULL, [cotco2] REAL NOT NULL, [cotiv1] REAL NOT NULL, [cotiv2] REAL NOT NULL, [databalan] SHORTDATE NOT NULL, [estqini] REAL NOT NULL, [estqent] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqsal] REAL NOT NULL, [estqmin] REAL NOT NULL, [estqpro] REAL NOT NULL, [saimin] REAL NOT NULL, [datmin] SHORTDATE NOT NULL, [diasent] REAL NOT NULL, [diasest] REAL NOT NULL, [frepes] TEXT(1) NOT NULL, [precust] REAL NOT NULL, [dimx] REAL NOT NULL, [dimy] REAL NOT NULL, [dimz] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [custf] REAL NOT NULL, [mmensal] REAL NOT NULL, [mindi] REAL NOT NULL, [minind] REAL NOT NULL, [cauto] REAL NOT NULL, [ipi] REAL NOT NULL, [cccli] TEXT(20) NOT NULL, [valinv] REAL NOT NULL, [instru] TEXT(50) NOT NULL, [ultprc] REAL NOT NULL, [ultund] TEXT(2) NOT NULL, [ultdata] SHORTDATE NOT NULL, [ccm] REAL NOT NULL, [consig] TEXT(1) NOT NULL, [codmw] TEXT(3) NOT NULL, [piscon] TEXT(1) NOT NULL, [pltinv] REAL NOT NULL);

-- Tabela: mu02
CREATE TABLE IF NOT EXISTS [mu02] ([codigo] TEXT(10) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [cotdata] SHORTDATE NOT NULL, [cotforn] REAL NOT NULL, [cotcogn] TEXT(12) NOT NULL, [cotcont] TEXT(20) NOT NULL, [cotval] REAL NOT NULL, [cotin1] TEXT(12) NOT NULL, [cotin2] TEXT(12) NOT NULL, [cotda1] SHORTDATE NOT NULL, [cotda2] SHORTDATE NOT NULL, [cotco1] REAL NOT NULL, [cotco2] REAL NOT NULL, [cotiv1] REAL NOT NULL, [cotiv2] REAL NOT NULL, [cotm01] SHORTDATE NOT NULL, [cotm02] SHORTDATE NOT NULL, [cotm03] SHORTDATE NOT NULL, [cotm04] SHORTDATE NOT NULL, [cotm05] SHORTDATE NOT NULL, [cotm06] SHORTDATE NOT NULL, [cotm07] SHORTDATE NOT NULL, [cotm08] SHORTDATE NOT NULL, [cotm09] SHORTDATE NOT NULL, [cotm10] SHORTDATE NOT NULL, [cotm11] SHORTDATE NOT NULL, [cotm12] SHORTDATE NOT NULL, [valm01] REAL NOT NULL, [valm02] REAL NOT NULL, [valm03] REAL NOT NULL, [valm04] REAL NOT NULL, [valm05] REAL NOT NULL, [valm06] REAL NOT NULL, [valm07] REAL NOT NULL, [valm08] REAL NOT NULL, [valm09] REAL NOT NULL, [valm10] REAL NOT NULL, [valm11] REAL NOT NULL, [valm12] REAL NOT NULL, [indm01] REAL NOT NULL, [indm02] REAL NOT NULL, [indm03] REAL NOT NULL, [indm04] REAL NOT NULL, [indm05] REAL NOT NULL, [indm06] REAL NOT NULL, [indm07] REAL NOT NULL, [indm08] REAL NOT NULL, [indm09] REAL NOT NULL, [indm10] REAL NOT NULL, [indm11] REAL NOT NULL, [indm12] REAL NOT NULL, [conm01] REAL NOT NULL, [conm02] REAL NOT NULL, [conm03] REAL NOT NULL, [conm04] REAL NOT NULL, [conm05] REAL NOT NULL, [conm06] REAL NOT NULL, [conm07] REAL NOT NULL, [conm08] REAL NOT NULL, [conm09] REAL NOT NULL, [conm10] REAL NOT NULL, [conm11] REAL NOT NULL, [conm12] REAL NOT NULL);

-- Tabela: mu03
CREATE TABLE IF NOT EXISTS [mu03] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [serie] TEXT(3) NOT NULL, [datafat] SHORTDATE NOT NULL, [osini] REAL NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pesoref] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [preco] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [obs] TEXT(30) NOT NULL);

-- Tabela: mu03bx
CREATE TABLE IF NOT EXISTS [mu03bx] ([codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [serie] TEXT(3) NOT NULL, [datafat] SHORTDATE NOT NULL, [osini] REAL NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pesoref] REAL NOT NULL, [classipi] TEXT(14) NOT NULL, [preco] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [obs] TEXT(30) NOT NULL);

-- Tabela: mu04
CREATE TABLE IF NOT EXISTS [mu04] ([codigo] TEXT(10) NOT NULL, [seq] REAL NOT NULL, [data] SHORTDATE NOT NULL, [historico] TEXT(30) NOT NULL, [tipoent] TEXT(1) NOT NULL, [qtdde] REAL NOT NULL, [preco] REAL NOT NULL, [totqtdde] REAL NOT NULL, [totpreco] REAL NOT NULL, [totitem] REAL NOT NULL, [medio] REAL NOT NULL);

-- Tabela: mu99
CREATE TABLE IF NOT EXISTS [mu99] ([arquivo] TEXT(8) NOT NULL, [documento] TEXT(40) NOT NULL, [operacao] TEXT(1) NOT NULL, [usuario] TEXT(5) NOT NULL, [qtde] REAL NOT NULL, [oldqtde] REAL NOT NULL, [data] SHORTDATE NOT NULL, [numero] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [rastro] TEXT(10) NOT NULL, [estqxxx] REAL NOT NULL, [estqyyy] REAL NOT NULL);

-- Tabela: mw01
CREATE TABLE IF NOT EXISTS [mw01] ([comped] REAL NOT NULL, [comfor] REAL NOT NULL, [comcog] TEXT(15) NOT NULL, [comcon] TEXT(22) NOT NULL, [comddd] TEXT(4) NOT NULL, [comtel] TEXT(9) NOT NULL, [comdddfax] TEXT(4) NOT NULL, [comtelfax] TEXT(9) NOT NULL, [compraz] TEXT(20) NOT NULL, [comdpraz] SHORTDATE NOT NULL, [comcpag] TEXT(2) NOT NULL, [comcpagd] TEXT(40) NOT NULL, [obs01] TEXT(100) NOT NULL, [obs02] TEXT(100) NOT NULL, [obs03] TEXT(100) NOT NULL, [obs04] TEXT(100) NOT NULL, [obs05] TEXT(100) NOT NULL, [obs06] TEXT(100) NOT NULL, [comdabe] SHORTDATE NOT NULL, [comdfec] SHORTDATE NOT NULL, [liber] TEXT(1) NOT NULL, [comcta] TEXT(11) NOT NULL, [libus] TEXT(10) NOT NULL, [libdat] SHORTDATE NOT NULL, [receber] TEXT(1) NOT NULL, [baixaobs] TEXT(20) NOT NULL, [prgent] REAL NOT NULL, [contrato] TEXT(1) NOT NULL, [baixaobx] TEXT(20) NOT NULL, [travaped] TEXT(1) NOT NULL, [pausa] TEXT(1) NOT NULL);

-- Tabela: mw01bx
CREATE TABLE IF NOT EXISTS [mw01bx] ([comped] REAL NOT NULL, [comfor] REAL NOT NULL, [comcog] TEXT(15) NOT NULL, [comcon] TEXT(22) NOT NULL, [comddd] TEXT(4) NOT NULL, [comtel] TEXT(9) NOT NULL, [comdddfax] TEXT(4) NOT NULL, [comtelfax] TEXT(9) NOT NULL, [compraz] TEXT(20) NOT NULL, [comdpraz] SHORTDATE NOT NULL, [comcpag] TEXT(2) NOT NULL, [comcpagd] TEXT(40) NOT NULL, [obs01] TEXT(100) NOT NULL, [obs02] TEXT(100) NOT NULL, [obs03] TEXT(100) NOT NULL, [obs04] TEXT(100) NOT NULL, [obs05] TEXT(100) NOT NULL, [obs06] TEXT(100) NOT NULL, [comdabe] SHORTDATE NOT NULL, [comdfec] SHORTDATE NOT NULL, [liber] TEXT(1) NOT NULL, [comcta] TEXT(11) NOT NULL, [libus] TEXT(10) NOT NULL, [libdat] SHORTDATE NOT NULL, [receber] TEXT(1) NOT NULL, [baixaobs] TEXT(20) NOT NULL, [prgent] REAL NOT NULL, [contrato] TEXT(1) NOT NULL, [baixaobx] TEXT(20) NOT NULL, [travaped] TEXT(1) NOT NULL, [pausa] TEXT(1) NOT NULL);

-- Tabela: mw02
CREATE TABLE IF NOT EXISTS [mw02] ([comped] REAL NOT NULL, [item] REAL NOT NULL, [itetip] TEXT(1) NOT NULL, [itecod] TEXT(13) NOT NULL, [iterec] REAL NOT NULL, [itenom] TEXT(200) NOT NULL, [iteno2] TEXT(50) NOT NULL, [iteo01] TEXT(200) NOT NULL, [iteo02] TEXT(70) NOT NULL, [iteo03] TEXT(70) NOT NULL, [iten01] TEXT(35) NOT NULL, [iten02] TEXT(35) NOT NULL, [iteuni] TEXT(2) NOT NULL, [iteqtd] REAL NOT NULL, [itetot] REAL NOT NULL, [iteprc] REAL NOT NULL, [recdat] SHORTDATE NOT NULL, [iteue] TEXT(7) NOT NULL, [itesol] TEXT(12) NOT NULL, [itecta] TEXT(11) NOT NULL, [iteipi] REAL NOT NULL, [iteent] REAL NOT NULL, [iteres] REAL NOT NULL, [itesal] REAL NOT NULL, [iteccm] REAL NOT NULL, [destino] TEXT(20) NOT NULL, [coddep] TEXT(3) NOT NULL, [reco01] TEXT(200) NOT NULL, [reco02] TEXT(70) NOT NULL, [reco03] TEXT(70) NOT NULL, [recnum] REAL NOT NULL, [recnot] REAL NOT NULL, [prgent] REAL NOT NULL, [reqdat] SHORTDATE NOT NULL, [pedcli] TEXT(1) NOT NULL, [vigencia] SHORTDATE NOT NULL, [verifica] SHORTDATE NOT NULL, [residuo] TEXT(1) NOT NULL, [ppap] REAL NOT NULL, [ppapd] SHORTDATE NOT NULL, [redicm] REAL NOT NULL, [pedativo] TEXT(1) NOT NULL, [codmw] TEXT(3) NOT NULL);

-- Tabela: mw02bx
CREATE TABLE IF NOT EXISTS [mw02bx] ([comped] REAL NOT NULL, [item] REAL NOT NULL, [itetip] TEXT(1) NOT NULL, [itecod] TEXT(13) NOT NULL, [iterec] REAL NOT NULL, [itenom] TEXT(200) NOT NULL, [iteno2] TEXT(50) NOT NULL, [iteo01] TEXT(200) NOT NULL, [iteo02] TEXT(70) NOT NULL, [iteo03] TEXT(70) NOT NULL, [iten01] TEXT(35) NOT NULL, [iten02] TEXT(35) NOT NULL, [iteuni] TEXT(2) NOT NULL, [iteqtd] REAL NOT NULL, [itetot] REAL NOT NULL, [iteprc] REAL NOT NULL, [recdat] SHORTDATE NOT NULL, [iteue] TEXT(7) NOT NULL, [itesol] TEXT(12) NOT NULL, [itecta] TEXT(11) NOT NULL, [iteipi] REAL NOT NULL, [iteent] REAL NOT NULL, [iteres] REAL NOT NULL, [itesal] REAL NOT NULL, [iteccm] REAL NOT NULL, [destino] TEXT(20) NOT NULL, [coddep] TEXT(3) NOT NULL, [reco01] TEXT(200) NOT NULL, [reco02] TEXT(70) NOT NULL, [reco03] TEXT(70) NOT NULL, [recnum] REAL NOT NULL, [recnot] REAL NOT NULL, [prgent] REAL NOT NULL, [reqdat] SHORTDATE NOT NULL, [pedcli] TEXT(1) NOT NULL, [vigencia] SHORTDATE NOT NULL, [verifica] SHORTDATE NOT NULL, [residuo] TEXT(1) NOT NULL, [ppap] REAL NOT NULL, [ppapd] SHORTDATE NOT NULL, [redicm] REAL NOT NULL, [pedativo] TEXT(1) NOT NULL, [codmw] TEXT(3) NOT NULL);

-- Tabela: mw03
CREATE TABLE IF NOT EXISTS [mw03] ([comped] REAL NOT NULL, [item] REAL NOT NULL, [iteent] REAL NOT NULL, [datent] SHORTDATE NOT NULL, [datobs] TEXT(20) NOT NULL, [qtdini] REAL NOT NULL, [qtdent] REAL NOT NULL, [qtdsal] REAL NOT NULL, [qtdnf] REAL NOT NULL, [nfent] REAL NOT NULL, [nfdat] SHORTDATE NOT NULL, [comfor] REAL NOT NULL, [comcog] TEXT(12) NOT NULL, [itecod] TEXT(12) NOT NULL);

-- Tabela: mw03bx
CREATE TABLE IF NOT EXISTS [mw03bx] ([comped] REAL NOT NULL, [item] REAL NOT NULL, [iteent] REAL NOT NULL, [datent] SHORTDATE NOT NULL, [datobs] TEXT(20) NOT NULL, [qtdini] REAL NOT NULL, [qtdent] REAL NOT NULL, [qtdsal] REAL NOT NULL, [qtdnf] REAL NOT NULL, [nfent] REAL NOT NULL, [nfdat] SHORTDATE NOT NULL, [comfor] REAL NOT NULL, [comcog] TEXT(12) NOT NULL, [itecod] TEXT(12) NOT NULL);

-- Tabela: mw04
CREATE TABLE IF NOT EXISTS [mw04] ([reccom] REAL NOT NULL, [recdat] SHORTDATE NOT NULL, [recue] TEXT(7) NOT NULL, [recsol] TEXT(12) NOT NULL, [rectip] TEXT(1) NOT NULL, [reccod] TEXT(13) NOT NULL, [recnom] TEXT(200) NOT NULL, [recno2] TEXT(50) NOT NULL, [reccta] TEXT(11) NOT NULL, [relqtdi] REAL NOT NULL, [relqtdp] REAL NOT NULL, [relqtds] REAL NOT NULL, [recped] REAL NOT NULL, [recpd] SHORTDATE NOT NULL, [recpi] REAL NOT NULL, [recund] TEXT(3) NOT NULL, [reco01] TEXT(78) NOT NULL, [reco02] TEXT(78) NOT NULL, [reco03] TEXT(78) NOT NULL, [lirer] TEXT(1) NOT NULL, [lirus] TEXT(10) NOT NULL, [lirdat] SHORTDATE NOT NULL, [libhor] REAL NOT NULL, [licer] TEXT(1) NOT NULL, [licus] TEXT(10) NOT NULL, [licdat] SHORTDATE NOT NULL, [lichor] REAL NOT NULL, [recpra] SHORTDATE NOT NULL, [recpro] TEXT(20) NOT NULL, [recesq] REAL NOT NULL, [recctr] TEXT(1) NOT NULL, [cotacao] REAL NOT NULL, [avulsa] TEXT(1) NOT NULL, [recgru] TEXT(5) NOT NULL, [recult] REAL NOT NULL, [recccm] REAL NOT NULL, [comf01] REAL NOT NULL, [comf02] REAL NOT NULL, [comf03] REAL NOT NULL, [itep01] REAL NOT NULL, [itep02] REAL NOT NULL, [itep03] REAL NOT NULL, [iteu01] TEXT(2) NOT NULL, [iteu02] TEXT(2) NOT NULL, [iteu03] TEXT(2) NOT NULL, [ited01] SHORTDATE NOT NULL, [ited02] SHORTDATE NOT NULL, [ited03] SHORTDATE NOT NULL, [obsnf] TEXT(50) NOT NULL, [obsfo] TEXT(50) NOT NULL, [obspr] REAL NOT NULL);

-- Tabela: mw04pg
CREATE TABLE IF NOT EXISTS [mw04pg] ([reccom] REAL NOT NULL, [recdat] SHORTDATE NOT NULL, [recue] TEXT(7) NOT NULL, [recsol] TEXT(12) NOT NULL, [rectip] TEXT(1) NOT NULL, [reccod] TEXT(13) NOT NULL, [recnom] TEXT(200) NOT NULL, [recno2] TEXT(50) NOT NULL, [reccta] TEXT(11) NOT NULL, [relqtdi] REAL NOT NULL, [relqtdp] REAL NOT NULL, [relqtds] REAL NOT NULL, [recped] REAL NOT NULL, [recpd] SHORTDATE NOT NULL, [recpi] REAL NOT NULL, [recund] TEXT(3) NOT NULL, [reco01] TEXT(78) NOT NULL, [reco02] TEXT(78) NOT NULL, [reco03] TEXT(78) NOT NULL, [lirer] TEXT(1) NOT NULL, [lirus] TEXT(10) NOT NULL, [lirdat] SHORTDATE NOT NULL, [libhor] REAL NOT NULL, [licer] TEXT(1) NOT NULL, [licus] TEXT(10) NOT NULL, [licdat] SHORTDATE NOT NULL, [lichor] REAL NOT NULL, [recpra] SHORTDATE NOT NULL, [recpro] TEXT(20) NOT NULL, [recesq] REAL NOT NULL, [recctr] TEXT(1) NOT NULL, [cotacao] REAL NOT NULL, [avulsa] TEXT(1) NOT NULL, [recgru] TEXT(5) NOT NULL, [recult] REAL NOT NULL, [recccm] REAL NOT NULL, [comf01] REAL NOT NULL, [comf02] REAL NOT NULL, [comf03] REAL NOT NULL, [itep01] REAL NOT NULL, [itep02] REAL NOT NULL, [itep03] REAL NOT NULL, [iteu01] TEXT(2) NOT NULL, [iteu02] TEXT(2) NOT NULL, [iteu03] TEXT(2) NOT NULL, [ited01] SHORTDATE NOT NULL, [ited02] SHORTDATE NOT NULL, [ited03] SHORTDATE NOT NULL, [obsnf] TEXT(50) NOT NULL, [obsfo] TEXT(50) NOT NULL, [obspr] REAL NOT NULL);

-- Tabela: mw05
CREATE TABLE IF NOT EXISTS [mw05] ([codigo] TEXT(15) NOT NULL, [nome] TEXT(200) NOT NULL, [nom2] TEXT(1) NOT NULL, [ctacontb] TEXT(11) NOT NULL, [unidade] TEXT(2) NOT NULL, [saimin] REAL NOT NULL, [estqmin] REAL NOT NULL, [estqent] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqini] REAL NOT NULL, [estqsal] REAL NOT NULL, [estqpro] REAL NOT NULL, [diasent] REAL NOT NULL, [diasest] REAL NOT NULL, [databalan] SHORTDATE NOT NULL, [datmin] SHORTDATE NOT NULL, [mmensal] REAL NOT NULL, [mindi] REAL NOT NULL, [minind] REAL NOT NULL, [cauto] REAL NOT NULL, [mw05gru] TEXT(5) NOT NULL, [tipdis] TEXT(1) NOT NULL, [diadis] REAL NOT NULL, [obs] TEXT(70) NOT NULL, [cotval] REAL NOT NULL, [ultprc] REAL NOT NULL, [ultund] TEXT(2) NOT NULL, [ultdata] SHORTDATE NOT NULL, [ccm] REAL NOT NULL, [redicm] REAL NOT NULL, [aplicacao] TEXT(50) NOT NULL, [codmw] TEXT(3) NOT NULL, [piscon] TEXT(1) NOT NULL, [codipi] TEXT(2) NOT NULL, [classipi] TEXT(14) NOT NULL, [ipi] REAL NOT NULL, [valinv] REAL NOT NULL, [precust] REAL NOT NULL, [pltinv] REAL NOT NULL);

-- Tabela: mw06
CREATE TABLE IF NOT EXISTS [mw06] ([tipo] TEXT(1) NOT NULL, [codigo] TEXT(15) NOT NULL, [ano] REAL NOT NULL, [mes] REAL NOT NULL, [uso] REAL NOT NULL);

-- Tabela: mw07
CREATE TABLE IF NOT EXISTS [mw07] ([codigo] TEXT(15) NOT NULL, [nome] TEXT(200) NOT NULL, [nom2] TEXT(1) NOT NULL, [ctacontb] TEXT(11) NOT NULL, [unidade] TEXT(2) NOT NULL, [saimin] REAL NOT NULL, [estqmin] REAL NOT NULL, [estqent] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqini] REAL NOT NULL, [estqsal] REAL NOT NULL, [estqpro] REAL NOT NULL, [diasent] REAL NOT NULL, [diasest] REAL NOT NULL, [databalan] SHORTDATE NOT NULL, [datmin] SHORTDATE NOT NULL, [mmensal] REAL NOT NULL, [mindi] REAL NOT NULL, [minind] REAL NOT NULL, [cauto] REAL NOT NULL, [mw05gru] TEXT(5) NOT NULL, [tipdis] TEXT(1) NOT NULL, [diadis] REAL NOT NULL, [obs] TEXT(70) NOT NULL, [cotval] REAL NOT NULL, [ultprc] REAL NOT NULL, [ultund] TEXT(2) NOT NULL, [ultdata] SHORTDATE NOT NULL, [ccm] REAL NOT NULL, [redicm] REAL NOT NULL, [aplicacao] TEXT(50) NOT NULL, [codmw] TEXT(3) NOT NULL, [piscon] TEXT(1) NOT NULL, [codipi] TEXT(2) NOT NULL, [classipi] TEXT(14) NOT NULL, [ipi] REAL NOT NULL, [valinv] REAL NOT NULL, [precust] REAL NOT NULL, [pltinv] REAL NOT NULL, [pesliq] REAL NOT NULL, [qtdeapu] REAL NOT NULL, [crmsel] REAL NOT NULL);

-- Tabela: mw08
CREATE TABLE IF NOT EXISTS [mw08] ([itetip] TEXT(1) NOT NULL, [itecod] TEXT(24) NOT NULL, [comfor] REAL NOT NULL, [iteprc] REAL NOT NULL, [iteuni] TEXT(2) NOT NULL, [data] SHORTDATE NOT NULL, [comped] REAL NOT NULL, [item] REAL NOT NULL, [pedativo] TEXT(1) NOT NULL, [codmw] TEXT(3) NOT NULL, [dataini] SHORTDATE NOT NULL);

-- Tabela: mw91
CREATE TABLE IF NOT EXISTS [mw91] ([comped] REAL NOT NULL, [comfor] REAL NOT NULL, [comcog] TEXT(15) NOT NULL, [comcon] TEXT(22) NOT NULL, [comddd] TEXT(4) NOT NULL, [comtel] TEXT(12) NOT NULL, [comdddfax] TEXT(4) NOT NULL, [comtelfax] TEXT(12) NOT NULL, [compraz] TEXT(20) NOT NULL, [comdpraz] SHORTDATE NOT NULL, [comcpag] TEXT(2) NOT NULL, [comcpagd] TEXT(40) NOT NULL, [obs01] TEXT(100) NOT NULL, [obs02] TEXT(100) NOT NULL, [obs03] TEXT(100) NOT NULL, [obs04] TEXT(100) NOT NULL, [obs05] TEXT(100) NOT NULL, [obs06] TEXT(100) NOT NULL, [comdabe] SHORTDATE NOT NULL, [comdfec] SHORTDATE NOT NULL, [liber] TEXT(1) NOT NULL, [comcta] TEXT(11) NOT NULL, [libus] TEXT(10) NOT NULL, [libdat] SHORTDATE NOT NULL, [receber] TEXT(1) NOT NULL, [baixaobs] TEXT(20) NOT NULL, [prgent] REAL NOT NULL, [contrato] TEXT(1) NOT NULL, [baixaobx] TEXT(20) NOT NULL, [travaped] TEXT(1) NOT NULL, [pausa] TEXT(1) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: mw92
CREATE TABLE IF NOT EXISTS [mw92] ([comped] REAL NOT NULL, [item] REAL NOT NULL, [itetip] TEXT(1) NOT NULL, [itecod] TEXT(13) NOT NULL, [iterec] REAL NOT NULL, [itenom] TEXT(200) NOT NULL, [iteno2] TEXT(50) NOT NULL, [iteo01] TEXT(200) NOT NULL, [iteo02] TEXT(70) NOT NULL, [iteo03] TEXT(70) NOT NULL, [iten01] TEXT(35) NOT NULL, [iten02] TEXT(35) NOT NULL, [iteuni] TEXT(2) NOT NULL, [iteqtd] REAL NOT NULL, [itetot] REAL NOT NULL, [iteprc] REAL NOT NULL, [recdat] SHORTDATE NOT NULL, [iteue] TEXT(7) NOT NULL, [itesol] TEXT(12) NOT NULL, [itecta] TEXT(11) NOT NULL, [iteipi] REAL NOT NULL, [iteent] REAL NOT NULL, [iteres] REAL NOT NULL, [itesal] REAL NOT NULL, [iteccm] REAL NOT NULL, [destino] TEXT(20) NOT NULL, [coddep] TEXT(3) NOT NULL, [reco01] TEXT(200) NOT NULL, [reco02] TEXT(70) NOT NULL, [reco03] TEXT(70) NOT NULL, [recnum] REAL NOT NULL, [recnot] REAL NOT NULL, [prgent] REAL NOT NULL, [reqdat] SHORTDATE NOT NULL, [pedcli] TEXT(1) NOT NULL, [vigencia] SHORTDATE NOT NULL, [verifica] SHORTDATE NOT NULL, [residuo] TEXT(1) NOT NULL, [ppap] REAL NOT NULL, [ppapd] SHORTDATE NOT NULL, [redicm] REAL NOT NULL, [pedativo] TEXT(1) NOT NULL, [codmw] TEXT(3) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: mw95
CREATE TABLE IF NOT EXISTS [mw95] ([arquivo] TEXT(8) NOT NULL, [documento] TEXT(40) NOT NULL, [operacao] TEXT(1) NOT NULL, [usuario] TEXT(5) NOT NULL, [qtde] REAL NOT NULL, [oldqtde] REAL NOT NULL, [numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [codigo] TEXT(24) NOT NULL, [rastro] TEXT(10) NOT NULL, [estqxxx] REAL NOT NULL, [estqyyy] REAL NOT NULL);

-- Tabela: mw97
CREATE TABLE IF NOT EXISTS [mw97] ([arquivo] TEXT(8) NOT NULL, [documento] TEXT(40) NOT NULL, [operacao] TEXT(1) NOT NULL, [usuario] TEXT(5) NOT NULL, [qtde] REAL NOT NULL, [oldqtde] REAL NOT NULL, [numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [codigo] TEXT(24) NOT NULL, [rastro] TEXT(10) NOT NULL, [estqxxx] REAL NOT NULL, [estqyyy] REAL NOT NULL);

-- Tabela: mx01
CREATE TABLE IF NOT EXISTS [mx01] ([os] REAL NOT NULL, [data] SHORTDATE NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [empregado] REAL NOT NULL, [nome] TEXT(32) NOT NULL, [cargo] TEXT(20) NOT NULL, [cod_cargo] REAL NOT NULL, [servico] TEXT(8) NOT NULL, [descricao] TEXT(40) NOT NULL, [hrini] REAL NOT NULL, [hrfim] REAL NOT NULL, [hrdes] REAL NOT NULL, [hrqtde] REAL NOT NULL, [database] SHORTDATE NOT NULL, [tipbase] TEXT(1) NOT NULL, [tiposerv] TEXT(1) NOT NULL, [valor] REAL NOT NULL, [valortot] REAL NOT NULL, [observacao] TEXT(73) NOT NULL, [qtdde] REAL NOT NULL, [imposto] TEXT(2) NOT NULL, [aliquota] REAL NOT NULL, [unid] TEXT(2) NOT NULL, [valorimp] REAL NOT NULL, [valormer] REAL NOT NULL);

-- Tabela: mx02
CREATE TABLE IF NOT EXISTS [mx02] ([os] REAL NOT NULL, [data] SHORTDATE NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [descricao] TEXT(40) NOT NULL, [obs] TEXT(70) NOT NULL);

-- Tabela: mx03
CREATE TABLE IF NOT EXISTS [mx03] ([codigo] TEXT(8) NOT NULL, [descricao] TEXT(50) NOT NULL, [total] REAL NOT NULL);

-- Tabela: mx03a
CREATE TABLE IF NOT EXISTS [mx03a] ([codigo] TEXT(8) NOT NULL, [seq] REAL NOT NULL, [descri] TEXT(30) NOT NULL, [preco] REAL NOT NULL);

-- Tabela: mx04
CREATE TABLE IF NOT EXISTS [mx04] ([seq] REAL NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [data] SHORTDATE NOT NULL, [hora] REAL NOT NULL, [valor] REAL NOT NULL);

-- Tabela: mx05
CREATE TABLE IF NOT EXISTS [mx05] ([seq] REAL NOT NULL, [cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [solicita] SHORTDATE NOT NULL, [horasol] REAL NOT NULL, [contato] TEXT(12) NOT NULL, [tecnico] REAL NOT NULL, [cogtec] TEXT(12) NOT NULL, [previsao] SHORTDATE NOT NULL, [efetuada] SHORTDATE NOT NULL, [horaefe] REAL NOT NULL, [assunto] TEXT(30) NOT NULL, [dizer1] TEXT(78) NOT NULL, [dizer2] TEXT(78) NOT NULL);

-- Tabela: my01
CREATE TABLE IF NOT EXISTS [my01] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tipo1] TEXT(1) NOT NULL, [tipo2] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [qtde] REAL NOT NULL, [unid] TEXT(2) NOT NULL, [os] REAL NOT NULL, [item] REAL NOT NULL, [obs] TEXT(40) NOT NULL, [distri] TEXT(1) NOT NULL, [rastro] TEXT(8) NOT NULL, [tecnico] REAL NOT NULL, [nrnota] REAL NOT NULL, [crm] REAL NOT NULL, [reqint] REAL NOT NULL, [nummb01] REAL NOT NULL, [prcmw02] REAL NOT NULL, [prcmy04] REAL NOT NULL, [prcmk02] REAL NOT NULL, [aut] REAL NOT NULL, [nummw04] REAL NOT NULL, [naomedio] TEXT(1) NOT NULL, [firma] REAL NOT NULL, [tipo3] TEXT(3) NOT NULL);

-- Tabela: my01e
CREATE TABLE IF NOT EXISTS [my01e] ([arquivo] TEXT(8) NOT NULL, [documento] TEXT(40) NOT NULL, [operacao] TEXT(1) NOT NULL, [usuario] TEXT(5) NOT NULL, [qtde] REAL NOT NULL, [oldqtde] REAL NOT NULL, [numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [codigo] TEXT(24) NOT NULL, [rastro] TEXT(10) NOT NULL, [estqxxx] REAL NOT NULL, [estqyyy] REAL NOT NULL);

-- Tabela: my02
CREATE TABLE IF NOT EXISTS [my02] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tipo1] TEXT(1) NOT NULL, [tipo2] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [qtde] REAL NOT NULL, [unid] TEXT(2) NOT NULL, [os] REAL NOT NULL);

-- Tabela: my03
CREATE TABLE IF NOT EXISTS [my03] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [codigo] TEXT(24) NOT NULL, [codig2] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [qtdde] REAL NOT NULL, [tioope] TEXT(1) NOT NULL, [codope] REAL NOT NULL, [codmaq] TEXT(4) NOT NULL, [iniopr] REAL NOT NULL, [fimopr] REAL NOT NULL, [almini] REAL NOT NULL, [almfim] REAL NOT NULL, [datopr] SHORTDATE NOT NULL, [horopr] REAL NOT NULL, [rastro] TEXT(6) NOT NULL, [parada] REAL NOT NULL, [op] REAL NOT NULL, [valref] REAL NOT NULL, [antref] REAL NOT NULL, [fatref] REAL NOT NULL, [salref] REAL NOT NULL, [turno] TEXT(2) NOT NULL, [obslan] TEXT(20) NOT NULL, [virada] TEXT(1) NOT NULL, [bxmy03] TEXT(1) NOT NULL, [tpmy03] TEXT(1) NOT NULL, [excmaq] TEXT(1) NOT NULL, [submaq] TEXT(3) NOT NULL, [horuso] REAL NOT NULL, [firma] REAL NOT NULL, [nummb01] REAL NOT NULL, [temporef] REAL NOT NULL, [codigoint] TEXT(24) NOT NULL);

-- Tabela: my03a
CREATE TABLE IF NOT EXISTS [my03a] ([numero] REAL NOT NULL, [item] REAL NOT NULL, [codpar] TEXT(3) NOT NULL, [codpard] TEXT(1) NOT NULL, [pini] REAL NOT NULL, [pfim] REAL NOT NULL, [pali] REAL NOT NULL, [palf] REAL NOT NULL, [tempo] REAL NOT NULL, [obs] TEXT(78) NOT NULL);

-- Tabela: my03i
CREATE TABLE IF NOT EXISTS [my03i] ([arquivo] TEXT(8) NOT NULL, [documento] TEXT(40) NOT NULL, [operacao] TEXT(1) NOT NULL, [usuario] TEXT(5) NOT NULL, [qtde] REAL NOT NULL, [oldqtde] REAL NOT NULL, [data] SHORTDATE NOT NULL, [numero] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [rastro] TEXT(10) NOT NULL, [estqxxx] REAL NOT NULL, [estqyyy] REAL NOT NULL);

-- Tabela: my03mid
CREATE TABLE IF NOT EXISTS [my03mid] ([codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [qtdde] REAL NOT NULL, [horas] REAL NOT NULL, [tirado] BIT NOT NULL, [datopr] SHORTDATE NOT NULL, [pchora] REAL NOT NULL, [iniopr] REAL NOT NULL, [fimopr] REAL NOT NULL, [parada] REAL NOT NULL);

-- Tabela: my03tmp
CREATE TABLE IF NOT EXISTS [my03tmp] ([codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [qtdde] REAL NOT NULL, [horas] REAL NOT NULL, [datopr] SHORTDATE NOT NULL, [codigoint] TEXT(24) NOT NULL);

-- Tabela: my04
CREATE TABLE IF NOT EXISTS [my04] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tipo1] TEXT(1) NOT NULL, [tipo2] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [qtde] REAL NOT NULL, [qtdeini] REAL NOT NULL, [qtdesal] REAL NOT NULL, [unid] TEXT(2) NOT NULL, [os] REAL NOT NULL, [item] REAL NOT NULL, [obs] TEXT(40) NOT NULL, [distri] TEXT(1) NOT NULL, [rastro] TEXT(8) NOT NULL, [tecnico] REAL NOT NULL, [nrnota] REAL NOT NULL, [crm] REAL NOT NULL, [reqint] REAL NOT NULL, [nummb01] REAL NOT NULL, [prcmw02] REAL NOT NULL, [prcmy04] REAL NOT NULL, [prcmk02] REAL NOT NULL, [aut] REAL NOT NULL, [nummw04] REAL NOT NULL, [naomedio] TEXT(1) NOT NULL, [firma] REAL NOT NULL, [tipo3] TEXT(3) NOT NULL, [coddep] TEXT(3) NOT NULL);

-- Tabela: my04e
CREATE TABLE IF NOT EXISTS [my04e] ([arquivo] TEXT(8) NOT NULL, [documento] TEXT(40) NOT NULL, [operacao] TEXT(1) NOT NULL, [usuario] TEXT(5) NOT NULL, [qtde] REAL NOT NULL, [oldqtde] REAL NOT NULL, [numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [codigo] TEXT(24) NOT NULL, [rastro] TEXT(10) NOT NULL, [estqxxx] REAL NOT NULL, [estqyyy] REAL NOT NULL);

-- Tabela: mz01
CREATE TABLE IF NOT EXISTS [mz01] ([nrnota] REAL NOT NULL, [data] SHORTDATE NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [vendedor] TEXT(5) NOT NULL, [fatura] REAL NOT NULL, [tipfat] TEXT(1) NOT NULL, [totfat] REAL NOT NULL, [nrpv] REAL NOT NULL, [datapv] SHORTDATE NOT NULL, [totpvs] REAL NOT NULL, [cambio] REAL NOT NULL, [pagto] REAL NOT NULL, [banco] TEXT(3) NOT NULL, [nomebco] TEXT(12) NOT NULL, [cheque] TEXT(8) NOT NULL, [valorch] REAL NOT NULL, [venciment] SHORTDATE NOT NULL, [valors] REAL NOT NULL, [juros] REAL NOT NULL, [situacao] REAL NOT NULL, [bancoc] REAL NOT NULL, [documento] TEXT(15) NOT NULL, [obs1] TEXT(70) NOT NULL, [obs2] TEXT(70) NOT NULL, [obs3] TEXT(70) NOT NULL, [obs4] TEXT(70) NOT NULL, [debcre] TEXT(1) NOT NULL);

-- Tabela: nfscod
CREATE TABLE IF NOT EXISTS [nfscod] ([codigo1] TEXT(5) NOT NULL, [descricao] TEXT(255) NOT NULL, [codigo2] TEXT(1) NOT NULL, [codigo3] TEXT(5) NOT NULL);

-- Tabela: nota
CREATE TABLE IF NOT EXISTS [nota] ([nome] TEXT(10) NOT NULL, [obs1] TEXT(60) NOT NULL, [obs2] TEXT(60) NOT NULL, [obs3] TEXT(60) NOT NULL, [obs4] TEXT(60) NOT NULL, [obs5] TEXT(60) NOT NULL, [obs6] TEXT(60) NOT NULL, [obs7] TEXT(60) NOT NULL);

-- Tabela: oc01
CREATE TABLE IF NOT EXISTS [oc01] ([oc] REAL NOT NULL, [data] SHORTDATE NOT NULL, [obs] TEXT(60) NOT NULL, [total] REAL NOT NULL);

-- Tabela: oc01a
CREATE TABLE IF NOT EXISTS [oc01a] ([oc] REAL NOT NULL, [item] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [qtduni] REAL NOT NULL, [qtdemb] REAL NOT NULL, [pesuni] REAL NOT NULL, [pesemb] REAL NOT NULL, [soma] REAL NOT NULL);

-- Tabela: of01
CREATE TABLE IF NOT EXISTS [of01] ([of] REAL NOT NULL, [item] REAL NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [codigo] TEXT(24) NOT NULL, [qpedido] REAL NOT NULL, [qreserva] REAL NOT NULL, [qtolera] REAL NOT NULL, [qfabricar] REAL NOT NULL, [qfabricad] REAL NOT NULL, [qsaldo] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [perto] REAL NOT NULL, [diafab] REAL NOT NULL, [diacom] REAL NOT NULL, [unid] TEXT(2) NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL);

-- Tabela: of02
CREATE TABLE IF NOT EXISTS [of02] ([of] REAL NOT NULL, [item] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [quso] REAL NOT NULL, [tipcomp] TEXT(1) NOT NULL, [codcomp] TEXT(24) NOT NULL, [nomecomp] TEXT(40) NOT NULL, [qtcomp] REAL NOT NULL, [qttot] REAL NOT NULL, [reserva] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [baixac] TEXT(1) NOT NULL);

-- Tabela: of03
CREATE TABLE IF NOT EXISTS [of03] ([of] REAL NOT NULL, [item] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [dlimp] SHORTDATE NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [codmp01] TEXT(12) NOT NULL, [codmp02] TEXT(12) NOT NULL, [codmp02b] TEXT(12) NOT NULL, [codmp02c] TEXT(24) NOT NULL, [codmp02d] TEXT(24) NOT NULL, [codmp03] TEXT(24) NOT NULL, [qttime] REAL NOT NULL, [qtfab] REAL NOT NULL, [qtres] REAL NOT NULL, [qtfal] REAL NOT NULL);

-- Tabela: of99
CREATE TABLE IF NOT EXISTS [of99] ([arquivo] TEXT(8) NOT NULL, [documento] TEXT(30) NOT NULL, [operacao] TEXT(1) NOT NULL, [usuario] TEXT(5) NOT NULL, [qtde] REAL NOT NULL, [oldqtde] REAL NOT NULL, [data] SHORTDATE NOT NULL, [numero] REAL NOT NULL, [codigo] TEXT(8) NOT NULL);

-- Tabela: or01
CREATE TABLE IF NOT EXISTS [or01] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or01bx
CREATE TABLE IF NOT EXISTS [or01bx] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or02
CREATE TABLE IF NOT EXISTS [or02] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or02bx
CREATE TABLE IF NOT EXISTS [or02bx] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or03
CREATE TABLE IF NOT EXISTS [or03] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or03bx
CREATE TABLE IF NOT EXISTS [or03bx] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or04
CREATE TABLE IF NOT EXISTS [or04] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or04bx
CREATE TABLE IF NOT EXISTS [or04bx] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or05
CREATE TABLE IF NOT EXISTS [or05] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or05bx
CREATE TABLE IF NOT EXISTS [or05bx] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or06
CREATE TABLE IF NOT EXISTS [or06] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or06bx
CREATE TABLE IF NOT EXISTS [or06bx] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or07
CREATE TABLE IF NOT EXISTS [or07] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or07bx
CREATE TABLE IF NOT EXISTS [or07bx] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or08
CREATE TABLE IF NOT EXISTS [or08] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or08bx
CREATE TABLE IF NOT EXISTS [or08bx] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or09
CREATE TABLE IF NOT EXISTS [or09] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or09bx
CREATE TABLE IF NOT EXISTS [or09bx] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or10
CREATE TABLE IF NOT EXISTS [or10] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or10bx
CREATE TABLE IF NOT EXISTS [or10bx] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or11
CREATE TABLE IF NOT EXISTS [or11] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or11bx
CREATE TABLE IF NOT EXISTS [or11bx] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or12
CREATE TABLE IF NOT EXISTS [or12] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or12bx
CREATE TABLE IF NOT EXISTS [or12bx] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or15
CREATE TABLE IF NOT EXISTS [or15] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or15bx
CREATE TABLE IF NOT EXISTS [or15bx] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or16
CREATE TABLE IF NOT EXISTS [or16] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or16bx
CREATE TABLE IF NOT EXISTS [or16bx] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or17
CREATE TABLE IF NOT EXISTS [or17] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or17bx
CREATE TABLE IF NOT EXISTS [or17bx] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or18
CREATE TABLE IF NOT EXISTS [or18] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: or18bx
CREATE TABLE IF NOT EXISTS [or18bx] ([codigo] TEXT(24) NOT NULL, [os] REAL NOT NULL, [of] REAL NOT NULL, [qtdde] REAL NOT NULL, [requisi] REAL NOT NULL, [nrnota] REAL NOT NULL, [seq] REAL NOT NULL, [baixa] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [qtdebai] REAL NOT NULL, [dlimite] SHORTDATE NOT NULL, [dpedi] SHORTDATE NOT NULL, [dlimp] SHORTDATE NOT NULL, [rastro] TEXT(6) NOT NULL);

-- Tabela: pt
CREATE TABLE IF NOT EXISTS [pt] ([trein] REAL NOT NULL, [tipcur] TEXT(1) NOT NULL, [tipdis] TEXT(1) NOT NULL, [carga] REAL NOT NULL, [aprovada] TEXT(1) NOT NULL, [aprodata] SHORTDATE NOT NULL, [data] SHORTDATE NOT NULL, [parti] REAL NOT NULL, [cert] TEXT(1) NOT NULL, [curso] TEXT(20) NOT NULL, [descur] TEXT(120) NOT NULL, [prini] SHORTDATE NOT NULL, [prfim] SHORTDATE NOT NULL, [datacur] SHORTDATE NOT NULL, [datafim] SHORTDATE NOT NULL, [horini] REAL NOT NULL, [horfim] REAL NOT NULL, [area] TEXT(2) NOT NULL, [respo] TEXT(40) NOT NULL, [instru] TEXT(40) NOT NULL, [ninstu] REAL NOT NULL, [nescola] REAL NOT NULL, [refer] TEXT(10) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [ntrein] REAL NOT NULL, [numsol] REAL NOT NULL, [nomsol] TEXT(40) NOT NULL);

-- Tabela: pti
CREATE TABLE IF NOT EXISTS [pti] ([trein] REAL NOT NULL, [numfun] REAL NOT NULL, [nomfun] TEXT(40) NOT NULL);

-- Tabela: rhab
CREATE TABLE IF NOT EXISTS [rhab] ([numero] REAL NOT NULL, [codigo] TEXT(2) NOT NULL, [data] SHORTDATE NOT NULL, [justifica] TEXT(1) NOT NULL, [horas] REAL NOT NULL, [seq] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [codigo2] TEXT(2) NOT NULL);

-- Tabela: rhabseq
CREATE TABLE IF NOT EXISTS [rhabseq] ([seq] REAL NOT NULL, [diafim] SHORTDATE NOT NULL, [diaini] SHORTDATE NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [descri] TEXT(30) NOT NULL, [anual] TEXT(1) NOT NULL, [semes] TEXT(1) NOT NULL, [dia01] SHORTDATE NOT NULL, [dia02] SHORTDATE NOT NULL, [dia03] SHORTDATE NOT NULL, [dia04] SHORTDATE NOT NULL, [dia05] SHORTDATE NOT NULL, [dia06] SHORTDATE NOT NULL, [dia07] SHORTDATE NOT NULL, [dia08] SHORTDATE NOT NULL, [dia09] SHORTDATE NOT NULL, [dia10] SHORTDATE NOT NULL, [dia11] SHORTDATE NOT NULL, [dia12] SHORTDATE NOT NULL, [dia13] SHORTDATE NOT NULL, [dia14] SHORTDATE NOT NULL, [dia15] SHORTDATE NOT NULL, [dia16] SHORTDATE NOT NULL, [dia17] SHORTDATE NOT NULL, [dia18] SHORTDATE NOT NULL, [dia19] SHORTDATE NOT NULL, [dia20] SHORTDATE NOT NULL, [dia21] SHORTDATE NOT NULL, [dia22] SHORTDATE NOT NULL, [dia23] SHORTDATE NOT NULL, [dia24] SHORTDATE NOT NULL, [dia25] SHORTDATE NOT NULL, [dia26] SHORTDATE NOT NULL, [dia27] SHORTDATE NOT NULL, [dia28] SHORTDATE NOT NULL, [dia29] SHORTDATE NOT NULL, [dia30] SHORTDATE NOT NULL, [dia31] SHORTDATE NOT NULL);

-- Tabela: rhabtb
CREATE TABLE IF NOT EXISTS [rhabtb] ([ano] REAL NOT NULL, [mes] REAL NOT NULL, [numero] REAL NOT NULL, [nome] TEXT(50) NOT NULL, [setor] TEXT(12) NOT NULL, [seq] REAL NOT NULL, [cod01] TEXT(2) NOT NULL, [cod02] TEXT(2) NOT NULL, [cod03] TEXT(2) NOT NULL, [cod04] TEXT(2) NOT NULL, [cod05] TEXT(2) NOT NULL, [cod06] TEXT(2) NOT NULL, [cod07] TEXT(2) NOT NULL, [cod08] TEXT(2) NOT NULL, [cod09] TEXT(2) NOT NULL, [cod10] TEXT(2) NOT NULL, [cod11] TEXT(2) NOT NULL, [cod12] TEXT(2) NOT NULL, [cod13] TEXT(2) NOT NULL, [cod14] TEXT(2) NOT NULL, [cod15] TEXT(2) NOT NULL, [cod16] TEXT(2) NOT NULL, [cod17] TEXT(2) NOT NULL, [cod18] TEXT(2) NOT NULL, [cod19] TEXT(2) NOT NULL, [cod20] TEXT(2) NOT NULL, [cod21] TEXT(2) NOT NULL, [cod22] TEXT(2) NOT NULL, [cod23] TEXT(2) NOT NULL, [cod24] TEXT(2) NOT NULL, [cod25] TEXT(2) NOT NULL, [cod26] TEXT(2) NOT NULL, [cod27] TEXT(2) NOT NULL, [cod28] TEXT(2) NOT NULL, [cod29] TEXT(2) NOT NULL, [cod30] TEXT(2) NOT NULL, [cod31] TEXT(2) NOT NULL, [totju] REAL NOT NULL, [totnj] REAL NOT NULL, [tot] REAL NOT NULL);

-- Tabela: telememo
CREATE TABLE IF NOT EXISTS [telememo] ([nome] TEXT(15) NOT NULL, [especif] TEXT(35) NOT NULL, [telef] TEXT(14) NOT NULL, [fax] TEXT(14) NOT NULL);

-- Tabela: treii
CREATE TABLE IF NOT EXISTS [treii] ([trein] REAL NOT NULL, [numfun] REAL NOT NULL, [nomfun] TEXT(40) NOT NULL, [compar] TEXT(1) NOT NULL, [avalia] TEXT(1) NOT NULL, [trxcer] TEXT(1) NOT NULL);

-- Tabela: trein
CREATE TABLE IF NOT EXISTS [trein] ([trein] REAL NOT NULL, [tipcur] TEXT(1) NOT NULL, [tipdis] TEXT(1) NOT NULL, [carga] REAL NOT NULL, [parti] REAL NOT NULL, [cert] TEXT(1) NOT NULL, [curso] TEXT(20) NOT NULL, [descur] TEXT(120) NOT NULL, [pro] TEXT(20) NOT NULL, [despro] TEXT(120) NOT NULL, [datacur] SHORTDATE NOT NULL, [datafim] SHORTDATE NOT NULL, [horini] REAL NOT NULL, [horfim] REAL NOT NULL, [area] TEXT(2) NOT NULL, [respo] TEXT(40) NOT NULL, [instru] TEXT(40) NOT NULL, [ninstu] REAL NOT NULL, [nescola] REAL NOT NULL, [refer] TEXT(10) NOT NULL, [tipoana] TEXT(1) NOT NULL, [avager] TEXT(1) NOT NULL, [numsol] REAL NOT NULL, [nomsol] TEXT(40) NOT NULL, [objetivo] TEXT(100) NOT NULL);

-- Tabela: trjob
CREATE TABLE IF NOT EXISTS [trjob] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [numins] REAL NOT NULL, [nomins] TEXT(40) NOT NULL, [codmaq] TEXT(4) NOT NULL, [datf] SHORTDATE NOT NULL);

-- Tabela: trjobi
CREATE TABLE IF NOT EXISTS [trjobi] ([numero] REAL NOT NULL, [peca] TEXT(24) NOT NULL, [numtec] REAL NOT NULL, [nomtec] TEXT(40) NOT NULL, [carga] REAL NOT NULL);

-- Tabela: y399
CREATE TABLE IF NOT EXISTS [y399] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [codigo] TEXT(24) NOT NULL, [codig2] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [qtdde] REAL NOT NULL, [tioope] TEXT(1) NOT NULL, [codope] REAL NOT NULL, [codop2] REAL NOT NULL, [codop3] REAL NOT NULL, [codmaq] TEXT(4) NOT NULL, [iniopr] REAL NOT NULL, [fimopr] REAL NOT NULL, [almini] REAL NOT NULL, [almfim] REAL NOT NULL, [datopr] SHORTDATE NOT NULL, [horopr] REAL NOT NULL, [rastro] TEXT(10) NOT NULL, [parada] REAL NOT NULL, [op] REAL NOT NULL, [codpar] TEXT(2) NOT NULL, [valref] REAL NOT NULL, [antref] REAL NOT NULL, [fatref] REAL NOT NULL, [salref] REAL NOT NULL, [total] REAL NOT NULL, [turno] TEXT(2) NOT NULL, [obslan] TEXT(60) NOT NULL, [virada] TEXT(1) NOT NULL, [bxmy03] TEXT(1) NOT NULL, [tpmy03] TEXT(1) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: ya99
CREATE TABLE IF NOT EXISTS [ya99] ([numero] REAL NOT NULL, [item] REAL NOT NULL, [codpar] TEXT(3) NOT NULL, [codpard] TEXT(1) NOT NULL, [pini] REAL NOT NULL, [pfim] REAL NOT NULL, [pali] REAL NOT NULL, [palf] REAL NOT NULL, [tempo] REAL NOT NULL, [obs] TEXT(78) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- �ndice: idx_apucfo_apucfo
CREATE INDEX IF NOT EXISTS [idx_apucfo_apucfo] ON [apucfo] ([cfo], [subcfo]);

-- �ndice: idx_apucfo_apucfo-2
CREATE INDEX IF NOT EXISTS [idx_apucfo_apucfo-2] ON [apucfo] ([cfonew]);

-- �ndice: idx_apucfouf_apucfou1
CREATE INDEX IF NOT EXISTS [idx_apucfouf_apucfou1] ON [apucfouf] ([cfo], [subcfo], [uf]);

-- �ndice: idx_apucfouf_apucfou2
CREATE INDEX IF NOT EXISTS [idx_apucfouf_apucfou2] ON [apucfouf] ([cfonew], [uf]);

-- �ndice: idx_apucfouf_apucfou3
CREATE INDEX IF NOT EXISTS [idx_apucfouf_apucfou3] ON [apucfouf] ([cfonew], [ufgia]);

-- �ndice: idx_apucfozf_apucfozf
CREATE INDEX IF NOT EXISTS [idx_apucfozf_apucfozf] ON [apucfozf] ([nf]);

-- �ndice: idx_apuita_apuita
CREATE INDEX IF NOT EXISTS [idx_apuita_apuita] ON [apuita] ([ano], [mes]);

-- �ndice: idx_apura2_apura2-1
CREATE INDEX IF NOT EXISTS [idx_apura2_apura2-1] ON [apura2] ([total]);

-- �ndice: idx_apura2_apura2-2
CREATE INDEX IF NOT EXISTS [idx_apura2_apura2-2] ON [apura2] ([grupoemp]);

-- �ndice: idx_apura2c_apura2c1
CREATE INDEX IF NOT EXISTS [idx_apura2c_apura2c1] ON [apura2c] ([total]);

-- �ndice: idx_apura5_apura5-1
CREATE INDEX IF NOT EXISTS [idx_apura5_apura5-1] ON [apura5] ([cliente], [codigo]);

-- �ndice: idx_apura5_apura5-2
CREATE INDEX IF NOT EXISTS [idx_apura5_apura5-2] ON [apura5] ([percli], [codigo]);

-- �ndice: idx_apura5_apura5-3
CREATE INDEX IF NOT EXISTS [idx_apura5_apura5-3] ON [apura5] ([codigo]);

-- �ndice: idx_apura5_apura5-4
CREATE INDEX IF NOT EXISTS [idx_apura5_apura5-4] ON [apura5] ([perluc]);

-- �ndice: idx_apura5_apura5-5
CREATE INDEX IF NOT EXISTS [idx_apura5_apura5-5] ON [apura5] ([difluc]);

-- �ndice: idx_apura5a_apura5a1
CREATE INDEX IF NOT EXISTS [idx_apura5a_apura5a1] ON [apura5a] ([cliente]);

-- �ndice: idx_apura_apura-1
CREATE INDEX IF NOT EXISTS [idx_apura_apura-1] ON [apura] ([cognome]);

-- �ndice: idx_apuser_apuser
CREATE INDEX IF NOT EXISTS [idx_apuser_apuser] ON [apuser] ([cliente], [ano], [mes]);

-- �ndice: idx_apuser_apuser-2
CREATE INDEX IF NOT EXISTS [idx_apuser_apuser-2] ON [apuser] ([ano], [mes], [cliente]);

-- �ndice: idx_cnab400r_cnab400r
CREATE INDEX IF NOT EXISTS [idx_cnab400r_cnab400r] ON [cnab400r] ([seqarq]);

-- �ndice: idx_dipam2_dipam2-1
CREATE INDEX IF NOT EXISTS [idx_dipam2_dipam2-1] ON [dipam2] ([valormer]);

-- �ndice: idx_dipam3_dipam3
CREATE INDEX IF NOT EXISTS [idx_dipam3_dipam3] ON [dipam3] ([valormer]);

-- �ndice: idx_dipam_dipam
CREATE INDEX IF NOT EXISTS [idx_dipam_dipam] ON [dipam] ([fornecedo], [classipi], [codigo]);

-- �ndice: idx_dipam_dipam-2
CREATE INDEX IF NOT EXISTS [idx_dipam_dipam-2] ON [dipam] ([valormer]);

-- �ndice: idx_dipam_dipam-3
CREATE INDEX IF NOT EXISTS [idx_dipam_dipam-3] ON [dipam] ([classipi], [nome]);

-- �ndice: idx_eti_eti
CREATE INDEX IF NOT EXISTS [idx_eti_eti] ON [eti] ([codigo]);

-- �ndice: idx_eti_eti-2
CREATE INDEX IF NOT EXISTS [idx_eti_eti-2] ON [eti] ([nome]);

-- �ndice: idx_fo_chis_fo_chi2
CREATE INDEX IF NOT EXISTS [idx_fo_chis_fo_chi2] ON [fo_chis] ([nome]);

-- �ndice: idx_fo_chis_fo_chis
CREATE INDEX IF NOT EXISTS [idx_fo_chis_fo_chis] ON [fo_chis] ([numero]);

-- �ndice: idx_ma01_ma01-1
CREATE INDEX IF NOT EXISTS [idx_ma01_ma01-1] ON [ma01] ([numero]);

-- �ndice: idx_ma01_ma01-2
CREATE INDEX IF NOT EXISTS [idx_ma01_ma01-2] ON [ma01] ([cognome]);

-- �ndice: idx_ma01_ma01-3
CREATE INDEX IF NOT EXISTS [idx_ma01_ma01-3] ON [ma01] ([nome]);

-- �ndice: idx_ma01_ma01-4
CREATE INDEX IF NOT EXISTS [idx_ma01_ma01-4] ON [ma01] ([cgc]);

-- �ndice: idx_ma01_ma01-5
CREATE INDEX IF NOT EXISTS [idx_ma01_ma01-5] ON [ma01] ([vendedor], [cognome]);

-- �ndice: idx_ma01_ma01-6
CREATE INDEX IF NOT EXISTS [idx_ma01_ma01-6] ON [ma01] ([sisco]);

-- �ndice: idx_ma01_ma01-7
CREATE INDEX IF NOT EXISTS [idx_ma01_ma01-7] ON [ma01] ([cnumero]);

-- �ndice: idx_ma01_ma01-8
CREATE INDEX IF NOT EXISTS [idx_ma01_ma01-8] ON [ma01] ([codigoint]);

-- �ndice: idx_manivers_maniver1
CREATE INDEX IF NOT EXISTS [idx_manivers_maniver1] ON [manivers] ([nome]);

-- �ndice: idx_manivers_maniver2
CREATE INDEX IF NOT EXISTS [idx_manivers_maniver2] ON [manivers] ([data], [data]);

-- �ndice: idx_mb01_mb01-1
CREATE INDEX IF NOT EXISTS [idx_mb01_mb01-1] ON [mb01] ([numero]);

-- �ndice: idx_mb01_mb01-2
CREATE INDEX IF NOT EXISTS [idx_mb01_mb01-2] ON [mb01] ([cognome]);

-- �ndice: idx_mb01_mb01-3
CREATE INDEX IF NOT EXISTS [idx_mb01_mb01-3] ON [mb01] ([cgc]);

-- �ndice: idx_mb01_mb01-4
CREATE INDEX IF NOT EXISTS [idx_mb01_mb01-4] ON [mb01] ([nome]);

-- �ndice: idx_mc01_mc01-1
CREATE INDEX IF NOT EXISTS [idx_mc01_mc01-1] ON [mc01] ([numero]);

-- �ndice: idx_mc02_mc02-1
CREATE INDEX IF NOT EXISTS [idx_mc02_mc02-1] ON [mc02] ([numero]);

-- �ndice: idx_mc03_mc03-1
CREATE INDEX IF NOT EXISTS [idx_mc03_mc03-1] ON [mc03] ([numero]);

-- �ndice: idx_mc04_mc04-1
CREATE INDEX IF NOT EXISTS [idx_mc04_mc04-1] ON [mc04] ([numero]);

-- �ndice: idx_mc05_mc05-1
CREATE INDEX IF NOT EXISTS [idx_mc05_mc05-1] ON [mc05] ([numero]);

-- �ndice: idx_md01_md01-1
CREATE INDEX IF NOT EXISTS [idx_md01_md01-1] ON [md01] ([codigo]);

-- �ndice: idx_md02_md02-1
CREATE INDEX IF NOT EXISTS [idx_md02_md02-1] ON [md02] ([codigo], [codigo1], [data]);

-- �ndice: idx_md02_md02-2
CREATE INDEX IF NOT EXISTS [idx_md02_md02-2] ON [md02] ([data]);

-- �ndice: idx_md02_md02-3
CREATE INDEX IF NOT EXISTS [idx_md02_md02-3] ON [md02] ([codigo]);

-- �ndice: idx_md02_md02-4
CREATE INDEX IF NOT EXISTS [idx_md02_md02-4] ON [md02] ([codigo], [data]);

-- �ndice: idx_md03_md03-1
CREATE INDEX IF NOT EXISTS [idx_md03_md03-1] ON [md03] ([codigo]);

-- �ndice: idx_md03_md03-2
CREATE INDEX IF NOT EXISTS [idx_md03_md03-2] ON [md03] ([classific]);

-- �ndice: idx_md03_md03-3
CREATE INDEX IF NOT EXISTS [idx_md03_md03-3] ON [md03] ([classific], [codigo]);

-- �ndice: idx_md06_md06-1
CREATE INDEX IF NOT EXISTS [idx_md06_md06-1] ON [md06] ([mes], [ano]);

-- �ndice: idx_md07_md07-1
CREATE INDEX IF NOT EXISTS [idx_md07_md07-1] ON [md07] ([unidade]);

-- �ndice: idx_md08_md08-1
CREATE INDEX IF NOT EXISTS [idx_md08_md08-1] ON [md08] ([sedext], [kilo]);

-- �ndice: idx_md09_md09-1
CREATE INDEX IF NOT EXISTS [idx_md09_md09-1] ON [md09] ([codigo]);

-- �ndice: idx_me01_me01-1
CREATE INDEX IF NOT EXISTS [idx_me01_me01-1] ON [me01] ([numero]);

-- �ndice: idx_me01_me01-2
CREATE INDEX IF NOT EXISTS [idx_me01_me01-2] ON [me01] ([nome], [modelo]);

-- �ndice: idx_me01_me01-3
CREATE INDEX IF NOT EXISTS [idx_me01_me01-3] ON [me01] ([codmp01], [numero]);

-- �ndice: idx_me01inv_me01inv
CREATE INDEX IF NOT EXISTS [idx_me01inv_me01inv] ON [me01inv] ([contabil]);

-- �ndice: idx_me02_me02-1
CREATE INDEX IF NOT EXISTS [idx_me02_me02-1] ON [me02] ([numero], [seq]);

-- �ndice: idx_me02_me02-2
CREATE INDEX IF NOT EXISTS [idx_me02_me02-2] ON [me02] ([codmp01], [seq]);

-- �ndice: idx_me03_me03-1
CREATE INDEX IF NOT EXISTS [idx_me03_me03-1] ON [me03] ([numero], [data]);

-- �ndice: idx_me03a_me03a-1
CREATE INDEX IF NOT EXISTS [idx_me03a_me03a-1] ON [me03a] ([numero], [data], [of]);

-- �ndice: idx_me05_me05-1
CREATE INDEX IF NOT EXISTS [idx_me05_me05-1] ON [me05] ([ddd], [numero]);

-- �ndice: idx_mf01_mf01-1
CREATE INDEX IF NOT EXISTS [idx_mf01_mf01-1] ON [mf01] ([numero], [digito]);

-- �ndice: idx_mf01_mf01-2
CREATE INDEX IF NOT EXISTS [idx_mf01_mf01-2] ON [mf01] ([cognome]);

-- �ndice: idx_mf01_mf01-3
CREATE INDEX IF NOT EXISTS [idx_mf01_mf01-3] ON [mf01] ([nome]);

-- �ndice: idx_mf02_mf02-1
CREATE INDEX IF NOT EXISTS [idx_mf02_mf02-1] ON [mf02] ([numero], [agencia], [conta]);

-- �ndice: idx_mf02_mf02-2
CREATE INDEX IF NOT EXISTS [idx_mf02_mf02-2] ON [mf02] ([nrconta]);

-- �ndice: idx_mf03_mf03-1
CREATE INDEX IF NOT EXISTS [idx_mf03_mf03-1] ON [mf03] ([numero], [agencia], [conta]);

-- �ndice: idx_mf04_mf04-1
CREATE INDEX IF NOT EXISTS [idx_mf04_mf04-1] ON [mf04] ([numero], [praca]);

-- �ndice: idx_mf05_mf05-1
CREATE INDEX IF NOT EXISTS [idx_mf05_mf05-1] ON [mf05] ([cartao]);

-- �ndice: idx_mf06_mf06-1
CREATE INDEX IF NOT EXISTS [idx_mf06_mf06-1] ON [mf06] ([conta]);

-- �ndice: idx_mg01_mg01-1
CREATE INDEX IF NOT EXISTS [idx_mg01_mg01-1] ON [mg01] ([numero]);

-- �ndice: idx_mg01_mg01-2
CREATE INDEX IF NOT EXISTS [idx_mg01_mg01-2] ON [mg01] ([cognome]);

-- �ndice: idx_mg01_mg01-3
CREATE INDEX IF NOT EXISTS [idx_mg01_mg01-3] ON [mg01] ([cgc]);

-- �ndice: idx_mg02_mg02-1
CREATE INDEX IF NOT EXISTS [idx_mg02_mg02-1] ON [mg02] ([numero], [codemp]);

-- �ndice: idx_mg03_mg03-1
CREATE INDEX IF NOT EXISTS [idx_mg03_mg03-1] ON [mg03] ([numero], [codfro]);

-- �ndice: idx_mg04_mg04-1
CREATE INDEX IF NOT EXISTS [idx_mg04_mg04-1] ON [mg04] ([nummarca], [modelo]);

-- �ndice: idx_mg05_mg05-1
CREATE INDEX IF NOT EXISTS [idx_mg05_mg05-1] ON [mg05] ([numero]);

-- �ndice: idx_mg05_mg05-2
CREATE INDEX IF NOT EXISTS [idx_mg05_mg05-2] ON [mg05] ([nome]);

-- �ndice: idx_mh01_mh01-1
CREATE INDEX IF NOT EXISTS [idx_mh01_mh01-1] ON [mh01] ([numero]);

-- �ndice: idx_mh01_mh01-2
CREATE INDEX IF NOT EXISTS [idx_mh01_mh01-2] ON [mh01] ([cognome]);

-- �ndice: idx_mh02_mh02-1
CREATE INDEX IF NOT EXISTS [idx_mh02_mh02-1] ON [mh02] ([numero]);

-- �ndice: idx_mh02_mh02-2
CREATE INDEX IF NOT EXISTS [idx_mh02_mh02-2] ON [mh02] ([cognome]);

-- �ndice: idx_mh03_mh03-1
CREATE INDEX IF NOT EXISTS [idx_mh03_mh03-1] ON [mh03] ([numero]);

-- �ndice: idx_mh03_mh03-2
CREATE INDEX IF NOT EXISTS [idx_mh03_mh03-2] ON [mh03] ([cognome]);

-- �ndice: idx_mi01_mi01-1
CREATE INDEX IF NOT EXISTS [idx_mi01_mi01-1] ON [mi01] ([conta]);

-- �ndice: idx_mi01_mi01-2
CREATE INDEX IF NOT EXISTS [idx_mi01_mi01-2] ON [mi01] ([numero]);

-- �ndice: idx_mi02_mi02-1
CREATE INDEX IF NOT EXISTS [idx_mi02_mi02-1] ON [mi02] ([codigo]);

-- �ndice: idx_mi03_mi03-1
CREATE INDEX IF NOT EXISTS [idx_mi03_mi03-1] ON [mi03] ([centro]);

-- �ndice: idx_mi04_mi04-1
CREATE INDEX IF NOT EXISTS [idx_mi04_mi04-1] ON [mi04] ([conta]);

-- �ndice: idx_mj01_mj01-1
CREATE INDEX IF NOT EXISTS [idx_mj01_mj01-1] ON [mj01] ([numero]);

-- �ndice: idx_mj01_mj01-2
CREATE INDEX IF NOT EXISTS [idx_mj01_mj01-2] ON [mj01] ([nome]);

-- �ndice: idx_mk01_mk01-1
CREATE INDEX IF NOT EXISTS [idx_mk01_mk01-1] ON [mk01] ([nrnota], [fornecedo]);

-- �ndice: idx_mk01_mk01-2
CREATE INDEX IF NOT EXISTS [idx_mk01_mk01-2] ON [mk01] ([fornecedo]);

-- �ndice: idx_mk01_mk01-3
CREATE INDEX IF NOT EXISTS [idx_mk01_mk01-3] ON [mk01] ([totnf]);

-- �ndice: idx_mk01_mk01-4
CREATE INDEX IF NOT EXISTS [idx_mk01_mk01-4] ON [mk01] ([cognome]);

-- �ndice: idx_mk01_mk01-5
CREATE INDEX IF NOT EXISTS [idx_mk01_mk01-5] ON [mk01] ([ordem]);

-- �ndice: idx_mk01_mk01-6
CREATE INDEX IF NOT EXISTS [idx_mk01_mk01-6] ON [mk01] ([operacao]);

-- �ndice: idx_mk02_mk02-1
CREATE INDEX IF NOT EXISTS [idx_mk02_mk02-1] ON [mk02] ([nrnota], [fornecedo], [codigo], [item]);

-- �ndice: idx_mk02_mk02-2
CREATE INDEX IF NOT EXISTS [idx_mk02_mk02-2] ON [mk02] ([fornecedo]);

-- �ndice: idx_mk02_mk02-3
CREATE INDEX IF NOT EXISTS [idx_mk02_mk02-3] ON [mk02] ([operacao], [classipi]);

-- �ndice: idx_mk02_mk02-4
CREATE INDEX IF NOT EXISTS [idx_mk02_mk02-4] ON [mk02] ([nrnota]);

-- �ndice: idx_mk02_mk02-5
CREATE INDEX IF NOT EXISTS [idx_mk02_mk02-5] ON [mk02] ([tipoent], [codigo]);

-- �ndice: idx_mk06_mk06-1
CREATE INDEX IF NOT EXISTS [idx_mk06_mk06-1] ON [mk06] ([ordem], [numero], [item]);

-- �ndice: idx_mk06_mk06-2
CREATE INDEX IF NOT EXISTS [idx_mk06_mk06-2] ON [mk06] ([dcfonew]);

-- �ndice: idx_mk06_mk06-3
CREATE INDEX IF NOT EXISTS [idx_mk06_mk06-3] ON [mk06] ([numero]);

-- �ndice: idx_mk06_mk06-4
CREATE INDEX IF NOT EXISTS [idx_mk06_mk06-4] ON [mk06] ([lote]);

-- �ndice: idx_mk06_mk06-5
CREATE INDEX IF NOT EXISTS [idx_mk06_mk06-5] ON [mk06] ([dvalornf]);

-- �ndice: idx_mk09_mk09-1
CREATE INDEX IF NOT EXISTS [idx_mk09_mk09-1] ON [mk09] ([numero], [fornecedo]);

-- �ndice: idx_mk09_mk09-2
CREATE INDEX IF NOT EXISTS [idx_mk09_mk09-2] ON [mk09] ([numero]);

-- �ndice: idx_mk09_mk09-3
CREATE INDEX IF NOT EXISTS [idx_mk09_mk09-3] ON [mk09] ([dvalornf]);

-- �ndice: idx_mk09_mk09-4
CREATE INDEX IF NOT EXISTS [idx_mk09_mk09-4] ON [mk09] ([lote]);

-- �ndice: idx_mk90_mk90-1
CREATE INDEX IF NOT EXISTS [idx_mk90_mk90-1] ON [mk90] ([numero], [fornecedo]);

-- �ndice: idx_mk90_mk90-2
CREATE INDEX IF NOT EXISTS [idx_mk90_mk90-2] ON [mk90] ([numero]);

-- �ndice: idx_mk90_mk90-3
CREATE INDEX IF NOT EXISTS [idx_mk90_mk90-3] ON [mk90] ([dvalornf]);

-- �ndice: idx_mk90_mk90-4
CREATE INDEX IF NOT EXISTS [idx_mk90_mk90-4] ON [mk90] ([lote]);

-- �ndice: idx_mk91_mk91-1
CREATE INDEX IF NOT EXISTS [idx_mk91_mk91-1] ON [mk91] ([nrnota], [fornecedo]);

-- �ndice: idx_mk91_mk91-2
CREATE INDEX IF NOT EXISTS [idx_mk91_mk91-2] ON [mk91] ([fornecedo]);

-- �ndice: idx_mk91_mk91-3
CREATE INDEX IF NOT EXISTS [idx_mk91_mk91-3] ON [mk91] ([totnf]);

-- �ndice: idx_mk91_mk91-4
CREATE INDEX IF NOT EXISTS [idx_mk91_mk91-4] ON [mk91] ([cognome]);

-- �ndice: idx_mk91_mk91-5
CREATE INDEX IF NOT EXISTS [idx_mk91_mk91-5] ON [mk91] ([ordem]);

-- �ndice: idx_mk92_mk92-1
CREATE INDEX IF NOT EXISTS [idx_mk92_mk92-1] ON [mk92] ([nrnota], [fornecedo], [codigo], [item]);

-- �ndice: idx_mk92_mk92-2
CREATE INDEX IF NOT EXISTS [idx_mk92_mk92-2] ON [mk92] ([fornecedo]);

-- �ndice: idx_mk92_mk92-3
CREATE INDEX IF NOT EXISTS [idx_mk92_mk92-3] ON [mk92] ([operacao], [classipi]);

-- �ndice: idx_mk92_mk92-4
CREATE INDEX IF NOT EXISTS [idx_mk92_mk92-4] ON [mk92] ([nrnota]);

-- �ndice: idx_mk96_mk96-1
CREATE INDEX IF NOT EXISTS [idx_mk96_mk96-1] ON [mk96] ([ordem], [numero], [item]);

-- �ndice: idx_mk96_mk96-2
CREATE INDEX IF NOT EXISTS [idx_mk96_mk96-2] ON [mk96] ([dcfonew]);

-- �ndice: idx_mk96_mk96-3
CREATE INDEX IF NOT EXISTS [idx_mk96_mk96-3] ON [mk96] ([numero]);

-- �ndice: idx_mk96_mk96-4
CREATE INDEX IF NOT EXISTS [idx_mk96_mk96-4] ON [mk96] ([lote]);

-- �ndice: idx_mk96_mk96-5
CREATE INDEX IF NOT EXISTS [idx_mk96_mk96-5] ON [mk96] ([dvalornf]);

-- �ndice: idx_ml01_ml01-1
CREATE INDEX IF NOT EXISTS [idx_ml01_ml01-1] ON [ml01] ([venciment], [nrnota], [tipfat]);

-- �ndice: idx_ml01_ml01-2
CREATE INDEX IF NOT EXISTS [idx_ml01_ml01-2] ON [ml01] ([docdup]);

-- �ndice: idx_ml01_ml01-3
CREATE INDEX IF NOT EXISTS [idx_ml01_ml01-3] ON [ml01] ([docbol]);

-- �ndice: idx_ml01_ml01-4
CREATE INDEX IF NOT EXISTS [idx_ml01_ml01-4] ON [ml01] ([nrnota]);

-- �ndice: idx_ml01_ml01-5
CREATE INDEX IF NOT EXISTS [idx_ml01_ml01-5] ON [ml01] ([valor]);

-- �ndice: idx_ml01_ml01-6
CREATE INDEX IF NOT EXISTS [idx_ml01_ml01-6] ON [ml01] ([data]);

-- �ndice: idx_ml01_ml01-7
CREATE INDEX IF NOT EXISTS [idx_ml01_ml01-7] ON [ml01] ([fornecedo]);

-- �ndice: idx_ml01pg_ml01pg-1
CREATE INDEX IF NOT EXISTS [idx_ml01pg_ml01pg-1] ON [ml01pg] ([venciment], [nrnota], [tipfat]);

-- �ndice: idx_ml01pg_ml01pg-2
CREATE INDEX IF NOT EXISTS [idx_ml01pg_ml01pg-2] ON [ml01pg] ([nrnota], [tipfat]);

-- �ndice: idx_ml01pg_ml01pg-3
CREATE INDEX IF NOT EXISTS [idx_ml01pg_ml01pg-3] ON [ml01pg] ([fornecedo]);

-- �ndice: idx_ml01pg_ml01pg-4
CREATE INDEX IF NOT EXISTS [idx_ml01pg_ml01pg-4] ON [ml01pg] ([banco], [datapg]);

-- �ndice: idx_ml01pg_ml01pg-5
CREATE INDEX IF NOT EXISTS [idx_ml01pg_ml01pg-5] ON [ml01pg] ([valor]);

-- �ndice: idx_ml02_ml02-1
CREATE INDEX IF NOT EXISTS [idx_ml02_ml02-1] ON [ml02] ([cliente], [ventip], [datent]);

-- �ndice: idx_ml03_ml03-1
CREATE INDEX IF NOT EXISTS [idx_ml03_ml03-1] ON [ml03] ([nrnota], [tipfat]);

-- �ndice: idx_ml03pg_ml03pg-1
CREATE INDEX IF NOT EXISTS [idx_ml03pg_ml03pg-1] ON [ml03pg] ([nrnota], [tipfat]);

-- �ndice: idx_ml91pg_ml91pg-1
CREATE INDEX IF NOT EXISTS [idx_ml91pg_ml91pg-1] ON [ml91pg] ([venciment], [nrnota], [tipfat]);

-- �ndice: idx_ml91pg_ml91pg-2
CREATE INDEX IF NOT EXISTS [idx_ml91pg_ml91pg-2] ON [ml91pg] ([nrnota], [tipfat]);

-- �ndice: idx_ml91pg_ml91pg-3
CREATE INDEX IF NOT EXISTS [idx_ml91pg_ml91pg-3] ON [ml91pg] ([fornecedo]);

-- �ndice: idx_ml91pg_ml91pg-4
CREATE INDEX IF NOT EXISTS [idx_ml91pg_ml91pg-4] ON [ml91pg] ([banco], [datapg]);

-- �ndice: idx_ml99_ml99-1
CREATE INDEX IF NOT EXISTS [idx_ml99_ml99-1] ON [ml99] ([venciment], [nrnota], [tipfat]);

-- �ndice: idx_ml99_ml99-2
CREATE INDEX IF NOT EXISTS [idx_ml99_ml99-2] ON [ml99] ([nrnota], [tipfat]);

-- �ndice: idx_ml99_ml99-3
CREATE INDEX IF NOT EXISTS [idx_ml99_ml99-3] ON [ml99] ([fornecedo]);

-- �ndice: idx_mm01_mm01-1
CREATE INDEX IF NOT EXISTS [idx_mm01_mm01-1] ON [mm01] ([numero]);

-- �ndice: idx_mm01_mm01-2
CREATE INDEX IF NOT EXISTS [idx_mm01_mm01-2] ON [mm01] ([fornecedo]);

-- �ndice: idx_mm01_mm01-3
CREATE INDEX IF NOT EXISTS [idx_mm01_mm01-3] ON [mm01] ([totnf]);

-- �ndice: idx_mm02_mm02-1
CREATE INDEX IF NOT EXISTS [idx_mm02_mm02-1] ON [mm02] ([numero], [seq]);

-- �ndice: idx_mm02_mm02-2
CREATE INDEX IF NOT EXISTS [idx_mm02_mm02-2] ON [mm02] ([fornecedo]);

-- �ndice: idx_mm02_mm02-3
CREATE INDEX IF NOT EXISTS [idx_mm02_mm02-3] ON [mm02] ([operacao], [classipi]);

-- �ndice: idx_mm02_mm02-4
CREATE INDEX IF NOT EXISTS [idx_mm02_mm02-4] ON [mm02] ([numero]);

-- �ndice: idx_mm02_mm02-5
CREATE INDEX IF NOT EXISTS [idx_mm02_mm02-5] ON [mm02] ([codigo]);

-- �ndice: idx_mm02l_mm02l-1
CREATE INDEX IF NOT EXISTS [idx_mm02l_mm02l-1] ON [mm02l] ([nummens]);

-- �ndice: idx_mm03_mm03-1
CREATE INDEX IF NOT EXISTS [idx_mm03_mm03-1] ON [mm03] ([nummens]);

-- �ndice: idx_mm04_mm04-1
CREATE INDEX IF NOT EXISTS [idx_mm04_mm04-1] ON [mm04] ([nummens]);

-- �ndice: idx_mm05_mm05-1
CREATE INDEX IF NOT EXISTS [idx_mm05_mm05-1] ON [mm05] ([operacao], [classipi]);

-- �ndice: idx_mm06_mm06-1
CREATE INDEX IF NOT EXISTS [idx_mm06_mm06-1] ON [mm06] ([ordem], [numero], [item]);

-- �ndice: idx_mm06_mm06-2
CREATE INDEX IF NOT EXISTS [idx_mm06_mm06-2] ON [mm06] ([dcfonew]);

-- �ndice: idx_mm06_mm06-3
CREATE INDEX IF NOT EXISTS [idx_mm06_mm06-3] ON [mm06] ([numero]);

-- �ndice: idx_mm06_mm06-4
CREATE INDEX IF NOT EXISTS [idx_mm06_mm06-4] ON [mm06] ([lote]);

-- �ndice: idx_mm06_mm06-5
CREATE INDEX IF NOT EXISTS [idx_mm06_mm06-5] ON [mm06] ([dvalornf]);

-- �ndice: idx_mm07_mm07-1
CREATE INDEX IF NOT EXISTS [idx_mm07_mm07-1] ON [mm07] ([reqdev]);

-- �ndice: idx_mm08_mm08-1
CREATE INDEX IF NOT EXISTS [idx_mm08_mm08-1] ON [mm08] ([tipoent], [codigo], [fornecedo]);

-- �ndice: idx_mm09_mm09-1
CREATE INDEX IF NOT EXISTS [idx_mm09_mm09-1] ON [mm09] ([numero], [fornecedo]);

-- �ndice: idx_mm09_mm09-2
CREATE INDEX IF NOT EXISTS [idx_mm09_mm09-2] ON [mm09] ([numero]);

-- �ndice: idx_mm09_mm09-3
CREATE INDEX IF NOT EXISTS [idx_mm09_mm09-3] ON [mm09] ([dvalornf]);

-- �ndice: idx_mm09_mm09-4
CREATE INDEX IF NOT EXISTS [idx_mm09_mm09-4] ON [mm09] ([lote]);

-- �ndice: idx_mm90_mm90-1
CREATE INDEX IF NOT EXISTS [idx_mm90_mm90-1] ON [mm90] ([numero], [fornecedo]);

-- �ndice: idx_mm90_mm90-2
CREATE INDEX IF NOT EXISTS [idx_mm90_mm90-2] ON [mm90] ([numero]);

-- �ndice: idx_mm90_mm90-3
CREATE INDEX IF NOT EXISTS [idx_mm90_mm90-3] ON [mm90] ([dvalornf]);

-- �ndice: idx_mm90_mm90-4
CREATE INDEX IF NOT EXISTS [idx_mm90_mm90-4] ON [mm90] ([lote]);

-- �ndice: idx_mm91_mm91-1
CREATE INDEX IF NOT EXISTS [idx_mm91_mm91-1] ON [mm91] ([numero]);

-- �ndice: idx_mm92_mm92-1
CREATE INDEX IF NOT EXISTS [idx_mm92_mm92-1] ON [mm92] ([numero], [seq]);

-- �ndice: idx_mm92_mm92-2
CREATE INDEX IF NOT EXISTS [idx_mm92_mm92-2] ON [mm92] ([fornecedo]);

-- �ndice: idx_mm92_mm92-3
CREATE INDEX IF NOT EXISTS [idx_mm92_mm92-3] ON [mm92] ([operacao], [classipi]);

-- �ndice: idx_mm92_mm92-4
CREATE INDEX IF NOT EXISTS [idx_mm92_mm92-4] ON [mm92] ([numero]);

-- �ndice: idx_mm92_mm92-5
CREATE INDEX IF NOT EXISTS [idx_mm92_mm92-5] ON [mm92] ([codigo]);

-- �ndice: idx_mm96_mm96-1
CREATE INDEX IF NOT EXISTS [idx_mm96_mm96-1] ON [mm96] ([ordem], [numero], [item]);

-- �ndice: idx_mm96_mm96-2
CREATE INDEX IF NOT EXISTS [idx_mm96_mm96-2] ON [mm96] ([dcfonew]);

-- �ndice: idx_mm96_mm96-3
CREATE INDEX IF NOT EXISTS [idx_mm96_mm96-3] ON [mm96] ([numero]);

-- �ndice: idx_mm96_mm96-4
CREATE INDEX IF NOT EXISTS [idx_mm96_mm96-4] ON [mm96] ([lote]);

-- �ndice: idx_mm96_mm96-5
CREATE INDEX IF NOT EXISTS [idx_mm96_mm96-5] ON [mm96] ([dvalornf]);

-- �ndice: idx_mn01_mn01-1
CREATE INDEX IF NOT EXISTS [idx_mn01_mn01-1] ON [mn01] ([venciment], [numero], [tipfat]);

-- �ndice: idx_mn01_mn01-2
CREATE INDEX IF NOT EXISTS [idx_mn01_mn01-2] ON [mn01] ([docdup]);

-- �ndice: idx_mn01_mn01-3
CREATE INDEX IF NOT EXISTS [idx_mn01_mn01-3] ON [mn01] ([docbol]);

-- �ndice: idx_mn01_mn01-4
CREATE INDEX IF NOT EXISTS [idx_mn01_mn01-4] ON [mn01] ([numero]);

-- �ndice: idx_mn01_mn01-5
CREATE INDEX IF NOT EXISTS [idx_mn01_mn01-5] ON [mn01] ([fornecedo]);

-- �ndice: idx_mn01_mn01-6
CREATE INDEX IF NOT EXISTS [idx_mn01_mn01-6] ON [mn01] ([valor]);

-- �ndice: idx_mn01pg_mn01pg-1
CREATE INDEX IF NOT EXISTS [idx_mn01pg_mn01pg-1] ON [mn01pg] ([venciment], [numero], [tipfat]);

-- �ndice: idx_mn01pg_mn01pg-2
CREATE INDEX IF NOT EXISTS [idx_mn01pg_mn01pg-2] ON [mn01pg] ([datapg], [numero], [tipfat]);

-- �ndice: idx_mn01pg_mn01pg-3
CREATE INDEX IF NOT EXISTS [idx_mn01pg_mn01pg-3] ON [mn01pg] ([fornecedo], [numero]);

-- �ndice: idx_mn01pg_mn01pg-4
CREATE INDEX IF NOT EXISTS [idx_mn01pg_mn01pg-4] ON [mn01pg] ([banco], [datapg]);

-- �ndice: idx_mn01pg_mn01pg-5
CREATE INDEX IF NOT EXISTS [idx_mn01pg_mn01pg-5] ON [mn01pg] ([numero]);

-- �ndice: idx_mn03_mn03-1
CREATE INDEX IF NOT EXISTS [idx_mn03_mn03-1] ON [mn03] ([nrnota], [tipfat]);

-- �ndice: idx_mn03pg_mn03pg-1
CREATE INDEX IF NOT EXISTS [idx_mn03pg_mn03pg-1] ON [mn03pg] ([nrnota], [tipfat]);

-- �ndice: idx_mn99_mn99-1
CREATE INDEX IF NOT EXISTS [idx_mn99_mn99-1] ON [mn99] ([venciment], [numero], [tipfat]);

-- �ndice: idx_mn99_mn99-2
CREATE INDEX IF NOT EXISTS [idx_mn99_mn99-2] ON [mn99] ([datapg], [numero], [tipfat]);

-- �ndice: idx_mn99_mn99-3
CREATE INDEX IF NOT EXISTS [idx_mn99_mn99-3] ON [mn99] ([fornecedo], [numero]);

-- �ndice: idx_mn99_mn99-4
CREATE INDEX IF NOT EXISTS [idx_mn99_mn99-4] ON [mn99] ([banco], [datapg]);

-- �ndice: idx_mo01_mo01-1
CREATE INDEX IF NOT EXISTS [idx_mo01_mo01-1] ON [mo01] ([pedido]);

-- �ndice: idx_mo01_mo01-2
CREATE INDEX IF NOT EXISTS [idx_mo01_mo01-2] ON [mo01] ([fornecedo], [entrega], [pedidocli]);

-- �ndice: idx_mo01bx_mo01bx-1
CREATE INDEX IF NOT EXISTS [idx_mo01bx_mo01bx-1] ON [mo01bx] ([pedido]);

-- �ndice: idx_mo02_mo02-1
CREATE INDEX IF NOT EXISTS [idx_mo02_mo02-1] ON [mo02] ([pedido], [item]);

-- �ndice: idx_mo02_mo02-2
CREATE INDEX IF NOT EXISTS [idx_mo02_mo02-2] ON [mo02] ([cognome], [codigo], [entrega], [horaprg]);

-- �ndice: idx_mo02_mo02-3
CREATE INDEX IF NOT EXISTS [idx_mo02_mo02-3] ON [mo02] ([codigo]);

-- �ndice: idx_mo02_mo02-4
CREATE INDEX IF NOT EXISTS [idx_mo02_mo02-4] ON [mo02] ([pedido]);

-- �ndice: idx_mo02_mo02-5
CREATE INDEX IF NOT EXISTS [idx_mo02_mo02-5] ON [mo02] ([fornecedo], [codigo], [entrega], [horaprg]);

-- �ndice: idx_mo02_mo02-6
CREATE INDEX IF NOT EXISTS [idx_mo02_mo02-6] ON [mo02] ([codigo], [lista], [compra]);

-- �ndice: idx_mo02bx_mo02bx-1
CREATE INDEX IF NOT EXISTS [idx_mo02bx_mo02bx-1] ON [mo02bx] ([pedido], [item]);

-- �ndice: idx_mo02x_mo02x-1
CREATE INDEX IF NOT EXISTS [idx_mo02x_mo02x-1] ON [mo02x] ([pedido], [item]);

-- �ndice: idx_mofp_mofp-1
CREATE INDEX IF NOT EXISTS [idx_mofp_mofp-1] ON [mofp] ([fp]);

-- �ndice: idx_mofp_mofp-2
CREATE INDEX IF NOT EXISTS [idx_mofp_mofp-2] ON [mofp] ([codigo], [seq], [ssq]);

-- �ndice: idx_mofp_mofp-3
CREATE INDEX IF NOT EXISTS [idx_mofp_mofp-3] ON [mofp] ([me01cod]);

-- �ndice: idx_mosb01_mosb01-1
CREATE INDEX IF NOT EXISTS [idx_mosb01_mosb01-1] ON [mosb01] ([numero]);

-- �ndice: idx_mosb02_mosb02-1
CREATE INDEX IF NOT EXISTS [idx_mosb02_mosb02-1] ON [mosb02] ([numero], [seq]);

-- �ndice: idx_mosb02_mosb02-2
CREATE INDEX IF NOT EXISTS [idx_mosb02_mosb02-2] ON [mosb02] ([numero], [tipoent]);

-- �ndice: idx_mp01_mp01-1
CREATE INDEX IF NOT EXISTS [idx_mp01_mp01-1] ON [mp01] ([codigo]);

-- �ndice: idx_mp01_mp01-2
CREATE INDEX IF NOT EXISTS [idx_mp01_mp01-2] ON [mp01] ([nome]);

-- �ndice: idx_mp01_mp01-3
CREATE INDEX IF NOT EXISTS [idx_mp01_mp01-3] ON [mp01] ([codfolha]);

-- �ndice: idx_mp01a_mp01a-1
CREATE INDEX IF NOT EXISTS [idx_mp01a_mp01a-1] ON [mp01a] ([codigo], [seq]);

-- �ndice: idx_mp01a_mp01a-2
CREATE INDEX IF NOT EXISTS [idx_mp01a_mp01a-2] ON [mp01a] ([codmpsb], [seq]);

-- �ndice: idx_mp02_mp02-1
CREATE INDEX IF NOT EXISTS [idx_mp02_mp02-1] ON [mp02] ([codigo]);

-- �ndice: idx_mp02_mp02-2
CREATE INDEX IF NOT EXISTS [idx_mp02_mp02-2] ON [mp02] ([nome]);

-- �ndice: idx_mp02_mp02-3
CREATE INDEX IF NOT EXISTS [idx_mp02_mp02-3] ON [mp02] ([codfolha]);

-- �ndice: idx_mp02a_mp02a-1
CREATE INDEX IF NOT EXISTS [idx_mp02a_mp02a-1] ON [mp02a] ([codigo], [seq]);

-- �ndice: idx_mp02a_mp02a-2
CREATE INDEX IF NOT EXISTS [idx_mp02a_mp02a-2] ON [mp02a] ([codmpsb], [seq]);

-- �ndice: idx_mp02tal_chave
CREATE INDEX IF NOT EXISTS [idx_mp02tal_chave] ON [mp02tal] ([codigo], [curso], [numfun]);

-- �ndice: idx_mp03_mp03-1
CREATE INDEX IF NOT EXISTS [idx_mp03_mp03-1] ON [mp03] ([codigo]);

-- �ndice: idx_mp03_mp03-2
CREATE INDEX IF NOT EXISTS [idx_mp03_mp03-2] ON [mp03] ([nome]);

-- �ndice: idx_mp03_mp03-3
CREATE INDEX IF NOT EXISTS [idx_mp03_mp03-3] ON [mp03] ([codigoint]);

-- �ndice: idx_mp03a_mp03a-1
CREATE INDEX IF NOT EXISTS [idx_mp03a_mp03a-1] ON [mp03a] ([codigo], [seq]);

-- �ndice: idx_mp03a_mp03a-2
CREATE INDEX IF NOT EXISTS [idx_mp03a_mp03a-2] ON [mp03a] ([codmpsb], [seq]);

-- �ndice: idx_mp03x_mp03x-1
CREATE INDEX IF NOT EXISTS [idx_mp03x_mp03x-1] ON [mp03x] ([codigo]);

-- �ndice: idx_mp03x_mp03x-2
CREATE INDEX IF NOT EXISTS [idx_mp03x_mp03x-2] ON [mp03x] ([nome]);

-- �ndice: idx_mp03x_mp03x-3
CREATE INDEX IF NOT EXISTS [idx_mp03x_mp03x-3] ON [mp03x] ([codigoint]);

-- �ndice: idx_mp04_mp04-1
CREATE INDEX IF NOT EXISTS [idx_mp04_mp04-1] ON [mp04] ([tecnico]);

-- �ndice: idx_mp04_mp04-2
CREATE INDEX IF NOT EXISTS [idx_mp04_mp04-2] ON [mp04] ([nomtec]);

-- �ndice: idx_mp04_mp04-3
CREATE INDEX IF NOT EXISTS [idx_mp04_mp04-3] ON [mp04] ([cnumero]);

-- �ndice: idx_mp04_mp04-4
CREATE INDEX IF NOT EXISTS [idx_mp04_mp04-4] ON [mp04] ([tabtec]);

-- �ndice: idx_mp04a_curso
CREATE INDEX IF NOT EXISTS [idx_mp04a_curso] ON [mp04a] ([curso]);

-- �ndice: idx_mp04a_tecnico
CREATE INDEX IF NOT EXISTS [idx_mp04a_tecnico] ON [mp04a] ([tecnico]);

-- �ndice: idx_mp04c_curso
CREATE INDEX IF NOT EXISTS [idx_mp04c_curso] ON [mp04c] ([curso]);

-- �ndice: idx_mp04c_tecnico
CREATE INDEX IF NOT EXISTS [idx_mp04c_tecnico] ON [mp04c] ([tecnico]);

-- �ndice: idx_mp05_mp05-1
CREATE INDEX IF NOT EXISTS [idx_mp05_mp05-1] ON [mp05] ([codigo]);

-- �ndice: idx_mp07_mp07-1
CREATE INDEX IF NOT EXISTS [idx_mp07_mp07-1] ON [mp07] ([armario]);

-- �ndice: idx_mp07_mp07-2
CREATE INDEX IF NOT EXISTS [idx_mp07_mp07-2] ON [mp07] ([numero]);

-- �ndice: idx_mp08_mp08-1
CREATE INDEX IF NOT EXISTS [idx_mp08_mp08-1] ON [mp08] ([numero]);

-- �ndice: idx_mp08_mp08-2
CREATE INDEX IF NOT EXISTS [idx_mp08_mp08-2] ON [mp08] ([nummp04]);

-- �ndice: idx_mp08_mp08-3
CREATE INDEX IF NOT EXISTS [idx_mp08_mp08-3] ON [mp08] ([prazo]);

-- �ndice: idx_mp91_mp91-1
CREATE INDEX IF NOT EXISTS [idx_mp91_mp91-1] ON [mp91] ([arquivo], [documento]);

-- �ndice: idx_mp91_mp91-2
CREATE INDEX IF NOT EXISTS [idx_mp91_mp91-2] ON [mp91] ([codigo], [data]);

-- �ndice: idx_mp92_mp92-1
CREATE INDEX IF NOT EXISTS [idx_mp92_mp92-1] ON [mp92] ([arquivo], [documento]);

-- �ndice: idx_mp92_mp92-2
CREATE INDEX IF NOT EXISTS [idx_mp92_mp92-2] ON [mp92] ([codigo], [data]);

-- �ndice: idx_mp93_mp93-1
CREATE INDEX IF NOT EXISTS [idx_mp93_mp93-1] ON [mp93] ([arquivo], [documento]);

-- �ndice: idx_mp93_mp93-2
CREATE INDEX IF NOT EXISTS [idx_mp93_mp93-2] ON [mp93] ([codigo], [data]);

-- �ndice: idx_mq01_mq01-1
CREATE INDEX IF NOT EXISTS [idx_mq01_mq01-1] ON [mq01] ([codigo]);

-- �ndice: idx_mq01_mq01-2
CREATE INDEX IF NOT EXISTS [idx_mq01_mq01-2] ON [mq01] ([nome]);

-- �ndice: idx_mq01x_mq01x-1
CREATE INDEX IF NOT EXISTS [idx_mq01x_mq01x-1] ON [mq01x] ([codigo]);

-- �ndice: idx_mq01x_mq01x-2
CREATE INDEX IF NOT EXISTS [idx_mq01x_mq01x-2] ON [mq01x] ([nome]);

-- �ndice: idx_mq01x_mq01x-3
CREATE INDEX IF NOT EXISTS [idx_mq01x_mq01x-3] ON [mq01x] ([codigoint]);

-- �ndice: idx_mq02_mq02-1
CREATE INDEX IF NOT EXISTS [idx_mq02_mq02-1] ON [mq02] ([codigo], [cotforn]);

-- �ndice: idx_mq03_mq03-1
CREATE INDEX IF NOT EXISTS [idx_mq03_mq03-1] ON [mq03] ([codigo], [nrnotaini], [digctr]);

-- �ndice: idx_mq03_mq03-2
CREATE INDEX IF NOT EXISTS [idx_mq03_mq03-2] ON [mq03] ([nrnotaini], [codigo]);

-- �ndice: idx_mq03_mq03-3
CREATE INDEX IF NOT EXISTS [idx_mq03_mq03-3] ON [mq03] ([cliente], [codigo]);

-- �ndice: idx_mq03_mq03-4
CREATE INDEX IF NOT EXISTS [idx_mq03_mq03-4] ON [mq03] ([cliente]);

-- �ndice: idx_mq03bx_mq03bx-1
CREATE INDEX IF NOT EXISTS [idx_mq03bx_mq03bx-1] ON [mq03bx] ([codigo], [nrnotaini], [digctr]);

-- �ndice: idx_mq03bx_mq03bx-2
CREATE INDEX IF NOT EXISTS [idx_mq03bx_mq03bx-2] ON [mq03bx] ([nrnotaini], [codigo]);

-- �ndice: idx_mq03bx_mq03bx-3
CREATE INDEX IF NOT EXISTS [idx_mq03bx_mq03bx-3] ON [mq03bx] ([nrnotaini]);

-- �ndice: idx_mq03bx_mq03bx-4
CREATE INDEX IF NOT EXISTS [idx_mq03bx_mq03bx-4] ON [mq03bx] ([cliente]);

-- �ndice: idx_mq04_mq04-1
CREATE INDEX IF NOT EXISTS [idx_mq04_mq04-1] ON [mq04] ([codigo], [seq]);

-- �ndice: idx_mq99_mq99-1
CREATE INDEX IF NOT EXISTS [idx_mq99_mq99-1] ON [mq99] ([arquivo], [documento]);

-- �ndice: idx_mq99_mq99-2
CREATE INDEX IF NOT EXISTS [idx_mq99_mq99-2] ON [mq99] ([codigo], [data]);

-- �ndice: idx_mr01_mr01-1
CREATE INDEX IF NOT EXISTS [idx_mr01_mr01-1] ON [mr01] ([codigo]);

-- �ndice: idx_mr01_mr01-2
CREATE INDEX IF NOT EXISTS [idx_mr01_mr01-2] ON [mr01] ([nome]);

-- �ndice: idx_mr02_mr02-1
CREATE INDEX IF NOT EXISTS [idx_mr02_mr02-1] ON [mr02] ([codigo], [cotforn]);

-- �ndice: idx_mr03_mr03-1
CREATE INDEX IF NOT EXISTS [idx_mr03_mr03-1] ON [mr03] ([codigo], [nrnotaini], [digctr]);

-- �ndice: idx_mr03_mr03-2
CREATE INDEX IF NOT EXISTS [idx_mr03_mr03-2] ON [mr03] ([nrnotaini], [codigo]);

-- �ndice: idx_mr03_mr03-3
CREATE INDEX IF NOT EXISTS [idx_mr03_mr03-3] ON [mr03] ([cliente], [codigo]);

-- �ndice: idx_mr03_mr03-4
CREATE INDEX IF NOT EXISTS [idx_mr03_mr03-4] ON [mr03] ([cliente]);

-- �ndice: idx_mr03bx_mr03bx-1
CREATE INDEX IF NOT EXISTS [idx_mr03bx_mr03bx-1] ON [mr03bx] ([codigo], [nrnotaini], [digctr]);

-- �ndice: idx_mr03bx_mr03bx-2
CREATE INDEX IF NOT EXISTS [idx_mr03bx_mr03bx-2] ON [mr03bx] ([nrnotaini], [codigo]);

-- �ndice: idx_mr03bx_mr03bx-3
CREATE INDEX IF NOT EXISTS [idx_mr03bx_mr03bx-3] ON [mr03bx] ([nrnotaini]);

-- �ndice: idx_mr03bx_mr03bx-4
CREATE INDEX IF NOT EXISTS [idx_mr03bx_mr03bx-4] ON [mr03bx] ([cliente]);

-- �ndice: idx_mr04_mr04-1
CREATE INDEX IF NOT EXISTS [idx_mr04_mr04-1] ON [mr04] ([codigo], [seq]);

-- �ndice: idx_mr99_mr99-1
CREATE INDEX IF NOT EXISTS [idx_mr99_mr99-1] ON [mr99] ([arquivo], [documento]);

-- �ndice: idx_mr99_mr99-2
CREATE INDEX IF NOT EXISTS [idx_mr99_mr99-2] ON [mr99] ([codigo], [data]);

-- �ndice: idx_mrms_mrms-1
CREATE INDEX IF NOT EXISTS [idx_mrms_mrms-1] ON [mrms] ([codms01], [codma01]);

-- �ndice: idx_ms01_ms01-1
CREATE INDEX IF NOT EXISTS [idx_ms01_ms01-1] ON [ms01] ([codigo], [fornecedo], [compra]);

-- �ndice: idx_ms01_ms01-2
CREATE INDEX IF NOT EXISTS [idx_ms01_ms01-2] ON [ms01] ([codigo]);

-- �ndice: idx_ms01_ms01-3
CREATE INDEX IF NOT EXISTS [idx_ms01_ms01-3] ON [ms01] ([codigoint]);

-- �ndice: idx_ms01_ms01-4
CREATE INDEX IF NOT EXISTS [idx_ms01_ms01-4] ON [ms01] ([fornecedo], [codigo]);

-- �ndice: idx_ms01_ms01-5
CREATE INDEX IF NOT EXISTS [idx_ms01_ms01-5] ON [ms01] ([fornecedo]);

-- �ndice: idx_ms01p_ms01p-1
CREATE INDEX IF NOT EXISTS [idx_ms01p_ms01p-1] ON [ms01p] ([codigo], [fornecedo]);

-- �ndice: idx_ms01x_ms01x-1
CREATE INDEX IF NOT EXISTS [idx_ms01x_ms01x-1] ON [ms01x] ([codigo]);

-- �ndice: idx_ms01x_ms01x-2
CREATE INDEX IF NOT EXISTS [idx_ms01x_ms01x-2] ON [ms01x] ([nome]);

-- �ndice: idx_ms01x_ms01x-3
CREATE INDEX IF NOT EXISTS [idx_ms01x_ms01x-3] ON [ms01x] ([codigoint]);

-- �ndice: idx_ms02_ms02-1
CREATE INDEX IF NOT EXISTS [idx_ms02_ms02-1] ON [ms02] ([codigo], [fornecedo], [compra], [data]);

-- �ndice: idx_ms02_ms02-2
CREATE INDEX IF NOT EXISTS [idx_ms02_ms02-2] ON [ms02] ([codigo], [fornecedo]);

-- �ndice: idx_ms02_ms02-3
CREATE INDEX IF NOT EXISTS [idx_ms02_ms02-3] ON [ms02] ([codigo]);

-- �ndice: idx_ms02_ms02-4
CREATE INDEX IF NOT EXISTS [idx_ms02_ms02-4] ON [ms02] ([codigo], [data], [data], [data]);

-- �ndice: idx_ms02_ms02-5
CREATE INDEX IF NOT EXISTS [idx_ms02_ms02-5] ON [ms02] ([codigo], [fornecedo], [data]);

-- �ndice: idx_ms03_ms03-1
CREATE INDEX IF NOT EXISTS [idx_ms03_ms03-1] ON [ms03] ([codigo], [tipoent], [codcomp], [bseq], [bssq]);

-- �ndice: idx_ms03_ms03-2
CREATE INDEX IF NOT EXISTS [idx_ms03_ms03-2] ON [ms03] ([codigo], [bseq], [bssq]);

-- �ndice: idx_ms03_ms03-3
CREATE INDEX IF NOT EXISTS [idx_ms03_ms03-3] ON [ms03] ([codcomp]);

-- �ndice: idx_ms03_ms03-4
CREATE INDEX IF NOT EXISTS [idx_ms03_ms03-4] ON [ms03] ([codigo]);

-- �ndice: idx_ms04_ms04-1
CREATE INDEX IF NOT EXISTS [idx_ms04_ms04-1] ON [ms04] ([codigo], [nrnotaini], [digctr]);

-- �ndice: idx_ms04_ms04-2
CREATE INDEX IF NOT EXISTS [idx_ms04_ms04-2] ON [ms04] ([nrnotaini], [codigo]);

-- �ndice: idx_ms04_ms04-3
CREATE INDEX IF NOT EXISTS [idx_ms04_ms04-3] ON [ms04] ([nrnotaini]);

-- �ndice: idx_ms04_ms04-4
CREATE INDEX IF NOT EXISTS [idx_ms04_ms04-4] ON [ms04] ([cliente]);

-- �ndice: idx_ms04bx_ms04bx-1
CREATE INDEX IF NOT EXISTS [idx_ms04bx_ms04bx-1] ON [ms04bx] ([codigo], [nrnotaini], [digctr]);

-- �ndice: idx_ms04bx_ms04bx-2
CREATE INDEX IF NOT EXISTS [idx_ms04bx_ms04bx-2] ON [ms04bx] ([nrnotaini], [codigo]);

-- �ndice: idx_ms04bx_ms04bx-3
CREATE INDEX IF NOT EXISTS [idx_ms04bx_ms04bx-3] ON [ms04bx] ([nrnotaini]);

-- �ndice: idx_ms04bx_ms04bx-4
CREATE INDEX IF NOT EXISTS [idx_ms04bx_ms04bx-4] ON [ms04bx] ([cliente]);

-- �ndice: idx_ms06_ms06-1
CREATE INDEX IF NOT EXISTS [idx_ms06_ms06-1] ON [ms06] ([codigo], [seq], [ssq]);

-- �ndice: idx_ms06_ms06-2
CREATE INDEX IF NOT EXISTS [idx_ms06_ms06-2] ON [ms06] ([codigo]);

-- �ndice: idx_ms06_ms06-3
CREATE INDEX IF NOT EXISTS [idx_ms06_ms06-3] ON [ms06] ([ferramen]);

-- �ndice: idx_ms06_ms06-4
CREATE INDEX IF NOT EXISTS [idx_ms06_ms06-4] ON [ms06] ([codigo], [tipfec]);

-- �ndice: idx_ms06_ms06-5
CREATE INDEX IF NOT EXISTS [idx_ms06_ms06-5] ON [ms06] ([pf], [seq], [ssq]);

-- �ndice: idx_ms06_ms06-6
CREATE INDEX IF NOT EXISTS [idx_ms06_ms06-6] ON [ms06] ([codint]);

-- �ndice: idx_ms06bx_ms06bx-1
CREATE INDEX IF NOT EXISTS [idx_ms06bx_ms06bx-1] ON [ms06bx] ([codigo], [seq], [ssq]);

-- �ndice: idx_ms06bx_ms06bx-2
CREATE INDEX IF NOT EXISTS [idx_ms06bx_ms06bx-2] ON [ms06bx] ([codigo]);

-- �ndice: idx_ms06bx_ms06bx-3
CREATE INDEX IF NOT EXISTS [idx_ms06bx_ms06bx-3] ON [ms06bx] ([ferramen]);

-- �ndice: idx_ms06bx_ms06bx-4
CREATE INDEX IF NOT EXISTS [idx_ms06bx_ms06bx-4] ON [ms06bx] ([codigo], [tipfec]);

-- �ndice: idx_ms06bx_ms06bx-5
CREATE INDEX IF NOT EXISTS [idx_ms06bx_ms06bx-5] ON [ms06bx] ([pf], [seq], [ssq]);

-- �ndice: idx_ms06req_ms06req1
CREATE INDEX IF NOT EXISTS [idx_ms06req_ms06req1] ON [ms06req] ([numero]);

-- �ndice: idx_ms06req_ms06req2
CREATE INDEX IF NOT EXISTS [idx_ms06req_ms06req2] ON [ms06req] ([codigo], [seq], [ssq]);

-- �ndice: idx_ms07_ms07-1
CREATE INDEX IF NOT EXISTS [idx_ms07_ms07-1] ON [ms07] ([codigo], [nrnotaini], [digctr]);

-- �ndice: idx_ms07_ms07-2
CREATE INDEX IF NOT EXISTS [idx_ms07_ms07-2] ON [ms07] ([nrnotaini], [codigo]);

-- �ndice: idx_ms07_ms07-3
CREATE INDEX IF NOT EXISTS [idx_ms07_ms07-3] ON [ms07] ([nrnotaini]);

-- �ndice: idx_ms07_ms07-4
CREATE INDEX IF NOT EXISTS [idx_ms07_ms07-4] ON [ms07] ([cliente]);

-- �ndice: idx_ms07bx_ms07bx-1
CREATE INDEX IF NOT EXISTS [idx_ms07bx_ms07bx-1] ON [ms07bx] ([codigo], [nrnotaini], [digctr]);

-- �ndice: idx_ms07bx_ms07bx-2
CREATE INDEX IF NOT EXISTS [idx_ms07bx_ms07bx-2] ON [ms07bx] ([nrnotaini], [codigo]);

-- �ndice: idx_ms07bx_ms07bx-3
CREATE INDEX IF NOT EXISTS [idx_ms07bx_ms07bx-3] ON [ms07bx] ([nrnotaini]);

-- �ndice: idx_ms07bx_ms07bx-4
CREATE INDEX IF NOT EXISTS [idx_ms07bx_ms07bx-4] ON [ms07bx] ([cliente]);

-- �ndice: idx_ms96_ms96-1
CREATE INDEX IF NOT EXISTS [idx_ms96_ms96-1] ON [ms96] ([arquivo], [documento]);

-- �ndice: idx_ms96_ms96-2
CREATE INDEX IF NOT EXISTS [idx_ms96_ms96-2] ON [ms96] ([codigo], [seq], [ssq], [data]);

-- �ndice: idx_ms99_ms99-1
CREATE INDEX IF NOT EXISTS [idx_ms99_ms99-1] ON [ms99] ([arquivo], [documento]);

-- �ndice: idx_ms99_ms99-2
CREATE INDEX IF NOT EXISTS [idx_ms99_ms99-2] ON [ms99] ([codigo], [data]);

-- �ndice: idx_msbai_msbai
CREATE INDEX IF NOT EXISTS [idx_msbai_msbai] ON [msbai] ([origem], [planta]);

-- �ndice: idx_msinv_msinv-1
CREATE INDEX IF NOT EXISTS [idx_msinv_msinv-1] ON [msinv] ([cliente], [ano], [mes]);

-- �ndice: idx_msop_msop-1
CREATE INDEX IF NOT EXISTS [idx_msop_msop-1] ON [msop] ([codigo], [local], [op]);

-- �ndice: idx_mt01_mt01-1
CREATE INDEX IF NOT EXISTS [idx_mt01_mt01-1] ON [mt01] ([codigo]);

-- �ndice: idx_mt01_mt01-2
CREATE INDEX IF NOT EXISTS [idx_mt01_mt01-2] ON [mt01] ([nome]);

-- �ndice: idx_mt01_mt01-3
CREATE INDEX IF NOT EXISTS [idx_mt01_mt01-3] ON [mt01] ([dimx], [dimy], [dimz]);

-- �ndice: idx_mt02_mt02-1
CREATE INDEX IF NOT EXISTS [idx_mt02_mt02-1] ON [mt02] ([codigo], [cotforn]);

-- �ndice: idx_mt03_mt03-1
CREATE INDEX IF NOT EXISTS [idx_mt03_mt03-1] ON [mt03] ([codigo], [nrnotaini], [digctr]);

-- �ndice: idx_mt03_mt03-2
CREATE INDEX IF NOT EXISTS [idx_mt03_mt03-2] ON [mt03] ([nrnotaini], [codigo]);

-- �ndice: idx_mt03_mt03-3
CREATE INDEX IF NOT EXISTS [idx_mt03_mt03-3] ON [mt03] ([nrnotaini]);

-- �ndice: idx_mt03_mt03-4
CREATE INDEX IF NOT EXISTS [idx_mt03_mt03-4] ON [mt03] ([cliente]);

-- �ndice: idx_mt03bx_mt03bx-1
CREATE INDEX IF NOT EXISTS [idx_mt03bx_mt03bx-1] ON [mt03bx] ([codigo], [nrnotaini], [digctr]);

-- �ndice: idx_mt03bx_mt03bx-2
CREATE INDEX IF NOT EXISTS [idx_mt03bx_mt03bx-2] ON [mt03bx] ([nrnotaini], [codigo]);

-- �ndice: idx_mt03bx_mt03bx-3
CREATE INDEX IF NOT EXISTS [idx_mt03bx_mt03bx-3] ON [mt03bx] ([nrnotaini]);

-- �ndice: idx_mt03bx_mt03bx-4
CREATE INDEX IF NOT EXISTS [idx_mt03bx_mt03bx-4] ON [mt03bx] ([cliente], [nrnotaini]);

-- �ndice: idx_mt04_mt04-1
CREATE INDEX IF NOT EXISTS [idx_mt04_mt04-1] ON [mt04] ([codigo], [seq]);

-- �ndice: idx_mt99_mt99-1
CREATE INDEX IF NOT EXISTS [idx_mt99_mt99-1] ON [mt99] ([arquivo], [documento]);

-- �ndice: idx_mt99_mt99-2
CREATE INDEX IF NOT EXISTS [idx_mt99_mt99-2] ON [mt99] ([codigo], [data]);

-- �ndice: idx_mu01_mu01-1
CREATE INDEX IF NOT EXISTS [idx_mu01_mu01-1] ON [mu01] ([codigo]);

-- �ndice: idx_mu01_mu01-2
CREATE INDEX IF NOT EXISTS [idx_mu01_mu01-2] ON [mu01] ([nome]);

-- �ndice: idx_mu01_mu01-3
CREATE INDEX IF NOT EXISTS [idx_mu01_mu01-3] ON [mu01] ([dimx], [dimy], [dimz]);

-- �ndice: idx_mu02_mu02-1
CREATE INDEX IF NOT EXISTS [idx_mu02_mu02-1] ON [mu02] ([codigo], [cotforn]);

-- �ndice: idx_mu03_mu03-1
CREATE INDEX IF NOT EXISTS [idx_mu03_mu03-1] ON [mu03] ([codigo], [nrnotaini], [digctr]);

-- �ndice: idx_mu03_mu03-2
CREATE INDEX IF NOT EXISTS [idx_mu03_mu03-2] ON [mu03] ([nrnotaini], [codigo]);

-- �ndice: idx_mu03_mu03-3
CREATE INDEX IF NOT EXISTS [idx_mu03_mu03-3] ON [mu03] ([nrnotaini]);

-- �ndice: idx_mu03_mu03-4
CREATE INDEX IF NOT EXISTS [idx_mu03_mu03-4] ON [mu03] ([cliente]);

-- �ndice: idx_mu03bx_mu03bx-1
CREATE INDEX IF NOT EXISTS [idx_mu03bx_mu03bx-1] ON [mu03bx] ([codigo], [nrnotaini], [digctr]);

-- �ndice: idx_mu03bx_mu03bx-2
CREATE INDEX IF NOT EXISTS [idx_mu03bx_mu03bx-2] ON [mu03bx] ([nrnotaini], [codigo]);

-- �ndice: idx_mu03bx_mu03bx-3
CREATE INDEX IF NOT EXISTS [idx_mu03bx_mu03bx-3] ON [mu03bx] ([nrnotaini]);

-- �ndice: idx_mu03bx_mu03bx-4
CREATE INDEX IF NOT EXISTS [idx_mu03bx_mu03bx-4] ON [mu03bx] ([cliente]);

-- �ndice: idx_mu04_mu04-1
CREATE INDEX IF NOT EXISTS [idx_mu04_mu04-1] ON [mu04] ([codigo], [seq]);

-- �ndice: idx_mu99_mu99-1
CREATE INDEX IF NOT EXISTS [idx_mu99_mu99-1] ON [mu99] ([arquivo], [documento]);

-- �ndice: idx_mu99_mu99-2
CREATE INDEX IF NOT EXISTS [idx_mu99_mu99-2] ON [mu99] ([codigo], [data]);

-- �ndice: idx_mw01_mw01-1
CREATE INDEX IF NOT EXISTS [idx_mw01_mw01-1] ON [mw01] ([comped]);

-- �ndice: idx_mw01_mw01-2
CREATE INDEX IF NOT EXISTS [idx_mw01_mw01-2] ON [mw01] ([comcta]);

-- �ndice: idx_mw01bx_mw01bx-1
CREATE INDEX IF NOT EXISTS [idx_mw01bx_mw01bx-1] ON [mw01bx] ([comped]);

-- �ndice: idx_mw01bx_mw01bx-2
CREATE INDEX IF NOT EXISTS [idx_mw01bx_mw01bx-2] ON [mw01bx] ([comcta]);

-- �ndice: idx_mw02_mw02-1
CREATE INDEX IF NOT EXISTS [idx_mw02_mw02-1] ON [mw02] ([comped], [item]);

-- �ndice: idx_mw02_mw02-2
CREATE INDEX IF NOT EXISTS [idx_mw02_mw02-2] ON [mw02] ([comped]);

-- �ndice: idx_mw02_mw02-3
CREATE INDEX IF NOT EXISTS [idx_mw02_mw02-3] ON [mw02] ([itecod]);

-- �ndice: idx_mw02_mw02-4
CREATE INDEX IF NOT EXISTS [idx_mw02_mw02-4] ON [mw02] ([prgent]);

-- �ndice: idx_mw02bx_mw02bx-1
CREATE INDEX IF NOT EXISTS [idx_mw02bx_mw02bx-1] ON [mw02bx] ([comped], [item]);

-- �ndice: idx_mw02bx_mw02bx-2
CREATE INDEX IF NOT EXISTS [idx_mw02bx_mw02bx-2] ON [mw02bx] ([comped]);

-- �ndice: idx_mw03_mw03-1
CREATE INDEX IF NOT EXISTS [idx_mw03_mw03-1] ON [mw03] ([comped], [item], [iteent]);

-- �ndice: idx_mw03bx_mw03bx-1
CREATE INDEX IF NOT EXISTS [idx_mw03bx_mw03bx-1] ON [mw03bx] ([comped], [item], [iteent]);

-- �ndice: idx_mw04_mw04-1
CREATE INDEX IF NOT EXISTS [idx_mw04_mw04-1] ON [mw04] ([reccom]);

-- �ndice: idx_mw04_mw04-2
CREATE INDEX IF NOT EXISTS [idx_mw04_mw04-2] ON [mw04] ([recue], [reccom]);

-- �ndice: idx_mw04pg_mw04pg-1
CREATE INDEX IF NOT EXISTS [idx_mw04pg_mw04pg-1] ON [mw04pg] ([reccom], [recped], [recpi]);

-- �ndice: idx_mw04pg_mw04pg-2
CREATE INDEX IF NOT EXISTS [idx_mw04pg_mw04pg-2] ON [mw04pg] ([reccom]);

-- �ndice: idx_mw04pg_mw04pg-3
CREATE INDEX IF NOT EXISTS [idx_mw04pg_mw04pg-3] ON [mw04pg] ([recue], [reccom]);

-- �ndice: idx_mw05_mw05-1
CREATE INDEX IF NOT EXISTS [idx_mw05_mw05-1] ON [mw05] ([codigo]);

-- �ndice: idx_mw05_mw05-2
CREATE INDEX IF NOT EXISTS [idx_mw05_mw05-2] ON [mw05] ([nome]);

-- �ndice: idx_mw06_mw06-1
CREATE INDEX IF NOT EXISTS [idx_mw06_mw06-1] ON [mw06] ([tipo], [codigo], [ano], [mes]);

-- �ndice: idx_mw07_mw07-1
CREATE INDEX IF NOT EXISTS [idx_mw07_mw07-1] ON [mw07] ([codigo]);

-- �ndice: idx_mw07_mw07-2
CREATE INDEX IF NOT EXISTS [idx_mw07_mw07-2] ON [mw07] ([nome]);

-- �ndice: idx_mw08_mw08-1
CREATE INDEX IF NOT EXISTS [idx_mw08_mw08-1] ON [mw08] ([itetip], [itecod], [comfor], [data]);

-- �ndice: idx_mw08_mw08-2
CREATE INDEX IF NOT EXISTS [idx_mw08_mw08-2] ON [mw08] ([itetip], [itecod], [data]);

-- �ndice: idx_mw08_mw08-3
CREATE INDEX IF NOT EXISTS [idx_mw08_mw08-3] ON [mw08] ([comfor]);

-- �ndice: idx_mw08_mw08-4
CREATE INDEX IF NOT EXISTS [idx_mw08_mw08-4] ON [mw08] ([comped]);

-- �ndice: idx_mw91_mw91-1
CREATE INDEX IF NOT EXISTS [idx_mw91_mw91-1] ON [mw91] ([comped]);

-- �ndice: idx_mw92_mw92-1
CREATE INDEX IF NOT EXISTS [idx_mw92_mw92-1] ON [mw92] ([comped], [item]);

-- �ndice: idx_mw95_mw95-1
CREATE INDEX IF NOT EXISTS [idx_mw95_mw95-1] ON [mw95] ([arquivo], [documento]);

-- �ndice: idx_mw95_mw95-2
CREATE INDEX IF NOT EXISTS [idx_mw95_mw95-2] ON [mw95] ([codigo], [data]);

-- �ndice: idx_mw97_mw97-1
CREATE INDEX IF NOT EXISTS [idx_mw97_mw97-1] ON [mw97] ([arquivo], [documento]);

-- �ndice: idx_mw97_mw97-2
CREATE INDEX IF NOT EXISTS [idx_mw97_mw97-2] ON [mw97] ([codigo], [data]);

-- �ndice: idx_mx01_mx01-1
CREATE INDEX IF NOT EXISTS [idx_mx01_mx01-1] ON [mx01] ([os]);

-- �ndice: idx_mx01_mx01-2
CREATE INDEX IF NOT EXISTS [idx_mx01_mx01-2] ON [mx01] ([cliente]);

-- �ndice: idx_mx02_mx02-1
CREATE INDEX IF NOT EXISTS [idx_mx02_mx02-1] ON [mx02] ([os]);

-- �ndice: idx_mx02_mx02-2
CREATE INDEX IF NOT EXISTS [idx_mx02_mx02-2] ON [mx02] ([cliente]);

-- �ndice: idx_mx03_mx03-1
CREATE INDEX IF NOT EXISTS [idx_mx03_mx03-1] ON [mx03] ([codigo]);

-- �ndice: idx_mx03a_mx03a-1
CREATE INDEX IF NOT EXISTS [idx_mx03a_mx03a-1] ON [mx03a] ([codigo], [seq]);

-- �ndice: idx_mx04_mx04
CREATE INDEX IF NOT EXISTS [idx_mx04_mx04] ON [mx04] ([seq]);

-- �ndice: idx_mx05_mx05-1
CREATE INDEX IF NOT EXISTS [idx_mx05_mx05-1] ON [mx05] ([seq]);

-- �ndice: idx_my01_my01-1
CREATE INDEX IF NOT EXISTS [idx_my01_my01-1] ON [my01] ([numero]);

-- �ndice: idx_my01_my01-2
CREATE INDEX IF NOT EXISTS [idx_my01_my01-2] ON [my01] ([codigo], [tipo2], [tipo1]);

-- �ndice: idx_my01_my01-3
CREATE INDEX IF NOT EXISTS [idx_my01_my01-3] ON [my01] ([nrnota], [nummb01]);

-- �ndice: idx_my01_my01-4
CREATE INDEX IF NOT EXISTS [idx_my01_my01-4] ON [my01] ([os]);

-- �ndice: idx_my03_my03-1
CREATE INDEX IF NOT EXISTS [idx_my03_my03-1] ON [my03] ([numero]);

-- �ndice: idx_my03_my03-2
CREATE INDEX IF NOT EXISTS [idx_my03_my03-2] ON [my03] ([codigo], [seq], [ssq], [codmaq], [numero]);

-- �ndice: idx_my03_my03-3
CREATE INDEX IF NOT EXISTS [idx_my03_my03-3] ON [my03] ([codigo], [seq], [ssq]);

-- �ndice: idx_my03_my03-4
CREATE INDEX IF NOT EXISTS [idx_my03_my03-4] ON [my03] ([codmaq], [seq], [ssq], [codigo], [datopr]);

-- �ndice: idx_my03_my03-5
CREATE INDEX IF NOT EXISTS [idx_my03_my03-5] ON [my03] ([codigoint]);

-- �ndice: idx_my03a_my03a-1
CREATE INDEX IF NOT EXISTS [idx_my03a_my03a-1] ON [my03a] ([numero], [item]);

-- �ndice: idx_my03mid_my03mid
CREATE INDEX IF NOT EXISTS [idx_my03mid_my03mid] ON [my03mid] ([codigo], [seq], [ssq], [datopr]);

-- �ndice: idx_my03mid_my03mid2
CREATE INDEX IF NOT EXISTS [idx_my03mid_my03mid2] ON [my03mid] ([codigo], [seq], [ssq], [pchora]);

-- �ndice: idx_my03tmp_my03tmp
CREATE INDEX IF NOT EXISTS [idx_my03tmp_my03tmp] ON [my03tmp] ([codigo], [seq], [ssq], [datopr]);

-- �ndice: idx_my04_my04-1
CREATE INDEX IF NOT EXISTS [idx_my04_my04-1] ON [my04] ([numero]);

-- �ndice: idx_my04_my04-2
CREATE INDEX IF NOT EXISTS [idx_my04_my04-2] ON [my04] ([codigo], [tipo2], [tipo1]);

-- �ndice: idx_my04_my04-3
CREATE INDEX IF NOT EXISTS [idx_my04_my04-3] ON [my04] ([nrnota], [nummb01]);

-- �ndice: idx_my04_my04-4
CREATE INDEX IF NOT EXISTS [idx_my04_my04-4] ON [my04] ([os], [item]);

-- �ndice: idx_my04_my04-5
CREATE INDEX IF NOT EXISTS [idx_my04_my04-5] ON [my04] ([tecnico]);

-- �ndice: idx_mz01_mz01-1
CREATE INDEX IF NOT EXISTS [idx_mz01_mz01-1] ON [mz01] ([venciment], [nrnota], [tipfat]);

-- �ndice: idx_oc01_oc01-1
CREATE INDEX IF NOT EXISTS [idx_oc01_oc01-1] ON [oc01] ([oc]);

-- �ndice: idx_oc01a_oc01a-1
CREATE INDEX IF NOT EXISTS [idx_oc01a_oc01a-1] ON [oc01a] ([oc], [item]);

-- �ndice: idx_of01_of01-1
CREATE INDEX IF NOT EXISTS [idx_of01_of01-1] ON [of01] ([of], [item]);

-- �ndice: idx_of01_of01-2
CREATE INDEX IF NOT EXISTS [idx_of01_of01-2] ON [of01] ([cliente], [dlimite]);

-- �ndice: idx_of01_of01-3
CREATE INDEX IF NOT EXISTS [idx_of01_of01-3] ON [of01] ([codigo], [dlimite]);

-- �ndice: idx_of02_of02-1
CREATE INDEX IF NOT EXISTS [idx_of02_of02-1] ON [of02] ([of], [item], [tipcomp], [codcomp]);

-- �ndice: idx_of02_of02-2
CREATE INDEX IF NOT EXISTS [idx_of02_of02-2] ON [of02] ([tipcomp], [codcomp]);

-- �ndice: idx_of02_of02-3
CREATE INDEX IF NOT EXISTS [idx_of02_of02-3] ON [of02] ([tipcomp], [dlimp], [codcomp]);

-- �ndice: idx_of03_of03-1
CREATE INDEX IF NOT EXISTS [idx_of03_of03-1] ON [of03] ([of], [item], [codigo], [seq], [ssq]);

-- �ndice: idx_of03_of03-2
CREATE INDEX IF NOT EXISTS [idx_of03_of03-2] ON [of03] ([codigo], [seq], [ssq], [dlimp]);

-- �ndice: idx_of03_of03-3
CREATE INDEX IF NOT EXISTS [idx_of03_of03-3] ON [of03] ([dlimp], [seq], [ssq]);

-- �ndice: idx_or01_or01-1
CREATE INDEX IF NOT EXISTS [idx_or01_or01-1] ON [or01] ([codigo], [os], [requisi]);

-- �ndice: idx_or01_or01-2
CREATE INDEX IF NOT EXISTS [idx_or01_or01-2] ON [or01] ([requisi], [os]);

-- �ndice: idx_or01_or01-3
CREATE INDEX IF NOT EXISTS [idx_or01_or01-3] ON [or01] ([codigo], [dlimite]);

-- �ndice: idx_or01_or01-4
CREATE INDEX IF NOT EXISTS [idx_or01_or01-4] ON [or01] ([codigo], [dlimp]);

-- �ndice: idx_or01bx_or01bx-1
CREATE INDEX IF NOT EXISTS [idx_or01bx_or01bx-1] ON [or01bx] ([codigo], [os], [nrnota], [seq]);

-- �ndice: idx_or02_or02-1
CREATE INDEX IF NOT EXISTS [idx_or02_or02-1] ON [or02] ([codigo], [os], [requisi]);

-- �ndice: idx_or02_or02-2
CREATE INDEX IF NOT EXISTS [idx_or02_or02-2] ON [or02] ([requisi], [os]);

-- �ndice: idx_or02_or02-3
CREATE INDEX IF NOT EXISTS [idx_or02_or02-3] ON [or02] ([codigo], [dlimite]);

-- �ndice: idx_or02_or02-4
CREATE INDEX IF NOT EXISTS [idx_or02_or02-4] ON [or02] ([codigo], [dlimp]);

-- �ndice: idx_or02bx_or02bx-1
CREATE INDEX IF NOT EXISTS [idx_or02bx_or02bx-1] ON [or02bx] ([codigo], [os], [nrnota], [seq]);

-- �ndice: idx_or03_or03-1
CREATE INDEX IF NOT EXISTS [idx_or03_or03-1] ON [or03] ([codigo], [os], [requisi]);

-- �ndice: idx_or03_or03-2
CREATE INDEX IF NOT EXISTS [idx_or03_or03-2] ON [or03] ([requisi], [os]);

-- �ndice: idx_or03_or03-3
CREATE INDEX IF NOT EXISTS [idx_or03_or03-3] ON [or03] ([codigo], [dlimite]);

-- �ndice: idx_or03_or03-4
CREATE INDEX IF NOT EXISTS [idx_or03_or03-4] ON [or03] ([codigo], [dlimp]);

-- �ndice: idx_or03bx_or03bx-1
CREATE INDEX IF NOT EXISTS [idx_or03bx_or03bx-1] ON [or03bx] ([codigo], [os], [nrnota], [seq]);

-- �ndice: idx_or04_or04-1
CREATE INDEX IF NOT EXISTS [idx_or04_or04-1] ON [or04] ([codigo], [os], [requisi]);

-- �ndice: idx_or04_or04-2
CREATE INDEX IF NOT EXISTS [idx_or04_or04-2] ON [or04] ([requisi], [os]);

-- �ndice: idx_or04_or04-3
CREATE INDEX IF NOT EXISTS [idx_or04_or04-3] ON [or04] ([codigo], [dlimite]);

-- �ndice: idx_or04_or04-4
CREATE INDEX IF NOT EXISTS [idx_or04_or04-4] ON [or04] ([codigo], [dlimp]);

-- �ndice: idx_or04bx_or04bx-1
CREATE INDEX IF NOT EXISTS [idx_or04bx_or04bx-1] ON [or04bx] ([codigo], [os], [nrnota], [seq]);

-- �ndice: idx_or05_or05-1
CREATE INDEX IF NOT EXISTS [idx_or05_or05-1] ON [or05] ([codigo], [os], [requisi]);

-- �ndice: idx_or05_or05-2
CREATE INDEX IF NOT EXISTS [idx_or05_or05-2] ON [or05] ([requisi], [os]);

-- �ndice: idx_or05_or05-3
CREATE INDEX IF NOT EXISTS [idx_or05_or05-3] ON [or05] ([codigo], [dlimite]);

-- �ndice: idx_or05_or05-4
CREATE INDEX IF NOT EXISTS [idx_or05_or05-4] ON [or05] ([codigo], [dlimp]);

-- �ndice: idx_or05bx_or05bx-1
CREATE INDEX IF NOT EXISTS [idx_or05bx_or05bx-1] ON [or05bx] ([codigo], [os], [nrnota], [seq]);

-- �ndice: idx_or06_or06-1
CREATE INDEX IF NOT EXISTS [idx_or06_or06-1] ON [or06] ([codigo], [os], [requisi]);

-- �ndice: idx_or06_or06-2
CREATE INDEX IF NOT EXISTS [idx_or06_or06-2] ON [or06] ([requisi], [os]);

-- �ndice: idx_or06_or06-3
CREATE INDEX IF NOT EXISTS [idx_or06_or06-3] ON [or06] ([codigo], [dlimite]);

-- �ndice: idx_or06_or06-4
CREATE INDEX IF NOT EXISTS [idx_or06_or06-4] ON [or06] ([codigo], [dlimp]);

-- �ndice: idx_or06bx_or06bx-1
CREATE INDEX IF NOT EXISTS [idx_or06bx_or06bx-1] ON [or06bx] ([codigo], [os], [nrnota], [seq]);

-- �ndice: idx_or07_or07-1
CREATE INDEX IF NOT EXISTS [idx_or07_or07-1] ON [or07] ([codigo], [os], [requisi]);

-- �ndice: idx_or07_or07-2
CREATE INDEX IF NOT EXISTS [idx_or07_or07-2] ON [or07] ([requisi], [os]);

-- �ndice: idx_or07_or07-3
CREATE INDEX IF NOT EXISTS [idx_or07_or07-3] ON [or07] ([codigo], [dlimite]);

-- �ndice: idx_or07_or07-4
CREATE INDEX IF NOT EXISTS [idx_or07_or07-4] ON [or07] ([codigo], [dlimp]);

-- �ndice: idx_or07bx_or07bx-1
CREATE INDEX IF NOT EXISTS [idx_or07bx_or07bx-1] ON [or07bx] ([codigo], [os], [nrnota], [seq]);

-- �ndice: idx_or08_or08-1
CREATE INDEX IF NOT EXISTS [idx_or08_or08-1] ON [or08] ([codigo], [os], [requisi]);

-- �ndice: idx_or08_or08-2
CREATE INDEX IF NOT EXISTS [idx_or08_or08-2] ON [or08] ([requisi], [os]);

-- �ndice: idx_or08_or08-3
CREATE INDEX IF NOT EXISTS [idx_or08_or08-3] ON [or08] ([codigo], [dlimite]);

-- �ndice: idx_or08_or08-4
CREATE INDEX IF NOT EXISTS [idx_or08_or08-4] ON [or08] ([codigo], [dlimp]);

-- �ndice: idx_or08bx_or08bx-1
CREATE INDEX IF NOT EXISTS [idx_or08bx_or08bx-1] ON [or08bx] ([codigo], [os], [nrnota], [seq]);

-- �ndice: idx_or09_or09-1
CREATE INDEX IF NOT EXISTS [idx_or09_or09-1] ON [or09] ([codigo], [os], [requisi]);

-- �ndice: idx_or09_or09-2
CREATE INDEX IF NOT EXISTS [idx_or09_or09-2] ON [or09] ([requisi], [os]);

-- �ndice: idx_or09_or09-3
CREATE INDEX IF NOT EXISTS [idx_or09_or09-3] ON [or09] ([codigo], [dlimite]);

-- �ndice: idx_or09_or09-4
CREATE INDEX IF NOT EXISTS [idx_or09_or09-4] ON [or09] ([codigo], [dlimp]);

-- �ndice: idx_or09bx_or09bx-1
CREATE INDEX IF NOT EXISTS [idx_or09bx_or09bx-1] ON [or09bx] ([codigo], [os], [nrnota], [seq]);

-- �ndice: idx_or10_or10-1
CREATE INDEX IF NOT EXISTS [idx_or10_or10-1] ON [or10] ([codigo], [os], [requisi]);

-- �ndice: idx_or10_or10-2
CREATE INDEX IF NOT EXISTS [idx_or10_or10-2] ON [or10] ([requisi], [os]);

-- �ndice: idx_or10_or10-3
CREATE INDEX IF NOT EXISTS [idx_or10_or10-3] ON [or10] ([codigo], [dlimite]);

-- �ndice: idx_or10_or10-4
CREATE INDEX IF NOT EXISTS [idx_or10_or10-4] ON [or10] ([codigo], [dlimp]);

-- �ndice: idx_or10bx_or10bx-1
CREATE INDEX IF NOT EXISTS [idx_or10bx_or10bx-1] ON [or10bx] ([codigo], [os], [nrnota], [seq]);

-- �ndice: idx_or11_or11-1
CREATE INDEX IF NOT EXISTS [idx_or11_or11-1] ON [or11] ([codigo], [os], [requisi]);

-- �ndice: idx_or11_or11-2
CREATE INDEX IF NOT EXISTS [idx_or11_or11-2] ON [or11] ([requisi], [os]);

-- �ndice: idx_or11_or11-3
CREATE INDEX IF NOT EXISTS [idx_or11_or11-3] ON [or11] ([codigo], [dlimite]);

-- �ndice: idx_or11_or11-4
CREATE INDEX IF NOT EXISTS [idx_or11_or11-4] ON [or11] ([codigo], [dlimp]);

-- �ndice: idx_or11bx_or11bx-1
CREATE INDEX IF NOT EXISTS [idx_or11bx_or11bx-1] ON [or11bx] ([codigo], [os], [nrnota], [seq]);

-- �ndice: idx_or12_or12-1
CREATE INDEX IF NOT EXISTS [idx_or12_or12-1] ON [or12] ([codigo], [os], [requisi]);

-- �ndice: idx_or12_or12-2
CREATE INDEX IF NOT EXISTS [idx_or12_or12-2] ON [or12] ([requisi], [os]);

-- �ndice: idx_or12_or12-3
CREATE INDEX IF NOT EXISTS [idx_or12_or12-3] ON [or12] ([codigo], [dlimite]);

-- �ndice: idx_or12_or12-4
CREATE INDEX IF NOT EXISTS [idx_or12_or12-4] ON [or12] ([codigo], [dlimp]);

-- �ndice: idx_or12bx_or12bx-1
CREATE INDEX IF NOT EXISTS [idx_or12bx_or12bx-1] ON [or12bx] ([codigo], [os], [nrnota], [seq]);

-- �ndice: idx_or15_or15-1
CREATE INDEX IF NOT EXISTS [idx_or15_or15-1] ON [or15] ([codigo], [os], [requisi]);

-- �ndice: idx_or15_or15-2
CREATE INDEX IF NOT EXISTS [idx_or15_or15-2] ON [or15] ([requisi], [os]);

-- �ndice: idx_or15_or15-3
CREATE INDEX IF NOT EXISTS [idx_or15_or15-3] ON [or15] ([codigo], [dlimite]);

-- �ndice: idx_or15_or15-4
CREATE INDEX IF NOT EXISTS [idx_or15_or15-4] ON [or15] ([codigo], [dlimp]);

-- �ndice: idx_or15bx_or15bx-1
CREATE INDEX IF NOT EXISTS [idx_or15bx_or15bx-1] ON [or15bx] ([codigo], [os], [nrnota], [seq]);

-- �ndice: idx_or16_or16-1
CREATE INDEX IF NOT EXISTS [idx_or16_or16-1] ON [or16] ([codigo], [os], [requisi]);

-- �ndice: idx_or16_or16-2
CREATE INDEX IF NOT EXISTS [idx_or16_or16-2] ON [or16] ([requisi], [os]);

-- �ndice: idx_or16_or16-3
CREATE INDEX IF NOT EXISTS [idx_or16_or16-3] ON [or16] ([codigo], [dlimite]);

-- �ndice: idx_or16_or16-4
CREATE INDEX IF NOT EXISTS [idx_or16_or16-4] ON [or16] ([codigo], [dlimp]);

-- �ndice: idx_or16bx_or16bx-1
CREATE INDEX IF NOT EXISTS [idx_or16bx_or16bx-1] ON [or16bx] ([codigo], [os], [nrnota], [seq]);

-- �ndice: idx_or17_or17-1
CREATE INDEX IF NOT EXISTS [idx_or17_or17-1] ON [or17] ([codigo], [os], [requisi]);

-- �ndice: idx_or17_or17-2
CREATE INDEX IF NOT EXISTS [idx_or17_or17-2] ON [or17] ([requisi], [os]);

-- �ndice: idx_or17_or17-3
CREATE INDEX IF NOT EXISTS [idx_or17_or17-3] ON [or17] ([codigo], [dlimite]);

-- �ndice: idx_or17_or17-4
CREATE INDEX IF NOT EXISTS [idx_or17_or17-4] ON [or17] ([codigo], [dlimp]);

-- �ndice: idx_or17bx_or17bx-1
CREATE INDEX IF NOT EXISTS [idx_or17bx_or17bx-1] ON [or17bx] ([codigo], [os], [nrnota], [seq]);

-- �ndice: idx_or18_or18-1
CREATE INDEX IF NOT EXISTS [idx_or18_or18-1] ON [or18] ([codigo], [os], [requisi]);

-- �ndice: idx_or18_or18-2
CREATE INDEX IF NOT EXISTS [idx_or18_or18-2] ON [or18] ([requisi], [os]);

-- �ndice: idx_or18_or18-3
CREATE INDEX IF NOT EXISTS [idx_or18_or18-3] ON [or18] ([codigo], [dlimite]);

-- �ndice: idx_or18_or18-4
CREATE INDEX IF NOT EXISTS [idx_or18_or18-4] ON [or18] ([codigo], [dlimp]);

-- �ndice: idx_or18bx_or18bx-1
CREATE INDEX IF NOT EXISTS [idx_or18bx_or18bx-1] ON [or18bx] ([codigo], [os], [nrnota], [seq]);

-- �ndice: idx_pt_pt
CREATE INDEX IF NOT EXISTS [idx_pt_pt] ON [pt] ([trein]);

-- �ndice: idx_pt_pt-2
CREATE INDEX IF NOT EXISTS [idx_pt_pt-2] ON [pt] ([curso]);

-- �ndice: idx_pti_pti
CREATE INDEX IF NOT EXISTS [idx_pti_pti] ON [pti] ([trein]);

-- �ndice: idx_pti_pti-2
CREATE INDEX IF NOT EXISTS [idx_pti_pti-2] ON [pti] ([numfun]);

-- �ndice: idx_rhab_rhab
CREATE INDEX IF NOT EXISTS [idx_rhab_rhab] ON [rhab] ([numero], [data]);

-- �ndice: idx_rhab_rhab-2
CREATE INDEX IF NOT EXISTS [idx_rhab_rhab-2] ON [rhab] ([ano], [mes], [numero], [data]);

-- �ndice: idx_rhabseq_seq
CREATE INDEX IF NOT EXISTS [idx_rhabseq_seq] ON [rhabseq] ([seq]);

-- �ndice: idx_rhabtb_seqnum
CREATE INDEX IF NOT EXISTS [idx_rhabtb_seqnum] ON [rhabtb] ([ano], [mes], [numero]);

-- �ndice: idx_treii_treii
CREATE INDEX IF NOT EXISTS [idx_treii_treii] ON [treii] ([trein]);

-- �ndice: idx_treii_treii2
CREATE INDEX IF NOT EXISTS [idx_treii_treii2] ON [treii] ([numfun]);

-- �ndice: idx_trein_trein
CREATE INDEX IF NOT EXISTS [idx_trein_trein] ON [trein] ([trein]);

-- �ndice: idx_trein_trein-2
CREATE INDEX IF NOT EXISTS [idx_trein_trein-2] ON [trein] ([curso]);

-- �ndice: idx_trein_trein-3
CREATE INDEX IF NOT EXISTS [idx_trein_trein-3] ON [trein] ([refer]);

-- �ndice: idx_trein_trein-4
CREATE INDEX IF NOT EXISTS [idx_trein_trein-4] ON [trein] ([datacur]);

-- �ndice: idx_trjob_numero
CREATE INDEX IF NOT EXISTS [idx_trjob_numero] ON [trjob] ([numero]);

-- �ndice: idx_trjobi_numero
CREATE INDEX IF NOT EXISTS [idx_trjobi_numero] ON [trjobi] ([numero]);

-- �ndice: idx_trjobi_numtec
CREATE INDEX IF NOT EXISTS [idx_trjobi_numtec] ON [trjobi] ([numtec]);

-- �ndice: idx_trjobi_peca
CREATE INDEX IF NOT EXISTS [idx_trjobi_peca] ON [trjobi] ([peca]);

-- �ndice: idx_y399_y399-1
CREATE INDEX IF NOT EXISTS [idx_y399_y399-1] ON [y399] ([numero]);

-- �ndice: idx_y399_y399-2
CREATE INDEX IF NOT EXISTS [idx_y399_y399-2] ON [y399] ([codigo], [seq], [ssq], [codmaq], [numero]);

-- �ndice: idx_ya99-1
CREATE INDEX IF NOT EXISTS [idx_ya99-1] ON [ya99] ([numero], [item]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
