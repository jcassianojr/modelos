--
-- Arquivo gerado com SQLiteStudio v3.4.4 em ter ago 6 17:29:42 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: agenda
CREATE TABLE IF NOT EXISTS [agenda] ([cddata] SHORTDATE NOT NULL, [obs1] TEXT(60) NOT NULL, [obs2] TEXT(60) NOT NULL, [obs3] TEXT(60) NOT NULL, [obs4] TEXT(60) NOT NULL, [obs5] TEXT(60) NOT NULL, [obs6] TEXT(60) NOT NULL, [obs7] TEXT(60) NOT NULL, [obs8] TEXT(60) NOT NULL);

-- Tabela: codimp
CREATE TABLE IF NOT EXISTS [codimp] ([codigo] TEXT(6) NOT NULL, [nomeimp] TEXT(12) NOT NULL, [descricao] TEXT(50) NOT NULL, [conteudo] TEXT(70) NOT NULL);

-- Tabela: cores
CREATE TABLE IF NOT EXISTS [cores] ([codigo] TEXT(7) NOT NULL, [descricao] TEXT(60) NOT NULL, [cor1] TEXT(6) NOT NULL, [cor2] TEXT(6) NOT NULL, [cor3] TEXT(6) NOT NULL, [cor4] TEXT(6) NOT NULL, [cor5] TEXT(6) NOT NULL, [cor6] TEXT(6) NOT NULL);

-- Tabela: dici
CREATE TABLE IF NOT EXISTS [dici] ([tabela] TEXT(10) NOT NULL, [campo] TEXT(10) NOT NULL, [tipo] TEXT(1) NOT NULL, [tam] REAL NOT NULL, [dec] REAL NOT NULL, [excluido] TEXT(10) NOT NULL);

-- Tabela: macess
CREATE TABLE IF NOT EXISTS [macess] ([codigo] TEXT(6) NOT NULL, [descricao] TEXT(60) NOT NULL, [senha] TEXT(5) NOT NULL);

-- Tabela: manaman
CREATE TABLE IF NOT EXISTS [manaman] ([descricao] TEXT(76) NOT NULL, [arquivo] TEXT(12) NOT NULL);

-- Tabela: manarq
CREATE TABLE IF NOT EXISTS [manarq] ([arquivo] TEXT(8) NOT NULL, [descricao] TEXT(60) NOT NULL, [fixar] TEXT(1) NOT NULL, [lachi] REAL NOT NULL, [padrao] TEXT(1) NOT NULL, [video] TEXT(1) NOT NULL, [pbus] TEXT(1) NOT NULL, [pind] TEXT(1) NOT NULL, [cbar] TEXT(120) NOT NULL, [tipg] TEXT(1) NOT NULL, [layget] TEXT(6) NOT NULL, [cbas] TEXT(78) NOT NULL, [ibus] REAL NOT NULL, [iexi] REAL NOT NULL, [caminho] TEXT(25) NOT NULL, [arqmes] REAL NOT NULL, [arqano] REAL NOT NULL, [pulafix] TEXT(1) NOT NULL, [driver] TEXT(10) NOT NULL);

-- Tabela: manarq1
CREATE TABLE IF NOT EXISTS [manarq1] ([arquivo] TEXT(8) NOT NULL, [item] REAL NOT NULL, [indice] TEXT(8) NOT NULL, [indexp] TEXT(60) NOT NULL, [desc] TEXT(55) NOT NULL, [lin1] REAL NOT NULL, [lin2] REAL NOT NULL, [lin3] REAL NOT NULL, [col1] REAL NOT NULL, [col2] REAL NOT NULL, [col3] REAL NOT NULL, [var1] TEXT(10) NOT NULL, [var2] TEXT(10) NOT NULL, [var3] TEXT(10) NOT NULL, [des1] TEXT(30) NOT NULL, [des2] TEXT(30) NOT NULL, [des3] TEXT(30) NOT NULL, [formula] TEXT(60) NOT NULL);

-- Tabela: manatu
CREATE TABLE IF NOT EXISTS [manatu] ([arquivo1] TEXT(8) NOT NULL, [arquivo2] TEXT(8) NOT NULL, [indice] REAL NOT NULL);

-- Tabela: manerr
CREATE TABLE IF NOT EXISTS [manerr] ([usuario] TEXT(10) NOT NULL, [data] SHORTDATE NOT NULL, [hora] TEXT(8) NOT NULL, [erro] TEXT(20) NOT NULL, [opr] TEXT(3) NOT NULL, [arquivo] TEXT(8) NOT NULL);

-- Tabela: manfec
CREATE TABLE IF NOT EXISTS [manfec] ([arqori] TEXT(8) NOT NULL, [strano] TEXT(8) NOT NULL, [strdes] TEXT(2) NOT NULL, [stratu] TEXT(8) NOT NULL, [strbai] TEXT(8) NOT NULL, [fecanu] TEXT(100) NOT NULL, [camdat] TEXT(10) NOT NULL, [camda2] TEXT(10) NOT NULL, [oper01] TEXT(200) NOT NULL, [oper02] TEXT(200) NOT NULL, [oper03] TEXT(200) NOT NULL, [oper04] TEXT(200) NOT NULL, [oper05] TEXT(200) NOT NULL, [oper06] TEXT(200) NOT NULL, [oper07] TEXT(200) NOT NULL, [fechaauto] TEXT(1) NOT NULL);

-- Tabela: manfer
CREATE TABLE IF NOT EXISTS [manfer] ([dia] REAL NOT NULL, [mes] REAL NOT NULL, [descricao] TEXT(40) NOT NULL);

-- Tabela: manget
CREATE TABLE IF NOT EXISTS [manget] ([codigo] TEXT(6) NOT NULL, [seq] REAL NOT NULL, [tip] TEXT(1) NOT NULL, [linini] REAL NOT NULL, [colini] REAL NOT NULL, [linfim] REAL NOT NULL, [colfim] REAL NOT NULL, [campo] TEXT(10) NOT NULL, [estilo] TEXT(25) NOT NULL, [mensagem] TEXT(40) NOT NULL, [condicao] TEXT(200) NOT NULL, [precond] TEXT(200) NOT NULL);

-- Tabela: manopt
CREATE TABLE IF NOT EXISTS [manopt] ([itemenu] TEXT(1) NOT NULL, [posicao] REAL NOT NULL, [descp] TEXT(30) NOT NULL, [descm] TEXT(75) NOT NULL, [linha] REAL NOT NULL, [coluna] REAL NOT NULL, [tecla] REAL NOT NULL, [executar] TEXT(254) NOT NULL);

-- Tabela: manre1
CREATE TABLE IF NOT EXISTS [manre1] ([arquivo] REAL NOT NULL, [menu] TEXT(2) NOT NULL, [codigo] TEXT(8) NOT NULL, [tipo] TEXT(1) NOT NULL, [sequencia] REAL NOT NULL, [seq] REAL NOT NULL, [espacejar] REAL NOT NULL, [coluna] REAL NOT NULL, [conteudo] TEXT(78) NOT NULL, [mascara] TEXT(25) NOT NULL, [totaliza] BIT NOT NULL, [formula] TEXT(35) NOT NULL, [quebrar] REAL NOT NULL);

-- Tabela: manreg
CREATE TABLE IF NOT EXISTS [manreg] ([posicao] REAL NOT NULL, [grupo] TEXT(2) NOT NULL, [descricao] TEXT(70) NOT NULL);

-- Tabela: manrel
CREATE TABLE IF NOT EXISTS [manrel] ([menu] TEXT(2) NOT NULL, [menu1] TEXT(2) NOT NULL, [codigo] TEXT(8) NOT NULL, [codigo1] TEXT(8) NOT NULL, [nome] TEXT(60) NOT NULL, [folha] REAL NOT NULL, [etiq] TEXT(1) NOT NULL, [altura] REAL NOT NULL, [largura] REAL NOT NULL, [colunas] REAL NOT NULL, [arquivo1] TEXT(8) NOT NULL, [pind1] TEXT(1) NOT NULL, [indice1] REAL NOT NULL, [campo1] TEXT(150) NOT NULL, [arquivo2] TEXT(8) NOT NULL, [pind2] TEXT(1) NOT NULL, [indice2] REAL NOT NULL, [campo2] TEXT(150) NOT NULL, [arquivo3] TEXT(8) NOT NULL, [pind3] TEXT(1) NOT NULL, [indice3] REAL NOT NULL, [campo3] TEXT(150) NOT NULL, [arquivo4] TEXT(8) NOT NULL, [pind4] TEXT(1) NOT NULL, [indice4] REAL NOT NULL, [campo4] TEXT(150) NOT NULL, [arquivo5] TEXT(8) NOT NULL, [pind5] TEXT(1) NOT NULL, [indice5] REAL NOT NULL, [campo5] TEXT(150) NOT NULL, [arquivo6] TEXT(8) NOT NULL, [pind6] TEXT(1) NOT NULL, [indice6] REAL NOT NULL, [campo6] TEXT(150) NOT NULL, [indexacao] TEXT(78) NOT NULL, [setup] TEXT(78) NOT NULL, [filtro] TEXT(78) NOT NULL, [rel1arq] REAL NOT NULL, [rel2arq] REAL NOT NULL, [rel3arq] REAL NOT NULL, [rel4arq] REAL NOT NULL, [relacao1] TEXT(71) NOT NULL, [relacao2] TEXT(71) NOT NULL, [relacao3] TEXT(71) NOT NULL, [relacao4] TEXT(71) NOT NULL, [default] REAL NOT NULL, [quebra1a] TEXT(53) NOT NULL, [quebra1b] TEXT(53) NOT NULL, [quebra1c] TEXT(53) NOT NULL, [quebra1d] TEXT(53) NOT NULL, [quebra1e] TEXT(53) NOT NULL, [quebra2a] TEXT(53) NOT NULL, [quebra2b] TEXT(53) NOT NULL, [quebra2c] TEXT(53) NOT NULL, [quebra2d] TEXT(53) NOT NULL, [quebra2e] TEXT(53) NOT NULL, [quebra3a] TEXT(53) NOT NULL, [quebra3b] TEXT(53) NOT NULL, [quebra3c] TEXT(53) NOT NULL, [quebra3d] TEXT(53) NOT NULL, [quebra3e] TEXT(53) NOT NULL, [quebra4a] TEXT(53) NOT NULL, [quebra4b] TEXT(53) NOT NULL, [quebra4c] TEXT(53) NOT NULL, [quebra4d] TEXT(53) NOT NULL, [quebra4e] TEXT(53) NOT NULL, [quebra5a] TEXT(53) NOT NULL, [quebra5b] TEXT(53) NOT NULL, [quebra5c] TEXT(53) NOT NULL, [quebra5d] TEXT(53) NOT NULL, [quebra5e] TEXT(53) NOT NULL, [selecao] REAL NOT NULL, [fator1] TEXT(1) NOT NULL, [fator2] TEXT(1) NOT NULL, [fator3] TEXT(1) NOT NULL, [fator4] TEXT(1) NOT NULL, [fator5] TEXT(1) NOT NULL, [descrica1] TEXT(25) NOT NULL, [descrica2] TEXT(25) NOT NULL, [descrica3] TEXT(25) NOT NULL, [descrica4] TEXT(25) NOT NULL, [descrica5] TEXT(25) NOT NULL, [tam1] REAL NOT NULL, [tam2] REAL NOT NULL, [tam3] REAL NOT NULL, [tam4] REAL NOT NULL, [tam5] REAL NOT NULL, [nome_lista] TEXT(70) NOT NULL, [rel_niv2] TEXT(1) NOT NULL, [rel_niv3] TEXT(1) NOT NULL, [rel_niv4] TEXT(1) NOT NULL, [rel_niv5] TEXT(1) NOT NULL, [acessos] REAL NOT NULL, [datault] SHORTDATE NOT NULL);

-- Tabela: mansub
CREATE TABLE IF NOT EXISTS [mansub] ([itemenu] TEXT(4) NOT NULL, [posicao] REAL NOT NULL, [descp] TEXT(30) NOT NULL, [descm] TEXT(75) NOT NULL, [linha] REAL NOT NULL, [coluna] REAL NOT NULL, [tecla] REAL NOT NULL, [executar] TEXT(200) NOT NULL);

-- Tabela: mantel
CREATE TABLE IF NOT EXISTS [mantel] ([codigo] TEXT(6) NOT NULL, [seq] REAL NOT NULL, [tip] TEXT(1) NOT NULL, [linini] REAL NOT NULL, [colini] REAL NOT NULL, [linfim] REAL NOT NULL, [colfim] REAL NOT NULL, [dizer] TEXT(80) NOT NULL, [estilo] TEXT(20) NOT NULL);

-- Tabela: mcarta
CREATE TABLE IF NOT EXISTS [mcarta] ([arquivo] TEXT(8) NOT NULL, [nome] TEXT(50) NOT NULL, [setup] TEXT(20) NOT NULL, [marsup] REAL NOT NULL, [marinf] REAL NOT NULL, [mardir] REAL NOT NULL, [maresq] REAL NOT NULL, [marcol] REAL NOT NULL, [marlin] REAL NOT NULL);

-- Tabela: mcopia
CREATE TABLE IF NOT EXISTS [mcopia] ([nome] TEXT(6) NOT NULL, [diretorio] TEXT(35) NOT NULL, [arq01] TEXT(12) NOT NULL, [arq02] TEXT(12) NOT NULL, [arq03] TEXT(12) NOT NULL, [arq04] TEXT(12) NOT NULL, [arq05] TEXT(12) NOT NULL, [arq06] TEXT(12) NOT NULL, [arqo7] TEXT(12) NOT NULL, [arqo8] TEXT(12) NOT NULL, [arq09] TEXT(12) NOT NULL, [arq10] TEXT(12) NOT NULL, [arq11] TEXT(12) NOT NULL, [arq12] TEXT(12) NOT NULL, [arq13] TEXT(12) NOT NULL, [arq14] TEXT(12) NOT NULL, [arq15] TEXT(12) NOT NULL, [arq16] TEXT(12) NOT NULL, [arq17] TEXT(12) NOT NULL, [arq18] TEXT(12) NOT NULL, [arq19] TEXT(12) NOT NULL, [arq20] TEXT(12) NOT NULL, [arq21] TEXT(12) NOT NULL, [arq22] TEXT(12) NOT NULL, [arq23] TEXT(12) NOT NULL, [arq24] TEXT(12) NOT NULL, [arq25] TEXT(12) NOT NULL, [arq26] TEXT(12) NOT NULL, [arq27] TEXT(12) NOT NULL, [arq28] TEXT(12) NOT NULL, [arq29] TEXT(12) NOT NULL, [arq30] TEXT(12) NOT NULL, [arq31] TEXT(12) NOT NULL, [arq32] TEXT(12) NOT NULL, [arq33] TEXT(12) NOT NULL, [arq34] TEXT(12) NOT NULL, [arq35] TEXT(12) NOT NULL, [arq36] TEXT(12) NOT NULL, [arq37] TEXT(12) NOT NULL, [arq38] TEXT(12) NOT NULL, [arq39] TEXT(12) NOT NULL, [arq40] TEXT(12) NOT NULL);

-- Tabela: metiq
CREATE TABLE IF NOT EXISTS [metiq] ([codigo] TEXT(6) NOT NULL, [nome] TEXT(50) NOT NULL, [linha1] TEXT(75) NOT NULL, [linha2] TEXT(75) NOT NULL, [linha3] TEXT(75) NOT NULL, [linha4] TEXT(75) NOT NULL, [linha5] TEXT(75) NOT NULL, [linha6] TEXT(75) NOT NULL, [linha7] TEXT(75) NOT NULL, [linha8] TEXT(75) NOT NULL, [nlin] REAL NOT NULL, [ncol] REAL NOT NULL, [ncar] REAL NOT NULL, [setup] TEXT(20) NOT NULL, [arquivo] TEXT(8) NOT NULL, [indice] REAL NOT NULL, [filtro] TEXT(50) NOT NULL, [arqgra] TEXT(8) NOT NULL, [pind] TEXT(1) NOT NULL, [nind] REAL NOT NULL, [tipfil] TEXT(1) NOT NULL, [confil] TEXT(50) NOT NULL, [pfil] TEXT(1) NOT NULL, [setupfim] TEXT(20) NOT NULL);

-- Tabela: mexpor
CREATE TABLE IF NOT EXISTS [mexpor] ([arqori] TEXT(8) NOT NULL, [arqdes] TEXT(8) NOT NULL, [codigo] TEXT(6) NOT NULL, [descricao] TEXT(50) NOT NULL, [chaveind] TEXT(30) NOT NULL, [desapp] TEXT(10) NOT NULL, [oriapp] TEXT(40) NOT NULL, [repenc] TEXT(1) NOT NULL, [apaga] TEXT(1) NOT NULL, [tipo] TEXT(1) NOT NULL, [arqoriext] TEXT(3) NOT NULL, [arqdesext] TEXT(3) NOT NULL);

-- Tabela: mexpor1
CREATE TABLE IF NOT EXISTS [mexpor1] ([codigo] TEXT(6) NOT NULL, [vardes] TEXT(20) NOT NULL, [vardri] TEXT(100) NOT NULL);

-- Tabela: mf11
CREATE TABLE IF NOT EXISTS [mf11] ([variavel] TEXT(10) NOT NULL, [execute] TEXT(120) NOT NULL, [arquivo] TEXT(8) NOT NULL);

-- Tabela: mmes
CREATE TABLE IF NOT EXISTS [mmes] ([codigo] TEXT(6) NOT NULL, [uso] TEXT(50) NOT NULL, [mensagem] TEXT(50) NOT NULL, [descricao] TEXT(2147483647) NOT NULL);

-- Tabela: muser
CREATE TABLE IF NOT EXISTS [muser] ([usuario] TEXT(10) NOT NULL, [senha] TEXT(8) NOT NULL, [validade] TEXT(8) NOT NULL, [valdata] SHORTDATE NOT NULL, [equivale] TEXT(10) NOT NULL, [estado] TEXT(1) NOT NULL, [arqfon] TEXT(8) NOT NULL, [setor] TEXT(10) NOT NULL, [wrptno] REAL NOT NULL, [folhano] REAL NOT NULL, [datatro] SHORTDATE NOT NULL, [usuariow] TEXT(20) NOT NULL, [senhaw] TEXT(20) NOT NULL, [postel01] REAL NOT NULL, [postel02] REAL NOT NULL, [postel03] REAL NOT NULL, [postel04] REAL NOT NULL, [postel05] REAL NOT NULL, [postel06] REAL NOT NULL, [postel07] REAL NOT NULL, [postel08] REAL NOT NULL, [postel09] REAL NOT NULL, [postel10] REAL NOT NULL, [postel11] REAL NOT NULL, [postel12] REAL NOT NULL, [postel13] REAL NOT NULL, [postel14] REAL NOT NULL, [postel15] REAL NOT NULL, [postel16] REAL NOT NULL, [postel17] REAL NOT NULL, [postel18] REAL NOT NULL, [chaveh] TEXT(64) NOT NULL, [chavewc] TEXT(64) NOT NULL, [chaveww] TEXT(64) NOT NULL, [chavews] TEXT(64) NOT NULL);

-- Tabela: musera
CREATE TABLE IF NOT EXISTS [musera] ([controle] TEXT(20) NOT NULL);

-- Tabela: muserf
CREATE TABLE IF NOT EXISTS [muserf] ([controle] TEXT(20) NOT NULL);

-- Tabela: muserm
CREATE TABLE IF NOT EXISTS [muserm] ([controle] TEXT(13) NOT NULL);

-- Tabela: musern
CREATE TABLE IF NOT EXISTS [musern] ([usuario] TEXT(10) NOT NULL, [id] TEXT(40) NOT NULL);

-- Tabela: musero
CREATE TABLE IF NOT EXISTS [musero] ([controle] TEXT(20) NOT NULL);

-- Tabela: muserr
CREATE TABLE IF NOT EXISTS [muserr] ([controle] TEXT(20) NOT NULL);

-- Tabela: nota
CREATE TABLE IF NOT EXISTS [nota] ([nome] TEXT(10) NOT NULL, [obs1] TEXT(60) NOT NULL, [obs2] TEXT(60) NOT NULL, [obs3] TEXT(60) NOT NULL, [obs4] TEXT(60) NOT NULL, [obs5] TEXT(60) NOT NULL, [obs6] TEXT(60) NOT NULL, [obs7] TEXT(60) NOT NULL);

-- Tabela: padre1
CREATE TABLE IF NOT EXISTS [padre1] ([arquivo] REAL NOT NULL, [menu] TEXT(2) NOT NULL, [codigo] TEXT(8) NOT NULL, [tipo] TEXT(1) NOT NULL, [sequencia] REAL NOT NULL, [seq] REAL NOT NULL, [espacejar] REAL NOT NULL, [coluna] REAL NOT NULL, [conteudo] TEXT(78) NOT NULL, [mascara] TEXT(25) NOT NULL, [totaliza] BIT NOT NULL, [formula] TEXT(35) NOT NULL, [quebrar] REAL NOT NULL);

-- Tabela: padrel
CREATE TABLE IF NOT EXISTS [padrel] ([menu] TEXT(2) NOT NULL, [menu1] TEXT(2) NOT NULL, [codigo] TEXT(8) NOT NULL, [codigo1] TEXT(8) NOT NULL, [nome] TEXT(60) NOT NULL, [folha] REAL NOT NULL, [etiq] TEXT(1) NOT NULL, [altura] REAL NOT NULL, [largura] REAL NOT NULL, [colunas] REAL NOT NULL, [arquivo1] TEXT(8) NOT NULL, [pind1] TEXT(1) NOT NULL, [indice1] REAL NOT NULL, [campo1] TEXT(150) NOT NULL, [arquivo2] TEXT(8) NOT NULL, [pind2] TEXT(1) NOT NULL, [indice2] REAL NOT NULL, [campo2] TEXT(150) NOT NULL, [arquivo3] TEXT(8) NOT NULL, [pind3] TEXT(1) NOT NULL, [indice3] REAL NOT NULL, [campo3] TEXT(150) NOT NULL, [arquivo4] TEXT(8) NOT NULL, [pind4] TEXT(1) NOT NULL, [indice4] REAL NOT NULL, [campo4] TEXT(150) NOT NULL, [arquivo5] TEXT(8) NOT NULL, [pind5] TEXT(1) NOT NULL, [indice5] REAL NOT NULL, [campo5] TEXT(150) NOT NULL, [arquivo6] TEXT(8) NOT NULL, [pind6] TEXT(1) NOT NULL, [indice6] REAL NOT NULL, [campo6] TEXT(150) NOT NULL, [indexacao] TEXT(78) NOT NULL, [setup] TEXT(78) NOT NULL, [filtro] TEXT(78) NOT NULL, [rel1arq] REAL NOT NULL, [rel2arq] REAL NOT NULL, [rel3arq] REAL NOT NULL, [rel4arq] REAL NOT NULL, [relacao1] TEXT(71) NOT NULL, [relacao2] TEXT(71) NOT NULL, [relacao3] TEXT(71) NOT NULL, [relacao4] TEXT(71) NOT NULL, [default] REAL NOT NULL, [quebra1a] TEXT(53) NOT NULL, [quebra1b] TEXT(53) NOT NULL, [quebra1c] TEXT(53) NOT NULL, [quebra1d] TEXT(53) NOT NULL, [quebra1e] TEXT(53) NOT NULL, [quebra2a] TEXT(53) NOT NULL, [quebra2b] TEXT(53) NOT NULL, [quebra2c] TEXT(53) NOT NULL, [quebra2d] TEXT(53) NOT NULL, [quebra2e] TEXT(53) NOT NULL, [quebra3a] TEXT(53) NOT NULL, [quebra3b] TEXT(53) NOT NULL, [quebra3c] TEXT(53) NOT NULL, [quebra3d] TEXT(53) NOT NULL, [quebra3e] TEXT(53) NOT NULL, [quebra4a] TEXT(53) NOT NULL, [quebra4b] TEXT(53) NOT NULL, [quebra4c] TEXT(53) NOT NULL, [quebra4d] TEXT(53) NOT NULL, [quebra4e] TEXT(53) NOT NULL, [quebra5a] TEXT(53) NOT NULL, [quebra5b] TEXT(53) NOT NULL, [quebra5c] TEXT(53) NOT NULL, [quebra5d] TEXT(53) NOT NULL, [quebra5e] TEXT(53) NOT NULL, [selecao] REAL NOT NULL, [fator1] TEXT(1) NOT NULL, [fator2] TEXT(1) NOT NULL, [fator3] TEXT(1) NOT NULL, [fator4] TEXT(1) NOT NULL, [fator5] TEXT(1) NOT NULL, [descrica1] TEXT(25) NOT NULL, [descrica2] TEXT(25) NOT NULL, [descrica3] TEXT(25) NOT NULL, [descrica4] TEXT(25) NOT NULL, [descrica5] TEXT(25) NOT NULL, [tam1] REAL NOT NULL, [tam2] REAL NOT NULL, [tam3] REAL NOT NULL, [tam4] REAL NOT NULL, [tam5] REAL NOT NULL, [nome_lista] TEXT(70) NOT NULL, [rel_niv2] TEXT(1) NOT NULL, [rel_niv3] TEXT(1) NOT NULL, [rel_niv4] TEXT(1) NOT NULL, [rel_niv5] TEXT(1) NOT NULL, [acessos] REAL NOT NULL, [datault] SHORTDATE NOT NULL);

-- Tabela: sysopt
CREATE TABLE IF NOT EXISTS [sysopt] ([itemenu] TEXT(3) NOT NULL, [posicao] REAL NOT NULL, [descp] TEXT(30) NOT NULL, [descm] TEXT(75) NOT NULL, [linha] REAL NOT NULL, [coluna] REAL NOT NULL, [tecla] REAL NOT NULL, [executar] TEXT(200) NOT NULL);

-- Tabela: telememo
CREATE TABLE IF NOT EXISTS [telememo] ([nome] TEXT(15) NOT NULL, [especif] TEXT(35) NOT NULL, [telef] TEXT(15) NOT NULL, [fax] TEXT(15) NOT NULL);

-- Tabela: winopt
CREATE TABLE IF NOT EXISTS [winopt] ([itemenu] TEXT(3) NOT NULL, [posicao] REAL NOT NULL, [descp] TEXT(30) NOT NULL, [descm] TEXT(75) NOT NULL, [linha] REAL NOT NULL, [coluna] REAL NOT NULL, [tecla] REAL NOT NULL, [executar] TEXT(200) NOT NULL);

-- �ndice: idx_agenda_agenda
CREATE INDEX IF NOT EXISTS [idx_agenda_agenda] ON [agenda] ([cddata]);

-- �ndice: idx_codimp_codimp
CREATE INDEX IF NOT EXISTS [idx_codimp_codimp] ON [codimp] ([codigo]);

-- �ndice: idx_cores_cores
CREATE INDEX IF NOT EXISTS [idx_cores_cores] ON [cores] ([codigo]);

-- �ndice: idx_dici_dici
CREATE INDEX IF NOT EXISTS [idx_dici_dici] ON [dici] ([tabela], [campo]);

-- �ndice: idx_macess_macess
CREATE INDEX IF NOT EXISTS [idx_macess_macess] ON [macess] ([codigo]);

-- �ndice: idx_manarq1_manarq1
CREATE INDEX IF NOT EXISTS [idx_manarq1_manarq1] ON [manarq1] ([arquivo], [item]);

-- �ndice: idx_manarq_manarq
CREATE INDEX IF NOT EXISTS [idx_manarq_manarq] ON [manarq] ([arquivo]);

-- �ndice: idx_manatu_manatu
CREATE INDEX IF NOT EXISTS [idx_manatu_manatu] ON [manatu] ([arquivo1]);

-- �ndice: idx_manerr_manerr
CREATE INDEX IF NOT EXISTS [idx_manerr_manerr] ON [manerr] ([usuario], [data]);

-- �ndice: idx_manfec_manfec
CREATE INDEX IF NOT EXISTS [idx_manfec_manfec] ON [manfec] ([arqori]);

-- �ndice: idx_manfec_manfec-2
CREATE INDEX IF NOT EXISTS [idx_manfec_manfec-2] ON [manfec] ([strano]);

-- �ndice: idx_manfec_manfec-3
CREATE INDEX IF NOT EXISTS [idx_manfec_manfec-3] ON [manfec] ([strdes]);

-- �ndice: idx_manget_manget
CREATE INDEX IF NOT EXISTS [idx_manget_manget] ON [manget] ([codigo], [seq]);

-- �ndice: idx_manopt_manopt
CREATE INDEX IF NOT EXISTS [idx_manopt_manopt] ON [manopt] ([itemenu], [posicao]);

-- �ndice: idx_manreg_manreg-1
CREATE INDEX IF NOT EXISTS [idx_manreg_manreg-1] ON [manreg] ([posicao]);

-- �ndice: idx_manreg_manreg-2
CREATE INDEX IF NOT EXISTS [idx_manreg_manreg-2] ON [manreg] ([grupo]);

-- �ndice: idx_manrel_manrel
CREATE INDEX IF NOT EXISTS [idx_manrel_manrel] ON [manrel] ([menu], [codigo]);

-- �ndice: idx_mansub_mansub
CREATE INDEX IF NOT EXISTS [idx_mansub_mansub] ON [mansub] ([itemenu], [posicao]);

-- �ndice: idx_mantel_mantel
CREATE INDEX IF NOT EXISTS [idx_mantel_mantel] ON [mantel] ([codigo], [seq]);

-- �ndice: idx_mmes_mmes
CREATE INDEX IF NOT EXISTS [idx_mmes_mmes] ON [mmes] ([codigo]);

-- �ndice: idx_muser_muser
CREATE INDEX IF NOT EXISTS [idx_muser_muser] ON [muser] ([usuario]);

-- �ndice: idx_muserm_muserm
CREATE INDEX IF NOT EXISTS [idx_muserm_muserm] ON [muserm] ([controle]);

-- �ndice: idx_musern_musern
CREATE INDEX IF NOT EXISTS [idx_musern_musern] ON [musern] ([usuario]);

-- �ndice: idx_padrel-1
CREATE INDEX IF NOT EXISTS [idx_padrel-1] ON [padrel] ([menu], [codigo]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
