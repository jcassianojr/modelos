--
-- Arquivo gerado com Letos v4.0.0 em Sun Jun 28 15:41:04 2026
--
-- Codifica��o de texto usada: windows-1252
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: index_metadata
CREATE TABLE IF NOT EXISTS index_metadata (
    nome_tabela       TEXT,
    index_name        TEXT,
    expression        TEXT,
    sql_expression    TEXT,
    filter_expression TEXT,
    is_unique         INTEGER,
    is_bag            INTEGER
);

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'lc',
                               'IDX_lc_DOCUMENTO',
                               'DOCUMENTO',
                               'DOCUMENTO',
                               '',
                               0,
                               1
                           );

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'lc',
                               'IDX_lc_NOVODOC',
                               'NOVODOC',
                               'NOVODOC',
                               '',
                               0,
                               1
                           );

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'lc',
                               'IDX_lc_TIPONUMERO',
                               'TIPO+STR NUMERO 20',
                               'TIPO NUMERO',
                               '',
                               0,
                               1
                           );

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'lct',
                               'IDX_lct_TIPO',
                               'TIPO',
                               'TIPO',
                               '',
                               0,
                               1
                           );


-- Tabela: lc
CREATE TABLE IF NOT EXISTS lc (
    DOCUMENTO TEXT    NOT NULL
                      DEFAULT (''),
    DATA      TEXT    NOT NULL
                      DEFAULT (''),
    NOVODOC   TEXT    NOT NULL
                      DEFAULT (''),
    NOVODATA  TEXT    NOT NULL
                      DEFAULT (''),
    TIPO      TEXT    NOT NULL
                      DEFAULT (''),
    NUMCOMP   TEXT    NOT NULL
                      DEFAULT (''),
    PASTA     TEXT    NOT NULL
                      DEFAULT (''),
    NUMERO    INTEGER DEFAULT 0
);


-- Tabela: lct
CREATE TABLE IF NOT EXISTS lct (
    TIPO TEXT NOT NULL
            DEFAULT ('') 
);


-- Tabela: table_metadata
CREATE TABLE IF NOT EXISTS table_metadata (
    nome_tabela          TEXT,
    column_name          TEXT,
    original_type        TEXT,
    tamanho              INTEGER,
    precisao             INTEGER,
    is_nullable          INTEGER,
    field_visual_picture TEXT
);

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'lc',
                               'DOCUMENTO',
                               'C',
                               20,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'lc',
                               'DATA',
                               'C',
                               10,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'lc',
                               'NOVODOC',
                               'C',
                               40,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'lc',
                               'NOVODATA',
                               'C',
                               10,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'lc',
                               'TIPO',
                               'C',
                               20,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'lc',
                               'NUMCOMP',
                               'C',
                               10,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'lc',
                               'PASTA',
                               'C',
                               10,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'lc',
                               'NUMERO',
                               'N',
                               10,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'lct',
                               'TIPO',
                               'C',
                               20,
                               0,
                               NULL,
                               NULL
                           );


-- �ndice: IDX_lc_DOCUMENTO
CREATE INDEX IF NOT EXISTS IDX_lc_DOCUMENTO ON lc (
    DOCUMENTO
);


-- �ndice: IDX_lc_NOVODOC
CREATE INDEX IF NOT EXISTS IDX_lc_NOVODOC ON lc (
    NOVODOC
);


-- �ndice: IDX_lc_TIPONUMERO
CREATE INDEX IF NOT EXISTS IDX_lc_TIPONUMERO ON lc (
    TIPO,
    NUMERO
);


-- �ndice: IDX_lct_TIPO
CREATE INDEX IF NOT EXISTS IDX_lct_TIPO ON lct (
    TIPO
);


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
