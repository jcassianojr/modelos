--
-- Arquivo gerado com SQLiteStudio v3.4.4 em sex ago 2 15:43:54 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: lc
CREATE TABLE IF NOT EXISTS [lc] ([documento] TEXT(20) NOT NULL, [data] TEXT(10) NOT NULL, [novodoc] TEXT(40) NOT NULL, [novodata] TEXT(10) NOT NULL, [tipo] TEXT(20) NOT NULL, [numcomp] TEXT(10) NOT NULL, [pasta] TEXT(10) NOT NULL, [numero] REAL NOT NULL);

-- Tabela: lct
CREATE TABLE IF NOT EXISTS [lct] ([tipo] TEXT(20) NOT NULL);

-- �ndice: idx_lc_documento
CREATE INDEX IF NOT EXISTS [idx_lc_documento] ON [lc] ([documento]);

-- �ndice: idx_lc_novodoc
CREATE INDEX IF NOT EXISTS [idx_lc_novodoc] ON [lc] ([novodoc]);

-- �ndice: idx_lc_tiponumero
CREATE INDEX IF NOT EXISTS [idx_lc_tiponumero] ON [lc] ([tipo], [numero]);

-- �ndice: idx_tipo
CREATE INDEX IF NOT EXISTS [idx_tipo] ON [lct] ([tipo]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
