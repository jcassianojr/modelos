--
-- Arquivo gerado com SQLiteStudio v3.4.4 em seg ago 5 10:40:53 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: curemi
CREATE TABLE IF NOT EXISTS [curemi] ([numero] REAL NOT NULL, [curso] TEXT(20) NOT NULL, [descur] TEXT(120) NOT NULL);

-- Tabela: curemp
CREATE TABLE IF NOT EXISTS [curemp] ([numero] REAL NOT NULL, [cognome] TEXT(15) NOT NULL, [nome] TEXT(40) NOT NULL, [endereco] TEXT(40) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(30) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [ddd] TEXT(2) NOT NULL, [telefone] TEXT(12) NOT NULL, [ramal] TEXT(4) NOT NULL, [contato] TEXT(22) NOT NULL, [dddfax] TEXT(2) NOT NULL, [telefax] TEXT(12) NOT NULL, [cgc] TEXT(18) NOT NULL, [iestadual] TEXT(16) NOT NULL, [ddd1] TEXT(2) NOT NULL, [telefone1] TEXT(12) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(22) NOT NULL, [pessoa] TEXT(1) NOT NULL, [site] TEXT(30) NOT NULL, [email] TEXT(30) NOT NULL);

-- Tabela: curgrp
CREATE TABLE IF NOT EXISTS [curgrp] ([grupo] TEXT(5) NOT NULL, [nome] TEXT(40) NOT NULL);

-- Tabela: curso
CREATE TABLE IF NOT EXISTS [curso] ([curso] TEXT(20) NOT NULL, [grupo] TEXT(5) NOT NULL, [descur] TEXT(120) NOT NULL, [carga] REAL NOT NULL, [cert] TEXT(1) NOT NULL, [tipcur] TEXT(1) NOT NULL);

-- Tabela: mp02c
CREATE TABLE IF NOT EXISTS [mp02c] ([codigo] TEXT(12) NOT NULL, [curso] TEXT(20) NOT NULL, [tipo] TEXT(1) NOT NULL);

-- Tabela: mp02p
CREATE TABLE IF NOT EXISTS [mp02p] ([codigo] TEXT(12) NOT NULL, [curso] TEXT(20) NOT NULL, [tipo] TEXT(1) NOT NULL);

-- Tabela: mp06
CREATE TABLE IF NOT EXISTS [mp06] ([codigo] TEXT(12) NOT NULL, [nome] TEXT(30) NOT NULL);

-- Tabela: mp06c
CREATE TABLE IF NOT EXISTS [mp06c] ([codigo] TEXT(12) NOT NULL, [curso] TEXT(20) NOT NULL);

-- Tabela: procedim
CREATE TABLE IF NOT EXISTS [procedim] ([curso] TEXT(20) NOT NULL, [descur] TEXT(120) NOT NULL, [tipo] TEXT(1) NOT NULL, [grupo] TEXT(5) NOT NULL);

-- Tabela: rhabcod
CREATE TABLE IF NOT EXISTS [rhabcod] ([codigo] TEXT(2) NOT NULL, [nome] TEXT(40) NOT NULL);

-- Tabela: rhesc
CREATE TABLE IF NOT EXISTS [rhesc] ([codigo] TEXT(2) NOT NULL, [escola] TEXT(1) NOT NULL, [codigoold] TEXT(2) NOT NULL, [descri] TEXT(70) NOT NULL);

-- Tabela: rhsel
CREATE TABLE IF NOT EXISTS [rhsel] ([empresa] REAL NOT NULL, [numero] REAL NOT NULL, [nome] TEXT(60) NOT NULL, [pis] TEXT(11) NOT NULL, [cpf] TEXT(14) NOT NULL, [nasc] SHORTDATE NOT NULL, [nascibge] TEXT(7) NOT NULL, [nascpais] TEXT(4) NOT NULL, [rg] TEXT(12) NOT NULL, [rguf] TEXT(2) NOT NULL, [rgemis] TEXT(6) NOT NULL, [rgtip] TEXT(3) NOT NULL, [ender] TEXT(40) NOT NULL, [endnum] TEXT(10) NOT NULL, [endcompl] TEXT(30) NOT NULL, [endtip] TEXT(3) NOT NULL, [bairro] TEXT(20) NOT NULL, [ibge] TEXT(7) NOT NULL, [cidade] TEXT(30) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [codmp02] TEXT(12) NOT NULL, [indicacao] TEXT(30) NOT NULL, [indiparar] TEXT(10) NOT NULL, [comparece] BIT NOT NULL, [aprovado] BIT NOT NULL, [processo] BIT NOT NULL, [procobs] TEXT(40) NOT NULL, [obs] TEXT(80) NOT NULL, [sexo] TEXT(1) NOT NULL, [fone] TEXT(14) NOT NULL, [celular] TEXT(14) NOT NULL, [fonerec] TEXT(14) NOT NULL, [contato] TEXT(30) NOT NULL, [email] TEXT(50) NOT NULL, [for01] TEXT(100) NOT NULL, [for02] TEXT(100) NOT NULL, [for03] TEXT(100) NOT NULL, [apf01] TEXT(100) NOT NULL, [apf02] TEXT(100) NOT NULL, [apf03] TEXT(100) NOT NULL, [profis] TEXT(7) NOT NULL, [serie] TEXT(5) NOT NULL, [ctpsuf] TEXT(2) NOT NULL, [ex01emp] TEXT(40) NOT NULL, [ex01ram] TEXT(12) NOT NULL, [ex01tel] TEXT(12) NOT NULL, [ex01dem] SHORTDATE NOT NULL, [ex01adm] SHORTDATE NOT NULL, [ex01fun] TEXT(50) NOT NULL, [ex01ult] REAL NOT NULL, [ex01at1] TEXT(100) NOT NULL, [ex01at2] TEXT(100) NOT NULL, [ex02emp] TEXT(40) NOT NULL, [ex02ram] TEXT(12) NOT NULL, [ex02tel] TEXT(12) NOT NULL, [ex02dem] SHORTDATE NOT NULL, [ex02adm] SHORTDATE NOT NULL, [ex02fun] TEXT(50) NOT NULL, [ex02ult] REAL NOT NULL, [ex02at1] TEXT(100) NOT NULL, [ex02at2] TEXT(100) NOT NULL, [ex03emp] TEXT(40) NOT NULL, [ex03ram] TEXT(12) NOT NULL, [ex03tel] TEXT(12) NOT NULL, [ex03dem] SHORTDATE NOT NULL, [ex03adm] SHORTDATE NOT NULL, [ex03fun] TEXT(50) NOT NULL, [ex03ult] REAL NOT NULL, [ex03at1] TEXT(100) NOT NULL, [ex03at2] TEXT(100) NOT NULL, [func01] TEXT(50) NOT NULL, [func02] TEXT(50) NOT NULL, [salario] REAL NOT NULL, [obsen01] TEXT(100) NOT NULL, [obsen02] TEXT(100) NOT NULL, [obsen03] TEXT(100) NOT NULL, [numregant] REAL NOT NULL, [funcao] REAL NOT NULL, [numempant] REAL NOT NULL, [dattransf] SHORTDATE NOT NULL, [escrais] TEXT(2) NOT NULL, [situacao] TEXT(2) NOT NULL, [cnh] TEXT(11) NOT NULL, [catcnh] TEXT(2) NOT NULL, [valcnh] SHORTDATE NOT NULL, [expcnh] SHORTDATE NOT NULL, [oc] TEXT(10) NOT NULL, [ocval] SHORTDATE NOT NULL, [ocexp] SHORTDATE NOT NULL, [ocemi] TEXT(10) NOT NULL, [banco] TEXT(3) NOT NULL, [agencia] TEXT(7) NOT NULL, [conta] TEXT(12) NOT NULL, [contafgts] TEXT(11) NOT NULL, [titulo] TEXT(14) NOT NULL, [tituzona] TEXT(3) NOT NULL, [tituseca] TEXT(3) NOT NULL, [pai] TEXT(40) NOT NULL, [mae] TEXT(40) NOT NULL, [cns] TEXT(15) NOT NULL, [defici] TEXT(1) NOT NULL, [evinc] TEXT(3) NOT NULL, [tipo] TEXT(1) NOT NULL, [ccusto] REAL NOT NULL, [unifun] TEXT(10) NOT NULL, [aposent] TEXT(1) NOT NULL, [aposend] SHORTDATE NOT NULL, [estcivil] TEXT(1) NOT NULL, [reserv] TEXT(12) NOT NULL, [resecat] TEXT(1) NOT NULL, [rgdata] SHORTDATE NOT NULL, [ctpsdata] SHORTDATE NOT NULL, [anonasci] REAL NOT NULL, [racs] TEXT(1) NOT NULL, [demitido] SHORTDATE NOT NULL, [fgts] SHORTDATE NOT NULL, [admitido] TEXT(10) NOT NULL, [ocuf] TEXT(2) NOT NULL, [ricuf] TEXT(2) NOT NULL, [ricexp] SHORTDATE NOT NULL, [ric] TEXT(32) NOT NULL, [ricemi] TEXT(3) NOT NULL);

-- Tabela: rhselhist
CREATE TABLE IF NOT EXISTS [rhselhist] ([empresa] REAL NOT NULL, [numero] REAL NOT NULL, [nome] TEXT(40) NOT NULL, [ender] TEXT(40) NOT NULL, [nasc] SHORTDATE NOT NULL, [bairro] TEXT(20) NOT NULL, [cidade] TEXT(30) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [codmp02] TEXT(12) NOT NULL, [indicacao] TEXT(30) NOT NULL, [indiparar] TEXT(10) NOT NULL, [comparece] BIT NOT NULL, [aprovado] BIT NOT NULL, [processo] BIT NOT NULL, [procobs] TEXT(40) NOT NULL, [obs] TEXT(80) NOT NULL, [sexo] TEXT(1) NOT NULL, [civil] REAL NOT NULL, [fone] TEXT(12) NOT NULL, [celular] TEXT(12) NOT NULL, [fonerec] TEXT(12) NOT NULL, [contato] TEXT(30) NOT NULL, [email] TEXT(50) NOT NULL, [for01] TEXT(100) NOT NULL, [for02] TEXT(100) NOT NULL, [for03] TEXT(100) NOT NULL, [apf01] TEXT(100) NOT NULL, [apf02] TEXT(100) NOT NULL, [apf03] TEXT(100) NOT NULL, [rg] TEXT(12) NOT NULL, [cpf] TEXT(14) NOT NULL, [pis] TEXT(11) NOT NULL, [profis] TEXT(7) NOT NULL, [serie] TEXT(5) NOT NULL, [ctpsuf] TEXT(2) NOT NULL, [categoria] TEXT(2) NOT NULL, [ex01emp] TEXT(40) NOT NULL, [ex01ram] TEXT(12) NOT NULL, [ex01tel] TEXT(12) NOT NULL, [ex01dem] SHORTDATE NOT NULL, [ex01adm] SHORTDATE NOT NULL, [ex01fun] TEXT(50) NOT NULL, [ex01ult] REAL NOT NULL, [ex01at1] TEXT(100) NOT NULL, [ex01at2] TEXT(100) NOT NULL, [ex02emp] TEXT(40) NOT NULL, [ex02ram] TEXT(12) NOT NULL, [ex02tel] TEXT(12) NOT NULL, [ex02dem] SHORTDATE NOT NULL, [ex02adm] SHORTDATE NOT NULL, [ex02fun] TEXT(50) NOT NULL, [ex02ult] REAL NOT NULL, [ex02at1] TEXT(100) NOT NULL, [ex02at2] TEXT(100) NOT NULL, [ex03emp] TEXT(40) NOT NULL, [ex03ram] TEXT(12) NOT NULL, [ex03tel] TEXT(12) NOT NULL, [ex03dem] SHORTDATE NOT NULL, [ex03adm] SHORTDATE NOT NULL, [ex03fun] TEXT(50) NOT NULL, [ex03ult] REAL NOT NULL, [ex03at1] TEXT(100) NOT NULL, [ex03at2] TEXT(100) NOT NULL, [func01] TEXT(50) NOT NULL, [func02] TEXT(50) NOT NULL, [salario] REAL NOT NULL, [obsen01] TEXT(100) NOT NULL, [obsen02] TEXT(100) NOT NULL, [obsen03] TEXT(100) NOT NULL, [numregant] REAL NOT NULL, [funcao] REAL NOT NULL, [numempant] REAL NOT NULL, [dattransf] SHORTDATE NOT NULL, [escrais] TEXT(2) NOT NULL);

-- �ndice: idx_curemi_curemi
CREATE INDEX IF NOT EXISTS [idx_curemi_curemi] ON [curemi] ([numero], [curso]);

-- �ndice: idx_curemp_curemp
CREATE INDEX IF NOT EXISTS [idx_curemp_curemp] ON [curemp] ([numero]);

-- �ndice: idx_curemp_curemp-2
CREATE INDEX IF NOT EXISTS [idx_curemp_curemp-2] ON [curemp] ([cognome]);

-- �ndice: idx_curgrp_curgrp
CREATE INDEX IF NOT EXISTS [idx_curgrp_curgrp] ON [curgrp] ([grupo]);

-- �ndice: idx_curso_curso
CREATE INDEX IF NOT EXISTS [idx_curso_curso] ON [curso] ([curso]);

-- �ndice: idx_curso_curso-2
CREATE INDEX IF NOT EXISTS [idx_curso_curso-2] ON [curso] ([descur]);

-- �ndice: idx_curso_curso-3
CREATE INDEX IF NOT EXISTS [idx_curso_curso-3] ON [curso] ([grupo], [curso]);

-- �ndice: idx_mp02c_mp02c
CREATE INDEX IF NOT EXISTS [idx_mp02c_mp02c] ON [mp02c] ([codigo]);

-- �ndice: idx_mp02p_mpo2p
CREATE INDEX IF NOT EXISTS [idx_mp02p_mpo2p] ON [mp02p] ([codigo]);

-- �ndice: idx_mp06_mp06-1
CREATE INDEX IF NOT EXISTS [idx_mp06_mp06-1] ON [mp06] ([codigo]);

-- �ndice: idx_mp06_mp06-2
CREATE INDEX IF NOT EXISTS [idx_mp06_mp06-2] ON [mp06] ([nome]);

-- �ndice: idx_mp06c_mp06c
CREATE INDEX IF NOT EXISTS [idx_mp06c_mp06c] ON [mp06c] ([codigo]);

-- �ndice: idx_procedim_procedi2
CREATE INDEX IF NOT EXISTS [idx_procedim_procedi2] ON [procedim] ([descur]);

-- �ndice: idx_procedim_procedi3
CREATE INDEX IF NOT EXISTS [idx_procedim_procedi3] ON [procedim] ([grupo], [curso]);

-- �ndice: idx_procedim_procedim
CREATE INDEX IF NOT EXISTS [idx_procedim_procedim] ON [procedim] ([curso]);

-- �ndice: idx_rhabcod_rhabcod
CREATE INDEX IF NOT EXISTS [idx_rhabcod_rhabcod] ON [rhabcod] ([codigo]);

-- �ndice: idx_rhesc_rhesc
CREATE INDEX IF NOT EXISTS [idx_rhesc_rhesc] ON [rhesc] ([codigo]);

-- �ndice: idx_rhsel-3
CREATE INDEX IF NOT EXISTS [idx_rhsel-3] ON [rhselhist] ([funcao], [empresa]);

-- �ndice: idx_rhsel_rhsel-1
CREATE INDEX IF NOT EXISTS [idx_rhsel_rhsel-1] ON [rhsel] ([empresa], [numero]);

-- �ndice: idx_rhsel_rhsel-2
CREATE INDEX IF NOT EXISTS [idx_rhsel_rhsel-2] ON [rhsel] ([nome]);

-- �ndice: idx_rhsel_rhsel-3
CREATE INDEX IF NOT EXISTS [idx_rhsel_rhsel-3] ON [rhsel] ([funcao], [empresa]);

-- �ndice: idx_rhselhist_rhsel-1
CREATE INDEX IF NOT EXISTS [idx_rhselhist_rhsel-1] ON [rhselhist] ([empresa], [numero]);

-- �ndice: idx_rhselhist_rhsel-2
CREATE INDEX IF NOT EXISTS [idx_rhselhist_rhsel-2] ON [rhselhist] ([nome]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
