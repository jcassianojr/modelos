CREATE TABLE IF NOT EXISTS APU5CD2 (
    CLIENTE INTEGER default 0
    ,COGCLI TEXT NOT NULL DEFAULT ('')
    ,CODIGO TEXT NOT NULL DEFAULT ('')
    ,ANO INTEGER default 0
    ,MES INTEGER default 0
    ,INTCOM INTEGER default 0
    ,CLIENTE2 INTEGER default 0
    ,COGCLI2 TEXT NOT NULL DEFAULT ('')
    ,CODIGO2 TEXT NOT NULL DEFAULT ('')
    ,INTCOM2 INTEGER default 0
    ,CLIENT3 INTEGER default 0
    ,COGCLI3 TEXT NOT NULL DEFAULT ('')
    ,CODIGO3 TEXT NOT NULL DEFAULT ('')
    ,INTCOM3 INTEGER default 0
    ,JUNTO TEXT NOT NULL DEFAULT ('')
    ,JUNTOA TEXT NOT NULL DEFAULT ('')
    ,JUNTOB TEXT NOT NULL DEFAULT ('')
    ,JUNTOC TEXT NOT NULL DEFAULT ('')
    ,PERCOM FLOAT  default 0
    ,PERCOM2 FLOAT  default 0
    ,PERCOM3 FLOAT  default 0
) ;
CREATE INDEX APU5CD2 ON APU5CD2 ( ANO,MES ) ;
ALTER TABLE APU5CD2 ADD PRIMARY KEY(ANO,MES) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS APU5EM2 (
    CLI1 INTEGER default 0
    ,CLI2 INTEGER default 0
    ,COGCLI1 TEXT NOT NULL DEFAULT ('')
    ,COGCLI2 TEXT NOT NULL DEFAULT ('')
    ,JUNTO TEXT NOT NULL DEFAULT ('')
    ,PERCLI1 FLOAT  default 0
    ,PERCLI2 FLOAT  default 0
    ,MES INTEGER default 0
    ,ANO INTEGER default 0
    ,ANOMES INTEGER default 0
) ;
CREATE INDEX APU5EM21 ON APU5EM2 ( ANO,MES ) ;
ALTER TABLE APU5EM2 ADD PRIMARY KEY(ANO,MES) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS APU5EMP (
    CLIENTE INTEGER default 0
    ,COGCLI TEXT NOT NULL DEFAULT ('')
    ,VALORTOT FLOAT  default 0
    ,PERCLI FLOAT  default 0
    ,PERPRO FLOAT  default 0
    ,INTPERC INTEGER default 0
    ,ANO INTEGER default 0
    ,MES INTEGER default 0
    ,TGRUPO TEXT NOT NULL DEFAULT ('')
    ,LEXPORTA BOOLEAN
    ,VALOREXP FLOAT  default 0
    ,SUBGER TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX APU5EMP1 ON APU5EMP ( CLIENTE,ANO,MES ) ;
ALTER TABLE APU5EMP ADD PRIMARY KEY(CLIENTE,ANO,MES) ;
CREATE INDEX APU5EMP2 ON APU5EMP ( ANO,MES,PERCLI ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS APU5G (
    CLIENTE INTEGER default 0
    ,COGCLI TEXT NOT NULL DEFAULT ('')
    ,GRUPO TEXT NOT NULL DEFAULT ('')
    ,CODIGO TEXT NOT NULL DEFAULT ('')
    ,NOME TEXT NOT NULL DEFAULT ('')
    ,ICM FLOAT  default 0
    ,PARTI FLOAT  default 0
    ,PPLAN FLOAT  default 0
    ,PPLANL TEXT NOT NULL DEFAULT ('')
    ,PPCAL FLOAT  default 0
    ,QTDDE INTEGER default 0
    ,VALORMER FLOAT  default 0
    ,VALORTOT FLOAT  default 0
    ,PRECOM FLOAT  default 0
    ,PERCLI FLOAT  default 0
    ,PERLUC FLOAT  default 0
    ,VALLUC FLOAT  default 0
    ,DIFLUC FLOAT  default 0
    ,SUBGER TEXT NOT NULL DEFAULT ('')
    ,CLITOTPER FLOAT  default 0
    ,CLITOTVAL FLOAT  default 0
    ,MES INTEGER default 0
    ,ANO INTEGER default 0
) ;
CREATE INDEX APU5G ON APU5G ( ANO,MES ) ;
ALTER TABLE APU5G ADD PRIMARY KEY(ANO,MES) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS APU5G2 (
    CLIENTE INTEGER default 0
    ,COGCLI TEXT NOT NULL DEFAULT ('')
    ,CODIGO TEXT NOT NULL DEFAULT ('')
    ,NOME TEXT NOT NULL DEFAULT ('')
    ,PARTI FLOAT  default 0
    ,PPLAN FLOAT  default 0
    ,QTDDE INTEGER default 0
    ,VALORMER FLOAT  default 0
    ,VALORTOT FLOAT  default 0
    ,PRECOM FLOAT  default 0
    ,PERCLI FLOAT  default 0
    ,INTCOM INTEGER default 0
    ,INTCLI INTEGER default 0
    ,JUNTO TEXT NOT NULL DEFAULT ('')
    ,MES INTEGER default 0
    ,ANO INTEGER default 0
) ;
CREATE INDEX APU5G2 ON APU5G2 ( ANO,MES ) ;
ALTER TABLE APU5G2 ADD PRIMARY KEY(ANO,MES) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS APU5G3 (
    CLIENTE INTEGER default 0
    ,COGCLI TEXT NOT NULL DEFAULT ('')
    ,CODIGO TEXT NOT NULL DEFAULT ('')
    ,NOME TEXT NOT NULL DEFAULT ('')
    ,PARTI FLOAT  default 0
    ,PPLAN FLOAT  default 0
    ,QTDDE INTEGER default 0
    ,VALORMER FLOAT  default 0
    ,VALORTOT FLOAT  default 0
    ,PRECOM FLOAT  default 0
    ,PERCLI FLOAT  default 0
    ,INTCOM INTEGER default 0
    ,INTCLI INTEGER default 0
    ,JUNTO TEXT NOT NULL DEFAULT ('')
    ,MES INTEGER default 0
    ,ANO INTEGER default 0
    ,ORDEM INTEGER default 0
    ,PERCLITOR FLOAT  default 0
) ;
CREATE INDEX APU5G3 ON APU5G3 ( ANO,MES ) ;
ALTER TABLE APU5G3 ADD PRIMARY KEY(ANO,MES) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS APU5G4 (
    JUNTO TEXT NOT NULL DEFAULT ('')
    ,PERLUC FLOAT  default 0
    ,INTPER INTEGER default 0
    ,MES INTEGER default 0
    ,ANO INTEGER default 0
) ;
CREATE INDEX APU5G4 ON APU5G4 ( ANO,MES ) ;
ALTER TABLE APU5G4 ADD PRIMARY KEY(ANO,MES) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS APU5G5 (
    JUNTO TEXT NOT NULL DEFAULT ('')
    ,CODIGO TEXT NOT NULL DEFAULT ('')
    ,PERDIF FLOAT  default 0
    ,INTDIF INTEGER default 0
    ,MES INTEGER default 0
    ,ANO INTEGER default 0
    ,COGCLI TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX APU5G5 ON APU5G5 ( ANO,MES ) ;
ALTER TABLE APU5G5 ADD PRIMARY KEY(ANO,MES) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS APU5LIN (
    ANO INTEGER default 0
    ,SUBGER TEXT NOT NULL DEFAULT ('')
    ,PERFAT FLOAT  default 0
    ,VALORTOT FLOAT  default 0
) ;
CREATE INDEX APU5LIN ON APU5LIN ( ANO,SUBGER ) ;
ALTER TABLE APU5LIN ADD PRIMARY KEY(ANO,SUBGER) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS APU5TOT (
    MES INTEGER default 0
    ,ANO INTEGER default 0
    ,VALORTOT FLOAT  default 0
    ,VALOREXP FLOAT  default 0
    ,JUNTO TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX APU5TOT ON APU5TOT ( ANO,MES ) ;
ALTER TABLE APU5TOT ADD PRIMARY KEY(ANO,MES) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
