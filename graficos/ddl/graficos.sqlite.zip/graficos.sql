--
-- Arquivo gerado com SQLiteStudio v3.4.4 em seg ago 5 11:06:44 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: apu5cd2
CREATE TABLE IF NOT EXISTS [apu5cd2] ([cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [codigo] TEXT(24) NOT NULL, [ano] REAL NOT NULL, [mes] REAL NOT NULL, [intcom] REAL NOT NULL, [cliente2] REAL NOT NULL, [cogcli2] TEXT(12) NOT NULL, [codigo2] TEXT(24) NOT NULL, [intcom2] REAL NOT NULL, [client3] REAL NOT NULL, [cogcli3] TEXT(12) NOT NULL, [codigo3] TEXT(24) NOT NULL, [intcom3] REAL NOT NULL, [junto] TEXT(105) NOT NULL, [juntoa] TEXT(30) NOT NULL, [juntob] TEXT(30) NOT NULL, [juntoc] TEXT(30) NOT NULL, [percom] REAL NOT NULL, [percom2] REAL NOT NULL, [percom3] REAL NOT NULL);

-- Tabela: apu5em2
CREATE TABLE IF NOT EXISTS [apu5em2] ([cli1] REAL NOT NULL, [cli2] REAL NOT NULL, [cogcli1] TEXT(12) NOT NULL, [cogcli2] TEXT(12) NOT NULL, [junto] TEXT(40) NOT NULL, [percli1] REAL NOT NULL, [percli2] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [anomes] REAL NOT NULL);

-- Tabela: apu5emp
CREATE TABLE IF NOT EXISTS [apu5emp] ([cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [valortot] REAL NOT NULL, [percli] REAL NOT NULL, [perpro] REAL NOT NULL, [intperc] REAL NOT NULL, [ano] REAL NOT NULL, [mes] REAL NOT NULL, [tgrupo] TEXT(1) NOT NULL, [lexporta] BIT NOT NULL, [valorexp] REAL NOT NULL, [subger] TEXT(3) NOT NULL);

-- Tabela: apu5g
CREATE TABLE IF NOT EXISTS [apu5g] ([cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [grupo] TEXT(12) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [icm] REAL NOT NULL, [parti] REAL NOT NULL, [pplan] REAL NOT NULL, [pplanl] TEXT(1) NOT NULL, [ppcal] REAL NOT NULL, [qtdde] REAL NOT NULL, [valormer] REAL NOT NULL, [valortot] REAL NOT NULL, [precom] REAL NOT NULL, [percli] REAL NOT NULL, [perluc] REAL NOT NULL, [valluc] REAL NOT NULL, [difluc] REAL NOT NULL, [subger] TEXT(2) NOT NULL, [clitotper] REAL NOT NULL, [clitotval] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: apu5g2
CREATE TABLE IF NOT EXISTS [apu5g2] ([cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [parti] REAL NOT NULL, [pplan] REAL NOT NULL, [qtdde] REAL NOT NULL, [valormer] REAL NOT NULL, [valortot] REAL NOT NULL, [precom] REAL NOT NULL, [percli] REAL NOT NULL, [intcom] REAL NOT NULL, [intcli] REAL NOT NULL, [junto] TEXT(40) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: apu5g3
CREATE TABLE IF NOT EXISTS [apu5g3] ([cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [parti] REAL NOT NULL, [pplan] REAL NOT NULL, [qtdde] REAL NOT NULL, [valormer] REAL NOT NULL, [valortot] REAL NOT NULL, [precom] REAL NOT NULL, [percli] REAL NOT NULL, [intcom] REAL NOT NULL, [intcli] REAL NOT NULL, [junto] TEXT(40) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [ordem] REAL NOT NULL, [perclitor] REAL NOT NULL);

-- Tabela: apu5g4
CREATE TABLE IF NOT EXISTS [apu5g4] ([junto] TEXT(40) NOT NULL, [perluc] REAL NOT NULL, [intper] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: apu5g5
CREATE TABLE IF NOT EXISTS [apu5g5] ([junto] TEXT(40) NOT NULL, [codigo] TEXT(24) NOT NULL, [perdif] REAL NOT NULL, [intdif] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [cogcli] TEXT(15) NOT NULL);

-- Tabela: apu5lin
CREATE TABLE IF NOT EXISTS [apu5lin] ([ano] REAL NOT NULL, [subger] TEXT(2) NOT NULL, [perfat] REAL NOT NULL, [valortot] REAL NOT NULL);

-- Tabela: apu5tot
CREATE TABLE IF NOT EXISTS [apu5tot] ([mes] REAL NOT NULL, [ano] REAL NOT NULL, [valortot] REAL NOT NULL, [valorexp] REAL NOT NULL, [junto] TEXT(7) NOT NULL);

-- �ndice: idx_apu5cd2_apu5cd2
CREATE INDEX IF NOT EXISTS [idx_apu5cd2_apu5cd2] ON [apu5cd2] ([ano], [mes]);

-- �ndice: idx_apu5em2_apu5em21
CREATE INDEX IF NOT EXISTS [idx_apu5em2_apu5em21] ON [apu5em2] ([ano], [mes]);

-- �ndice: idx_apu5emp_apu5emp1
CREATE INDEX IF NOT EXISTS [idx_apu5emp_apu5emp1] ON [apu5emp] ([cliente], [ano], [mes]);

-- �ndice: idx_apu5emp_apu5emp2
CREATE INDEX IF NOT EXISTS [idx_apu5emp_apu5emp2] ON [apu5emp] ([ano], [mes], [percli]);

-- �ndice: idx_apu5g2_apu5g2
CREATE INDEX IF NOT EXISTS [idx_apu5g2_apu5g2] ON [apu5g2] ([ano], [mes]);

-- �ndice: idx_apu5g3_apu5g3
CREATE INDEX IF NOT EXISTS [idx_apu5g3_apu5g3] ON [apu5g3] ([ano], [mes]);

-- �ndice: idx_apu5g4_apu5g4
CREATE INDEX IF NOT EXISTS [idx_apu5g4_apu5g4] ON [apu5g4] ([ano], [mes]);

-- �ndice: idx_apu5g5_apu5g5
CREATE INDEX IF NOT EXISTS [idx_apu5g5_apu5g5] ON [apu5g5] ([ano], [mes]);

-- �ndice: idx_apu5g_apu5g
CREATE INDEX IF NOT EXISTS [idx_apu5g_apu5g] ON [apu5g] ([ano], [mes]);

-- �ndice: idx_apu5lin_apu5lin
CREATE INDEX IF NOT EXISTS [idx_apu5lin_apu5lin] ON [apu5lin] ([ano], [subger]);

-- �ndice: idx_apu5tot
CREATE INDEX IF NOT EXISTS [idx_apu5tot] ON [apu5tot] ([ano], [mes]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
