--
-- Arquivo gerado com SQLiteStudio v3.4.4 em sex set 20 12:10:03 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: cepbai
CREATE TABLE IF NOT EXISTS cepbai (
    bai_nu_seq REAL      NOT NULL,
    bai_no     TEXT (63) NOT NULL
);


-- Tabela: cepbailx
CREATE TABLE IF NOT EXISTS cepbailx (
    codibge    TEXT (7) NOT NULL,
    bai_nu_new REAL     NOT NULL,
    codbailx   REAL     NOT NULL
);


-- Tabela: cepgeo
CREATE TABLE IF NOT EXISTS cepgeo (
    cep        TEXT (8) NOT NULL,
    ddd        TEXT (2) NOT NULL,
    latitude   TEXT (8) NOT NULL,
    longitude  TEXT (8) NOT NULL,
    hemisferio TEXT (1) NOT NULL
);


-- Tabela: ceprua
CREATE TABLE IF NOT EXISTS ceprua (
    rua    TEXT (70) NOT NULL,
    cep    TEXT (8)  NOT NULL,
    tipo   TEXT (20) NOT NULL,
    chvbai REAL      NOT NULL,
    nini   REAL      NOT NULL,
    nfim   REAL      NOT NULL,
    parid  TEXT (1)  NOT NULL,
    titulo TEXT (1)  NOT NULL
);


-- Tabela: cidconv
CREATE TABLE IF NOT EXISTS cidconv (
    estado TEXT (2)  NOT NULL,
    cidori TEXT (60) NOT NULL,
    estdes TEXT (2)  NOT NULL,
    ciddes TEXT (35) NOT NULL
);


-- Tabela: md05
CREATE TABLE IF NOT EXISTS md05 (
    uficms     TEXT (2)  NOT NULL,
    zonafranca TEXT (1)  NOT NULL,
    aliquota   REAL      NOT NULL,
    aliquotar  REAL      NOT NULL,
    nomeext    TEXT (20) NOT NULL,
    capital    TEXT (20) NOT NULL,
    inicep     TEXT (9)  NOT NULL,
    fimcep     TEXT (9)  NOT NULL,
    inicep2    TEXT (9)  NOT NULL,
    fimcep2    TEXT (9)  NOT NULL,
    regiao     TEXT (2)  NOT NULL,
    codmun     TEXT (2)  NOT NULL,
    correio    REAL      NOT NULL,
    areatel    TEXT (1)  NOT NULL,
    aliqtel    REAL      NOT NULL,
    qtdecid    REAL      NOT NULL,
    regcod     TEXT (1)  NOT NULL,
    area       REAL      NOT NULL,
    tamie      REAL      NOT NULL,
    mascie     TEXT (20) NOT NULL,
    ufdest     TEXT (2)  NOT NULL
);


-- Tabela: md10
CREATE TABLE IF NOT EXISTS md10 (
    uf         TEXT (2)  NOT NULL,
    nome       TEXT (35) NOT NULL,
    ddd        TEXT (2)  NOT NULL,
    codirrf    TEXT (5)  NOT NULL,
    codibge    TEXT (7)  NOT NULL,
    codbacen   TEXT (5)  NOT NULL,
    zonaele    REAL      NOT NULL,
    codtel     TEXT (5)  NOT NULL,
    nomtel     TEXT (4)  NOT NULL,
    inicep     TEXT (8)  NOT NULL,
    fimcep     TEXT (8)  NOT NULL,
    inicep2    TEXT (8)  NOT NULL,
    fimcep2    TEXT (8)  NOT NULL,
    altitude   REAL      NOT NULL,
    area       REAL      NOT NULL,
    latitude   TEXT (8)  NOT NULL,
    longitude  TEXT (8)  NOT NULL,
    hemisferio TEXT (1)  NOT NULL,
    logix      TEXT (5)  NOT NULL
);


-- Tabela: md10nao
CREATE TABLE IF NOT EXISTS md10nao (
    uf         TEXT (2)  NOT NULL,
    nome       TEXT (35) NOT NULL,
    ddd        TEXT (2)  NOT NULL,
    inicep     TEXT (8)  NOT NULL,
    fimcep     TEXT (8)  NOT NULL,
    inicep2    TEXT (10) NOT NULL,
    fimcep2    TEXT (10) NOT NULL,
    codirrf    TEXT (5)  NOT NULL,
    codibge    TEXT (7)  NOT NULL,
    zonaele    REAL      NOT NULL,
    codtel     TEXT (5)  NOT NULL,
    nomtel     TEXT (4)  NOT NULL,
    altitude   REAL      NOT NULL,
    area       REAL      NOT NULL,
    latitude   TEXT (8)  NOT NULL,
    longitude  TEXT (8)  NOT NULL,
    hemisferio TEXT (1)  NOT NULL
);


-- Tabela: md11
CREATE TABLE IF NOT EXISTS md11 (
    cep TEXT (5) NOT NULL
);


-- Tabela: mdtip
CREATE TABLE IF NOT EXISTS mdtip (
    codigo  TEXT (8)  NOT NULL,
    nome    TEXT (22) NOT NULL,
    id      REAL      NOT NULL,
    esocial TEXT (3)  NOT NULL
);


-- Tabela: mdtit
CREATE TABLE IF NOT EXISTS mdtit (
    codigo    TEXT (15) NOT NULL,
    descricao TEXT (30) NOT NULL
);


-- Tabela: mdufddd
CREATE TABLE IF NOT EXISTS mdufddd (
    uf  TEXT (2) NOT NULL,
    ddd TEXT (2) NOT NULL
);


-- Tabela: paises
CREATE TABLE IF NOT EXISTS paises (
    BACEN      INTEGER,
    NOME       CHAR (35),
    UF         CHAR (2),
    DDD        CHAR (3),
    DDDDIRETO  CHAR (1),
    ISO3166A   CHAR (2),
    ISO3166B   CHAR (3),
    ISO3166C   CHAR (3),
    NOMEINT    CHAR (35),
    AREA       INTEGER,
    PERIM      INTEGER,
    INDEPYEAR  INTEGER,
    CONTINENT  CHAR (25),
    LOGIXCONT  INTEGER,
    MOEDA      CHAR (5),
    CONTREGIAO CHAR (10),
    CAPITAL    CHAR (20),
    URLPAIS    CHAR (5) 
);


-- �ndice: idx_cepbailx_cepbailx-1
CREATE INDEX IF NOT EXISTS [idx_cepbailx_cepbailx-1] ON cepbailx (
    codibge,
    bai_nu_new
);


-- �ndice: idx_cidconv_cidori
CREATE INDEX IF NOT EXISTS idx_cidconv_cidori ON cidconv (
    estado,
    cidori
);


-- �ndice: idx_descricao
CREATE INDEX IF NOT EXISTS idx_descricao ON mdtit (
    descricao
);


-- �ndice: idx_md05_md05-1
CREATE INDEX IF NOT EXISTS [idx_md05_md05-1] ON md05 (
    uficms
);


-- �ndice: idx_md05_md05-2
CREATE INDEX IF NOT EXISTS [idx_md05_md05-2] ON md05 (
    nomeext
);


-- �ndice: idx_md10_md10-1
CREATE INDEX IF NOT EXISTS [idx_md10_md10-1] ON md10 (
    uf,
    nome
);


-- �ndice: idx_md10_md10-2
CREATE INDEX IF NOT EXISTS [idx_md10_md10-2] ON md10 (
    inicep
);


-- �ndice: idx_md10_md10-3
CREATE INDEX IF NOT EXISTS [idx_md10_md10-3] ON md10 (
    codibge
);


-- �ndice: idx_md10_md10-4
CREATE INDEX IF NOT EXISTS [idx_md10_md10-4] ON md10 (
    codirrf
);


-- �ndice: idx_md10nao_md10-1
CREATE INDEX IF NOT EXISTS [idx_md10nao_md10-1] ON md10nao (
    uf,
    nome
);


-- �ndice: idx_md10nao_md10-2
CREATE INDEX IF NOT EXISTS [idx_md10nao_md10-2] ON md10nao (
    inicep
);


-- �ndice: idx_md10nao_md10-3
CREATE INDEX IF NOT EXISTS [idx_md10nao_md10-3] ON md10nao (
    codibge
);


-- �ndice: idx_md10nao_md10-4
CREATE INDEX IF NOT EXISTS [idx_md10nao_md10-4] ON md10nao (
    codirrf
);


-- �ndice: idx_md11_md11-1
CREATE INDEX IF NOT EXISTS [idx_md11_md11-1] ON md11 (
    cep
);


-- �ndice: idx_mdtip_mdtip1
CREATE INDEX IF NOT EXISTS idx_mdtip_mdtip1 ON mdtip (
    codigo
);


-- �ndice: idx_mdtip_mdtip2
CREATE INDEX IF NOT EXISTS idx_mdtip_mdtip2 ON mdtip (
    nome
);


-- �ndice: idx_mdtit_codigo
CREATE INDEX IF NOT EXISTS idx_mdtit_codigo ON mdtit (
    codigo
);


-- �ndice: idx_mdufddd_mdufdd-1
CREATE INDEX IF NOT EXISTS [idx_mdufddd_mdufdd-1] ON mdufddd (
    uf,
    ddd
);


-- �ndice: idx_mdufddd_mdufddd-2
CREATE INDEX IF NOT EXISTS [idx_mdufddd_mdufddd-2] ON mdufddd (
    uf
);


-- �ndice: idx_mdufddd_mdufddd-3
CREATE INDEX IF NOT EXISTS [idx_mdufddd_mdufddd-3] ON mdufddd (
    ddd
);


-- �ndice: PAISES1
CREATE INDEX IF NOT EXISTS PAISES1 ON paises (
    ISO3166A
);


-- �ndice: PAISES2
CREATE INDEX IF NOT EXISTS PAISES2 ON paises (
    ISO3166B
);


-- �ndice: PAISES3
CREATE INDEX IF NOT EXISTS PAISES3 ON paises (
    NOME
);


-- �ndice: PAISES4
CREATE INDEX IF NOT EXISTS PAISES4 ON paises (
    DDD
);


-- �ndice: PAISES5
CREATE INDEX IF NOT EXISTS PAISES5 ON paises (
    BACEN
);


-- �ndice: PAISES6
CREATE INDEX IF NOT EXISTS PAISES6 ON paises (
    NOMEINT
);


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
