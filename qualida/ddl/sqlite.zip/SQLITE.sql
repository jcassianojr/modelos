CREATE TABLE IF NOT EXISTS AC2 (
    ACP INTEGER default 0
    ,DATA DATE NOT NULL DEFAULT ('')
    ,CLIENTE INTEGER default 0
    ,CLINOME TEXT NOT NULL DEFAULT ('')
    ,DESENHO TEXT NOT NULL DEFAULT ('')
    ,DESCRI TEXT NOT NULL DEFAULT ('')
    ,AMOSTRA TEXT NOT NULL DEFAULT ('')
    ,INSTRU TEXT NOT NULL DEFAULT ('')
    ,DESCII TEXT NOT NULL DEFAULT ('')
    ,CARAC TEXT NOT NULL DEFAULT ('')
    ,SUMX FLOAT  default 0
    ,MEDX FLOAT  default 0
    ,SUMR FLOAT  default 0
    ,MEDR FLOAT  default 0
    ,MIN FLOAT  default 0
    ,MAX FLOAT  default 0
    ,X01 FLOAT  default 0
    ,X02 FLOAT  default 0
    ,X03 FLOAT  default 0
    ,X04 FLOAT  default 0
    ,X05 FLOAT  default 0
    ,X06 FLOAT  default 0
    ,X07 FLOAT  default 0
    ,X08 FLOAT  default 0
    ,X09 FLOAT  default 0
    ,X10 FLOAT  default 0
    ,X11 FLOAT  default 0
    ,X12 FLOAT  default 0
    ,X13 FLOAT  default 0
    ,X14 FLOAT  default 0
    ,X15 FLOAT  default 0
    ,X16 FLOAT  default 0
    ,X17 FLOAT  default 0
    ,X18 FLOAT  default 0
    ,X19 FLOAT  default 0
    ,X20 FLOAT  default 0
    ,X21 FLOAT  default 0
    ,X22 FLOAT  default 0
    ,X23 FLOAT  default 0
    ,X24 FLOAT  default 0
    ,X25 FLOAT  default 0
    ,X26 FLOAT  default 0
    ,X27 FLOAT  default 0
    ,X28 FLOAT  default 0
    ,X29 FLOAT  default 0
    ,X30 FLOAT  default 0
    ,R01 FLOAT  default 0
    ,R02 FLOAT  default 0
    ,R03 FLOAT  default 0
    ,R04 FLOAT  default 0
    ,R05 FLOAT  default 0
    ,R06 FLOAT  default 0
    ,R07 FLOAT  default 0
    ,R08 FLOAT  default 0
    ,R09 FLOAT  default 0
    ,R10 FLOAT  default 0
    ,R11 FLOAT  default 0
    ,R12 FLOAT  default 0
    ,R13 FLOAT  default 0
    ,R14 FLOAT  default 0
    ,R15 FLOAT  default 0
    ,R16 FLOAT  default 0
    ,R17 FLOAT  default 0
    ,R18 FLOAT  default 0
    ,R19 FLOAT  default 0
    ,R20 FLOAT  default 0
    ,R21 FLOAT  default 0
    ,R22 FLOAT  default 0
    ,R23 FLOAT  default 0
    ,R24 FLOAT  default 0
    ,R25 FLOAT  default 0
    ,R26 FLOAT  default 0
    ,R27 FLOAT  default 0
    ,R28 FLOAT  default 0
    ,R29 FLOAT  default 0
    ,R30 FLOAT  default 0
    ,SIGMA FLOAT  default 0
    ,PP FLOAT  default 0
    ,PPKA FLOAT  default 0
    ,PPKB FLOAT  default 0
    ,PPK FLOAT  default 0
    ,ACD INTEGER default 0
    ,LIC FLOAT  default 0
    ,LSC FLOAT  default 0
    ,RMAX FLOAT  default 0
    ,RMIN FLOAT  default 0
    ,XMAX FLOAT  default 0
    ,XMIN FLOAT  default 0
    ,DESV FLOAT  default 0
    ,ELANUM INTEGER default 0
    ,ELANOM TEXT NOT NULL DEFAULT ('')
    ,ELADAT DATE NOT NULL DEFAULT ('')
    ,RESNUM INTEGER default 0
    ,RESNOM TEXT NOT NULL DEFAULT ('')
    ,RESDAT DATE NOT NULL DEFAULT ('')
    ,FORAE INTEGER default 0
    ,FORAX INTEGER default 0
    ,FORAR INTEGER default 0
    ,RLSC FLOAT  default 0
    ,MODAX FLOAT  default 0
    ,MODAR FLOAT  default 0
    ,MEDIX FLOAT  default 0
    ,MEDIR FLOAT  default 0
    ,SEQ INTEGER default 0
    ,SSQ INTEGER default 0
    ,OPERACAO TEXT NOT NULL DEFAULT ('')
    ,REVD TEXT NOT NULL DEFAULT ('')
    ,DATAR DATE NOT NULL DEFAULT ('')
    ,DISTNOR TEXT NOT NULL DEFAULT ('')
    ,OBS TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX ACP ON AC2 ( ACP ) ;
ALTER TABLE AC2 ADD PRIMARY KEY(ACP) ;
CREATE INDEX ACD ON AC2 ( ACD ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS ACD (
    ACD INTEGER default 0
    ,DATA DATE NOT NULL DEFAULT ('')
    ,CLIENTE INTEGER default 0
    ,CLINOME TEXT NOT NULL DEFAULT ('')
    ,DESENHO TEXT NOT NULL DEFAULT ('')
    ,DESCRI TEXT NOT NULL DEFAULT ('')
    ,INSTRU TEXT NOT NULL DEFAULT ('')
    ,DESCII TEXT NOT NULL DEFAULT ('')
    ,CARAC TEXT NOT NULL DEFAULT ('')
    ,MIN FLOAT  default 0
    ,MAX FLOAT  default 0
    ,CONV BOOLEAN
    ,SEQ INTEGER default 0
    ,SSQ INTEGER default 0
    ,OPERACAO TEXT NOT NULL DEFAULT ('')
    ,DATAR DATE NOT NULL DEFAULT ('')
    ,REVD TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX ACD ON ACD ( ACD ) ;
ALTER TABLE ACD ADD PRIMARY KEY(ACD) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS ACDI (
    ACD INTEGER default 0
    ,VAL01 FLOAT  default 0
    ,VAL02 FLOAT  default 0
    ,VAL03 FLOAT  default 0
    ,VAL04 FLOAT  default 0
    ,VAL05 FLOAT  default 0
    ,MEDX FLOAT  default 0
    ,VALR FLOAT  default 0
    ,DATA DATE NOT NULL DEFAULT ('')
    ,HORA FLOAT  default 0
    ,ACP INTEGER default 0
    ,AEP INTEGER default 0
    ,ORDEM INTEGER default 0
    ,LIC FLOAT  default 0
    ,LSC FLOAT  default 0
) ;
CREATE INDEX ACDI ON ACDI ( ACD ) ;
ALTER TABLE ACDI ADD PRIMARY KEY(ACD) ;
CREATE INDEX ACDI_2 ON ACDI ( ACD,DATA,HORA ) ;
CREATE INDEX ACDI_3 ON ACDI ( ACP ) ;
CREATE INDEX ACDI_4 ON ACDI ( AEP ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS ACP (
    ACP INTEGER default 0
    ,DATA DATE NOT NULL DEFAULT ('')
    ,CLIENTE INTEGER default 0
    ,CLINOME TEXT NOT NULL DEFAULT ('')
    ,DESENHO TEXT NOT NULL DEFAULT ('')
    ,DESCRI TEXT NOT NULL DEFAULT ('')
    ,AMOSTRA TEXT NOT NULL DEFAULT ('')
    ,INSTRU TEXT NOT NULL DEFAULT ('')
    ,DESCII TEXT NOT NULL DEFAULT ('')
    ,CARAC TEXT NOT NULL DEFAULT ('')
    ,SUMX FLOAT  default 0
    ,MEDX FLOAT  default 0
    ,SUMR FLOAT  default 0
    ,MEDR FLOAT  default 0
    ,MIN FLOAT  default 0
    ,MAX FLOAT  default 0
    ,X01 FLOAT  default 0
    ,X02 FLOAT  default 0
    ,X03 FLOAT  default 0
    ,X04 FLOAT  default 0
    ,X05 FLOAT  default 0
    ,X06 FLOAT  default 0
    ,X07 FLOAT  default 0
    ,X08 FLOAT  default 0
    ,X09 FLOAT  default 0
    ,X10 FLOAT  default 0
    ,X11 FLOAT  default 0
    ,X12 FLOAT  default 0
    ,X13 FLOAT  default 0
    ,X14 FLOAT  default 0
    ,X15 FLOAT  default 0
    ,X16 FLOAT  default 0
    ,X17 FLOAT  default 0
    ,X18 FLOAT  default 0
    ,X19 FLOAT  default 0
    ,X20 FLOAT  default 0
    ,X21 FLOAT  default 0
    ,X22 FLOAT  default 0
    ,X23 FLOAT  default 0
    ,X24 FLOAT  default 0
    ,X25 FLOAT  default 0
    ,X26 FLOAT  default 0
    ,X27 FLOAT  default 0
    ,X28 FLOAT  default 0
    ,X29 FLOAT  default 0
    ,X30 FLOAT  default 0
    ,R01 FLOAT  default 0
    ,R02 FLOAT  default 0
    ,R03 FLOAT  default 0
    ,R04 FLOAT  default 0
    ,R05 FLOAT  default 0
    ,R06 FLOAT  default 0
    ,R07 FLOAT  default 0
    ,R08 FLOAT  default 0
    ,R09 FLOAT  default 0
    ,R10 FLOAT  default 0
    ,R11 FLOAT  default 0
    ,R12 FLOAT  default 0
    ,R13 FLOAT  default 0
    ,R14 FLOAT  default 0
    ,R15 FLOAT  default 0
    ,R16 FLOAT  default 0
    ,R17 FLOAT  default 0
    ,R18 FLOAT  default 0
    ,R19 FLOAT  default 0
    ,R20 FLOAT  default 0
    ,R21 FLOAT  default 0
    ,R22 FLOAT  default 0
    ,R23 FLOAT  default 0
    ,R24 FLOAT  default 0
    ,R25 FLOAT  default 0
    ,R26 FLOAT  default 0
    ,R27 FLOAT  default 0
    ,R28 FLOAT  default 0
    ,R29 FLOAT  default 0
    ,R30 FLOAT  default 0
    ,SIGMA FLOAT  default 0
    ,PP FLOAT  default 0
    ,PPKA FLOAT  default 0
    ,PPKB FLOAT  default 0
    ,PPK FLOAT  default 0
    ,ACD INTEGER default 0
    ,LIC FLOAT  default 0
    ,LSC FLOAT  default 0
    ,RMAX FLOAT  default 0
    ,RMIN FLOAT  default 0
    ,XMAX FLOAT  default 0
    ,XMIN FLOAT  default 0
    ,DESV FLOAT  default 0
    ,ELANUM INTEGER default 0
    ,ELANOM TEXT NOT NULL DEFAULT ('')
    ,ELADAT DATE NOT NULL DEFAULT ('')
    ,RESNUM INTEGER default 0
    ,RESNOM TEXT NOT NULL DEFAULT ('')
    ,RESDAT DATE NOT NULL DEFAULT ('')
    ,FORAE INTEGER default 0
    ,FORAX INTEGER default 0
    ,FORAR INTEGER default 0
    ,RLSC FLOAT  default 0
    ,MODAX FLOAT  default 0
    ,MODAR FLOAT  default 0
    ,MEDIX FLOAT  default 0
    ,MEDIR FLOAT  default 0
    ,SEQ INTEGER default 0
    ,SSQ INTEGER default 0
    ,OPERACAO TEXT NOT NULL DEFAULT ('')
    ,REVD TEXT NOT NULL DEFAULT ('')
    ,DATAR DATE NOT NULL DEFAULT ('')
    ,DISTNOR TEXT NOT NULL DEFAULT ('')
    ,OBS TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX ACP ON ACP ( ACP ) ;
ALTER TABLE ACP ADD PRIMARY KEY(ACP) ;
CREATE INDEX ACD ON ACP ( ACD ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS ACPR (
    ACP INTEGER default 0
    ,VALOR FLOAT  default 0
    ,QTDE INTEGER default 0
    ,TOTAL FLOAT  default 0
) ;
CREATE INDEX ACPVALOR ON ACPR ( ACP,VALOR ) ;
ALTER TABLE ACPR ADD PRIMARY KEY(ACP,VALOR) ;
CREATE INDEX ACP ON ACPR ( ACP ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS ACPX (
    ACP INTEGER default 0
    ,VALOR FLOAT  default 0
    ,QTDE INTEGER default 0
    ,TOTAL FLOAT  default 0
) ;
CREATE INDEX ACPVALOR ON ACPX ( ACP,VALOR ) ;
ALTER TABLE ACPX ADD PRIMARY KEY(ACP,VALOR) ;
CREATE INDEX ACP ON ACPX ( ACP ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS AEPR (
    ACP INTEGER default 0
    ,VALOR FLOAT  default 0
    ,QTDE INTEGER default 0
    ,TOTAL FLOAT  default 0
) ;
CREATE INDEX ACPVALOR ON AEPR ( ACP,VALOR ) ;
ALTER TABLE AEPR ADD PRIMARY KEY(ACP,VALOR) ;
CREATE INDEX ACP ON AEPR ( ACP ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS AEPX (
    ACP INTEGER default 0
    ,VALOR FLOAT  default 0
    ,QTDE INTEGER default 0
    ,TOTAL FLOAT  default 0
) ;
CREATE INDEX ACPVALOR ON AEPX ( ACP,VALOR ) ;
ALTER TABLE AEPX ADD PRIMARY KEY(ACP,VALOR) ;
CREATE INDEX ACP ON AEPX ( ACP ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS CI (
    CI INTEGER default 0
    ,TIPOI TEXT NOT NULL DEFAULT ('')
    ,DESCRI TEXT NOT NULL DEFAULT ('')
    ,DESENHO TEXT NOT NULL DEFAULT ('')
    ,REVD TEXT NOT NULL DEFAULT ('')
    ,DATAD DATE NOT NULL DEFAULT ('')
    ,DATAR DATE NOT NULL DEFAULT ('')
    ,PEDIDO TEXT NOT NULL DEFAULT ('')
    ,ORDEM TEXT NOT NULL DEFAULT ('')
    ,QTL TEXT NOT NULL DEFAULT ('')
    ,QTI TEXT NOT NULL DEFAULT ('')
    ,RASTRO TEXT NOT NULL DEFAULT ('')
    ,CLIENTE INTEGER default 0
    ,CLINOME TEXT NOT NULL DEFAULT ('')
    ,OBS01 TEXT NOT NULL DEFAULT ('')
    ,OBS02 TEXT NOT NULL DEFAULT ('')
    ,LAUDOF TEXT NOT NULL DEFAULT ('')
    ,DATA DATE NOT NULL DEFAULT ('')
    ,INSNUM INTEGER default 0
    ,INSNOM TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX CI ON CI ( CI ) ;
ALTER TABLE CI ADD PRIMARY KEY(CI) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS CIC (
    DESENHO TEXT NOT NULL DEFAULT ('')
    ,DESCRI TEXT NOT NULL DEFAULT ('')
    ,DATAR DATE NOT NULL DEFAULT ('')
    ,DATAD DATE NOT NULL DEFAULT ('')
    ,REVD TEXT NOT NULL DEFAULT ('')
    ,CLIENTE INTEGER default 0
) ;
CREATE INDEX DESENHO ON CIC ( DESENHO ) ;
ALTER TABLE CIC ADD PRIMARY KEY(DESENHO) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS CICI (
    DESENHO TEXT NOT NULL DEFAULT ('')
    ,ENC FLOAT  default 0
    ,CESPE TEXT NOT NULL DEFAULT ('')
    ,ESPE FLOAT  default 0
    ,MAX FLOAT  default 0
    ,MIN FLOAT  default 0
    ,UND TEXT NOT NULL DEFAULT ('')
    ,LOCALI TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX DESENHO ON CICI ( DESENHO ) ;
ALTER TABLE CICI ADD PRIMARY KEY(DESENHO) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS CII (
    CI INTEGER default 0
    ,ITEM INTEGER default 0
    ,DESVIO FLOAT  default 0
    ,ENC FLOAT  default 0
    ,CENC TEXT NOT NULL DEFAULT ('')
    ,CESPE TEXT NOT NULL DEFAULT ('')
    ,ESPE FLOAT  default 0
    ,MAX FLOAT  default 0
    ,MIN FLOAT  default 0
    ,UND TEXT NOT NULL DEFAULT ('')
    ,LOCALI TEXT NOT NULL DEFAULT ('')
    ,LAUDO TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX CI ON CII ( CI ) ;
ALTER TABLE CII ADD PRIMARY KEY(CI) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS CRTAUM (
    TIPO TEXT NOT NULL DEFAULT ('')
    ,DATA DATE NOT NULL DEFAULT ('')
    ,HORA FLOAT  default 0
    ,VALOR INTEGER default 0
    ,REFCTR TEXT NOT NULL DEFAULT ('')
    ,SALA TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX DATA ON CRTAUM ( DATA ) ;
ALTER TABLE CRTAUM ADD PRIMARY KEY(DATA) ;
CREATE INDEX REFCTR ON CRTAUM ( REFCTR ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS ETIPPP (
    NUMERO INTEGER default 0
    ,CODIGO TEXT NOT NULL DEFAULT ('')
    ,NOME TEXT NOT NULL DEFAULT ('')
    ,SUFIX TEXT NOT NULL DEFAULT ('')
    ,ENGENHA TEXT NOT NULL DEFAULT ('')
) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS GC (
    GC INTEGER default 0
    ,CLIENTE INTEGER default 0
    ,CLINOME TEXT NOT NULL DEFAULT ('')
    ,CODIGO TEXT NOT NULL DEFAULT ('')
    ,NOME TEXT NOT NULL DEFAULT ('')
    ,CODME01 TEXT NOT NULL DEFAULT ('')
    ,NOMME01 TEXT NOT NULL DEFAULT ('')
    ,SEQ INTEGER default 0
    ,SSQ INTEGER default 0
    ,CARAC TEXT NOT NULL DEFAULT ('')
    ,ESPEC TEXT NOT NULL DEFAULT ('')
    ,FREQ TEXT NOT NULL DEFAULT ('')
    ,TAM TEXT NOT NULL DEFAULT ('')
    ,CODME04 TEXT NOT NULL DEFAULT ('')
    ,NOMME04 TEXT NOT NULL DEFAULT ('')
    ,CO2ME04 TEXT NOT NULL DEFAULT ('')
    ,NO2ME04 TEXT NOT NULL DEFAULT ('')
    ,UNIDME TEXT NOT NULL DEFAULT ('')
    ,REFCTR TEXT NOT NULL DEFAULT ('')
    ,VALX FLOAT  default 0
    ,LIC FLOAT  default 0
    ,LSC FLOAT  default 0
    ,LIE FLOAT  default 0
    ,LSE FLOAT  default 0
    ,VINI FLOAT  default 0
    ,VDIV FLOAT  default 0
    ,VALR FLOAT  default 0
    ,LSCR FLOAT  default 0
    ,VDIR FLOAT  default 0
    ,VMAX FLOAT  default 0
    ,RMAX FLOAT  default 0
    ,ACP INTEGER default 0
    ,AEP INTEGER default 0
    ,OBS TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX GC ON GC ( GC ) ;
ALTER TABLE GC ADD PRIMARY KEY(GC) ;
CREATE INDEX REFCTR ON GC ( REFCTR ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS GCTEM (
    ITEM INTEGER default 0
    ,REFCTR TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX REFCTR ON GCTEM ( REFCTR ) ;
ALTER TABLE GCTEM ADD PRIMARY KEY(REFCTR) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS GCTEMP (
    ITEM INTEGER default 0
    ,REFCTR TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX ITEM ON GCTEMP ( ITEM ) ;
ALTER TABLE GCTEMP ADD PRIMARY KEY(ITEM) ;
CREATE INDEX REFCTR ON GCTEMP ( REFCTR ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS OPAE (
    OPAE INTEGER default 0
    ,CLIENTE INTEGER default 0
    ,DATA DATE NOT NULL DEFAULT ('')
    ,CODIGO TEXT NOT NULL DEFAULT ('')
    ,RASTRO TEXT NOT NULL DEFAULT ('')
    ,QTDE INTEGER default 0
    ,CODMP04 INTEGER default 0
) ;
CREATE INDEX OPAE ON OPAE ( OPAE ) ;
ALTER TABLE OPAE ADD PRIMARY KEY(OPAE) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS OPAI (
    OPAE INTEGER default 0
    ,ESPEC TEXT NOT NULL DEFAULT ('')
    ,LAUDO TEXT NOT NULL DEFAULT ('')
) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS PAC (
    PAC INTEGER default 0
    ,ACP INTEGER default 0
    ,AEP INTEGER default 0
    ,CLIENTE INTEGER default 0
    ,CLINOME TEXT NOT NULL DEFAULT ('')
    ,CODIGO TEXT NOT NULL DEFAULT ('')
    ,DATA DATE NOT NULL DEFAULT ('')
    ,NOME TEXT NOT NULL DEFAULT ('')
    ,ESPECI TEXT NOT NULL DEFAULT ('')
    ,CARAC TEXT NOT NULL DEFAULT ('')
    ,INSTRU TEXT NOT NULL DEFAULT ('')
    ,DESCII TEXT NOT NULL DEFAULT ('')
    ,SEQ INTEGER default 0
    ,SSQ INTEGER default 0
    ,EQU TEXT NOT NULL DEFAULT ('')
    ,NEQU TEXT NOT NULL DEFAULT ('')
    ,UNID TEXT NOT NULL DEFAULT ('')
    ,RMIN FLOAT  default 0
    ,RMAX FLOAT  default 0
    ,VMAX FLOAT  default 0
    ,VMIN FLOAT  default 0
    ,MEDX FLOAT  default 0
    ,PP FLOAT  default 0
    ,XMAX FLOAT  default 0
    ,XMIN FLOAT  default 0
    ,MEDR FLOAT  default 0
    ,PPK FLOAT  default 0
    ,IDE01 TEXT NOT NULL DEFAULT ('')
    ,IDE02 TEXT NOT NULL DEFAULT ('')
    ,IDE04 TEXT NOT NULL DEFAULT ('')
    ,IDE03 TEXT NOT NULL DEFAULT ('')
    ,CAV01 TEXT NOT NULL DEFAULT ('')
    ,CAV02 TEXT NOT NULL DEFAULT ('')
    ,CAV03 TEXT NOT NULL DEFAULT ('')
    ,CAV04 TEXT NOT NULL DEFAULT ('')
    ,ACA01 TEXT NOT NULL DEFAULT ('')
    ,ACA02 TEXT NOT NULL DEFAULT ('')
    ,ACA03 TEXT NOT NULL DEFAULT ('')
    ,ACA04 TEXT NOT NULL DEFAULT ('')
    ,SETOR TEXT NOT NULL DEFAULT ('')
    ,SETCOD TEXT NOT NULL DEFAULT ('')
    ,DESSEQ TEXT NOT NULL DEFAULT ('')
    ,VALP FLOAT  default 0
    ,NXMIN FLOAT  default 0
    ,NXMAX FLOAT  default 0
    ,NXMED FLOAT  default 0
    ,NRMIN FLOAT  default 0
    ,NRMAX FLOAT  default 0
    ,NRMED FLOAT  default 0
    ,NPP FLOAT  default 0
    ,NPPK FLOAT  default 0
    ,NVALP FLOAT  default 0
    ,NAEP INTEGER default 0
    ,NACP INTEGER default 0
    ,NVMIN FLOAT  default 0
    ,NVMAX FLOAT  default 0
) ;
CREATE INDEX PAC ON PAC ( PAC ) ;
ALTER TABLE PAC ADD PRIMARY KEY(PAC) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS PAEE (
    PAEE INTEGER default 0
    ,DATA DATE NOT NULL DEFAULT ('')
    ,CLIENTE INTEGER default 0
    ,CODIGO TEXT NOT NULL DEFAULT ('')
    ,OBS01 TEXT NOT NULL DEFAULT ('')
    ,OBS02 TEXT NOT NULL DEFAULT ('')
    ,OBS03 TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX PAEE ON PAEE ( PAEE ) ;
ALTER TABLE PAEE ADD PRIMARY KEY(PAEE) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS PAEI (
    DESENHO TEXT NOT NULL DEFAULT ('')
    ,ESPEC TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX PAEI ON PAEI ( DESENHO ) ;
ALTER TABLE PAEI ADD PRIMARY KEY(DESENHO) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS RI (
    RI INTEGER default 0
    ,TIPOI TEXT NOT NULL DEFAULT ('')
    ,TIPO2 TEXT NOT NULL DEFAULT ('')
    ,DESCRI TEXT NOT NULL DEFAULT ('')
    ,DESENHO TEXT NOT NULL DEFAULT ('')
    ,REVD TEXT NOT NULL DEFAULT ('')
    ,DATAD DATE NOT NULL DEFAULT ('')
    ,DATAR DATE NOT NULL DEFAULT ('')
    ,PEDIDO TEXT NOT NULL DEFAULT ('')
    ,ORDEM TEXT NOT NULL DEFAULT ('')
    ,QTL TEXT NOT NULL DEFAULT ('')
    ,QTI TEXT NOT NULL DEFAULT ('')
    ,RASTRO TEXT NOT NULL DEFAULT ('')
    ,CLIENTE INTEGER default 0
    ,CLINOME TEXT NOT NULL DEFAULT ('')
    ,OBS01 TEXT NOT NULL DEFAULT ('')
    ,OBS02 TEXT NOT NULL DEFAULT ('')
    ,LAUDOF TEXT NOT NULL DEFAULT ('')
    ,DATA DATE NOT NULL DEFAULT ('')
    ,INSNUM INTEGER default 0
    ,INSNOM TEXT NOT NULL DEFAULT ('')
    ,SEQ INTEGER default 0
    ,SSQ INTEGER default 0
    ,ORIGEM TEXT NOT NULL DEFAULT ('')
    ,CODIGOINT TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX RI ON RI ( RI ) ;
ALTER TABLE RI ADD PRIMARY KEY(RI) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS RII (
    RI INTEGER default 0
    ,ITEM INTEGER default 0
    ,DESVIO TEXT NOT NULL DEFAULT ('')
    ,ENC TEXT NOT NULL DEFAULT ('')
    ,ESPE TEXT NOT NULL DEFAULT ('')
    ,LOCALI TEXT NOT NULL DEFAULT ('')
    ,LAUDO TEXT NOT NULL DEFAULT ('')
    ,TIPINSP TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX RII ON RII ( RI ) ;
ALTER TABLE RII ADD PRIMARY KEY(RI) ;
CREATE INDEX RI ON RII ( RI ) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS RRL (
    RRS INTEGER default 0
    ,CLIENTE INTEGER default 0
    ,CLINOME TEXT NOT NULL DEFAULT ('')
    ,DESENHO TEXT NOT NULL DEFAULT ('')
    ,DESCRI TEXT NOT NULL DEFAULT ('')
    ,INSTRU TEXT NOT NULL DEFAULT ('')
    ,DESCII TEXT NOT NULL DEFAULT ('')
    ,CARAC TEXT NOT NULL DEFAULT ('')
    ,ESPEC TEXT NOT NULL DEFAULT ('')
    ,AVA TEXT NOT NULL DEFAULT ('')
    ,AVB TEXT NOT NULL DEFAULT ('')
    ,AVC TEXT NOT NULL DEFAULT ('')
    ,AVAN INTEGER default 0
    ,AVBN INTEGER default 0
    ,AVCN INTEGER default 0
    ,AMA01 FLOAT  default 0
    ,AMA02 FLOAT  default 0
    ,AMA03 FLOAT  default 0
    ,AMA04 FLOAT  default 0
    ,AMA05 FLOAT  default 0
    ,AMA06 FLOAT  default 0
    ,AMA07 FLOAT  default 0
    ,AMA08 FLOAT  default 0
    ,AMA09 FLOAT  default 0
    ,AMA10 FLOAT  default 0
    ,AMAA01 FLOAT  default 0
    ,AMAA02 FLOAT  default 0
    ,AMAA03 FLOAT  default 0
    ,AMAA04 FLOAT  default 0
    ,AMAA05 FLOAT  default 0
    ,AMAA06 FLOAT  default 0
    ,AMAA07 FLOAT  default 0
    ,AMAA08 FLOAT  default 0
    ,AMAA09 FLOAT  default 0
    ,AMAA10 FLOAT  default 0
    ,AMAAA01 FLOAT  default 0
    ,AMAAA02 FLOAT  default 0
    ,AMAAA03 FLOAT  default 0
    ,AMAAA04 FLOAT  default 0
    ,AMAAA05 FLOAT  default 0
    ,AMAAA06 FLOAT  default 0
    ,AMAAA07 FLOAT  default 0
    ,AMAAA08 FLOAT  default 0
    ,AMAAA09 FLOAT  default 0
    ,AMAAA10 FLOAT  default 0
    ,AMB01 FLOAT  default 0
    ,AMB02 FLOAT  default 0
    ,AMB03 FLOAT  default 0
    ,AMB04 FLOAT  default 0
    ,AMB05 FLOAT  default 0
    ,AMB06 FLOAT  default 0
    ,AMB07 FLOAT  default 0
    ,AMB08 FLOAT  default 0
    ,AMB09 FLOAT  default 0
    ,AMB10 FLOAT  default 0
    ,AMBB01 FLOAT  default 0
    ,AMBB02 FLOAT  default 0
    ,AMBB03 FLOAT  default 0
    ,AMBB04 FLOAT  default 0
    ,AMBB05 FLOAT  default 0
    ,AMBB06 FLOAT  default 0
    ,AMBB07 FLOAT  default 0
    ,AMBB08 FLOAT  default 0
    ,AMBB09 FLOAT  default 0
    ,AMBB10 FLOAT  default 0
    ,AMBBB01 FLOAT  default 0
    ,AMBBB02 FLOAT  default 0
    ,AMBBB03 FLOAT  default 0
    ,AMBBB04 FLOAT  default 0
    ,AMBBB05 FLOAT  default 0
    ,AMBBB06 FLOAT  default 0
    ,AMBBB07 FLOAT  default 0
    ,AMBBB08 FLOAT  default 0
    ,AMBBB09 FLOAT  default 0
    ,AMBBB10 FLOAT  default 0
    ,AMC01 FLOAT  default 0
    ,AMC02 FLOAT  default 0
    ,AMC03 FLOAT  default 0
    ,AMC04 FLOAT  default 0
    ,AMC05 FLOAT  default 0
    ,AMC06 FLOAT  default 0
    ,AMC07 FLOAT  default 0
    ,AMC08 FLOAT  default 0
    ,AMC09 FLOAT  default 0
    ,AMC10 FLOAT  default 0
    ,AMCC01 FLOAT  default 0
    ,AMCC02 FLOAT  default 0
    ,AMCC03 FLOAT  default 0
    ,AMCC04 FLOAT  default 0
    ,AMCC05 FLOAT  default 0
    ,AMCC06 FLOAT  default 0
    ,AMCC07 FLOAT  default 0
    ,AMCC08 FLOAT  default 0
    ,AMCC09 FLOAT  default 0
    ,AMCC10 FLOAT  default 0
    ,AMCCC01 FLOAT  default 0
    ,AMCCC02 FLOAT  default 0
    ,AMCCC03 FLOAT  default 0
    ,AMCCC04 FLOAT  default 0
    ,AMCCC05 FLOAT  default 0
    ,AMCCC06 FLOAT  default 0
    ,AMCCC07 FLOAT  default 0
    ,AMCCC08 FLOAT  default 0
    ,AMCCC09 FLOAT  default 0
    ,AMCCC10 FLOAT  default 0
    ,DIFA01 FLOAT  default 0
    ,DIFA02 FLOAT  default 0
    ,DIFA03 FLOAT  default 0
    ,DIFA04 FLOAT  default 0
    ,DIFA05 FLOAT  default 0
    ,DIFA06 FLOAT  default 0
    ,DIFA07 FLOAT  default 0
    ,DIFA08 FLOAT  default 0
    ,DIFA09 FLOAT  default 0
    ,DIFA10 FLOAT  default 0
    ,DIFB01 FLOAT  default 0
    ,DIFB02 FLOAT  default 0
    ,DIFB03 FLOAT  default 0
    ,DIFB04 FLOAT  default 0
    ,DIFB05 FLOAT  default 0
    ,DIFB06 FLOAT  default 0
    ,DIFB07 FLOAT  default 0
    ,DIFB08 FLOAT  default 0
    ,DIFB09 FLOAT  default 0
    ,DIFB10 FLOAT  default 0
    ,DIFC01 FLOAT  default 0
    ,DIFC02 FLOAT  default 0
    ,DIFC03 FLOAT  default 0
    ,DIFC04 FLOAT  default 0
    ,DIFC05 FLOAT  default 0
    ,DIFC06 FLOAT  default 0
    ,DIFC07 FLOAT  default 0
    ,DIFC08 FLOAT  default 0
    ,DIFC09 FLOAT  default 0
    ,DIFC10 FLOAT  default 0
    ,TOTAA FLOAT  default 0
    ,TOTAB FLOAT  default 0
    ,TOTAC FLOAT  default 0
    ,MEDAA FLOAT  default 0
    ,TOTALA FLOAT  default 0
    ,TOTBA FLOAT  default 0
    ,TOTBB FLOAT  default 0
    ,TOTBC FLOAT  default 0
    ,MEDBB FLOAT  default 0
    ,TOTALB FLOAT  default 0
    ,TOTCA FLOAT  default 0
    ,TOTCB FLOAT  default 0
    ,TOTCC FLOAT  default 0
    ,MEDCC FLOAT  default 0
    ,TOTALC FLOAT  default 0
    ,MEDIA FLOAT  default 0
    ,MEDIB FLOAT  default 0
    ,MEDIC FLOAT  default 0
    ,MEDSOM FLOAT  default 0
    ,MEDMED FLOAT  default 0
    ,DIFMED FLOAT  default 0
    ,VE FLOAT  default 0
    ,VA FLOAT  default 0
    ,RR FLOAT  default 0
    ,VP FLOAT  default 0
    ,VT FLOAT  default 0
    ,PVE FLOAT  default 0
    ,PVA FLOAT  default 0
    ,PRR FLOAT  default 0
    ,DATA DATE NOT NULL DEFAULT ('')
    ,OBS01 TEXT NOT NULL DEFAULT ('')
    ,XMAX FLOAT  default 0
    ,XMIN FLOAT  default 0
    ,RP FLOAT  default 0
    ,RPMAX FLOAT  default 0
    ,RPMIN FLOAT  default 0
    ,M01 FLOAT  default 0
    ,M02 FLOAT  default 0
    ,M03 FLOAT  default 0
    ,M04 FLOAT  default 0
    ,M05 FLOAT  default 0
    ,M06 FLOAT  default 0
    ,M07 FLOAT  default 0
    ,M08 FLOAT  default 0
    ,M09 FLOAT  default 0
    ,M10 FLOAT  default 0
    ,NCP FLOAT  default 0
    ,K01 FLOAT  default 0
    ,K02 FLOAT  default 0
    ,K03 FLOAT  default 0
    ,K04 FLOAT  default 0
    ,PVP FLOAT  default 0
    ,TOLMIN FLOAT  default 0
    ,TOLMAX FLOAT  default 0
    ,NUMASS INTEGER default 0
    ,DATASS DATE NOT NULL DEFAULT ('')
    ,NOMASS TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX RRS ON RRL ( RRS ) ;
ALTER TABLE RRL ADD PRIMARY KEY(RRS) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS RRS (
    RRS INTEGER default 0
    ,CLIENTE INTEGER default 0
    ,CLINOME TEXT NOT NULL DEFAULT ('')
    ,DESENHO TEXT NOT NULL DEFAULT ('')
    ,DESCRI TEXT NOT NULL DEFAULT ('')
    ,INSTRU TEXT NOT NULL DEFAULT ('')
    ,DESCII TEXT NOT NULL DEFAULT ('')
    ,CARAC TEXT NOT NULL DEFAULT ('')
    ,ESPEC TEXT NOT NULL DEFAULT ('')
    ,AVA TEXT NOT NULL DEFAULT ('')
    ,AVB TEXT NOT NULL DEFAULT ('')
    ,AVAN INTEGER default 0
    ,AVBN INTEGER default 0
    ,AMA01 FLOAT  default 0
    ,AMA02 FLOAT  default 0
    ,AMA03 FLOAT  default 0
    ,AMA04 FLOAT  default 0
    ,AMA05 FLOAT  default 0
    ,AMAA01 FLOAT  default 0
    ,AMAA02 FLOAT  default 0
    ,AMAA03 FLOAT  default 0
    ,AMAA04 FLOAT  default 0
    ,AMAA05 FLOAT  default 0
    ,AMB01 FLOAT  default 0
    ,AMB02 FLOAT  default 0
    ,AMB03 FLOAT  default 0
    ,AMB04 FLOAT  default 0
    ,AMB05 FLOAT  default 0
    ,AMBB01 FLOAT  default 0
    ,AMBB02 FLOAT  default 0
    ,AMBB03 FLOAT  default 0
    ,AMBB04 FLOAT  default 0
    ,AMBB05 FLOAT  default 0
    ,DIFA01 FLOAT  default 0
    ,DIFA02 FLOAT  default 0
    ,DIFA03 FLOAT  default 0
    ,DIFA04 FLOAT  default 0
    ,DIFA05 FLOAT  default 0
    ,DIFB01 FLOAT  default 0
    ,DIFB02 FLOAT  default 0
    ,DIFB03 FLOAT  default 0
    ,DIFB04 FLOAT  default 0
    ,DIFB05 FLOAT  default 0
    ,TOTAA FLOAT  default 0
    ,TOTAB FLOAT  default 0
    ,MEDAA FLOAT  default 0
    ,TOTALA FLOAT  default 0
    ,TOTBA FLOAT  default 0
    ,TOTBB FLOAT  default 0
    ,MEDBB FLOAT  default 0
    ,TOTALB FLOAT  default 0
    ,MEDIA FLOAT  default 0
    ,MEDIB FLOAT  default 0
    ,MEDSOM FLOAT  default 0
    ,MEDMED FLOAT  default 0
    ,DIFMED FLOAT  default 0
    ,VE FLOAT  default 0
    ,VA FLOAT  default 0
    ,RR FLOAT  default 0
    ,VP FLOAT  default 0
    ,VT FLOAT  default 0
    ,PRR FLOAT  default 0
    ,DATA DATE NOT NULL DEFAULT ('')
    ,OBS01 TEXT NOT NULL DEFAULT ('')
    ,OBS02 TEXT NOT NULL DEFAULT ('')
    ,RP FLOAT  default 0
    ,M01 FLOAT  default 0
    ,M02 FLOAT  default 0
    ,M03 FLOAT  default 0
    ,M04 FLOAT  default 0
    ,M05 FLOAT  default 0
    ,RPMAX FLOAT  default 0
    ,RPMIN FLOAT  default 0
    ,XMAX FLOAT  default 0
    ,XMIN FLOAT  default 0
    ,K01 FLOAT  default 0
    ,K02 FLOAT  default 0
    ,K03 FLOAT  default 0
    ,TOLMIN FLOAT  default 0
    ,TOLMAX FLOAT  default 0
    ,NUMASS INTEGER default 0
    ,DATASS DATE NOT NULL DEFAULT ('')
    ,NOMASS TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX RRS ON RRS ( RRS ) ;
ALTER TABLE RRS ADD PRIMARY KEY(RRS) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
CREATE TABLE IF NOT EXISTS TEEP (
    TEEP INTEGER default 0
    ,DATA DATE NOT NULL DEFAULT ('')
    ,DESENHO TEXT NOT NULL DEFAULT ('')
    ,CARAC TEXT NOT NULL DEFAULT ('')
    ,CLIENTE INTEGER default 0
    ,CLINOME TEXT NOT NULL DEFAULT ('')
    ,RR TEXT NOT NULL DEFAULT ('')
    ,P1 FLOAT  default 0
    ,PP FLOAT  default 0
    ,PPK FLOAT  default 0
    ,PLAN01 INTEGER default 0
    ,ESTAVEL TEXT NOT NULL DEFAULT ('')
    ,PLAN02 INTEGER default 0
    ,P2 FLOAT  default 0
    ,CP FLOAT  default 0
    ,CPK FLOAT  default 0
    ,PLAN03 INTEGER default 0
    ,ACP INTEGER default 0
    ,AEP INTEGER default 0
    ,ACPATR TEXT NOT NULL DEFAULT ('')
    ,AEPATR TEXT NOT NULL DEFAULT ('')
) ;
CREATE INDEX TEEP ON TEEP ( TEEP ) ;
ALTER TABLE TEEP ADD PRIMARY KEY(TEEP) ;
PRAGMA temp_store = MEMORY ;
PRAGMA cache_size = 2000 ;
PRAGMA journal_mode = WAL ;
PRAGMA synchronous = NORMAL ;
PRAGMA auto_vacuum = INCREMENTAL ;
PRAGMA page_size = 4096 ;
PRAGMA mmap_size = 300000000 ;
PRAGMA busy_timeout = 5000 ;
