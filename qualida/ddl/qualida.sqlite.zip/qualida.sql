--
-- Arquivo gerado com SQLiteStudio v3.4.4 em ter ago 6 17:30:42 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: ac2
CREATE TABLE IF NOT EXISTS [ac2] ([acp] REAL NOT NULL, [data] SHORTDATE NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [desenho] TEXT(24) NOT NULL, [descri] TEXT(40) NOT NULL, [amostra] TEXT(25) NOT NULL, [instru] TEXT(8) NOT NULL, [descii] TEXT(40) NOT NULL, [carac] TEXT(40) NOT NULL, [sumx] REAL NOT NULL, [medx] REAL NOT NULL, [sumr] REAL NOT NULL, [medr] REAL NOT NULL, [min] REAL NOT NULL, [max] REAL NOT NULL, [x01] REAL NOT NULL, [x02] REAL NOT NULL, [x03] REAL NOT NULL, [x04] REAL NOT NULL, [x05] REAL NOT NULL, [x06] REAL NOT NULL, [x07] REAL NOT NULL, [x08] REAL NOT NULL, [x09] REAL NOT NULL, [x10] REAL NOT NULL, [x11] REAL NOT NULL, [x12] REAL NOT NULL, [x13] REAL NOT NULL, [x14] REAL NOT NULL, [x15] REAL NOT NULL, [x16] REAL NOT NULL, [x17] REAL NOT NULL, [x18] REAL NOT NULL, [x19] REAL NOT NULL, [x20] REAL NOT NULL, [x21] REAL NOT NULL, [x22] REAL NOT NULL, [x23] REAL NOT NULL, [x24] REAL NOT NULL, [x25] REAL NOT NULL, [x26] REAL NOT NULL, [x27] REAL NOT NULL, [x28] REAL NOT NULL, [x29] REAL NOT NULL, [x30] REAL NOT NULL, [r01] REAL NOT NULL, [r02] REAL NOT NULL, [r03] REAL NOT NULL, [r04] REAL NOT NULL, [r05] REAL NOT NULL, [r06] REAL NOT NULL, [r07] REAL NOT NULL, [r08] REAL NOT NULL, [r09] REAL NOT NULL, [r10] REAL NOT NULL, [r11] REAL NOT NULL, [r12] REAL NOT NULL, [r13] REAL NOT NULL, [r14] REAL NOT NULL, [r15] REAL NOT NULL, [r16] REAL NOT NULL, [r17] REAL NOT NULL, [r18] REAL NOT NULL, [r19] REAL NOT NULL, [r20] REAL NOT NULL, [r21] REAL NOT NULL, [r22] REAL NOT NULL, [r23] REAL NOT NULL, [r24] REAL NOT NULL, [r25] REAL NOT NULL, [r26] REAL NOT NULL, [r27] REAL NOT NULL, [r28] REAL NOT NULL, [r29] REAL NOT NULL, [r30] REAL NOT NULL, [sigma] REAL NOT NULL, [pp] REAL NOT NULL, [ppka] REAL NOT NULL, [ppkb] REAL NOT NULL, [ppk] REAL NOT NULL, [acd] REAL NOT NULL, [lic] REAL NOT NULL, [lsc] REAL NOT NULL, [rmax] REAL NOT NULL, [rmin] REAL NOT NULL, [xmax] REAL NOT NULL, [xmin] REAL NOT NULL, [desv] REAL NOT NULL, [elanum] REAL NOT NULL, [elanom] TEXT(40) NOT NULL, [eladat] SHORTDATE NOT NULL, [resnum] REAL NOT NULL, [resnom] TEXT(40) NOT NULL, [resdat] SHORTDATE NOT NULL, [forae] REAL NOT NULL, [forax] REAL NOT NULL, [forar] REAL NOT NULL, [rlsc] REAL NOT NULL, [modax] REAL NOT NULL, [modar] REAL NOT NULL, [medix] REAL NOT NULL, [medir] REAL NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [operacao] TEXT(70) NOT NULL, [revd] TEXT(5) NOT NULL, [datar] SHORTDATE NOT NULL, [distnor] TEXT(1) NOT NULL, [obs] TEXT(40) NOT NULL);

-- Tabela: acd
CREATE TABLE IF NOT EXISTS [acd] ([acd] REAL NOT NULL, [data] SHORTDATE NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [desenho] TEXT(24) NOT NULL, [descri] TEXT(40) NOT NULL, [instru] TEXT(5) NOT NULL, [descii] TEXT(25) NOT NULL, [carac] TEXT(40) NOT NULL, [min] REAL NOT NULL, [max] REAL NOT NULL, [conv] BIT NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [operacao] TEXT(70) NOT NULL, [datar] SHORTDATE NOT NULL, [revd] TEXT(5) NOT NULL);

-- Tabela: acdi
CREATE TABLE IF NOT EXISTS [acdi] ([acd] REAL NOT NULL, [val01] REAL NOT NULL, [val02] REAL NOT NULL, [val03] REAL NOT NULL, [val04] REAL NOT NULL, [val05] REAL NOT NULL, [medx] REAL NOT NULL, [valr] REAL NOT NULL, [data] SHORTDATE NOT NULL, [hora] REAL NOT NULL, [acp] REAL NOT NULL, [aep] REAL NOT NULL, [ordem] REAL NOT NULL, [lic] REAL NOT NULL, [lsc] REAL NOT NULL);

-- Tabela: acp
CREATE TABLE IF NOT EXISTS [acp] ([acp] REAL NOT NULL, [data] SHORTDATE NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [desenho] TEXT(24) NOT NULL, [descri] TEXT(40) NOT NULL, [amostra] TEXT(25) NOT NULL, [instru] TEXT(8) NOT NULL, [descii] TEXT(40) NOT NULL, [carac] TEXT(40) NOT NULL, [sumx] REAL NOT NULL, [medx] REAL NOT NULL, [sumr] REAL NOT NULL, [medr] REAL NOT NULL, [min] REAL NOT NULL, [max] REAL NOT NULL, [x01] REAL NOT NULL, [x02] REAL NOT NULL, [x03] REAL NOT NULL, [x04] REAL NOT NULL, [x05] REAL NOT NULL, [x06] REAL NOT NULL, [x07] REAL NOT NULL, [x08] REAL NOT NULL, [x09] REAL NOT NULL, [x10] REAL NOT NULL, [x11] REAL NOT NULL, [x12] REAL NOT NULL, [x13] REAL NOT NULL, [x14] REAL NOT NULL, [x15] REAL NOT NULL, [x16] REAL NOT NULL, [x17] REAL NOT NULL, [x18] REAL NOT NULL, [x19] REAL NOT NULL, [x20] REAL NOT NULL, [x21] REAL NOT NULL, [x22] REAL NOT NULL, [x23] REAL NOT NULL, [x24] REAL NOT NULL, [x25] REAL NOT NULL, [x26] REAL NOT NULL, [x27] REAL NOT NULL, [x28] REAL NOT NULL, [x29] REAL NOT NULL, [x30] REAL NOT NULL, [r01] REAL NOT NULL, [r02] REAL NOT NULL, [r03] REAL NOT NULL, [r04] REAL NOT NULL, [r05] REAL NOT NULL, [r06] REAL NOT NULL, [r07] REAL NOT NULL, [r08] REAL NOT NULL, [r09] REAL NOT NULL, [r10] REAL NOT NULL, [r11] REAL NOT NULL, [r12] REAL NOT NULL, [r13] REAL NOT NULL, [r14] REAL NOT NULL, [r15] REAL NOT NULL, [r16] REAL NOT NULL, [r17] REAL NOT NULL, [r18] REAL NOT NULL, [r19] REAL NOT NULL, [r20] REAL NOT NULL, [r21] REAL NOT NULL, [r22] REAL NOT NULL, [r23] REAL NOT NULL, [r24] REAL NOT NULL, [r25] REAL NOT NULL, [r26] REAL NOT NULL, [r27] REAL NOT NULL, [r28] REAL NOT NULL, [r29] REAL NOT NULL, [r30] REAL NOT NULL, [sigma] REAL NOT NULL, [pp] REAL NOT NULL, [ppka] REAL NOT NULL, [ppkb] REAL NOT NULL, [ppk] REAL NOT NULL, [acd] REAL NOT NULL, [lic] REAL NOT NULL, [lsc] REAL NOT NULL, [rmax] REAL NOT NULL, [rmin] REAL NOT NULL, [xmax] REAL NOT NULL, [xmin] REAL NOT NULL, [desv] REAL NOT NULL, [elanum] REAL NOT NULL, [elanom] TEXT(40) NOT NULL, [eladat] SHORTDATE NOT NULL, [resnum] REAL NOT NULL, [resnom] TEXT(40) NOT NULL, [resdat] SHORTDATE NOT NULL, [forae] REAL NOT NULL, [forax] REAL NOT NULL, [forar] REAL NOT NULL, [rlsc] REAL NOT NULL, [modax] REAL NOT NULL, [modar] REAL NOT NULL, [medix] REAL NOT NULL, [medir] REAL NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [operacao] TEXT(70) NOT NULL, [revd] TEXT(5) NOT NULL, [datar] SHORTDATE NOT NULL, [distnor] TEXT(1) NOT NULL, [obs] TEXT(40) NOT NULL);

-- Tabela: acpr
CREATE TABLE IF NOT EXISTS [acpr] ([acp] REAL NOT NULL, [valor] REAL NOT NULL, [qtde] REAL NOT NULL, [total] REAL NOT NULL);

-- Tabela: acpx
CREATE TABLE IF NOT EXISTS [acpx] ([acp] REAL NOT NULL, [valor] REAL NOT NULL, [qtde] REAL NOT NULL, [total] REAL NOT NULL);

-- Tabela: aepr
CREATE TABLE IF NOT EXISTS [aepr] ([acp] REAL NOT NULL, [valor] REAL NOT NULL, [qtde] REAL NOT NULL, [total] REAL NOT NULL);

-- Tabela: aepx
CREATE TABLE IF NOT EXISTS [aepx] ([acp] REAL NOT NULL, [valor] REAL NOT NULL, [qtde] REAL NOT NULL, [total] REAL NOT NULL);

-- Tabela: ci
CREATE TABLE IF NOT EXISTS [ci] ([ci] REAL NOT NULL, [tipoi] TEXT(1) NOT NULL, [descri] TEXT(40) NOT NULL, [desenho] TEXT(24) NOT NULL, [revd] TEXT(5) NOT NULL, [datad] SHORTDATE NOT NULL, [datar] SHORTDATE NOT NULL, [pedido] TEXT(20) NOT NULL, [ordem] TEXT(20) NOT NULL, [qtl] TEXT(20) NOT NULL, [qti] TEXT(20) NOT NULL, [rastro] TEXT(12) NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [obs01] TEXT(80) NOT NULL, [obs02] TEXT(80) NOT NULL, [laudof] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [insnum] REAL NOT NULL, [insnom] TEXT(40) NOT NULL);

-- Tabela: cic
CREATE TABLE IF NOT EXISTS [cic] ([desenho] TEXT(24) NOT NULL, [descri] TEXT(40) NOT NULL, [datar] SHORTDATE NOT NULL, [datad] SHORTDATE NOT NULL, [revd] TEXT(5) NOT NULL, [cliente] REAL NOT NULL);

-- Tabela: cici
CREATE TABLE IF NOT EXISTS [cici] ([desenho] TEXT(24) NOT NULL, [enc] REAL NOT NULL, [cespe] TEXT(40) NOT NULL, [espe] REAL NOT NULL, [max] REAL NOT NULL, [min] REAL NOT NULL, [und] TEXT(20) NOT NULL, [locali] TEXT(30) NOT NULL);

-- Tabela: cii
CREATE TABLE IF NOT EXISTS [cii] ([ci] REAL NOT NULL, [item] REAL NOT NULL, [desvio] REAL NOT NULL, [enc] REAL NOT NULL, [cenc] TEXT(30) NOT NULL, [cespe] TEXT(40) NOT NULL, [espe] REAL NOT NULL, [max] REAL NOT NULL, [min] REAL NOT NULL, [und] TEXT(20) NOT NULL, [locali] TEXT(30) NOT NULL, [laudo] TEXT(1) NOT NULL);

-- Tabela: crtaum
CREATE TABLE IF NOT EXISTS [crtaum] ([tipo] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [hora] REAL NOT NULL, [valor] REAL NOT NULL, [refctr] TEXT(1) NOT NULL, [sala] TEXT(5) NOT NULL);

-- Tabela: etippp
CREATE TABLE IF NOT EXISTS [etippp] ([numero] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(50) NOT NULL, [sufix] TEXT(5) NOT NULL, [engenha] TEXT(50) NOT NULL);

-- Tabela: gc
CREATE TABLE IF NOT EXISTS [gc] ([gc] REAL NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(40) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [codme01] TEXT(12) NOT NULL, [nomme01] TEXT(40) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [carac] TEXT(50) NOT NULL, [espec] TEXT(30) NOT NULL, [freq] TEXT(10) NOT NULL, [tam] TEXT(10) NOT NULL, [codme04] TEXT(8) NOT NULL, [nomme04] TEXT(40) NOT NULL, [co2me04] TEXT(8) NOT NULL, [no2me04] TEXT(40) NOT NULL, [unidme] TEXT(10) NOT NULL, [refctr] TEXT(1) NOT NULL, [valx] REAL NOT NULL, [lic] REAL NOT NULL, [lsc] REAL NOT NULL, [lie] REAL NOT NULL, [lse] REAL NOT NULL, [vini] REAL NOT NULL, [vdiv] REAL NOT NULL, [valr] REAL NOT NULL, [lscr] REAL NOT NULL, [vdir] REAL NOT NULL, [vmax] REAL NOT NULL, [rmax] REAL NOT NULL, [acp] REAL NOT NULL, [aep] REAL NOT NULL, [obs] TEXT(80) NOT NULL);

-- Tabela: gctem
CREATE TABLE IF NOT EXISTS [gctem] ([item] REAL NOT NULL, [refctr] TEXT(1) NOT NULL);

-- Tabela: gctemp
CREATE TABLE IF NOT EXISTS [gctemp] ([item] REAL NOT NULL, [refctr] TEXT(1) NOT NULL);

-- Tabela: opae
CREATE TABLE IF NOT EXISTS [opae] ([opae] REAL NOT NULL, [cliente] REAL NOT NULL, [data] SHORTDATE NOT NULL, [codigo] TEXT(24) NOT NULL, [rastro] TEXT(15) NOT NULL, [qtde] REAL NOT NULL, [codmp04] REAL NOT NULL);

-- Tabela: opai
CREATE TABLE IF NOT EXISTS [opai] ([opae] REAL NOT NULL, [espec] TEXT(100) NOT NULL, [laudo] TEXT(1) NOT NULL);

-- Tabela: pac
CREATE TABLE IF NOT EXISTS [pac] ([pac] REAL NOT NULL, [acp] REAL NOT NULL, [aep] REAL NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(60) NOT NULL, [codigo] TEXT(24) NOT NULL, [data] SHORTDATE NOT NULL, [nome] TEXT(40) NOT NULL, [especi] TEXT(40) NOT NULL, [carac] TEXT(40) NOT NULL, [instru] TEXT(8) NOT NULL, [descii] TEXT(40) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [equ] TEXT(4) NOT NULL, [nequ] TEXT(40) NOT NULL, [unid] TEXT(2) NOT NULL, [rmin] REAL NOT NULL, [rmax] REAL NOT NULL, [vmax] REAL NOT NULL, [vmin] REAL NOT NULL, [medx] REAL NOT NULL, [pp] REAL NOT NULL, [xmax] REAL NOT NULL, [xmin] REAL NOT NULL, [medr] REAL NOT NULL, [ppk] REAL NOT NULL, [ide01] TEXT(70) NOT NULL, [ide02] TEXT(70) NOT NULL, [ide04] TEXT(70) NOT NULL, [ide03] TEXT(70) NOT NULL, [cav01] TEXT(70) NOT NULL, [cav02] TEXT(70) NOT NULL, [cav03] TEXT(70) NOT NULL, [cav04] TEXT(70) NOT NULL, [aca01] TEXT(70) NOT NULL, [aca02] TEXT(70) NOT NULL, [aca03] TEXT(70) NOT NULL, [aca04] TEXT(70) NOT NULL, [setor] TEXT(20) NOT NULL, [setcod] TEXT(1) NOT NULL, [desseq] TEXT(70) NOT NULL, [valp] REAL NOT NULL, [nxmin] REAL NOT NULL, [nxmax] REAL NOT NULL, [nxmed] REAL NOT NULL, [nrmin] REAL NOT NULL, [nrmax] REAL NOT NULL, [nrmed] REAL NOT NULL, [npp] REAL NOT NULL, [nppk] REAL NOT NULL, [nvalp] REAL NOT NULL, [naep] REAL NOT NULL, [nacp] REAL NOT NULL, [nvmin] REAL NOT NULL, [nvmax] REAL NOT NULL);

-- Tabela: paee
CREATE TABLE IF NOT EXISTS [paee] ([paee] REAL NOT NULL, [data] SHORTDATE NOT NULL, [cliente] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [obs01] TEXT(200) NOT NULL, [obs02] TEXT(200) NOT NULL, [obs03] TEXT(200) NOT NULL);

-- Tabela: paei
CREATE TABLE IF NOT EXISTS [paei] ([desenho] TEXT(24) NOT NULL, [espec] TEXT(100) NOT NULL);

-- Tabela: ri
CREATE TABLE IF NOT EXISTS [ri] ([ri] REAL NOT NULL, [tipoi] TEXT(1) NOT NULL, [tipo2] TEXT(1) NOT NULL, [descri] TEXT(40) NOT NULL, [desenho] TEXT(24) NOT NULL, [revd] TEXT(5) NOT NULL, [datad] SHORTDATE NOT NULL, [datar] SHORTDATE NOT NULL, [pedido] TEXT(20) NOT NULL, [ordem] TEXT(20) NOT NULL, [qtl] TEXT(20) NOT NULL, [qti] TEXT(20) NOT NULL, [rastro] TEXT(10) NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [obs01] TEXT(80) NOT NULL, [obs02] TEXT(80) NOT NULL, [laudof] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [insnum] REAL NOT NULL, [insnom] TEXT(40) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [origem] TEXT(5) NOT NULL, [codigoint] TEXT(24) NOT NULL);

-- Tabela: rii
CREATE TABLE IF NOT EXISTS [rii] ([ri] REAL NOT NULL, [item] REAL NOT NULL, [desvio] TEXT(20) NOT NULL, [enc] TEXT(40) NOT NULL, [espe] TEXT(100) NOT NULL, [locali] TEXT(30) NOT NULL, [laudo] TEXT(1) NOT NULL, [tipinsp] TEXT(1) NOT NULL);

-- Tabela: rrl
CREATE TABLE IF NOT EXISTS [rrl] ([rrs] REAL NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(40) NOT NULL, [desenho] TEXT(24) NOT NULL, [descri] TEXT(40) NOT NULL, [instru] TEXT(8) NOT NULL, [descii] TEXT(20) NOT NULL, [carac] TEXT(25) NOT NULL, [espec] TEXT(25) NOT NULL, [ava] TEXT(40) NOT NULL, [avb] TEXT(40) NOT NULL, [avc] TEXT(40) NOT NULL, [avan] REAL NOT NULL, [avbn] REAL NOT NULL, [avcn] REAL NOT NULL, [ama01] REAL NOT NULL, [ama02] REAL NOT NULL, [ama03] REAL NOT NULL, [ama04] REAL NOT NULL, [ama05] REAL NOT NULL, [ama06] REAL NOT NULL, [ama07] REAL NOT NULL, [ama08] REAL NOT NULL, [ama09] REAL NOT NULL, [ama10] REAL NOT NULL, [amaa01] REAL NOT NULL, [amaa02] REAL NOT NULL, [amaa03] REAL NOT NULL, [amaa04] REAL NOT NULL, [amaa05] REAL NOT NULL, [amaa06] REAL NOT NULL, [amaa07] REAL NOT NULL, [amaa08] REAL NOT NULL, [amaa09] REAL NOT NULL, [amaa10] REAL NOT NULL, [amaaa01] REAL NOT NULL, [amaaa02] REAL NOT NULL, [amaaa03] REAL NOT NULL, [amaaa04] REAL NOT NULL, [amaaa05] REAL NOT NULL, [amaaa06] REAL NOT NULL, [amaaa07] REAL NOT NULL, [amaaa08] REAL NOT NULL, [amaaa09] REAL NOT NULL, [amaaa10] REAL NOT NULL, [amb01] REAL NOT NULL, [amb02] REAL NOT NULL, [amb03] REAL NOT NULL, [amb04] REAL NOT NULL, [amb05] REAL NOT NULL, [amb06] REAL NOT NULL, [amb07] REAL NOT NULL, [amb08] REAL NOT NULL, [amb09] REAL NOT NULL, [amb10] REAL NOT NULL, [ambb01] REAL NOT NULL, [ambb02] REAL NOT NULL, [ambb03] REAL NOT NULL, [ambb04] REAL NOT NULL, [ambb05] REAL NOT NULL, [ambb06] REAL NOT NULL, [ambb07] REAL NOT NULL, [ambb08] REAL NOT NULL, [ambb09] REAL NOT NULL, [ambb10] REAL NOT NULL, [ambbb01] REAL NOT NULL, [ambbb02] REAL NOT NULL, [ambbb03] REAL NOT NULL, [ambbb04] REAL NOT NULL, [ambbb05] REAL NOT NULL, [ambbb06] REAL NOT NULL, [ambbb07] REAL NOT NULL, [ambbb08] REAL NOT NULL, [ambbb09] REAL NOT NULL, [ambbb10] REAL NOT NULL, [amc01] REAL NOT NULL, [amc02] REAL NOT NULL, [amc03] REAL NOT NULL, [amc04] REAL NOT NULL, [amc05] REAL NOT NULL, [amc06] REAL NOT NULL, [amc07] REAL NOT NULL, [amc08] REAL NOT NULL, [amc09] REAL NOT NULL, [amc10] REAL NOT NULL, [amcc01] REAL NOT NULL, [amcc02] REAL NOT NULL, [amcc03] REAL NOT NULL, [amcc04] REAL NOT NULL, [amcc05] REAL NOT NULL, [amcc06] REAL NOT NULL, [amcc07] REAL NOT NULL, [amcc08] REAL NOT NULL, [amcc09] REAL NOT NULL, [amcc10] REAL NOT NULL, [amccc01] REAL NOT NULL, [amccc02] REAL NOT NULL, [amccc03] REAL NOT NULL, [amccc04] REAL NOT NULL, [amccc05] REAL NOT NULL, [amccc06] REAL NOT NULL, [amccc07] REAL NOT NULL, [amccc08] REAL NOT NULL, [amccc09] REAL NOT NULL, [amccc10] REAL NOT NULL, [difa01] REAL NOT NULL, [difa02] REAL NOT NULL, [difa03] REAL NOT NULL, [difa04] REAL NOT NULL, [difa05] REAL NOT NULL, [difa06] REAL NOT NULL, [difa07] REAL NOT NULL, [difa08] REAL NOT NULL, [difa09] REAL NOT NULL, [difa10] REAL NOT NULL, [difb01] REAL NOT NULL, [difb02] REAL NOT NULL, [difb03] REAL NOT NULL, [difb04] REAL NOT NULL, [difb05] REAL NOT NULL, [difb06] REAL NOT NULL, [difb07] REAL NOT NULL, [difb08] REAL NOT NULL, [difb09] REAL NOT NULL, [difb10] REAL NOT NULL, [difc01] REAL NOT NULL, [difc02] REAL NOT NULL, [difc03] REAL NOT NULL, [difc04] REAL NOT NULL, [difc05] REAL NOT NULL, [difc06] REAL NOT NULL, [difc07] REAL NOT NULL, [difc08] REAL NOT NULL, [difc09] REAL NOT NULL, [difc10] REAL NOT NULL, [totaa] REAL NOT NULL, [totab] REAL NOT NULL, [totac] REAL NOT NULL, [medaa] REAL NOT NULL, [totala] REAL NOT NULL, [totba] REAL NOT NULL, [totbb] REAL NOT NULL, [totbc] REAL NOT NULL, [medbb] REAL NOT NULL, [totalb] REAL NOT NULL, [totca] REAL NOT NULL, [totcb] REAL NOT NULL, [totcc] REAL NOT NULL, [medcc] REAL NOT NULL, [totalc] REAL NOT NULL, [media] REAL NOT NULL, [medib] REAL NOT NULL, [medic] REAL NOT NULL, [medsom] REAL NOT NULL, [medmed] REAL NOT NULL, [difmed] REAL NOT NULL, [ve] REAL NOT NULL, [va] REAL NOT NULL, [rr] REAL NOT NULL, [vp] REAL NOT NULL, [vt] REAL NOT NULL, [pve] REAL NOT NULL, [pva] REAL NOT NULL, [prr] REAL NOT NULL, [data] SHORTDATE NOT NULL, [obs01] TEXT(50) NOT NULL, [xmax] REAL NOT NULL, [xmin] REAL NOT NULL, [rp] REAL NOT NULL, [rpmax] REAL NOT NULL, [rpmin] REAL NOT NULL, [m01] REAL NOT NULL, [m02] REAL NOT NULL, [m03] REAL NOT NULL, [m04] REAL NOT NULL, [m05] REAL NOT NULL, [m06] REAL NOT NULL, [m07] REAL NOT NULL, [m08] REAL NOT NULL, [m09] REAL NOT NULL, [m10] REAL NOT NULL, [ncp] REAL NOT NULL, [k01] REAL NOT NULL, [k02] REAL NOT NULL, [k03] REAL NOT NULL, [k04] REAL NOT NULL, [pvp] REAL NOT NULL, [tolmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [numass] REAL NOT NULL, [datass] SHORTDATE NOT NULL, [nomass] TEXT(40) NOT NULL);

-- Tabela: rrs
CREATE TABLE IF NOT EXISTS [rrs] ([rrs] REAL NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(40) NOT NULL, [desenho] TEXT(24) NOT NULL, [descri] TEXT(40) NOT NULL, [instru] TEXT(8) NOT NULL, [descii] TEXT(25) NOT NULL, [carac] TEXT(40) NOT NULL, [espec] TEXT(40) NOT NULL, [ava] TEXT(40) NOT NULL, [avb] TEXT(40) NOT NULL, [avan] REAL NOT NULL, [avbn] REAL NOT NULL, [ama01] REAL NOT NULL, [ama02] REAL NOT NULL, [ama03] REAL NOT NULL, [ama04] REAL NOT NULL, [ama05] REAL NOT NULL, [amaa01] REAL NOT NULL, [amaa02] REAL NOT NULL, [amaa03] REAL NOT NULL, [amaa04] REAL NOT NULL, [amaa05] REAL NOT NULL, [amb01] REAL NOT NULL, [amb02] REAL NOT NULL, [amb03] REAL NOT NULL, [amb04] REAL NOT NULL, [amb05] REAL NOT NULL, [ambb01] REAL NOT NULL, [ambb02] REAL NOT NULL, [ambb03] REAL NOT NULL, [ambb04] REAL NOT NULL, [ambb05] REAL NOT NULL, [difa01] REAL NOT NULL, [difa02] REAL NOT NULL, [difa03] REAL NOT NULL, [difa04] REAL NOT NULL, [difa05] REAL NOT NULL, [difb01] REAL NOT NULL, [difb02] REAL NOT NULL, [difb03] REAL NOT NULL, [difb04] REAL NOT NULL, [difb05] REAL NOT NULL, [totaa] REAL NOT NULL, [totab] REAL NOT NULL, [medaa] REAL NOT NULL, [totala] REAL NOT NULL, [totba] REAL NOT NULL, [totbb] REAL NOT NULL, [medbb] REAL NOT NULL, [totalb] REAL NOT NULL, [media] REAL NOT NULL, [medib] REAL NOT NULL, [medsom] REAL NOT NULL, [medmed] REAL NOT NULL, [difmed] REAL NOT NULL, [ve] REAL NOT NULL, [va] REAL NOT NULL, [rr] REAL NOT NULL, [vp] REAL NOT NULL, [vt] REAL NOT NULL, [prr] REAL NOT NULL, [data] SHORTDATE NOT NULL, [obs01] TEXT(50) NOT NULL, [obs02] TEXT(50) NOT NULL, [rp] REAL NOT NULL, [m01] REAL NOT NULL, [m02] REAL NOT NULL, [m03] REAL NOT NULL, [m04] REAL NOT NULL, [m05] REAL NOT NULL, [rpmax] REAL NOT NULL, [rpmin] REAL NOT NULL, [xmax] REAL NOT NULL, [xmin] REAL NOT NULL, [k01] REAL NOT NULL, [k02] REAL NOT NULL, [k03] REAL NOT NULL, [tolmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [numass] REAL NOT NULL, [datass] SHORTDATE NOT NULL, [nomass] TEXT(40) NOT NULL);

-- Tabela: teep
CREATE TABLE IF NOT EXISTS [teep] ([teep] REAL NOT NULL, [data] SHORTDATE NOT NULL, [desenho] TEXT(24) NOT NULL, [carac] TEXT(40) NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [rr] TEXT(1) NOT NULL, [p1] REAL NOT NULL, [pp] REAL NOT NULL, [ppk] REAL NOT NULL, [plan01] REAL NOT NULL, [estavel] TEXT(1) NOT NULL, [plan02] REAL NOT NULL, [p2] REAL NOT NULL, [cp] REAL NOT NULL, [cpk] REAL NOT NULL, [plan03] REAL NOT NULL, [acp] REAL NOT NULL, [aep] REAL NOT NULL, [acpatr] TEXT(1) NOT NULL, [aepatr] TEXT(1) NOT NULL);

-- �ndice: idx_ac2_acd
CREATE INDEX IF NOT EXISTS [idx_ac2_acd] ON [ac2] ([acd]);

-- �ndice: idx_ac2_acp
CREATE INDEX IF NOT EXISTS [idx_ac2_acp] ON [ac2] ([acp]);

-- �ndice: idx_acd_acd
CREATE INDEX IF NOT EXISTS [idx_acd_acd] ON [acd] ([acd]);

-- �ndice: idx_acdi_acdi
CREATE INDEX IF NOT EXISTS [idx_acdi_acdi] ON [acdi] ([acd]);

-- �ndice: idx_acdi_acdi-2
CREATE INDEX IF NOT EXISTS [idx_acdi_acdi-2] ON [acdi] ([acd], [data], [hora]);

-- �ndice: idx_acdi_acdi-3
CREATE INDEX IF NOT EXISTS [idx_acdi_acdi-3] ON [acdi] ([acp]);

-- �ndice: idx_acdi_acdi-4
CREATE INDEX IF NOT EXISTS [idx_acdi_acdi-4] ON [acdi] ([aep]);

-- �ndice: idx_acp_acd
CREATE INDEX IF NOT EXISTS [idx_acp_acd] ON [acp] ([acd]);

-- �ndice: idx_acp_acp
CREATE INDEX IF NOT EXISTS [idx_acp_acp] ON [acp] ([acp]);

-- �ndice: idx_acpr_acp
CREATE INDEX IF NOT EXISTS [idx_acpr_acp] ON [acpr] ([acp]);

-- �ndice: idx_acpr_acpvalor
CREATE INDEX IF NOT EXISTS [idx_acpr_acpvalor] ON [acpr] ([acp], [valor]);

-- �ndice: idx_acpx_acp
CREATE INDEX IF NOT EXISTS [idx_acpx_acp] ON [acpx] ([acp]);

-- �ndice: idx_acpx_acpvalor
CREATE INDEX IF NOT EXISTS [idx_acpx_acpvalor] ON [acpx] ([acp], [valor]);

-- �ndice: idx_aepr_acp
CREATE INDEX IF NOT EXISTS [idx_aepr_acp] ON [aepr] ([acp]);

-- �ndice: idx_aepr_acpvalor
CREATE INDEX IF NOT EXISTS [idx_aepr_acpvalor] ON [aepr] ([acp], [valor]);

-- �ndice: idx_aepx_acp
CREATE INDEX IF NOT EXISTS [idx_aepx_acp] ON [aepx] ([acp]);

-- �ndice: idx_aepx_acpvalor
CREATE INDEX IF NOT EXISTS [idx_aepx_acpvalor] ON [aepx] ([acp], [valor]);

-- �ndice: idx_ci_ci
CREATE INDEX IF NOT EXISTS [idx_ci_ci] ON [ci] ([ci]);

-- �ndice: idx_cic_desenho
CREATE INDEX IF NOT EXISTS [idx_cic_desenho] ON [cic] ([desenho]);

-- �ndice: idx_cici_desenho
CREATE INDEX IF NOT EXISTS [idx_cici_desenho] ON [cici] ([desenho]);

-- �ndice: idx_cii_ci
CREATE INDEX IF NOT EXISTS [idx_cii_ci] ON [cii] ([ci]);

-- �ndice: idx_crtaum_data
CREATE INDEX IF NOT EXISTS [idx_crtaum_data] ON [crtaum] ([data]);

-- �ndice: idx_crtaum_refctr
CREATE INDEX IF NOT EXISTS [idx_crtaum_refctr] ON [crtaum] ([refctr]);

-- �ndice: idx_gc_gc
CREATE INDEX IF NOT EXISTS [idx_gc_gc] ON [gc] ([gc]);

-- �ndice: idx_gc_refctr
CREATE INDEX IF NOT EXISTS [idx_gc_refctr] ON [gc] ([refctr]);

-- �ndice: idx_gctem_refctr
CREATE INDEX IF NOT EXISTS [idx_gctem_refctr] ON [gctem] ([refctr]);

-- �ndice: idx_gctemp_item
CREATE INDEX IF NOT EXISTS [idx_gctemp_item] ON [gctemp] ([item]);

-- �ndice: idx_gctemp_refctr
CREATE INDEX IF NOT EXISTS [idx_gctemp_refctr] ON [gctemp] ([refctr]);

-- �ndice: idx_opae_opae
CREATE INDEX IF NOT EXISTS [idx_opae_opae] ON [opae] ([opae]);

-- �ndice: idx_pac_pac
CREATE INDEX IF NOT EXISTS [idx_pac_pac] ON [pac] ([pac]);

-- �ndice: idx_paee_paee
CREATE INDEX IF NOT EXISTS [idx_paee_paee] ON [paee] ([paee]);

-- �ndice: idx_paei_paei
CREATE INDEX IF NOT EXISTS [idx_paei_paei] ON [paei] ([desenho]);

-- �ndice: idx_ri_ri
CREATE INDEX IF NOT EXISTS [idx_ri_ri] ON [ri] ([ri]);

-- �ndice: idx_rii_ri
CREATE INDEX IF NOT EXISTS [idx_rii_ri] ON [rii] ([ri]);

-- �ndice: idx_rii_rii
CREATE INDEX IF NOT EXISTS [idx_rii_rii] ON [rii] ([ri]);

-- �ndice: idx_rrl_rrs
CREATE INDEX IF NOT EXISTS [idx_rrl_rrs] ON [rrl] ([rrs]);

-- �ndice: idx_rrs_rrs
CREATE INDEX IF NOT EXISTS [idx_rrs_rrs] ON [rrs] ([rrs]);

-- �ndice: idx_teep
CREATE INDEX IF NOT EXISTS [idx_teep] ON [teep] ([teep]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
