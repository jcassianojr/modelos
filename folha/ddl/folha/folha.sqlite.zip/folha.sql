--
-- Arquivo gerado com SQLiteStudio v3.4.4 em ter ago 6 17:28:25 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: aci_cep
CREATE TABLE IF NOT EXISTS [aci_cep] ([cep] TEXT(8) NOT NULL);

-- Tabela: agenda
CREATE TABLE IF NOT EXISTS [agenda] ([cddata] SHORTDATE NOT NULL, [obs1] TEXT(60) NOT NULL, [obs2] TEXT(60) NOT NULL, [obs3] TEXT(60) NOT NULL, [obs4] TEXT(60) NOT NULL, [obs5] TEXT(60) NOT NULL, [obs6] TEXT(60) NOT NULL, [obs7] TEXT(60) NOT NULL, [obs8] TEXT(60) NOT NULL);

-- Tabela: agupel
CREATE TABLE IF NOT EXISTS [agupel] ([tip] TEXT(1) NOT NULL, [depto] REAL NOT NULL, [setor] REAL NOT NULL, [secao] REAL NOT NULL, [nomec] TEXT(15) NOT NULL, [tot01] REAL NOT NULL, [pes01] REAL NOT NULL, [tot02] REAL NOT NULL, [pes02] REAL NOT NULL, [tot03] REAL NOT NULL, [pes03] REAL NOT NULL, [qua01] REAL NOT NULL, [qua02] REAL NOT NULL, [pes04] REAL NOT NULL, [qua03] REAL NOT NULL, [pes05] REAL NOT NULL, [qua04] REAL NOT NULL, [qua05] REAL NOT NULL, [tot04] REAL NOT NULL, [pes06] REAL NOT NULL, [tot05] REAL NOT NULL, [tot06] REAL NOT NULL, [tot07] REAL NOT NULL, [tot08] REAL NOT NULL);

-- Tabela: ajuger
CREATE TABLE IF NOT EXISTS [ajuger] ([depto] REAL NOT NULL, [setor] REAL NOT NULL, [secao] REAL NOT NULL, [nome] TEXT(15) NOT NULL, [controle] REAL NOT NULL, [salario] REAL NOT NULL, [qt1] REAL NOT NULL, [vl1] REAL NOT NULL, [qt2] REAL NOT NULL, [vl2] REAL NOT NULL, [qt3] REAL NOT NULL, [vl3] REAL NOT NULL, [qt4] REAL NOT NULL, [vl4] REAL NOT NULL, [qt5] REAL NOT NULL, [vl5] REAL NOT NULL, [adm] REAL NOT NULL, [dem] REAL NOT NULL, [turn] REAL NOT NULL, [ati] REAL NOT NULL);

-- Tabela: apudepto
CREATE TABLE IF NOT EXISTS [apudepto] ([depto] REAL NOT NULL, [secao] REAL NOT NULL, [setor] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL);

-- Tabela: assmed
CREATE TABLE IF NOT EXISTS [assmed] ([mes] REAL NOT NULL, [ano] REAL NOT NULL, [mesext] TEXT(10) NOT NULL, [desct] REAL NOT NULL, [desctb] REAL NOT NULL, [desctc] REAL NOT NULL, [desctd] REAL NOT NULL, [descte] REAL NOT NULL);

-- Tabela: assodo
CREATE TABLE IF NOT EXISTS [assodo] ([mes] REAL NOT NULL, [ano] REAL NOT NULL, [mesext] TEXT(10) NOT NULL, [desct] REAL NOT NULL, [desctb] REAL NOT NULL, [desctc] REAL NOT NULL, [desctd] REAL NOT NULL, [descte] REAL NOT NULL);

-- Tabela: bcofgts
CREATE TABLE IF NOT EXISTS [bcofgts] ([emp] REAL NOT NULL, [numero] TEXT(3) NOT NULL, [nome] TEXT(30) NOT NULL, [agencia] TEXT(4) NOT NULL, [divagenci] TEXT(1) NOT NULL, [agencta] TEXT(9) NOT NULL, [nomeagenc] TEXT(30) NOT NULL, [cidade] TEXT(40) NOT NULL, [uf] TEXT(2) NOT NULL, [codemp] TEXT(4) NOT NULL, [sequencia] TEXT(7) NOT NULL, [unidade] TEXT(15) NOT NULL, [unigr] TEXT(5) NOT NULL, [conta] TEXT(15) NOT NULL, [codempdv] TEXT(1) NOT NULL, [sequendv] TEXT(1) NOT NULL, [tipoemp] TEXT(1) NOT NULL, [endereco] TEXT(30) NOT NULL, [numeroemp] TEXT(6) NOT NULL, [complemen] TEXT(15) NOT NULL, [truncar] TEXT(1) NOT NULL, [trunca2] TEXT(1) NOT NULL);

-- Tabela: caged
CREATE TABLE IF NOT EXISTS [caged] ([codigo] TEXT(2) NOT NULL, [descricao] TEXT(50) NOT NULL, [tipo] TEXT(1) NOT NULL);

-- Tabela: cartorio
CREATE TABLE IF NOT EXISTS [cartorio] ([codigo] TEXT(6) NOT NULL, [ibge] TEXT(7) NOT NULL, [nome] TEXT(240) NOT NULL);

-- Tabela: cbocnv
CREATE TABLE IF NOT EXISTS [cbocnv] ([cboold] TEXT(5) NOT NULL, [cbonew] TEXT(6) NOT NULL);

-- Tabela: cccor
CREATE TABLE IF NOT EXISTS [cccor] ([codigo] REAL NOT NULL, [descr] TEXT(35) NOT NULL, [co_his] REAL NOT NULL, [co_hisn] TEXT(70) NOT NULL, [co_cod] TEXT(13) NOT NULL, [co_codd] TEXT(13) NOT NULL, [co_codr] REAL NOT NULL, [co_codrd] REAL NOT NULL, [co_codn] TEXT(40) NOT NULL, [numemp] REAL NOT NULL);

-- Tabela: ccesp
CREATE TABLE IF NOT EXISTS [ccesp] ([codigo] REAL NOT NULL, [descr] TEXT(35) NOT NULL, [co_his] REAL NOT NULL, [co_hisn] TEXT(70) NOT NULL, [co_cod] TEXT(13) NOT NULL, [co_codd] TEXT(13) NOT NULL, [co_codr] REAL NOT NULL, [co_codrd] REAL NOT NULL, [co_codn] TEXT(40) NOT NULL, [numemp] REAL NOT NULL, [tipo] TEXT(1) NOT NULL, [arquivo] TEXT(8) NOT NULL, [campo] TEXT(10) NOT NULL);

-- Tabela: cid
CREATE TABLE IF NOT EXISTS [cid] ([codigo] TEXT(4) NOT NULL, [cat] TEXT(1) NOT NULL, [nome] TEXT(50) NOT NULL);

-- Tabela: cidgrupo
CREATE TABLE IF NOT EXISTS [cidgrupo] ([codigo] TEXT(10) NOT NULL, [nome] TEXT(100) NOT NULL);

-- Tabela: cnaecnv
CREATE TABLE IF NOT EXISTS [cnaecnv] ([cnae2] TEXT(7) NOT NULL, [descr2] TEXT(150) NOT NULL, [cnae1] TEXT(7) NOT NULL, [descr1] TEXT(150) NOT NULL, [seq] TEXT(1) NOT NULL);

-- Tabela: codfgts
CREATE TABLE IF NOT EXISTS [codfgts] ([codigo] TEXT(3) NOT NULL, [nome] TEXT(254) NOT NULL, [ictomador] TEXT(1) NOT NULL, [icrecfgts] TEXT(1) NOT NULL, [icrecinss] TEXT(1) NOT NULL, [icexclfgts] TEXT(1) NOT NULL, [icparcfgts] TEXT(1) NOT NULL, [iccodpgto] TEXT(1) NOT NULL, [iccafvi] TEXT(1) NOT NULL, [iccafoe] TEXT(1) NOT NULL, [iccaprvi] TEXT(1) NOT NULL, [iccaproe] TEXT(1) NOT NULL, [iccaedvi] TEXT(1) NOT NULL, [icinss13] TEXT(1) NOT NULL, [iccompensa] TEXT(1) NOT NULL, [icsalfami] TEXT(1) NOT NULL, [icoutinfo] TEXT(1) NOT NULL, [icoutinfop] TEXT(1) NOT NULL, [icprdrulpf] TEXT(1) NOT NULL, [icprdrulpj] TEXT(1) NOT NULL, [icrcvnddes] TEXT(1) NOT NULL, [icdd13sges] TEXT(1) NOT NULL, [icddsges] TEXT(1) NOT NULL, [iccentral] TEXT(1) NOT NULL, [icsimples] TEXT(1) NOT NULL, [icvrreten] TEXT(1) NOT NULL, [icfattom] TEXT(1) NOT NULL, [iccoptrab] TEXT(1) NOT NULL, [reg00] TEXT(1) NOT NULL, [reg01] TEXT(1) NOT NULL, [reg10] TEXT(1) NOT NULL, [reg11] TEXT(1) NOT NULL, [reg12] TEXT(1) NOT NULL, [reg13] TEXT(1) NOT NULL, [reg14] TEXT(1) NOT NULL, [reg20] TEXT(1) NOT NULL, [reg30] TEXT(1) NOT NULL, [reg31] TEXT(1) NOT NULL, [reg32] TEXT(1) NOT NULL, [reg70] TEXT(1) NOT NULL, [reg80] TEXT(1) NOT NULL, [reg90] TEXT(1) NOT NULL, [icmodoper] TEXT(1) NOT NULL, [corclpeadm] TEXT(3) NOT NULL);

-- Tabela: codirrf
CREATE TABLE IF NOT EXISTS [codirrf] ([codigo] TEXT(4) NOT NULL, [nome] TEXT(100) NOT NULL, [valpessoa] TEXT(1) NOT NULL);

-- Tabela: configu
CREATE TABLE IF NOT EXISTS [configu] ([temp] REAL NOT NULL, [impre] TEXT(1) NOT NULL, [drive] TEXT(1) NOT NULL, [monitor] TEXT(1) NOT NULL, [cursor] REAL NOT NULL, [ver] TEXT(100) NOT NULL, [vol] TEXT(100) NOT NULL, [dult] TEXT(8) NOT NULL, [drv] TEXT(1) NOT NULL, [dir] TEXT(40) NOT NULL, [ndir] TEXT(5) NOT NULL, [ndos] TEXT(5) NOT NULL, [ntot] TEXT(5) NOT NULL, [ndrv] TEXT(5) NOT NULL, [nemp] TEXT(5) NOT NULL, [nset] TEXT(10) NOT NULL, [dfim] TEXT(8) NOT NULL, [raiz01] REAL NOT NULL, [raiz02] REAL NOT NULL, [raiz03] REAL NOT NULL, [raiz04] REAL NOT NULL, [raiz05] REAL NOT NULL, [raiz06] REAL NOT NULL, [raiz07] REAL NOT NULL, [raiz08] REAL NOT NULL, [raiz09] REAL NOT NULL, [raiz10] REAL NOT NULL, [raiz11] REAL NOT NULL, [raiz12] REAL NOT NULL, [urvabr] REAL NOT NULL, [urvmai] REAL NOT NULL, [urvjun] REAL NOT NULL, [urvmar] REAL NOT NULL, [fffe01] REAL NOT NULL, [fffe02] REAL NOT NULL, [fffe03] REAL NOT NULL, [fffe04] REAL NOT NULL, [fffe05] REAL NOT NULL, [fffe06] REAL NOT NULL, [fffe07] REAL NOT NULL, [fffe08] REAL NOT NULL, [fffe09] REAL NOT NULL, [fffe10] REAL NOT NULL, [fffe11] REAL NOT NULL, [fffe12] REAL NOT NULL, [moeda01] TEXT(20) NOT NULL, [moeda02] TEXT(20) NOT NULL, [moeda03] TEXT(20) NOT NULL, [moeda04] TEXT(20) NOT NULL, [moeda05] TEXT(20) NOT NULL, [moeda06] TEXT(20) NOT NULL, [dirf01] REAL NOT NULL, [dirf02] REAL NOT NULL, [dirf03] REAL NOT NULL, [dirf04] REAL NOT NULL, [dirf05] REAL NOT NULL, [dirf06] REAL NOT NULL, [dirf07] REAL NOT NULL, [dirf08] REAL NOT NULL, [dirf09] REAL NOT NULL, [dirf10] REAL NOT NULL, [dirf11] REAL NOT NULL, [dirf12] REAL NOT NULL, [dire] TEXT(60) NOT NULL, [dirc] TEXT(60) NOT NULL, [dirp] TEXT(60) NOT NULL, [diri] TEXT(60) NOT NULL, [dira] TEXT(60) NOT NULL, [dirb] TEXT(60) NOT NULL);

-- Tabela: contas
CREATE TABLE IF NOT EXISTS [contas] ([codigo] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [guia_iapas] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [sal_13] REAL NOT NULL, [raiz] REAL NOT NULL, [demissao] REAL NOT NULL, [descr] TEXT(35) NOT NULL, [tipo] REAL NOT NULL, [valor] REAL NOT NULL, [nivel_13] REAL NOT NULL, [nivel_dem] REAL NOT NULL, [irendimen] REAL NOT NULL, [nrendimen] REAL NOT NULL, [ferias] REAL NOT NULL, [nivel_feri] REAL NOT NULL, [res] REAL NOT NULL, [posrec] REAL NOT NULL, [prfer] REAL NOT NULL, [prfco] REAL NOT NULL, [prres] REAL NOT NULL, [trfer] REAL NOT NULL, [trres] REAL NOT NULL, [resg] REAL NOT NULL, [selffe] TEXT(1) NOT NULL, [selecao] REAL NOT NULL, [grat] REAL NOT NULL, [tr13s1] REAL NOT NULL, [tr13s2] REAL NOT NULL, [tr13sc] REAL NOT NULL, [trfco] REAL NOT NULL, [irrf13] REAL NOT NULL, [inss13] REAL NOT NULL, [fgts13] REAL NOT NULL, [co_cod] TEXT(13) NOT NULL, [co_codn] TEXT(40) NOT NULL, [co_codr] REAL NOT NULL, [co_his] REAL NOT NULL, [co_hisn] TEXT(70) NOT NULL, [co_codd] TEXT(13) NOT NULL, [co_codrd] REAL NOT NULL, [fat01] REAL NOT NULL, [fat02] REAL NOT NULL, [fat03] REAL NOT NULL, [fat04] REAL NOT NULL, [fat05] REAL NOT NULL, [fat06] REAL NOT NULL, [fat07] REAL NOT NULL, [fat08] REAL NOT NULL, [fat09] REAL NOT NULL, [fat10] REAL NOT NULL, [fat11] REAL NOT NULL, [fat12] REAL NOT NULL, [aceite] TEXT(1) NOT NULL, [liscon] TEXT(1) NOT NULL, [basered] REAL NOT NULL, [baseredi] REAL NOT NULL, [baserir] REAL NOT NULL, [iper] REAL NOT NULL, [natrubr] REAL NOT NULL, [tprubr] REAL NOT NULL, [codinccp] REAL NOT NULL, [codincirrf] REAL NOT NULL, [codincfgts] REAL NOT NULL, [codincsind] REAL NOT NULL, [repdsr] TEXT(1) NOT NULL, [rep13] TEXT(1) NOT NULL, [repferias] TEXT(1) NOT NULL, [repaviso] TEXT(1) NOT NULL, [fatorrubr] REAL NOT NULL);

-- Tabela: ctarpa
CREATE TABLE IF NOT EXISTS [ctarpa] ([codigo] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [guia_iapas] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [sal_13] REAL NOT NULL, [raiz] REAL NOT NULL, [demissao] REAL NOT NULL, [descr] TEXT(35) NOT NULL, [tipo] REAL NOT NULL, [valor] REAL NOT NULL, [nivel_13] REAL NOT NULL, [nivel_dem] REAL NOT NULL, [irendimen] REAL NOT NULL, [nrendimen] REAL NOT NULL, [ferias] REAL NOT NULL, [nivel_feri] REAL NOT NULL, [res] REAL NOT NULL, [prfer] REAL NOT NULL, [prfco] REAL NOT NULL, [prres] REAL NOT NULL, [trfer] REAL NOT NULL, [trres] REAL NOT NULL, [resg] REAL NOT NULL, [selffe] TEXT(1) NOT NULL, [selecao] REAL NOT NULL, [grat] REAL NOT NULL, [tr13s1] REAL NOT NULL, [tr13s2] REAL NOT NULL, [tr13sc] REAL NOT NULL, [trfco] REAL NOT NULL, [irrf13] REAL NOT NULL, [inss13] REAL NOT NULL, [fgts13] REAL NOT NULL, [co_cod] TEXT(13) NOT NULL, [co_codn] TEXT(40) NOT NULL, [co_codr] REAL NOT NULL, [co_his] REAL NOT NULL, [co_hisn] TEXT(70) NOT NULL, [co_codd] TEXT(13) NOT NULL, [co_codrd] REAL NOT NULL, [fat01] REAL NOT NULL, [fat02] REAL NOT NULL, [fat03] REAL NOT NULL, [fat04] REAL NOT NULL, [fat05] REAL NOT NULL, [fat06] REAL NOT NULL, [fat07] REAL NOT NULL, [fat08] REAL NOT NULL, [fat09] REAL NOT NULL, [fat10] REAL NOT NULL, [fat11] REAL NOT NULL, [fat12] REAL NOT NULL, [aceite] TEXT(1) NOT NULL, [basered] REAL NOT NULL, [baseredi] REAL NOT NULL, [baserir] REAL NOT NULL, [iper] REAL NOT NULL, [natrubr] REAL NOT NULL, [tprubr] REAL NOT NULL, [codinccp] REAL NOT NULL, [codincirrf] REAL NOT NULL, [codincfgts] REAL NOT NULL, [codincsind] REAL NOT NULL, [repdsr] TEXT(1) NOT NULL, [rep13] TEXT(1) NOT NULL, [repferias] TEXT(1) NOT NULL, [repaviso] TEXT(1) NOT NULL, [fatorrubr] REAL NOT NULL);

-- Tabela: depto
CREATE TABLE IF NOT EXISTS [depto] ([depto] REAL NOT NULL, [secao] REAL NOT NULL, [setor] REAL NOT NULL, [nome] TEXT(40) NOT NULL, [controle] REAL NOT NULL, [control2] REAL NOT NULL, [control3] REAL NOT NULL, [nomer] TEXT(25) NOT NULL, [nomec] TEXT(15) NOT NULL, [fpas] TEXT(3) NOT NULL, [codsat] TEXT(7) NOT NULL, [totlab] REAL NOT NULL, [totaut] REAL NOT NULL, [txseg] REAL NOT NULL, [txemp] REAL NOT NULL, [txter] REAL NOT NULL, [totbas] REAL NOT NULL, [totrec] REAL NOT NULL, [totded] REAL NOT NULL, [totfun] REAL NOT NULL, [totadi] REAL NOT NULL, [ccusto] REAL NOT NULL, [unifun] TEXT(10) NOT NULL, [modireta] TEXT(1) NOT NULL);

-- Tabela: diskrel1
CREATE TABLE IF NOT EXISTS [diskrel1] ([nome] TEXT(6) NOT NULL, [seq] REAL NOT NULL, [lin] REAL NOT NULL, [col] REAL NOT NULL, [diz] TEXT(90) NOT NULL);

-- Tabela: diskrela
CREATE TABLE IF NOT EXISTS [diskrela] ([codigo] TEXT(12) NOT NULL, [descricao] TEXT(32) NOT NULL, [tipo] TEXT(2) NOT NULL, [rep] REAL NOT NULL, [arquivo] TEXT(50) NOT NULL, [arquivoq] TEXT(50) NOT NULL, [filtro] TEXT(70) NOT NULL, [filtroq] TEXT(70) NOT NULL, [setup] TEXT(70) NOT NULL, [memoria1] TEXT(6) NOT NULL, [memoria2] TEXT(6) NOT NULL, [memoria3] TEXT(6) NOT NULL, [lista] TEXT(6) NOT NULL, [listac] TEXT(6) NOT NULL, [listar] TEXT(6) NOT NULL, [listaq] TEXT(6) NOT NULL, [lcab] REAL NOT NULL, [lcot] REAL NOT NULL, [lrod] REAL NOT NULL, [lque] REAL NOT NULL, [associa1] TEXT(6) NOT NULL, [associa2] TEXT(6) NOT NULL, [associa3] TEXT(6) NOT NULL, [variavel1] TEXT(6) NOT NULL, [variavel2] TEXT(6) NOT NULL, [variavel3] TEXT(6) NOT NULL, [totais1] TEXT(6) NOT NULL, [totais2] TEXT(6) NOT NULL, [totais3] TEXT(6) NOT NULL, [grupo] TEXT(6) NOT NULL, [gravarem] TEXT(12) NOT NULL);

-- Tabela: diskrelm
CREATE TABLE IF NOT EXISTS [diskrelm] ([nome] TEXT(6) NOT NULL, [m01] TEXT(70) NOT NULL, [m02] TEXT(70) NOT NULL, [m03] TEXT(70) NOT NULL, [m04] TEXT(70) NOT NULL, [m05] TEXT(70) NOT NULL, [m06] TEXT(70) NOT NULL, [m07] TEXT(70) NOT NULL, [m08] TEXT(70) NOT NULL, [m09] TEXT(70) NOT NULL, [m10] TEXT(70) NOT NULL);

-- Tabela: diskrels
CREATE TABLE IF NOT EXISTS [diskrels] ([nome] TEXT(6) NOT NULL, [m01] TEXT(65) NOT NULL, [m02] TEXT(65) NOT NULL, [m03] TEXT(65) NOT NULL, [m04] TEXT(65) NOT NULL, [m05] TEXT(65) NOT NULL, [m06] TEXT(65) NOT NULL, [m07] TEXT(65) NOT NULL, [m08] TEXT(65) NOT NULL, [m09] TEXT(65) NOT NULL, [m10] TEXT(65) NOT NULL, [v01] REAL NOT NULL, [v02] REAL NOT NULL, [v03] REAL NOT NULL, [v04] REAL NOT NULL, [v05] REAL NOT NULL, [v06] REAL NOT NULL, [v07] REAL NOT NULL, [v08] REAL NOT NULL, [v09] REAL NOT NULL, [v10] REAL NOT NULL);

-- Tabela: escalpad
CREATE TABLE IF NOT EXISTS [escalpad] ([seq] REAL NOT NULL, [grupo] TEXT(2) NOT NULL, [data] SHORTDATE NOT NULL, [codrev] TEXT(2) NOT NULL, [entrev] REAL NOT NULL, [alirev] REAL NOT NULL, [alsrev] REAL NOT NULL, [sairev] REAL NOT NULL, [virada] TEXT(1) NOT NULL, [folgasn] TEXT(1) NOT NULL, [codadc] TEXT(2) NOT NULL, [bcosn] TEXT(1) NOT NULL, [horario] REAL NOT NULL);

-- Tabela: etiq1
CREATE TABLE IF NOT EXISTS [etiq1] ([codigo] TEXT(8) NOT NULL, [descricao] TEXT(30) NOT NULL, [selecao] TEXT(1) NOT NULL, [texto] TEXT(2147483647) NOT NULL);

-- Tabela: etiq2
CREATE TABLE IF NOT EXISTS [etiq2] ([altura] REAL NOT NULL, [largura] REAL NOT NULL, [colunas] REAL NOT NULL);

-- Tabela: etiq3
CREATE TABLE IF NOT EXISTS [etiq3] ([codigo] TEXT(12) NOT NULL, [descricao] TEXT(32) NOT NULL, [arquivo] TEXT(25) NOT NULL, [chave] TEXT(8) NOT NULL, [campo] TEXT(8) NOT NULL, [arquivo2] TEXT(25) NOT NULL, [chave2] TEXT(8) NOT NULL, [linha1] TEXT(80) NOT NULL, [linha2] TEXT(80) NOT NULL, [linha3] TEXT(80) NOT NULL, [linha4] TEXT(80) NOT NULL, [linha5] TEXT(80) NOT NULL, [linha6] TEXT(80) NOT NULL, [linha7] TEXT(80) NOT NULL, [linha8] TEXT(80) NOT NULL, [s1] REAL NOT NULL, [s2] REAL NOT NULL, [s3] REAL NOT NULL, [s4] REAL NOT NULL, [s5] REAL NOT NULL, [s6] REAL NOT NULL, [s7] REAL NOT NULL, [s8] REAL NOT NULL, [filtro] TEXT(70) NOT NULL, [setup] TEXT(70) NOT NULL);

-- Tabela: firma
CREATE TABLE IF NOT EXISTS [firma] ([nrclien] REAL NOT NULL, [cognome] TEXT(14) NOT NULL, [razao] TEXT(40) NOT NULL, [endereco] TEXT(32) NOT NULL, [bairro] TEXT(15) NOT NULL, [cidade] TEXT(15) NOT NULL, [cep] TEXT(9) NOT NULL, [estado] TEXT(2) NOT NULL, [telefone] TEXT(9) NOT NULL, [fax] TEXT(9) NOT NULL, [cgc] TEXT(18) NOT NULL, [cgcant] TEXT(18) NOT NULL, [insc] TEXT(15) NOT NULL, [atividade] TEXT(7) NOT NULL, [nat_estab] TEXT(4) NOT NULL, [nr_socios] REAL NOT NULL, [nr_familia] REAL NOT NULL, [senha] TEXT(5) NOT NULL, [horasmes] REAL NOT NULL, [saljan] REAL NOT NULL, [salfev] REAL NOT NULL, [salmar] REAL NOT NULL, [salabr] REAL NOT NULL, [salmai] REAL NOT NULL, [saljun] REAL NOT NULL, [saljul] REAL NOT NULL, [salago] REAL NOT NULL, [salset] REAL NOT NULL, [salout] REAL NOT NULL, [salnov] REAL NOT NULL, [saldez] REAL NOT NULL, [arredonda] REAL NOT NULL, [fpas] TEXT(3) NOT NULL, [acid] TEXT(7) NOT NULL, [cei] TEXT(12) NOT NULL, [pagar] TEXT(1) NOT NULL, [pessoa] TEXT(1) NOT NULL, [produ] TEXT(1) NOT NULL, [altins] TEXT(1) NOT NULL, [tipins] TEXT(1) NOT NULL, [altend] TEXT(1) NOT NULL, [raisneg] TEXT(1) NOT NULL, [pag01] TEXT(2) NOT NULL, [pag02] TEXT(2) NOT NULL, [pag03] TEXT(2) NOT NULL, [pag04] TEXT(1) NOT NULL, [pag05] TEXT(1) NOT NULL, [salnor] REAL NOT NULL, [atides] TEXT(15) NOT NULL, [cnaeibge] REAL NOT NULL, [catfgts] TEXT(2) NOT NULL, [codibge] TEXT(7) NOT NULL, [dbase] REAL NOT NULL, [responsav] TEXT(40) NOT NULL, [ddd] TEXT(4) NOT NULL, [ramal] TEXT(5) NOT NULL, [cpfresp] TEXT(14) NOT NULL, [concaged] TEXT(7) NOT NULL, [email] TEXT(60) NOT NULL, [simples] TEXT(1) NOT NULL, [iniano] TEXT(1) NOT NULL, [pat] TEXT(1) NOT NULL, [micro] TEXT(1) NOT NULL, [porte] TEXT(1) NOT NULL, [imgcon] TEXT(8) NOT NULL, [codempmig] TEXT(2) NOT NULL, [codmana5] REAL NOT NULL, [crtponto] TEXT(1) NOT NULL, [dnresp] SHORTDATE NOT NULL, [ctralmoco] TEXT(1) NOT NULL);

-- Tabela: fo_apu
CREATE TABLE IF NOT EXISTS [fo_apu] ([conta] REAL NOT NULL, [nome] TEXT(35) NOT NULL, [horas] REAL NOT NULL, [col] REAL NOT NULL, [valor] REAL NOT NULL);

-- Tabela: fo_cbo
CREATE TABLE IF NOT EXISTS [fo_cbo] ([codigo] TEXT(5) NOT NULL, [nome] TEXT(200) NOT NULL, [codgpbasec] TEXT(3) NOT NULL, [tpsituacao] TEXT(2) NOT NULL);

-- Tabela: fo_cbod
CREATE TABLE IF NOT EXISTS [fo_cbod] ([codigo] TEXT(6) NOT NULL, [nome] TEXT(70) NOT NULL);

-- Tabela: fo_cbog
CREATE TABLE IF NOT EXISTS [fo_cbog] ([codigo] TEXT(6) NOT NULL, [nome] TEXT(150) NOT NULL);

-- Tabela: fo_cbon
CREATE TABLE IF NOT EXISTS [fo_cbon] ([codigo] TEXT(6) NOT NULL, [nome] TEXT(150) NOT NULL, [criticaa] BIT NOT NULL, [criticac] BIT NOT NULL, [codintocup] REAL NOT NULL, [sglocup] TEXT(3) NOT NULL, [codgh] TEXT(2) NOT NULL, [codgpbasec] TEXT(4) NOT NULL, [cis] TEXT(5) NOT NULL, [desativado] BIT NOT NULL, [versaocbo] TEXT(7) NOT NULL, [cagedesco] REAL NOT NULL);

-- Tabela: fo_cnae
CREATE TABLE IF NOT EXISTS [fo_cnae] ([t_cnae] TEXT(7) NOT NULL, [descricao] TEXT(100) NOT NULL, [a_ibge] TEXT(4) NOT NULL, [taxa] REAL NOT NULL, [seq] TEXT(1) NOT NULL);

-- Tabela: fo_cnae2
CREATE TABLE IF NOT EXISTS [fo_cnae2] ([codigo] TEXT(7) NOT NULL, [descricao] TEXT(100) NOT NULL, [codigopai] TEXT(7) NOT NULL, [aliq_atv] REAL NOT NULL, [ncm_atv] TEXT(8) NOT NULL);

-- Tabela: fo_csat
CREATE TABLE IF NOT EXISTS [fo_csat] ([codigo] REAL NOT NULL, [descricao] TEXT(70) NOT NULL, [grau] REAL NOT NULL, [taxa] REAL NOT NULL);

-- Tabela: fo_fai
CREATE TABLE IF NOT EXISTS [fo_fai] ([faixa] TEXT(2) NOT NULL, [descricao] TEXT(50) NOT NULL, [valor] REAL NOT NULL, [indice] REAL NOT NULL);

-- Tabela: fo_plent
CREATE TABLE IF NOT EXISTS [fo_plent] ([nome] TEXT(6) NOT NULL, [c01] REAL NOT NULL, [c02] REAL NOT NULL, [c03] REAL NOT NULL, [c04] REAL NOT NULL, [c05] REAL NOT NULL, [c06] REAL NOT NULL, [c07] REAL NOT NULL, [c08] REAL NOT NULL, [c09] REAL NOT NULL, [c10] REAL NOT NULL, [c11] REAL NOT NULL, [c12] REAL NOT NULL, [c13] REAL NOT NULL, [c14] REAL NOT NULL, [c15] REAL NOT NULL, [c16] REAL NOT NULL, [c17] REAL NOT NULL, [c18] REAL NOT NULL);

-- Tabela: fo_rcau
CREATE TABLE IF NOT EXISTS [fo_rcau] ([id] REAL NOT NULL, [codigo] TEXT(10) NOT NULL, [rais] TEXT(2) NOT NULL, [caged] TEXT(2) NOT NULL, [codgre] TEXT(2) NOT NULL, [nome] TEXT(100) NOT NULL, [descrimp] TEXT(40) NOT NULL, [salsal] BIT NOT NULL, [adiins] BIT NOT NULL, [adiper] BIT NOT NULL, [dsrvar] BIT NOT NULL, [ferpro] BIT NOT NULL, [ferprom] BIT NOT NULL, [ferven] BIT NOT NULL, [fervenm] BIT NOT NULL, [avpind] BIT NOT NULL, [avpindm] BIT NOT NULL, [decter] BIT NOT NULL, [decterm] BIT NOT NULL, [salfam] BIT NOT NULL, [salfas] BIT NOT NULL, [fgta22] BIT NOT NULL, [fgta09] BIT NOT NULL, [indeni] BIT NOT NULL, [medadi] BIT NOT NULL, [decind] BIT NOT NULL, [decindm] BIT NOT NULL, [ferind] BIT NOT NULL, [ferindm] BIT NOT NULL, [adcsal] TEXT(1) NOT NULL);

-- Tabela: fo_tab
CREATE TABLE IF NOT EXISTS [fo_tab] ([tabela] TEXT(4) NOT NULL, [codigo] TEXT(5) NOT NULL, [codig2] TEXT(5) NOT NULL, [valor] REAL NOT NULL, [descri] TEXT(70) NOT NULL, [descr2] TEXT(70) NOT NULL);

-- Tabela: folget
CREATE TABLE IF NOT EXISTS [folget] ([codigo] TEXT(6) NOT NULL, [seq] REAL NOT NULL, [tip] TEXT(1) NOT NULL, [linini] REAL NOT NULL, [colini] REAL NOT NULL, [linfim] REAL NOT NULL, [colfim] REAL NOT NULL, [campo] TEXT(11) NOT NULL, [estilo] TEXT(25) NOT NULL, [condicao] TEXT(200) NOT NULL, [precond] TEXT(78) NOT NULL, [mensagem] TEXT(40) NOT NULL);

-- Tabela: folhaman
CREATE TABLE IF NOT EXISTS [folhaman] ([descricao] TEXT(76) NOT NULL, [arquivo] TEXT(12) NOT NULL);

-- Tabela: folhantx
CREATE TABLE IF NOT EXISTS [folhantx] ([descricao] TEXT(78) NOT NULL, [dbf] TEXT(20) NOT NULL, [ntx] TEXT(20) NOT NULL, [seq] REAL NOT NULL, [tag] TEXT(20) NOT NULL, [campo] TEXT(56) NOT NULL, [pad] TEXT(1) NOT NULL);

-- Tabela: folisntx
CREATE TABLE IF NOT EXISTS [folisntx] ([descricao] TEXT(78) NOT NULL, [dbf] TEXT(8) NOT NULL, [ntx] TEXT(8) NOT NULL, [seq] REAL NOT NULL, [tag] TEXT(20) NOT NULL, [campo] TEXT(56) NOT NULL, [pad] TEXT(1) NOT NULL);

-- Tabela: folopt
CREATE TABLE IF NOT EXISTS [folopt] ([itemenu] TEXT(1) NOT NULL, [posicao] REAL NOT NULL, [linha] REAL NOT NULL, [coluna] REAL NOT NULL, [descp] TEXT(30) NOT NULL, [tecla] REAL NOT NULL, [descm] TEXT(75) NOT NULL, [executar] TEXT(200) NOT NULL);

-- Tabela: folrel
CREATE TABLE IF NOT EXISTS [folrel] ([dbf] TEXT(8) NOT NULL, [campo] TEXT(10) NOT NULL, [dado] TEXT(40) NOT NULL, [descricao] TEXT(2147483647) NOT NULL, [arquivo] TEXT(12) NOT NULL);

-- Tabela: foltel
CREATE TABLE IF NOT EXISTS [foltel] ([codigo] TEXT(6) NOT NULL, [seq] REAL NOT NULL, [tip] TEXT(1) NOT NULL, [linini] REAL NOT NULL, [colini] REAL NOT NULL, [linfim] REAL NOT NULL, [colfim] REAL NOT NULL, [dizer] TEXT(80) NOT NULL, [estilo] TEXT(20) NOT NULL);

-- Tabela: foptoalm
CREATE TABLE IF NOT EXISTS [foptoalm] ([mes] REAL NOT NULL, [ano] REAL NOT NULL, [mesext] TEXT(10) NOT NULL, [desct] REAL NOT NULL, [desctb] REAL NOT NULL, [desctc] REAL NOT NULL, [desctd] REAL NOT NULL, [descte] REAL NOT NULL);

-- Tabela: foptobco
CREATE TABLE IF NOT EXISTS [foptobco] ([bco01] TEXT(100) NOT NULL, [bco02] TEXT(100) NOT NULL, [bco03] TEXT(100) NOT NULL, [bco04] TEXT(100) NOT NULL, [bco05] TEXT(100) NOT NULL, [bco06] TEXT(100) NOT NULL, [bco07] TEXT(100) NOT NULL, [bco08] TEXT(100) NOT NULL, [bco09] TEXT(100) NOT NULL, [bco10] TEXT(100) NOT NULL, [bco11] TEXT(100) NOT NULL, [bco12] TEXT(100) NOT NULL, [bco13] TEXT(100) NOT NULL, [bco14] TEXT(100) NOT NULL, [bco15] TEXT(100) NOT NULL, [bco16] TEXT(100) NOT NULL, [bco17] TEXT(100) NOT NULL, [bco18] TEXT(100) NOT NULL, [bco19] TEXT(100) NOT NULL, [bco20] TEXT(100) NOT NULL, [bco21] TEXT(100) NOT NULL, [bco22] TEXT(100) NOT NULL, [bco23] TEXT(100) NOT NULL, [bco24] TEXT(100) NOT NULL, [bcohr] TEXT(100) NOT NULL, [bcott] TEXT(100) NOT NULL, [empresa] REAL NOT NULL);

-- Tabela: foptocom
CREATE TABLE IF NOT EXISTS [foptocom] ([mes] REAL NOT NULL, [ano] REAL NOT NULL, [mesext] TEXT(10) NOT NULL, [dataini] SHORTDATE NOT NULL, [datafim] SHORTDATE NOT NULL, [empresa] REAL NOT NULL, [fechado] TEXT(1) NOT NULL);

-- Tabela: foptocon
CREATE TABLE IF NOT EXISTS [foptocon] ([empresa] REAL NOT NULL, [tr01] TEXT(1) NOT NULL, [cx01] TEXT(70) NOT NULL, [op01] TEXT(100) NOT NULL, [tr02] TEXT(1) NOT NULL, [op02] TEXT(100) NOT NULL, [cx02] TEXT(70) NOT NULL, [tr03] TEXT(1) NOT NULL, [op03] TEXT(100) NOT NULL, [cx03] TEXT(70) NOT NULL, [tr04] TEXT(1) NOT NULL, [cx04] TEXT(70) NOT NULL, [op04] TEXT(100) NOT NULL, [tr05] TEXT(1) NOT NULL, [op05] TEXT(100) NOT NULL, [cx05] TEXT(70) NOT NULL, [tr06] TEXT(1) NOT NULL, [cx06] TEXT(70) NOT NULL, [op06] TEXT(100) NOT NULL, [tr07] TEXT(1) NOT NULL, [cx07] TEXT(70) NOT NULL, [op07] TEXT(100) NOT NULL, [tr08] TEXT(1) NOT NULL, [cx08] TEXT(70) NOT NULL, [op08] TEXT(100) NOT NULL, [tr09] TEXT(1) NOT NULL, [cx09] TEXT(70) NOT NULL, [op09] TEXT(100) NOT NULL, [tr10] TEXT(1) NOT NULL, [cx10] TEXT(70) NOT NULL, [op10] TEXT(100) NOT NULL, [tr11] TEXT(1) NOT NULL, [cx11] TEXT(70) NOT NULL, [op11] TEXT(100) NOT NULL, [tr12] TEXT(1) NOT NULL, [cx12] TEXT(70) NOT NULL, [op12] TEXT(100) NOT NULL, [tr13] TEXT(1) NOT NULL, [cx13] TEXT(70) NOT NULL, [op13] TEXT(100) NOT NULL, [tr14] TEXT(1) NOT NULL, [cx14] TEXT(70) NOT NULL, [op14] TEXT(100) NOT NULL, [tr15] TEXT(1) NOT NULL, [cx15] TEXT(70) NOT NULL, [op15] TEXT(100) NOT NULL, [tr16] TEXT(1) NOT NULL, [cx16] TEXT(70) NOT NULL, [op16] TEXT(100) NOT NULL, [tr17] TEXT(1) NOT NULL, [cx17] TEXT(70) NOT NULL, [op17] TEXT(100) NOT NULL, [tr18] TEXT(1) NOT NULL, [cx18] TEXT(70) NOT NULL, [op18] TEXT(100) NOT NULL, [tr19] TEXT(1) NOT NULL, [cx19] TEXT(70) NOT NULL, [op19] TEXT(100) NOT NULL, [tr20] TEXT(1) NOT NULL, [cx20] TEXT(70) NOT NULL, [op20] TEXT(100) NOT NULL, [tr21] TEXT(1) NOT NULL, [cx21] TEXT(70) NOT NULL, [op21] TEXT(100) NOT NULL, [tr22] TEXT(1) NOT NULL, [cx22] TEXT(70) NOT NULL, [op22] TEXT(100) NOT NULL, [tr23] TEXT(1) NOT NULL, [cx23] TEXT(70) NOT NULL, [op23] TEXT(100) NOT NULL, [tr24] TEXT(1) NOT NULL, [cx24] TEXT(70) NOT NULL, [op24] TEXT(100) NOT NULL, [vi01] TEXT(70) NOT NULL, [vi02] TEXT(70) NOT NULL, [vi03] TEXT(70) NOT NULL, [vi04] TEXT(70) NOT NULL, [vi05] TEXT(70) NOT NULL, [vi06] TEXT(70) NOT NULL, [vi07] TEXT(70) NOT NULL, [vi08] TEXT(70) NOT NULL, [vi09] TEXT(70) NOT NULL, [vi10] TEXT(70) NOT NULL, [vi11] TEXT(70) NOT NULL, [vi12] TEXT(70) NOT NULL, [vi13] TEXT(70) NOT NULL, [vi14] TEXT(70) NOT NULL, [vi15] TEXT(70) NOT NULL, [vi16] TEXT(70) NOT NULL, [vi17] TEXT(70) NOT NULL, [vi18] TEXT(70) NOT NULL, [vi19] TEXT(70) NOT NULL, [vi20] TEXT(70) NOT NULL, [vi21] TEXT(70) NOT NULL, [vi22] TEXT(70) NOT NULL, [vi23] TEXT(70) NOT NULL, [vi24] TEXT(70) NOT NULL, [fs01] TEXT(140) NOT NULL, [fs02] TEXT(140) NOT NULL, [fs03] TEXT(140) NOT NULL, [fs04] TEXT(140) NOT NULL, [fs05] TEXT(140) NOT NULL, [fs06] TEXT(140) NOT NULL, [fs07] TEXT(140) NOT NULL, [fs08] TEXT(140) NOT NULL, [fs09] TEXT(140) NOT NULL, [fs10] TEXT(140) NOT NULL, [fs11] TEXT(140) NOT NULL, [fs12] TEXT(140) NOT NULL, [fs13] TEXT(140) NOT NULL, [fs14] TEXT(140) NOT NULL, [fs15] TEXT(140) NOT NULL, [fs16] TEXT(140) NOT NULL, [fs17] TEXT(140) NOT NULL, [fs18] TEXT(140) NOT NULL, [fs19] TEXT(140) NOT NULL, [fs20] TEXT(140) NOT NULL, [fs21] TEXT(140) NOT NULL, [fs22] TEXT(140) NOT NULL, [fs23] TEXT(140) NOT NULL, [fs24] TEXT(140) NOT NULL, [tol01] REAL NOT NULL, [tol02] REAL NOT NULL, [tol03] REAL NOT NULL, [tol04] REAL NOT NULL, [tol05] REAL NOT NULL, [tol06] REAL NOT NULL, [tol07] REAL NOT NULL, [tol08] REAL NOT NULL, [tol09] REAL NOT NULL, [tol10] REAL NOT NULL, [exporta] TEXT(100) NOT NULL, [caminex] TEXT(40) NOT NULL, [caminer] TEXT(40) NOT NULL, [contaref] REAL NOT NULL);

-- Tabela: foptoeqp
CREATE TABLE IF NOT EXISTS [foptoeqp] ([numero] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [tipo] TEXT(1) NOT NULL, [rep] TEXT(17) NOT NULL, [localinst] TEXT(50) NOT NULL, [ativo] TEXT(1) NOT NULL, [gruporel] REAL NOT NULL, [geraafd] TEXT(1) NOT NULL);

-- Tabela: foptohor
CREATE TABLE IF NOT EXISTS [foptohor] ([numero] REAL NOT NULL, [codigo] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [ent] REAL NOT NULL, [almi] REAL NOT NULL, [almf] REAL NOT NULL, [sai] REAL NOT NULL, [virada] TEXT(1) NOT NULL, [folgasn] TEXT(1) NOT NULL);

-- Tabela: foptohre
CREATE TABLE IF NOT EXISTS [foptohre] ([codigo] TEXT(2) NOT NULL, [nome] TEXT(40) NOT NULL, [hent] REAL NOT NULL, [hsai] REAL NOT NULL, [hals] REAL NOT NULL, [hale] REAL NOT NULL, [hent01] REAL NOT NULL, [hals01] REAL NOT NULL, [hale01] REAL NOT NULL, [hsai01] REAL NOT NULL, [hent02] REAL NOT NULL, [hals02] REAL NOT NULL, [hale02] REAL NOT NULL, [hsai02] REAL NOT NULL, [hent03] REAL NOT NULL, [hals03] REAL NOT NULL, [hale03] REAL NOT NULL, [hsai03] REAL NOT NULL, [hent04] REAL NOT NULL, [hals04] REAL NOT NULL, [hale04] REAL NOT NULL, [hsai04] REAL NOT NULL, [hent05] REAL NOT NULL, [hals05] REAL NOT NULL, [hale05] REAL NOT NULL, [hsai05] REAL NOT NULL, [hent06] REAL NOT NULL, [hals06] REAL NOT NULL, [hale06] REAL NOT NULL, [hsai06] REAL NOT NULL, [hent07] REAL NOT NULL, [hals07] REAL NOT NULL, [hale07] REAL NOT NULL, [hsai07] REAL NOT NULL, [hfol00] TEXT(1) NOT NULL, [hfol01] TEXT(1) NOT NULL, [hfol02] TEXT(1) NOT NULL, [hfol03] TEXT(1) NOT NULL, [hfol04] TEXT(1) NOT NULL, [hfol05] TEXT(1) NOT NULL, [hfol06] TEXT(1) NOT NULL, [hfol07] TEXT(1) NOT NULL, [chor] TEXT(2) NOT NULL, [chor01] TEXT(2) NOT NULL, [chor02] TEXT(2) NOT NULL, [chor03] TEXT(2) NOT NULL, [chor04] TEXT(2) NOT NULL, [chor05] TEXT(2) NOT NULL, [chor06] TEXT(2) NOT NULL, [chor07] TEXT(2) NOT NULL, [hor] REAL NOT NULL, [hor01] REAL NOT NULL, [hor02] REAL NOT NULL, [hor03] REAL NOT NULL, [hor04] REAL NOT NULL, [hor05] REAL NOT NULL, [hor06] REAL NOT NULL, [hor07] REAL NOT NULL);

-- Tabela: foptomot
CREATE TABLE IF NOT EXISTS [foptomot] ([numero] REAL NOT NULL, [nome] TEXT(60) NOT NULL);

-- Tabela: foptontx
CREATE TABLE IF NOT EXISTS [foptontx] ([descricao] TEXT(78) NOT NULL, [dbf] TEXT(8) NOT NULL, [ntx] TEXT(8) NOT NULL, [seq] REAL NOT NULL, [tag] TEXT(20) NOT NULL, [campo] TEXT(56) NOT NULL, [pad] TEXT(1) NOT NULL);

-- Tabela: foptopis
CREATE TABLE IF NOT EXISTS [foptopis] ([numero] REAL NOT NULL, [pis] TEXT(12) NOT NULL);

-- Tabela: foptopro
CREATE TABLE IF NOT EXISTS [foptopro] ([origem] REAL NOT NULL, [destino] REAL NOT NULL, [data] SHORTDATE NOT NULL, [nome] TEXT(60) NOT NULL, [motivo] REAL NOT NULL);

-- Tabela: foptorel
CREATE TABLE IF NOT EXISTS [foptorel] ([numero] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [destino] TEXT(1) NOT NULL, [caminho] TEXT(200) NOT NULL, [arquivo] TEXT(30) NOT NULL, [arqdest] TEXT(8) NOT NULL, [processo] TEXT(1) NOT NULL, [anorel] TEXT(1) NOT NULL, [horadec] TEXT(1) NOT NULL, [modelo] REAL NOT NULL);

-- Tabela: foptoval
CREATE TABLE IF NOT EXISTS [foptoval] ([empresa] REAL NOT NULL, [fval01] TEXT(70) NOT NULL, [fval02] TEXT(70) NOT NULL, [fval03] TEXT(70) NOT NULL, [fval04] TEXT(70) NOT NULL, [fval05] TEXT(70) NOT NULL, [fval06] TEXT(70) NOT NULL, [fval07] TEXT(70) NOT NULL, [fval08] TEXT(70) NOT NULL, [fval09] TEXT(70) NOT NULL, [fval10] TEXT(70) NOT NULL, [fval11] TEXT(70) NOT NULL, [fval12] TEXT(70) NOT NULL, [fval13] TEXT(70) NOT NULL, [fval14] TEXT(70) NOT NULL, [fval15] TEXT(70) NOT NULL, [fval16] TEXT(70) NOT NULL, [fval17] TEXT(70) NOT NULL, [fval18] TEXT(70) NOT NULL, [fval19] TEXT(70) NOT NULL, [fval20] TEXT(70) NOT NULL, [fval21] TEXT(70) NOT NULL, [fval22] TEXT(70) NOT NULL, [fval23] TEXT(70) NOT NULL, [fval24] TEXT(70) NOT NULL, [ffin01] TEXT(70) NOT NULL, [ffin02] TEXT(70) NOT NULL, [ffin03] TEXT(70) NOT NULL, [ffin04] TEXT(70) NOT NULL, [ffin05] TEXT(70) NOT NULL, [ffin06] TEXT(70) NOT NULL, [ffin07] TEXT(70) NOT NULL, [ffin08] TEXT(70) NOT NULL, [ffin09] TEXT(70) NOT NULL, [ffin10] TEXT(70) NOT NULL, [ffin11] TEXT(70) NOT NULL, [ffin12] TEXT(70) NOT NULL, [ffin13] TEXT(70) NOT NULL, [ffin14] TEXT(70) NOT NULL, [ffin15] TEXT(70) NOT NULL, [ffin16] TEXT(70) NOT NULL, [ffin17] TEXT(70) NOT NULL, [ffin18] TEXT(70) NOT NULL, [ffin19] TEXT(70) NOT NULL, [ffin20] TEXT(70) NOT NULL, [ffin21] TEXT(70) NOT NULL, [ffin22] TEXT(70) NOT NULL, [ffin23] TEXT(70) NOT NULL, [ffin24] TEXT(70) NOT NULL);

-- Tabela: forfentx
CREATE TABLE IF NOT EXISTS [forfentx] ([descricao] TEXT(78) NOT NULL, [dbf] TEXT(8) NOT NULL, [ntx] TEXT(8) NOT NULL, [seq] REAL NOT NULL, [tag] TEXT(20) NOT NULL, [campo] TEXT(56) NOT NULL, [pad] TEXT(1) NOT NULL);

-- Tabela: fosalmin
CREATE TABLE IF NOT EXISTS [fosalmin] ([ano] REAL NOT NULL, [moeda] TEXT(2) NOT NULL, [valor] REAL NOT NULL, [atolegal] TEXT(20) NOT NULL, [percentual] REAL NOT NULL, [mes] REAL NOT NULL, [vigencia] SHORTDATE NOT NULL);

-- Tabela: funcac
CREATE TABLE IF NOT EXISTS [funcac] ([codigo] REAL NOT NULL, [curso] TEXT(10) NOT NULL, [descur] TEXT(60) NOT NULL);

-- Tabela: funcao
CREATE TABLE IF NOT EXISTS [funcao] ([codigo] REAL NOT NULL, [nome] TEXT(40) NOT NULL, [valor] REAL NOT NULL, [cbo] TEXT(5) NOT NULL, [fnome] TEXT(17) NOT NULL, [faixa] TEXT(2) NOT NULL, [area] TEXT(2) NOT NULL, [codmp02] TEXT(10) NOT NULL, [des01] TEXT(70) NOT NULL, [des02] TEXT(70) NOT NULL, [des03] TEXT(70) NOT NULL, [des04] TEXT(70) NOT NULL, [des05] TEXT(70) NOT NULL, [des06] TEXT(70) NOT NULL, [des07] TEXT(70) NOT NULL, [des08] TEXT(70) NOT NULL, [des09] TEXT(70) NOT NULL, [des10] TEXT(70) NOT NULL, [req01] TEXT(70) NOT NULL, [req02] TEXT(70) NOT NULL, [req03] TEXT(70) NOT NULL, [req04] TEXT(70) NOT NULL, [req05] TEXT(70) NOT NULL, [req06] TEXT(70) NOT NULL, [req07] TEXT(70) NOT NULL, [req08] TEXT(70) NOT NULL, [req09] TEXT(70) NOT NULL, [req10] TEXT(70) NOT NULL, [red01] TEXT(70) NOT NULL, [red02] TEXT(70) NOT NULL, [red03] TEXT(70) NOT NULL, [red04] TEXT(70) NOT NULL, [red05] TEXT(70) NOT NULL, [red06] TEXT(70) NOT NULL, [red07] TEXT(70) NOT NULL, [red08] TEXT(70) NOT NULL, [red09] TEXT(70) NOT NULL, [red10] TEXT(70) NOT NULL, [cbonew] TEXT(6) NOT NULL, [reqcnh] TEXT(1) NOT NULL, [reqoc] TEXT(1) NOT NULL, [ocemis] TEXT(6) NOT NULL, [temlx] TEXT(1) NOT NULL);

-- Tabela: ginssd
CREATE TABLE IF NOT EXISTS [ginssd] ([numemp] REAL NOT NULL, [valrec] REAL NOT NULL, [valemp] REAL NOT NULL, [valter] REAL NOT NULL, [valded] REAL NOT NULL, [valliq] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [depto] REAL NOT NULL, [setor] REAL NOT NULL, [secao] REAL NOT NULL, [controle] TEXT(18) NOT NULL);

-- Tabela: horpad
CREATE TABLE IF NOT EXISTS [horpad] ([numero] REAL NOT NULL, [nome] TEXT(60) NOT NULL, [d1] TEXT(60) NOT NULL, [d2] TEXT(60) NOT NULL, [d3] TEXT(60) NOT NULL, [d4] TEXT(60) NOT NULL, [d5] TEXT(60) NOT NULL, [d6] TEXT(60) NOT NULL, [d7] TEXT(60) NOT NULL);

-- Tabela: medagdp
CREATE TABLE IF NOT EXISTS [medagdp] ([codigo] TEXT(9) NOT NULL, [nome] TEXT(135) NOT NULL);

-- Tabela: medicgrp
CREATE TABLE IF NOT EXISTS [medicgrp] ([codigo] TEXT(2) NOT NULL, [nome] TEXT(40) NOT NULL);

-- Tabela: medmaq
CREATE TABLE IF NOT EXISTS [medmaq] ([codigo] TEXT(2) NOT NULL, [nome] TEXT(37) NOT NULL);

-- Tabela: medmmb
CREATE TABLE IF NOT EXISTS [medmmb] ([codigo] TEXT(1) NOT NULL, [nome] TEXT(6) NOT NULL);

-- Tabela: medrisoc
CREATE TABLE IF NOT EXISTS [medrisoc] ([codigo] TEXT(6) NOT NULL, [nome] TEXT(43) NOT NULL);

-- Tabela: meshol
CREATE TABLE IF NOT EXISTS [meshol] ([nome] TEXT(6) NOT NULL, [mes1] TEXT(40) NOT NULL, [mes2] TEXT(40) NOT NULL, [mes3] TEXT(40) NOT NULL);

-- Tabela: muser
CREATE TABLE IF NOT EXISTS [muser] ([usuario] TEXT(10) NOT NULL, [senha] TEXT(8) NOT NULL, [validade] TEXT(8) NOT NULL, [valdata] SHORTDATE NOT NULL, [equivale] TEXT(10) NOT NULL, [estado] TEXT(1) NOT NULL, [arqfon] TEXT(8) NOT NULL, [setor] TEXT(10) NOT NULL, [wrptno] REAL NOT NULL, [folhano] REAL NOT NULL, [datatro] SHORTDATE NOT NULL, [usuariow] TEXT(20) NOT NULL, [senhaw] TEXT(20) NOT NULL, [postel01] REAL NOT NULL, [postel02] REAL NOT NULL, [postel03] REAL NOT NULL, [postel04] REAL NOT NULL, [postel05] REAL NOT NULL, [postel06] REAL NOT NULL, [postel07] REAL NOT NULL, [postel08] REAL NOT NULL, [postel09] REAL NOT NULL, [postel10] REAL NOT NULL, [postel11] REAL NOT NULL, [postel12] REAL NOT NULL, [postel13] REAL NOT NULL, [postel14] REAL NOT NULL, [postel15] REAL NOT NULL, [postel16] REAL NOT NULL, [postel17] REAL NOT NULL, [postel18] REAL NOT NULL, [chaveh] TEXT(64) NOT NULL, [chavewc] TEXT(64) NOT NULL, [chaveww] TEXT(64) NOT NULL, [chavews] TEXT(64) NOT NULL);

-- Tabela: muserm
CREATE TABLE IF NOT EXISTS [muserm] ([controle] TEXT(13) NOT NULL);

-- Tabela: nomesexo
CREATE TABLE IF NOT EXISTS [nomesexo] ([name] TEXT(14) NOT NULL, [classifica] TEXT(1) NOT NULL);

-- Tabela: nota
CREATE TABLE IF NOT EXISTS [nota] ([nome] TEXT(10) NOT NULL, [obs1] TEXT(60) NOT NULL, [obs2] TEXT(60) NOT NULL, [obs3] TEXT(60) NOT NULL, [obs4] TEXT(60) NOT NULL, [obs5] TEXT(60) NOT NULL, [obs6] TEXT(60) NOT NULL, [obs7] TEXT(60) NOT NULL, [obs8] TEXT(60) NOT NULL);

-- Tabela: orgemiss
CREATE TABLE IF NOT EXISTS [orgemiss] ([codigo] TEXT(10) NOT NULL, [nome] TEXT(85) NOT NULL, [caixa] REAL NOT NULL);

-- Tabela: pisindev
CREATE TABLE IF NOT EXISTS [pisindev] ([codigo] TEXT(11) NOT NULL, [nome] TEXT(15) NOT NULL);

-- Tabela: ptohoref
CREATE TABLE IF NOT EXISTS [ptohoref] ([relogio] TEXT(5) NOT NULL, [horini] REAL NOT NULL, [horfim] REAL NOT NULL, [tipo] REAL NOT NULL);

-- Tabela: raisnatj
CREATE TABLE IF NOT EXISTS [raisnatj] ([codigo] TEXT(4) NOT NULL, [nome] TEXT(80) NOT NULL, [natgru] TEXT(50) NOT NULL);

-- Tabela: raistadm
CREATE TABLE IF NOT EXISTS [raistadm] ([codigo] TEXT(2) NOT NULL, [nome] TEXT(150) NOT NULL);

-- Tabela: rbtemp
CREATE TABLE IF NOT EXISTS [rbtemp] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [hora] REAL NOT NULL, [dia] REAL NOT NULL);

-- Tabela: recucopy
CREATE TABLE IF NOT EXISTS [recucopy] ([nome] TEXT(6) NOT NULL, [diretorio] TEXT(35) NOT NULL, [arq01] TEXT(12) NOT NULL, [arq02] TEXT(12) NOT NULL, [arq03] TEXT(12) NOT NULL, [arq04] TEXT(12) NOT NULL, [arq05] TEXT(12) NOT NULL, [arq06] TEXT(12) NOT NULL, [arq07] TEXT(12) NOT NULL, [arq08] TEXT(12) NOT NULL, [arq09] TEXT(12) NOT NULL, [arq10] TEXT(12) NOT NULL, [arq11] TEXT(12) NOT NULL, [arq12] TEXT(12) NOT NULL, [arq13] TEXT(12) NOT NULL, [arq14] TEXT(12) NOT NULL, [arq15] TEXT(12) NOT NULL, [arq16] TEXT(12) NOT NULL, [arq17] TEXT(12) NOT NULL, [arq18] TEXT(12) NOT NULL, [arq19] TEXT(12) NOT NULL, [arq20] TEXT(12) NOT NULL, [arq21] TEXT(12) NOT NULL, [arq22] TEXT(12) NOT NULL, [arq23] TEXT(12) NOT NULL, [arq24] TEXT(12) NOT NULL, [arq25] TEXT(12) NOT NULL, [arq26] TEXT(12) NOT NULL, [arq27] TEXT(12) NOT NULL, [arq28] TEXT(12) NOT NULL, [arq29] TEXT(12) NOT NULL, [arq30] TEXT(12) NOT NULL, [arq31] TEXT(12) NOT NULL, [arq32] TEXT(12) NOT NULL, [arq33] TEXT(12) NOT NULL, [arq34] TEXT(12) NOT NULL, [arq35] TEXT(12) NOT NULL, [arq36] TEXT(12) NOT NULL, [arq37] TEXT(12) NOT NULL, [arq38] TEXT(12) NOT NULL, [arq39] TEXT(12) NOT NULL, [arq40] TEXT(12) NOT NULL);

-- Tabela: recuedit
CREATE TABLE IF NOT EXISTS [recuedit] ([descricao] TEXT(76) NOT NULL, [arquivo] TEXT(12) NOT NULL, [setup] TEXT(76) NOT NULL, [marsup] REAL NOT NULL, [marinf] REAL NOT NULL, [mardir] REAL NOT NULL, [maresq] REAL NOT NULL, [marcol] REAL NOT NULL, [marlin] REAL NOT NULL);

-- Tabela: recurntx
CREATE TABLE IF NOT EXISTS [recurntx] ([descricao] TEXT(78) NOT NULL, [dbf] TEXT(8) NOT NULL, [ntx] TEXT(8) NOT NULL, [seq] REAL NOT NULL, [tag] TEXT(20) NOT NULL, [campo] TEXT(56) NOT NULL, [pad] TEXT(1) NOT NULL);

-- Tabela: rel2
CREATE TABLE IF NOT EXISTS [rel2] ([codigo] TEXT(8) NOT NULL, [a] REAL NOT NULL, [b] REAL NOT NULL, [c] REAL NOT NULL, [d] REAL NOT NULL, [e] REAL NOT NULL, [f] REAL NOT NULL, [g] REAL NOT NULL, [h] REAL NOT NULL, [i] REAL NOT NULL, [j] REAL NOT NULL, [k] REAL NOT NULL, [l] REAL NOT NULL, [m] REAL NOT NULL, [n] REAL NOT NULL, [o] REAL NOT NULL, [p] REAL NOT NULL, [q] REAL NOT NULL, [r] REAL NOT NULL, [s] REAL NOT NULL, [t] REAL NOT NULL, [u] REAL NOT NULL, [v] REAL NOT NULL, [w] REAL NOT NULL, [x] REAL NOT NULL, [y] REAL NOT NULL, [z] REAL NOT NULL, [aa] REAL NOT NULL, [ab] REAL NOT NULL, [ac] REAL NOT NULL, [ad] REAL NOT NULL, [ae] REAL NOT NULL, [af] REAL NOT NULL);

-- Tabela: relconta
CREATE TABLE IF NOT EXISTS [relconta] ([codigo] TEXT(8) NOT NULL, [c1] REAL NOT NULL, [c2] REAL NOT NULL, [c3] REAL NOT NULL, [c4] REAL NOT NULL, [c5] REAL NOT NULL, [c6] REAL NOT NULL, [c7] REAL NOT NULL, [c8] REAL NOT NULL, [c9] REAL NOT NULL, [c10] REAL NOT NULL, [c11] REAL NOT NULL, [c12] REAL NOT NULL, [c13] REAL NOT NULL, [c14] REAL NOT NULL, [c15] REAL NOT NULL, [nome] TEXT(30) NOT NULL);

-- Tabela: relogios
CREATE TABLE IF NOT EXISTS [relogios] ([numero] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [numini] REAL NOT NULL, [numfim] REAL NOT NULL, [diaini] REAL NOT NULL, [diafim] REAL NOT NULL, [mesini] REAL NOT NULL, [mesfim] REAL NOT NULL, [anoini] REAL NOT NULL, [anofim] REAL NOT NULL, [horini] REAL NOT NULL, [horfim] REAL NOT NULL, [minini] REAL NOT NULL, [minfim] REAL NOT NULL, [segini] REAL NOT NULL, [segfim] REAL NOT NULL, [numrelini] REAL NOT NULL, [numrelfim] REAL NOT NULL, [numempini] REAL NOT NULL, [numempfim] REAL NOT NULL, [exemplo] TEXT(50) NOT NULL);

-- Tabela: sindcnpj
CREATE TABLE IF NOT EXISTS [sindcnpj] ([cnpj] TEXT(14) NOT NULL);

-- Tabela: sindicat
CREATE TABLE IF NOT EXISTS [sindicat] ([codigo] REAL NOT NULL, [cognome] TEXT(20) NOT NULL, [nome] TEXT(40) NOT NULL, [endereco] TEXT(30) NOT NULL, [bairro] TEXT(15) NOT NULL, [cidade] TEXT(20) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [telefone] TEXT(14) NOT NULL, [saljan] REAL NOT NULL, [salfev] REAL NOT NULL, [salmar] REAL NOT NULL, [salabr] REAL NOT NULL, [salmai] REAL NOT NULL, [saljun] REAL NOT NULL, [saljul] REAL NOT NULL, [salago] REAL NOT NULL, [salset] REAL NOT NULL, [salout] REAL NOT NULL, [salnov] REAL NOT NULL, [saldez] REAL NOT NULL, [taxaass] REAL NOT NULL, [tetoass] REAL NOT NULL, [datdissi] SHORTDATE NOT NULL, [datass1] SHORTDATE NOT NULL, [datass2] SHORTDATE NOT NULL, [datsind] SHORTDATE NOT NULL, [entidade] TEXT(20) NOT NULL, [cgc] TEXT(18) NOT NULL, [ie] TEXT(18) NOT NULL, [desconf] TEXT(1) NOT NULL, [perconf] REAL NOT NULL, [tetconf] REAL NOT NULL, [dessind] TEXT(1) NOT NULL, [tetsind] REAL NOT NULL, [persind] REAL NOT NULL, [ctasind] REAL NOT NULL, [ctaconf] REAL NOT NULL, [ctaassi] REAL NOT NULL, [ddd] TEXT(3) NOT NULL, [email] TEXT(60) NOT NULL, [numend] TEXT(10) NOT NULL, [categoria] TEXT(10) NOT NULL, [respo] TEXT(60) NOT NULL, [endcompl] TEXT(10) NOT NULL, [codlx] REAL NOT NULL, [codsi] REAL NOT NULL);

-- Tabela: tabarre
CREATE TABLE IF NOT EXISTS [tabarre] ([mes] REAL NOT NULL, [ano] REAL NOT NULL, [mesext] TEXT(10) NOT NULL, [desct] REAL NOT NULL, [desctb] REAL NOT NULL, [desctc] REAL NOT NULL, [desctd] REAL NOT NULL, [descte] REAL NOT NULL);

-- Tabela: tabfalta
CREATE TABLE IF NOT EXISTS [tabfalta] ([codigo] TEXT(2) NOT NULL, [nome] TEXT(40) NOT NULL, [apura] TEXT(1) NOT NULL, [formula] TEXT(40) NOT NULL, [obs] TEXT(50) NOT NULL, [macpad] TEXT(1) NOT NULL, [codimp01] REAL NOT NULL, [codimp02] REAL NOT NULL, [codfgs] TEXT(2) NOT NULL, [codfgr] TEXT(2) NOT NULL);

-- Tabela: tabinss
CREATE TABLE IF NOT EXISTS [tabinss] ([nmes] REAL NOT NULL, [emes] TEXT(10) NOT NULL, [cmes] TEXT(3) NOT NULL, [desal1] REAL NOT NULL, [atesal1] REAL NOT NULL, [taxa1] REAL NOT NULL, [taxai1] REAL NOT NULL, [desal2] REAL NOT NULL, [atesal2] REAL NOT NULL, [taxa2] REAL NOT NULL, [taxai2] REAL NOT NULL, [desal3] REAL NOT NULL, [atesal3] REAL NOT NULL, [taxai3] REAL NOT NULL, [taxa3] REAL NOT NULL, [desal4] REAL NOT NULL, [atesal4] REAL NOT NULL, [taxa4] REAL NOT NULL, [taxai4] REAL NOT NULL, [desal5] REAL NOT NULL, [atesal5] REAL NOT NULL, [taxa5] REAL NOT NULL, [taxai5] REAL NOT NULL, [desal6] REAL NOT NULL, [atesal6] REAL NOT NULL, [taxa6] REAL NOT NULL, [taxai6] REAL NOT NULL, [desal7] REAL NOT NULL, [atesal7] REAL NOT NULL, [taxa7] REAL NOT NULL, [taxai7] REAL NOT NULL, [tetoirrf] REAL NOT NULL, [tetomaximo] REAL NOT NULL, [minimo] REAL NOT NULL, [familia] REAL NOT NULL, [tetosalfa] REAL NOT NULL, [familia1] REAL NOT NULL, [tetosalf1] REAL NOT NULL, [desconto] REAL NOT NULL);

-- Tabela: tabirrf
CREATE TABLE IF NOT EXISTS [tabirrf] ([nmes] REAL NOT NULL, [emes] TEXT(10) NOT NULL, [cmes] TEXT(3) NOT NULL, [desal1] REAL NOT NULL, [atesal1] REAL NOT NULL, [taxa1] REAL NOT NULL, [parcela1] REAL NOT NULL, [desal2] REAL NOT NULL, [atesal2] REAL NOT NULL, [taxa2] REAL NOT NULL, [parcela2] REAL NOT NULL, [desal3] REAL NOT NULL, [atesal3] REAL NOT NULL, [taxa3] REAL NOT NULL, [parcela3] REAL NOT NULL, [desal4] REAL NOT NULL, [atesal4] REAL NOT NULL, [taxa4] REAL NOT NULL, [parcela4] REAL NOT NULL, [desal5] REAL NOT NULL, [atesal5] REAL NOT NULL, [taxa5] REAL NOT NULL, [parcela5] REAL NOT NULL, [desal6] REAL NOT NULL, [atesal6] REAL NOT NULL, [taxa6] REAL NOT NULL, [parcela6] REAL NOT NULL, [desal7] REAL NOT NULL, [atesal7] REAL NOT NULL, [taxa7] REAL NOT NULL, [parcela7] REAL NOT NULL, [qtdedep] REAL NOT NULL, [valdepende] REAL NOT NULL, [minimo] REAL NOT NULL, [arredonda] TEXT(1) NOT NULL, [despresa] TEXT(1) NOT NULL, [fatorirrf] REAL NOT NULL, [fatorirr2] REAL NOT NULL);

-- Tabela: tabocorr
CREATE TABLE IF NOT EXISTS [tabocorr] ([codigo] TEXT(2) NOT NULL, [nome] TEXT(40) NOT NULL);

-- Tabela: tabreaju
CREATE TABLE IF NOT EXISTS [tabreaju] ([codigo] TEXT(2) NOT NULL, [nome] TEXT(40) NOT NULL);

-- Tabela: tabtroco
CREATE TABLE IF NOT EXISTS [tabtroco] ([mes] REAL NOT NULL, [ano] REAL NOT NULL, [mesext] TEXT(10) NOT NULL, [desct] REAL NOT NULL, [desctb] REAL NOT NULL, [desctc] REAL NOT NULL, [desctd] REAL NOT NULL, [descte] REAL NOT NULL);

-- Tabela: tabturno
CREATE TABLE IF NOT EXISTS [tabturno] ([codigo] TEXT(2) NOT NULL, [nome] TEXT(40) NOT NULL, [nom2] TEXT(40) NOT NULL, [descricao] TEXT(40) NOT NULL, [apura] TEXT(1) NOT NULL, [formula] TEXT(40) NOT NULL);

-- Tabela: tb_grpar
CREATE TABLE IF NOT EXISTS [tb_grpar] ([codigo] TEXT(2) NOT NULL, [nome] TEXT(20) NOT NULL);

-- Tabela: tbcodpg
CREATE TABLE IF NOT EXISTS [tbcodpg] ([codigo] TEXT(4) NOT NULL, [nome] TEXT(50) NOT NULL);

-- Tabela: telememo
CREATE TABLE IF NOT EXISTS [telememo] ([nome] TEXT(15) NOT NULL, [especif] TEXT(35) NOT NULL, [telef] TEXT(14) NOT NULL, [fax] TEXT(14) NOT NULL);

-- Tabela: tilresg
CREATE TABLE IF NOT EXISTS [tilresg] ([nome] TEXT(12) NOT NULL, [titulo] TEXT(12) NOT NULL);

-- Tabela: tomador
CREATE TABLE IF NOT EXISTS [tomador] ([numero] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [nome] TEXT(40) NOT NULL, [endereco] TEXT(40) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(35) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [cxpostal] TEXT(5) NOT NULL, [dddtlx] TEXT(4) NOT NULL, [telex] TEXT(6) NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [ramal] TEXT(4) NOT NULL, [contato] TEXT(22) NOT NULL, [ddd1] TEXT(4) NOT NULL, [telefone1] TEXT(9) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(22) NOT NULL, [dddfax] TEXT(4) NOT NULL, [telefax] TEXT(9) NOT NULL, [cgc] TEXT(18) NOT NULL, [inscr] TEXT(15) NOT NULL, [jucesp] TEXT(15) NOT NULL, [observa] TEXT(30) NOT NULL, [pessoa] TEXT(1) NOT NULL, [imuni] TEXT(15) NOT NULL, [site] TEXT(30) NOT NULL, [email] TEXT(30) NOT NULL);

-- Tabela: toolhelp
CREATE TABLE IF NOT EXISTS [toolhelp] ([dbf] TEXT(8) NOT NULL, [campo] TEXT(10) NOT NULL, [dado] TEXT(40) NOT NULL, [arquivo] TEXT(12) NOT NULL, [descricao] TEXT(2147483647) NOT NULL);

-- Tabela: unid
CREATE TABLE IF NOT EXISTS [unid] ([codigo] TEXT(10) NOT NULL, [numero] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [modireta] TEXT(1) NOT NULL, [codsiner] REAL NOT NULL);

-- Tabela: vinculo
CREATE TABLE IF NOT EXISTS [vinculo] ([id] REAL NOT NULL, [codigo] TEXT(2) NOT NULL, [nome] TEXT(150) NOT NULL, [cognome] TEXT(40) NOT NULL, [relacao_em] TEXT(1) NOT NULL, [gera_caged] TEXT(1) NOT NULL, [codrais] TEXT(2) NOT NULL, [cod_retenc] TEXT(3) NOT NULL, [pct_fgts] REAL NOT NULL, [integra_pl] TEXT(1) NOT NULL, [categoria_] TEXT(1) NOT NULL, [gera_rais] TEXT(1) NOT NULL, [pct_fgts_a] TEXT(1) NOT NULL, [fma_arred_] TEXT(1) NOT NULL, [tip_contra] TEXT(1) NOT NULL, [paga_feria] TEXT(1) NOT NULL, [paga_folha] TEXT(1) NOT NULL, [paga_13_sa] TEXT(1) NOT NULL, [paga_ppr] TEXT(1) NOT NULL, [codsefip] TEXT(10) NOT NULL);

-- Tabela: vtcomp
CREATE TABLE IF NOT EXISTS [vtcomp] ([codigo] REAL NOT NULL, [valor] REAL NOT NULL, [descr] TEXT(50) NOT NULL, [cod01] REAL NOT NULL, [cod02] REAL NOT NULL, [cod03] REAL NOT NULL, [cod04] REAL NOT NULL, [cod05] REAL NOT NULL, [cod06] REAL NOT NULL, [cod07] REAL NOT NULL, [cod08] REAL NOT NULL, [cod09] REAL NOT NULL, [cod10] REAL NOT NULL, [val01] REAL NOT NULL, [val02] REAL NOT NULL, [val03] REAL NOT NULL, [val04] REAL NOT NULL, [val05] REAL NOT NULL, [val06] REAL NOT NULL, [val07] REAL NOT NULL, [val08] REAL NOT NULL, [val09] REAL NOT NULL, [val10] REAL NOT NULL, [qtd01] REAL NOT NULL, [qtd02] REAL NOT NULL, [qtd03] REAL NOT NULL, [qtd04] REAL NOT NULL, [qtd05] REAL NOT NULL, [qtd06] REAL NOT NULL, [qtd07] REAL NOT NULL, [qtd08] REAL NOT NULL, [qtd09] REAL NOT NULL, [qtd10] REAL NOT NULL);

-- Tabela: vtconta
CREATE TABLE IF NOT EXISTS [vtconta] ([codigo] REAL NOT NULL, [valor] REAL NOT NULL, [dataatu] SHORTDATE NOT NULL, [descr] TEXT(30) NOT NULL, [tkcodope] TEXT(6) NOT NULL, [tkcodbil] TEXT(12) NOT NULL, [compl] TEXT(10) NOT NULL, [facial] TEXT(1) NOT NULL, [estado] TEXT(2) NOT NULL, [vbcodbil] TEXT(5) NOT NULL, [vbregiao] TEXT(2) NOT NULL, [vbtipo] TEXT(1) NOT NULL, [qtdemin] REAL NOT NULL, [qtdemax] REAL NOT NULL, [valmax] REAL NOT NULL, [valmin] REAL NOT NULL);

-- Tabela: vtoper
CREATE TABLE IF NOT EXISTS [vtoper] ([numero] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [nome] TEXT(40) NOT NULL, [endereco] TEXT(40) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(35) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [cxpostal] TEXT(5) NOT NULL, [dddtlx] TEXT(4) NOT NULL, [telex] TEXT(6) NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [ramal] TEXT(4) NOT NULL, [contato] TEXT(22) NOT NULL, [ddd1] TEXT(4) NOT NULL, [telefone1] TEXT(9) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(22) NOT NULL, [dddfax] TEXT(4) NOT NULL, [telefax] TEXT(9) NOT NULL, [cgc] TEXT(18) NOT NULL, [inscr] TEXT(15) NOT NULL, [jucesp] TEXT(15) NOT NULL, [observa] TEXT(30) NOT NULL, [pessoa] TEXT(1) NOT NULL, [imuni] TEXT(15) NOT NULL, [site] TEXT(30) NOT NULL, [email] TEXT(30) NOT NULL, [tkcodope] TEXT(6) NOT NULL);

-- �ndice: idx_aci_cep_cep
CREATE INDEX IF NOT EXISTS [idx_aci_cep_cep] ON [aci_cep] ([cep]);

-- �ndice: idx_agenda_agenda
CREATE INDEX IF NOT EXISTS [idx_agenda_agenda] ON [agenda] ([cddata]);

-- �ndice: idx_agupel_agupel
CREATE INDEX IF NOT EXISTS [idx_agupel_agupel] ON [agupel] ([tip], [depto], [setor], [secao]);

-- �ndice: idx_ajuger_ajuger
CREATE INDEX IF NOT EXISTS [idx_ajuger_ajuger] ON [ajuger] ([controle]);

-- �ndice: idx_apudepto_apudepto
CREATE INDEX IF NOT EXISTS [idx_apudepto_apudepto] ON [apudepto] ([controle]);

-- �ndice: idx_assmed_assmed
CREATE INDEX IF NOT EXISTS [idx_assmed_assmed] ON [assmed] ([ano], [mes]);

-- �ndice: idx_assodo_assodo
CREATE INDEX IF NOT EXISTS [idx_assodo_assodo] ON [assodo] ([ano], [mes]);

-- �ndice: idx_bcofgts_emp
CREATE INDEX IF NOT EXISTS [idx_bcofgts_emp] ON [bcofgts] ([emp]);

-- �ndice: idx_caged_caged
CREATE INDEX IF NOT EXISTS [idx_caged_caged] ON [caged] ([codigo]);

-- �ndice: idx_cartorio_codigo
CREATE INDEX IF NOT EXISTS [idx_cartorio_codigo] ON [cartorio] ([codigo]);

-- �ndice: idx_cbocnv_cbocnv
CREATE INDEX IF NOT EXISTS [idx_cbocnv_cbocnv] ON [cbocnv] ([cboold]);

-- �ndice: idx_cbocnv_cbocnv2
CREATE INDEX IF NOT EXISTS [idx_cbocnv_cbocnv2] ON [cbocnv] ([cbonew]);

-- �ndice: idx_cccor_cccor
CREATE INDEX IF NOT EXISTS [idx_cccor_cccor] ON [cccor] ([codigo], [numemp]);

-- �ndice: idx_ccesp_ccesp
CREATE INDEX IF NOT EXISTS [idx_ccesp_ccesp] ON [ccesp] ([codigo], [numemp]);

-- �ndice: idx_cid_cid-2
CREATE INDEX IF NOT EXISTS [idx_cid_cid-2] ON [cid] ([nome]);

-- �ndice: idx_cid_codigo
CREATE INDEX IF NOT EXISTS [idx_cid_codigo] ON [cid] ([codigo]);

-- �ndice: idx_cidgrupo_codigo
CREATE INDEX IF NOT EXISTS [idx_cidgrupo_codigo] ON [cidgrupo] ([codigo]);

-- �ndice: idx_cnaecnv_cnae1
CREATE INDEX IF NOT EXISTS [idx_cnaecnv_cnae1] ON [cnaecnv] ([cnae1]);

-- �ndice: idx_cnaecnv_cnae2
CREATE INDEX IF NOT EXISTS [idx_cnaecnv_cnae2] ON [cnaecnv] ([cnae2]);

-- �ndice: idx_codfgts_codfgts
CREATE INDEX IF NOT EXISTS [idx_codfgts_codfgts] ON [codfgts] ([codigo]);

-- �ndice: idx_codirrf_codirrf
CREATE INDEX IF NOT EXISTS [idx_codirrf_codirrf] ON [codirrf] ([codigo]);

-- �ndice: idx_contas_contas
CREATE INDEX IF NOT EXISTS [idx_contas_contas] ON [contas] ([codigo]);

-- �ndice: idx_ctarpa_ctarpa
CREATE INDEX IF NOT EXISTS [idx_ctarpa_ctarpa] ON [ctarpa] ([codigo]);

-- �ndice: idx_depto_depto
CREATE INDEX IF NOT EXISTS [idx_depto_depto] ON [depto] ([controle]);

-- �ndice: idx_depto_depto-2
CREATE INDEX IF NOT EXISTS [idx_depto_depto-2] ON [depto] ([depto]);

-- �ndice: idx_depto_depto-3
CREATE INDEX IF NOT EXISTS [idx_depto_depto-3] ON [depto] ([ccusto]);

-- �ndice: idx_diskrel1_diskrel1
CREATE INDEX IF NOT EXISTS [idx_diskrel1_diskrel1] ON [diskrel1] ([nome], [seq]);

-- �ndice: idx_diskrela_diskrela
CREATE INDEX IF NOT EXISTS [idx_diskrela_diskrela] ON [diskrela] ([codigo]);

-- �ndice: idx_diskrelm_diskrelm
CREATE INDEX IF NOT EXISTS [idx_diskrelm_diskrelm] ON [diskrelm] ([nome]);

-- �ndice: idx_diskrels_diskrels
CREATE INDEX IF NOT EXISTS [idx_diskrels_diskrels] ON [diskrels] ([nome]);

-- �ndice: idx_escalpad_escalpad
CREATE INDEX IF NOT EXISTS [idx_escalpad_escalpad] ON [escalpad] ([grupo], [seq]);

-- �ndice: idx_etiq1_etiq1
CREATE INDEX IF NOT EXISTS [idx_etiq1_etiq1] ON [etiq1] ([codigo]);

-- �ndice: idx_etiq3_etiq3
CREATE INDEX IF NOT EXISTS [idx_etiq3_etiq3] ON [etiq3] ([codigo]);

-- �ndice: idx_firma_firma
CREATE INDEX IF NOT EXISTS [idx_firma_firma] ON [firma] ([nrclien]);

-- �ndice: idx_fo_apu_fo_apu
CREATE INDEX IF NOT EXISTS [idx_fo_apu_fo_apu] ON [fo_apu] ([conta]);

-- �ndice: idx_fo_cbo_fo_cbo
CREATE INDEX IF NOT EXISTS [idx_fo_cbo_fo_cbo] ON [fo_cbo] ([codigo]);

-- �ndice: idx_fo_cbod_fo_cbod
CREATE INDEX IF NOT EXISTS [idx_fo_cbod_fo_cbod] ON [fo_cbod] ([codigo]);

-- �ndice: idx_fo_cbog_fo_cbon
CREATE INDEX IF NOT EXISTS [idx_fo_cbog_fo_cbon] ON [fo_cbog] ([codigo]);

-- �ndice: idx_fo_cbon_fo_cbon
CREATE INDEX IF NOT EXISTS [idx_fo_cbon_fo_cbon] ON [fo_cbon] ([codigo]);

-- �ndice: idx_fo_cnae2_fo_cnae2
CREATE INDEX IF NOT EXISTS [idx_fo_cnae2_fo_cnae2] ON [fo_cnae2] ([codigo]);

-- �ndice: idx_fo_cnae_fo_cnae
CREATE INDEX IF NOT EXISTS [idx_fo_cnae_fo_cnae] ON [fo_cnae] ([t_cnae]);

-- �ndice: idx_fo_csat_fo_csat
CREATE INDEX IF NOT EXISTS [idx_fo_csat_fo_csat] ON [fo_csat] ([codigo]);

-- �ndice: idx_fo_fai_fo_fai
CREATE INDEX IF NOT EXISTS [idx_fo_fai_fo_fai] ON [fo_fai] ([faixa]);

-- �ndice: idx_fo_plent_fo_plent
CREATE INDEX IF NOT EXISTS [idx_fo_plent_fo_plent] ON [fo_plent] ([nome]);

-- �ndice: idx_fo_rcau_fo_rcau
CREATE INDEX IF NOT EXISTS [idx_fo_rcau_fo_rcau] ON [fo_rcau] ([codigo]);

-- �ndice: idx_fo_rcau_fo_rcau2
CREATE INDEX IF NOT EXISTS [idx_fo_rcau_fo_rcau2] ON [fo_rcau] ([rais]);

-- �ndice: idx_fo_tab_fo_tab
CREATE INDEX IF NOT EXISTS [idx_fo_tab_fo_tab] ON [fo_tab] ([tabela], [codigo]);

-- �ndice: idx_folget_folget
CREATE INDEX IF NOT EXISTS [idx_folget_folget] ON [folget] ([codigo], [seq]);

-- �ndice: idx_folhaman_folhaman
CREATE INDEX IF NOT EXISTS [idx_folhaman_folhaman] ON [folhaman] ([arquivo]);

-- �ndice: idx_folhantx_folhantx
CREATE INDEX IF NOT EXISTS [idx_folhantx_folhantx] ON [folhantx] ([dbf], [ntx], [seq]);

-- �ndice: idx_folisntx_folisntx
CREATE INDEX IF NOT EXISTS [idx_folisntx_folisntx] ON [folisntx] ([dbf], [ntx], [seq]);

-- �ndice: idx_folopt_folopt
CREATE INDEX IF NOT EXISTS [idx_folopt_folopt] ON [folopt] ([itemenu], [posicao]);

-- �ndice: idx_folrel_folrel
CREATE INDEX IF NOT EXISTS [idx_folrel_folrel] ON [folrel] ([dbf], [campo]);

-- �ndice: idx_foltel_foltel
CREATE INDEX IF NOT EXISTS [idx_foltel_foltel] ON [foltel] ([codigo], [seq]);

-- �ndice: idx_foptoalm_foptoalm
CREATE INDEX IF NOT EXISTS [idx_foptoalm_foptoalm] ON [foptoalm] ([ano], [mes]);

-- �ndice: idx_foptobco_foptobco
CREATE INDEX IF NOT EXISTS [idx_foptobco_foptobco] ON [foptobco] ([empresa]);

-- �ndice: idx_foptocom_foptocom
CREATE INDEX IF NOT EXISTS [idx_foptocom_foptocom] ON [foptocom] ([ano], [mes], [empresa]);

-- �ndice: idx_foptocon_foptocon
CREATE INDEX IF NOT EXISTS [idx_foptocon_foptocon] ON [foptocon] ([empresa]);

-- �ndice: idx_foptoeqp_foptoeqp
CREATE INDEX IF NOT EXISTS [idx_foptoeqp_foptoeqp] ON [foptoeqp] ([numero]);

-- �ndice: idx_foptoeqp_foptoeqp2
CREATE INDEX IF NOT EXISTS [idx_foptoeqp_foptoeqp2] ON [foptoeqp] ([rep]);

-- �ndice: idx_foptohre_foptohre
CREATE INDEX IF NOT EXISTS [idx_foptohre_foptohre] ON [foptohre] ([codigo]);

-- �ndice: idx_foptomot_foptomot
CREATE INDEX IF NOT EXISTS [idx_foptomot_foptomot] ON [foptomot] ([numero]);

-- �ndice: idx_foptontx_foptontx
CREATE INDEX IF NOT EXISTS [idx_foptontx_foptontx] ON [foptontx] ([dbf], [ntx], [seq]);

-- �ndice: idx_foptopis_foptopis
CREATE INDEX IF NOT EXISTS [idx_foptopis_foptopis] ON [foptopis] ([numero]);

-- �ndice: idx_foptopro_foptopro
CREATE INDEX IF NOT EXISTS [idx_foptopro_foptopro] ON [foptopro] ([origem], [data]);

-- �ndice: idx_foptorel_foptorel
CREATE INDEX IF NOT EXISTS [idx_foptorel_foptorel] ON [foptorel] ([numero]);

-- �ndice: idx_foptoval_foptoval
CREATE INDEX IF NOT EXISTS [idx_foptoval_foptoval] ON [foptoval] ([empresa]);

-- �ndice: idx_forfentx_forfentx
CREATE INDEX IF NOT EXISTS [idx_forfentx_forfentx] ON [forfentx] ([dbf], [ntx], [seq]);

-- �ndice: idx_fosalmin_fosalmin
CREATE INDEX IF NOT EXISTS [idx_fosalmin_fosalmin] ON [fosalmin] ([ano], [mes]);

-- �ndice: idx_funcac_funcac
CREATE INDEX IF NOT EXISTS [idx_funcac_funcac] ON [funcac] ([codigo], [curso]);

-- �ndice: idx_funcao_funcao
CREATE INDEX IF NOT EXISTS [idx_funcao_funcao] ON [funcao] ([codigo]);

-- �ndice: idx_ginssd_ginssd
CREATE INDEX IF NOT EXISTS [idx_ginssd_ginssd] ON [ginssd] ([controle]);

-- �ndice: idx_horpad_horpad
CREATE INDEX IF NOT EXISTS [idx_horpad_horpad] ON [horpad] ([nome]);

-- �ndice: idx_medicgrp_codigo
CREATE INDEX IF NOT EXISTS [idx_medicgrp_codigo] ON [medicgrp] ([codigo]);

-- �ndice: idx_medmaq_medmaq
CREATE INDEX IF NOT EXISTS [idx_medmaq_medmaq] ON [medmaq] ([codigo]);

-- �ndice: idx_medmmb_medmmb
CREATE INDEX IF NOT EXISTS [idx_medmmb_medmmb] ON [medmmb] ([codigo]);

-- �ndice: idx_medrisoc_medrisoc
CREATE INDEX IF NOT EXISTS [idx_medrisoc_medrisoc] ON [medrisoc] ([codigo]);

-- �ndice: idx_meshol_meshol
CREATE INDEX IF NOT EXISTS [idx_meshol_meshol] ON [meshol] ([nome]);

-- �ndice: idx_muser_muser
CREATE INDEX IF NOT EXISTS [idx_muser_muser] ON [muser] ([usuario]);

-- �ndice: idx_muserm_muserm
CREATE INDEX IF NOT EXISTS [idx_muserm_muserm] ON [muserm] ([controle]);

-- �ndice: idx_nomesexo_nome
CREATE INDEX IF NOT EXISTS [idx_nomesexo_nome] ON [nomesexo] ([name]);

-- �ndice: idx_nota_nota
CREATE INDEX IF NOT EXISTS [idx_nota_nota] ON [nota] ([nome]);

-- �ndice: idx_orgemiss_codigo
CREATE INDEX IF NOT EXISTS [idx_orgemiss_codigo] ON [orgemiss] ([codigo]);

-- �ndice: idx_pisindev_pisindev
CREATE INDEX IF NOT EXISTS [idx_pisindev_pisindev] ON [pisindev] ([codigo]);

-- �ndice: idx_ptohoref_ptohoref
CREATE INDEX IF NOT EXISTS [idx_ptohoref_ptohoref] ON [ptohoref] ([relogio], [horini]);

-- �ndice: idx_raisnatj_raisnatj
CREATE INDEX IF NOT EXISTS [idx_raisnatj_raisnatj] ON [raisnatj] ([codigo]);

-- �ndice: idx_raistadm_raistadm
CREATE INDEX IF NOT EXISTS [idx_raistadm_raistadm] ON [raistadm] ([codigo]);

-- �ndice: idx_rbtemp_rbtemp
CREATE INDEX IF NOT EXISTS [idx_rbtemp_rbtemp] ON [rbtemp] ([numero], [data], [hora]);

-- �ndice: idx_recucopy_recucopy
CREATE INDEX IF NOT EXISTS [idx_recucopy_recucopy] ON [recucopy] ([nome]);

-- �ndice: idx_recuedit_recuedit
CREATE INDEX IF NOT EXISTS [idx_recuedit_recuedit] ON [recuedit] ([arquivo]);

-- �ndice: idx_recurntx_recurntx
CREATE INDEX IF NOT EXISTS [idx_recurntx_recurntx] ON [recurntx] ([dbf], [ntx], [seq]);

-- �ndice: idx_rel2_rel2
CREATE INDEX IF NOT EXISTS [idx_rel2_rel2] ON [rel2] ([codigo]);

-- �ndice: idx_relconta_relconta
CREATE INDEX IF NOT EXISTS [idx_relconta_relconta] ON [relconta] ([codigo]);

-- �ndice: idx_relogios_relogios
CREATE INDEX IF NOT EXISTS [idx_relogios_relogios] ON [relogios] ([numero]);

-- �ndice: idx_sindcnpj_sindcnpj
CREATE INDEX IF NOT EXISTS [idx_sindcnpj_sindcnpj] ON [sindcnpj] ([cnpj]);

-- �ndice: idx_sindicat_sindicat
CREATE INDEX IF NOT EXISTS [idx_sindicat_sindicat] ON [sindicat] ([codigo]);

-- �ndice: idx_sindicat_sindicat2
CREATE INDEX IF NOT EXISTS [idx_sindicat_sindicat2] ON [sindicat] ([cgc]);

-- �ndice: idx_sindicat_sindicat3
CREATE INDEX IF NOT EXISTS [idx_sindicat_sindicat3] ON [sindicat] ([codsi]);

-- �ndice: idx_tabarre_tabarre
CREATE INDEX IF NOT EXISTS [idx_tabarre_tabarre] ON [tabarre] ([ano], [mes]);

-- �ndice: idx_tabfalta_tabfalta
CREATE INDEX IF NOT EXISTS [idx_tabfalta_tabfalta] ON [tabfalta] ([codigo]);

-- �ndice: idx_tabinss_tabinss
CREATE INDEX IF NOT EXISTS [idx_tabinss_tabinss] ON [tabinss] ([nmes]);

-- �ndice: idx_tabirrf_tabirrf
CREATE INDEX IF NOT EXISTS [idx_tabirrf_tabirrf] ON [tabirrf] ([nmes]);

-- �ndice: idx_tabreaju_tabreaju
CREATE INDEX IF NOT EXISTS [idx_tabreaju_tabreaju] ON [tabreaju] ([codigo]);

-- �ndice: idx_tabtroco_tabtroco
CREATE INDEX IF NOT EXISTS [idx_tabtroco_tabtroco] ON [tabtroco] ([ano], [mes]);

-- �ndice: idx_tabturno_tabturno
CREATE INDEX IF NOT EXISTS [idx_tabturno_tabturno] ON [tabturno] ([codigo]);

-- �ndice: idx_tb_grpar_tb_grpar
CREATE INDEX IF NOT EXISTS [idx_tb_grpar_tb_grpar] ON [tb_grpar] ([codigo]);

-- �ndice: idx_tbcodpg_tbcodpg
CREATE INDEX IF NOT EXISTS [idx_tbcodpg_tbcodpg] ON [tbcodpg] ([codigo]);

-- �ndice: idx_telememo_telememo
CREATE INDEX IF NOT EXISTS [idx_telememo_telememo] ON [telememo] ([nome]);

-- �ndice: idx_tomador_tomador
CREATE INDEX IF NOT EXISTS [idx_tomador_tomador] ON [tomador] ([numero]);

-- �ndice: idx_toolhelp_toolhelp
CREATE INDEX IF NOT EXISTS [idx_toolhelp_toolhelp] ON [toolhelp] ([dbf], [campo]);

-- �ndice: idx_unid_unid-1
CREATE INDEX IF NOT EXISTS [idx_unid_unid-1] ON [unid] ([codigo]);

-- �ndice: idx_unid_unid-2
CREATE INDEX IF NOT EXISTS [idx_unid_unid-2] ON [unid] ([numero]);

-- �ndice: idx_unid_unid-3
CREATE INDEX IF NOT EXISTS [idx_unid_unid-3] ON [unid] ([codsiner]);

-- �ndice: idx_vinculo_vinculo
CREATE INDEX IF NOT EXISTS [idx_vinculo_vinculo] ON [vinculo] ([codigo]);

-- �ndice: idx_vtcomp_vtcomp
CREATE INDEX IF NOT EXISTS [idx_vtcomp_vtcomp] ON [vtcomp] ([codigo]);

-- �ndice: idx_vtconta_vtconta
CREATE INDEX IF NOT EXISTS [idx_vtconta_vtconta] ON [vtconta] ([codigo]);

-- �ndice: idx_vtconta_vtconta-2
CREATE INDEX IF NOT EXISTS [idx_vtconta_vtconta-2] ON [vtconta] ([tkcodbil]);

-- �ndice: idx_vtconta_vtconta-3
CREATE INDEX IF NOT EXISTS [idx_vtconta_vtconta-3] ON [vtconta] ([vbcodbil]);

-- �ndice: idx_vtoper-2
CREATE INDEX IF NOT EXISTS [idx_vtoper-2] ON [vtoper] ([tkcodope]);

-- �ndice: idx_vtoper_vtoper
CREATE INDEX IF NOT EXISTS [idx_vtoper_vtoper] ON [vtoper] ([numero]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
