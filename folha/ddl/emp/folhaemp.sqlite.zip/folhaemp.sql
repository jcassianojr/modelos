--
-- Arquivo gerado com SQLiteStudio v3.4.4 em ter ago 6 17:28:48 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: afdterr
CREATE TABLE IF NOT EXISTS [afdterr] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [hora] REAL NOT NULL, [motivo] REAL NOT NULL, [motoco] TEXT(70) NOT NULL);

-- Tabela: ajudira
CREATE TABLE IF NOT EXISTS [ajudira] ([cpf] TEXT(14) NOT NULL, [mes] REAL NOT NULL, [numero] REAL NOT NULL, [valor1] REAL NOT NULL, [valor2] REAL NOT NULL, [valor3] REAL NOT NULL, [valor5] REAL NOT NULL, [valor4] REAL NOT NULL, [valor6] REAL NOT NULL, [valor7] REAL NOT NULL, [valuf1] REAL NOT NULL, [valuf2] REAL NOT NULL, [valuf3] REAL NOT NULL, [valuf4] REAL NOT NULL, [valuf5] REAL NOT NULL, [valuf6] REAL NOT NULL, [valuf7] REAL NOT NULL);

-- Tabela: ajudird
CREATE TABLE IF NOT EXISTS [ajudird] ([cpf] TEXT(14) NOT NULL, [mes] REAL NOT NULL, [numero] REAL NOT NULL, [valor1] REAL NOT NULL, [valor2] REAL NOT NULL, [valor3] REAL NOT NULL, [valor5] REAL NOT NULL, [valor4] REAL NOT NULL, [valor6] REAL NOT NULL, [valor7] REAL NOT NULL, [valuf1] REAL NOT NULL, [valuf2] REAL NOT NULL, [valuf3] REAL NOT NULL, [valuf4] REAL NOT NULL, [valuf5] REAL NOT NULL, [valuf6] REAL NOT NULL, [valuf7] REAL NOT NULL);

-- Tabela: ajudirf
CREATE TABLE IF NOT EXISTS [ajudirf] ([cpf] TEXT(14) NOT NULL, [mes] REAL NOT NULL, [numero] REAL NOT NULL, [valor1] REAL NOT NULL, [valor2] REAL NOT NULL, [valor3] REAL NOT NULL, [valor5] REAL NOT NULL, [valor4] REAL NOT NULL, [valor6] REAL NOT NULL, [valor7] REAL NOT NULL, [valuf1] REAL NOT NULL, [valuf2] REAL NOT NULL, [valuf3] REAL NOT NULL, [valuf4] REAL NOT NULL, [valuf5] REAL NOT NULL, [valuf6] REAL NOT NULL, [valuf7] REAL NOT NULL);

-- Tabela: bcobak
CREATE TABLE IF NOT EXISTS [bcobak] ([numero] REAL NOT NULL, [ano] REAL NOT NULL, [mes] REAL NOT NULL, [saldo] REAL NOT NULL, [salant] REAL NOT NULL, [credito] REAL NOT NULL, [debito] REAL NOT NULL, [diaant] REAL NOT NULL, [diacre] REAL NOT NULL, [diadeb] REAL NOT NULL, [diasal] REAL NOT NULL);

-- Tabela: bcodek
CREATE TABLE IF NOT EXISTS [bcodek] ([numero] REAL NOT NULL, [ano] REAL NOT NULL, [mes] REAL NOT NULL, [saldo] REAL NOT NULL, [salant] REAL NOT NULL, [credito] REAL NOT NULL, [debito] REAL NOT NULL, [diaant] REAL NOT NULL, [diacre] REAL NOT NULL, [diadeb] REAL NOT NULL, [diasal] REAL NOT NULL);

-- Tabela: bcodem
CREATE TABLE IF NOT EXISTS [bcodem] ([numero] REAL NOT NULL, [ano] REAL NOT NULL, [mes] REAL NOT NULL, [saldo] REAL NOT NULL, [salant] REAL NOT NULL, [credito] REAL NOT NULL, [debito] REAL NOT NULL, [diaant] REAL NOT NULL, [diacre] REAL NOT NULL, [diadeb] REAL NOT NULL, [diasal] REAL NOT NULL);

-- Tabela: bcohrs
CREATE TABLE IF NOT EXISTS [bcohrs] ([numero] REAL NOT NULL, [ano] REAL NOT NULL, [mes] REAL NOT NULL, [saldo] REAL NOT NULL, [salant] REAL NOT NULL, [credito] REAL NOT NULL, [debito] REAL NOT NULL, [diaant] REAL NOT NULL, [diacre] REAL NOT NULL, [diadeb] REAL NOT NULL, [diasal] REAL NOT NULL);

-- Tabela: bcoreq
CREATE TABLE IF NOT EXISTS [bcoreq] ([requisi] REAL NOT NULL, [numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [horas] REAL NOT NULL, [dias] REAL NOT NULL, [obs] TEXT(60) NOT NULL, [imp] TEXT(6) NOT NULL);

-- Tabela: bcrbak
CREATE TABLE IF NOT EXISTS [bcrbak] ([requisi] REAL NOT NULL, [numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [horas] REAL NOT NULL, [dias] REAL NOT NULL, [obs] TEXT(60) NOT NULL, [imp] TEXT(6) NOT NULL);

-- Tabela: bh2408
CREATE TABLE IF NOT EXISTS [bh2408] ([requisi] REAL NOT NULL, [numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [horas] REAL NOT NULL, [dias] REAL NOT NULL, [obs] TEXT(60) NOT NULL, [imp] TEXT(6) NOT NULL);

-- Tabela: bh2409
CREATE TABLE IF NOT EXISTS [bh2409] ([requisi] REAL NOT NULL, [numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [horas] REAL NOT NULL, [dias] REAL NOT NULL, [obs] TEXT(60) NOT NULL, [imp] TEXT(6) NOT NULL);

-- Tabela: bk2408
CREATE TABLE IF NOT EXISTS [bk2408] ([requisi] REAL NOT NULL, [numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [horas] REAL NOT NULL, [dias] REAL NOT NULL, [obs] TEXT(60) NOT NULL, [imp] TEXT(6) NOT NULL);

-- Tabela: bk2409
CREATE TABLE IF NOT EXISTS [bk2409] ([requisi] REAL NOT NULL, [numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [horas] REAL NOT NULL, [dias] REAL NOT NULL, [obs] TEXT(60) NOT NULL, [imp] TEXT(6) NOT NULL);

-- Tabela: cesta
CREATE TABLE IF NOT EXISTS [cesta] ([numero] REAL NOT NULL, [nome] TEXT(40) NOT NULL, [cesta] TEXT(1) NOT NULL, [admitido] SHORTDATE NOT NULL, [obs] TEXT(40) NOT NULL);

-- Tabela: ctrhor
CREATE TABLE IF NOT EXISTS [ctrhor] ([depto] REAL NOT NULL, [setor] REAL NOT NULL, [secao] REAL NOT NULL, [nomec] TEXT(15) NOT NULL, [ano] REAL NOT NULL, [mes] REAL NOT NULL, [qtfun] REAL NOT NULL, [hrtra] REAL NOT NULL, [hrdsr] REAL NOT NULL, [hrnju] REAL NOT NULL, [hrjus] REAL NOT NULL, [ccusto] REAL NOT NULL, [unifun] TEXT(10) NOT NULL, [modireto] TEXT(1) NOT NULL);

-- Tabela: ferias
CREATE TABLE IF NOT EXISTS [ferias] ([numero] REAL NOT NULL, [depto] REAL NOT NULL, [secao] REAL NOT NULL, [setor] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [admitido] SHORTDATE NOT NULL, [ccusto] REAL NOT NULL, [unifun] TEXT(10) NOT NULL, [modireta] TEXT(1) NOT NULL, [qtven] REAL NOT NULL, [iniper] SHORTDATE NOT NULL, [fimper] SHORTDATE NOT NULL, [inigoz] SHORTDATE NOT NULL, [fimgoz] SHORTDATE NOT NULL, [iniprg] SHORTDATE NOT NULL, [fimprg] SHORTDATE NOT NULL, [depsetsec] REAL NOT NULL, [denunifun] TEXT(30) NOT NULL, [cnumero] TEXT(8) NOT NULL, [funcao] REAL NOT NULL, [funnome] TEXT(30) NOT NULL, [htt] TEXT(2) NOT NULL, [situacao] TEXT(2) NOT NULL, [saladm] REAL NOT NULL);

-- Tabela: fo_comp
CREATE TABLE IF NOT EXISTS [fo_comp] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL, [valormes1] REAL NOT NULL, [valormes3] REAL NOT NULL, [mes1] REAL NOT NULL, [mes2] REAL NOT NULL);

-- Tabela: fo_exp
CREATE TABLE IF NOT EXISTS [fo_exp] ([depto] REAL NOT NULL, [setor] REAL NOT NULL, [secao] REAL NOT NULL, [chapa] REAL NOT NULL, [numero] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [admitido] SHORTDATE NOT NULL, [dias1] REAL NOT NULL, [dias2] REAL NOT NULL, [datafim1] SHORTDATE NOT NULL, [datafim2] SHORTDATE NOT NULL, [obs1] TEXT(60) NOT NULL, [obs2] TEXT(60) NOT NULL, [obs3] TEXT(60) NOT NULL, [obs4] TEXT(60) NOT NULL, [obs5] TEXT(60) NOT NULL);

-- Tabela: fo_fer
CREATE TABLE IF NOT EXISTS [fo_fer] ([depto] REAL NOT NULL, [secao] REAL NOT NULL, [setor] REAL NOT NULL, [chapa] REAL NOT NULL, [numero] REAL NOT NULL, [controle] REAL NOT NULL, [datferias] SHORTDATE NOT NULL, [datferiasf] SHORTDATE NOT NULL, [faltas] REAL NOT NULL, [gozou1de] SHORTDATE NOT NULL, [gozou1ate] SHORTDATE NOT NULL, [gozou2de] SHORTDATE NOT NULL, [gozou2ate] SHORTDATE NOT NULL, [programa] SHORTDATE NOT NULL, [programa1] SHORTDATE NOT NULL, [diasjus] REAL NOT NULL, [diaspago] REAL NOT NULL, [diasgoza] REAL NOT NULL, [baixado] TEXT(1) NOT NULL, [abono1de] SHORTDATE NOT NULL, [abono1ate] SHORTDATE NOT NULL, [diaspago2] REAL NOT NULL, [diasgoza2] REAL NOT NULL, [diaspago3] REAL NOT NULL, [diasgoza3] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [compdatai] SHORTDATE NOT NULL, [compdataf] SHORTDATE NOT NULL, [fa01] REAL NOT NULL, [fa02] REAL NOT NULL, [fa03] REAL NOT NULL, [fa04] REAL NOT NULL, [fa05] REAL NOT NULL, [fa06] REAL NOT NULL, [fa07] REAL NOT NULL, [fa08] REAL NOT NULL, [fa09] REAL NOT NULL, [fa10] REAL NOT NULL, [fa11] REAL NOT NULL, [fa12] REAL NOT NULL, [fa13] REAL NOT NULL, [salvar] REAL NOT NULL, [salvarc] REAL NOT NULL, [compaboi] SHORTDATE NOT NULL, [compabof] SHORTDATE NOT NULL);

-- Tabela: fo_ffe
CREATE TABLE IF NOT EXISTS [fo_ffe] ([conta] REAL NOT NULL, [mes] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL);

-- Tabela: fo_fp13a
CREATE TABLE IF NOT EXISTS [fo_fp13a] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL);

-- Tabela: fo_fp13b
CREATE TABLE IF NOT EXISTS [fo_fp13b] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL);

-- Tabela: fo_fp13c
CREATE TABLE IF NOT EXISTS [fo_fp13c] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL);

-- Tabela: fo_hor
CREATE TABLE IF NOT EXISTS [fo_hor] ([numero] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [d1] TEXT(60) NOT NULL, [d2] TEXT(60) NOT NULL, [d3] TEXT(60) NOT NULL, [d4] TEXT(60) NOT NULL, [d5] TEXT(60) NOT NULL, [d6] TEXT(60) NOT NULL, [d7] TEXT(60) NOT NULL);

-- Tabela: fo_ira
CREATE TABLE IF NOT EXISTS [fo_ira] ([numero] REAL NOT NULL, [codren] REAL NOT NULL, [mes] REAL NOT NULL, [valor] REAL NOT NULL, [valufir] REAL NOT NULL, [controle] REAL NOT NULL, [cpf] TEXT(14) NOT NULL, [control2] TEXT(20) NOT NULL);

-- Tabela: fo_ird
CREATE TABLE IF NOT EXISTS [fo_ird] ([numero] REAL NOT NULL, [codren] REAL NOT NULL, [mes] REAL NOT NULL, [valor] REAL NOT NULL, [valufir] REAL NOT NULL, [controle] REAL NOT NULL, [cpf] TEXT(14) NOT NULL, [control2] TEXT(20) NOT NULL);

-- Tabela: fo_irr
CREATE TABLE IF NOT EXISTS [fo_irr] ([numero] REAL NOT NULL, [codren] REAL NOT NULL, [mes] REAL NOT NULL, [valor] REAL NOT NULL, [valufir] REAL NOT NULL, [controle] REAL NOT NULL, [cpf] TEXT(14) NOT NULL, [control2] TEXT(20) NOT NULL);

-- Tabela: fo_oco
CREATE TABLE IF NOT EXISTS [fo_oco] ([numero] REAL NOT NULL, [datasaida] SHORTDATE NOT NULL, [periodopag] REAL NOT NULL, [dataretorn] SHORTDATE NOT NULL, [codigo] TEXT(2) NOT NULL, [nome] TEXT(30) NOT NULL, [tem_13_sal] TEXT(1) NOT NULL, [prazomaxim] REAL NOT NULL, [conta] REAL NOT NULL, [controle] REAL NOT NULL, [obs] TEXT(60) NOT NULL, [obs2] TEXT(60) NOT NULL, [nomef] TEXT(30) NOT NULL, [datafim13s] SHORTDATE NOT NULL, [datafimpag] SHORTDATE NOT NULL, [depto] REAL NOT NULL, [setor] REAL NOT NULL, [secao] REAL NOT NULL, [chapa] REAL NOT NULL, [valpg] REAL NOT NULL, [abtfgts] TEXT(1) NOT NULL, [codfgs] TEXT(2) NOT NULL, [codfgr] TEXT(2) NOT NULL, [pgfgs] TEXT(1) NOT NULL, [pgfgr] TEXT(1) NOT NULL, [diass] REAL NOT NULL, [diasr] REAL NOT NULL);

-- Tabela: fo_pes
CREATE TABLE IF NOT EXISTS [fo_pes] ([numero] REAL NOT NULL, [cnumero] TEXT(8) NOT NULL, [depto] REAL NOT NULL, [secao] REAL NOT NULL, [setor] REAL NOT NULL, [depsetsec] REAL NOT NULL, [chapa] REAL NOT NULL, [ordem] REAL NOT NULL, [nome] TEXT(60) NOT NULL, [endtip] TEXT(3) NOT NULL, [ender] TEXT(40) NOT NULL, [endnum] TEXT(10) NOT NULL, [endcompl] TEXT(30) NOT NULL, [bairro] TEXT(30) NOT NULL, [ibge] TEXT(7) NOT NULL, [cidade] TEXT(35) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [fone] TEXT(14) NOT NULL, [nasc] SHORTDATE NOT NULL, [nascibge] TEXT(7) NOT NULL, [anonasci] REAL NOT NULL, [nascpais] TEXT(4) NOT NULL, [civil] REAL NOT NULL, [estcivil] TEXT(1) NOT NULL, [escrais] TEXT(2) NOT NULL, [pai] TEXT(40) NOT NULL, [mae] TEXT(40) NOT NULL, [cpf] TEXT(14) NOT NULL, [profis] TEXT(7) NOT NULL, [ctpsdata] SHORTDATE NOT NULL, [ctpsuf] TEXT(2) NOT NULL, [serie] TEXT(5) NOT NULL, [pis] TEXT(11) NOT NULL, [rgtip] TEXT(3) NOT NULL, [rg] TEXT(14) NOT NULL, [rguf] TEXT(2) NOT NULL, [rgemis] TEXT(6) NOT NULL, [rgdata] SHORTDATE NOT NULL, [fgts] SHORTDATE NOT NULL, [admitido] SHORTDATE NOT NULL, [tipfgts] TEXT(2) NOT NULL, [tipo] TEXT(1) NOT NULL, [hrsem] REAL NOT NULL, [funcao] REAL NOT NULL, [demitido] SHORTDATE NOT NULL, [motivo] TEXT(2) NOT NULL, [datcontsin] SHORTDATE NOT NULL, [sindicato] REAL NOT NULL, [banco] TEXT(3) NOT NULL, [agencia] TEXT(7) NOT NULL, [conta] TEXT(12) NOT NULL, [sociosind] TEXT(1) NOT NULL, [situacao] TEXT(2) NOT NULL, [insalubri] TEXT(1) NOT NULL, [periculo] TEXT(1) NOT NULL, [avisoprev] SHORTDATE NOT NULL, [altfgts] TEXT(3) NOT NULL, [contafgts] TEXT(11) NOT NULL, [avosm] REAL NOT NULL, [sexo] TEXT(1) NOT NULL, [assm] TEXT(1) NOT NULL, [asso] TEXT(1) NOT NULL, [ht] TEXT(40) NOT NULL, [fgtsmot] TEXT(2) NOT NULL, [motivodem] REAL NOT NULL, [htt] TEXT(2) NOT NULL, [excvale] TEXT(1) NOT NULL, [valehora] REAL NOT NULL, [salvar13s] REAL NOT NULL, [cnh] TEXT(11) NOT NULL, [catcnh] TEXT(2) NOT NULL, [valcnh] SHORTDATE NOT NULL, [expcnh] SHORTDATE NOT NULL, [oc] TEXT(10) NOT NULL, [ocval] SHORTDATE NOT NULL, [ocexp] SHORTDATE NOT NULL, [ocemi] TEXT(10) NOT NULL, [exadat] SHORTDATE NOT NULL, [exapro] SHORTDATE NOT NULL, [categoria] TEXT(2) NOT NULL, [pgfgts] TEXT(1) NOT NULL, [ocofgts] TEXT(1) NOT NULL, [eoco] TEXT(1) NOT NULL, [vtdias] REAL NOT NULL, [ci] REAL NOT NULL, [classe] REAL NOT NULL, [tomador] REAL NOT NULL, [pgassi] TEXT(1) NOT NULL, [racs] TEXT(1) NOT NULL, [defici] TEXT(1) NOT NULL, [ccusto] REAL NOT NULL, [unifun] TEXT(10) NOT NULL, [modireta] TEXT(1) NOT NULL, [cesta] TEXT(1) NOT NULL, [vt] TEXT(1) NOT NULL, [email] TEXT(50) NOT NULL, [titulo] TEXT(14) NOT NULL, [tituzona] TEXT(3) NOT NULL, [tituseca] TEXT(3) NOT NULL, [cns] TEXT(15) NOT NULL, [numregant] REAL NOT NULL, [numempant] REAL NOT NULL, [dattransf] SHORTDATE NOT NULL, [etadm] TEXT(1) NOT NULL, [eiadm] TEXT(1) NOT NULL, [e1adm] TEXT(1) NOT NULL, [eregi] TEXT(3) NOT NULL, [eprev] TEXT(4) NOT NULL, [evinc] TEXT(3) NOT NULL, [eltra] TEXT(1) NOT NULL, [etjor] TEXT(1) NOT NULL, [etcor] TEXT(1) NOT NULL, [saladm] REAL NOT NULL, [aposent] TEXT(1) NOT NULL, [aposend] SHORTDATE NOT NULL, [reserv] TEXT(12) NOT NULL, [resecat] TEXT(1) NOT NULL, [ocuf] TEXT(2) NOT NULL, [celular] TEXT(14) NOT NULL, [ricuf] TEXT(2) NOT NULL, [ricexp] SHORTDATE NOT NULL, [ric] TEXT(32) NOT NULL, [ricemi] TEXT(3) NOT NULL);

-- Tabela: fo_pfe
CREATE TABLE IF NOT EXISTS [fo_pfe] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL, [valormes1] REAL NOT NULL, [valormes2] REAL NOT NULL, [mes1] REAL NOT NULL, [mes2] REAL NOT NULL, [datacomp] SHORTDATE NOT NULL);

-- Tabela: fo_pos
CREATE TABLE IF NOT EXISTS [fo_pos] ([numero] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [semini] SHORTDATE NOT NULL, [semfim] SHORTDATE NOT NULL, [cta01] REAL NOT NULL, [cta02] REAL NOT NULL, [cta03] REAL NOT NULL, [cta04] REAL NOT NULL, [cta05] REAL NOT NULL, [cta06] REAL NOT NULL, [cta07] REAL NOT NULL, [cta08] REAL NOT NULL, [cta09] REAL NOT NULL, [cta10] REAL NOT NULL, [cta11] REAL NOT NULL, [cta12] REAL NOT NULL, [cta13] REAL NOT NULL, [cta14] REAL NOT NULL, [cta15] REAL NOT NULL, [cta16] REAL NOT NULL, [cta17] REAL NOT NULL, [cta18] REAL NOT NULL, [cta19] REAL NOT NULL, [cta20] REAL NOT NULL, [cta21] REAL NOT NULL, [cta22] REAL NOT NULL, [cta23] REAL NOT NULL, [cta24] REAL NOT NULL, [val01] REAL NOT NULL, [val02] REAL NOT NULL, [val03] REAL NOT NULL, [val04] REAL NOT NULL, [val05] REAL NOT NULL, [val06] REAL NOT NULL, [val07] REAL NOT NULL, [val08] REAL NOT NULL, [val09] REAL NOT NULL, [val10] REAL NOT NULL, [val11] REAL NOT NULL, [val12] REAL NOT NULL, [val13] REAL NOT NULL, [val14] REAL NOT NULL, [val15] REAL NOT NULL, [val16] REAL NOT NULL, [val17] REAL NOT NULL, [val18] REAL NOT NULL, [val19] REAL NOT NULL, [val20] REAL NOT NULL, [val21] REAL NOT NULL, [val22] REAL NOT NULL, [val23] REAL NOT NULL, [val24] REAL NOT NULL, [bcohrs] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: fo_pot
CREATE TABLE IF NOT EXISTS [fo_pot] ([numero] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [cta01] REAL NOT NULL, [cta02] REAL NOT NULL, [cta03] REAL NOT NULL, [cta04] REAL NOT NULL, [cta05] REAL NOT NULL, [cta06] REAL NOT NULL, [cta07] REAL NOT NULL, [cta08] REAL NOT NULL, [cta09] REAL NOT NULL, [cta10] REAL NOT NULL, [cta11] REAL NOT NULL, [cta12] REAL NOT NULL, [cta13] REAL NOT NULL, [cta14] REAL NOT NULL, [cta15] REAL NOT NULL, [cta16] REAL NOT NULL, [cta17] REAL NOT NULL, [cta18] REAL NOT NULL, [cta19] REAL NOT NULL, [cta20] REAL NOT NULL, [cta21] REAL NOT NULL, [cta22] REAL NOT NULL, [cta23] REAL NOT NULL, [cta24] REAL NOT NULL, [val01] REAL NOT NULL, [val02] REAL NOT NULL, [val03] REAL NOT NULL, [val04] REAL NOT NULL, [val05] REAL NOT NULL, [val06] REAL NOT NULL, [val07] REAL NOT NULL, [val08] REAL NOT NULL, [val09] REAL NOT NULL, [val10] REAL NOT NULL, [val11] REAL NOT NULL, [val12] REAL NOT NULL, [val13] REAL NOT NULL, [val14] REAL NOT NULL, [val15] REAL NOT NULL, [val16] REAL NOT NULL, [val17] REAL NOT NULL, [val18] REAL NOT NULL, [val19] REAL NOT NULL, [val20] REAL NOT NULL, [val21] REAL NOT NULL, [val22] REAL NOT NULL, [val23] REAL NOT NULL, [val24] REAL NOT NULL, [bcohrs] REAL NOT NULL);

-- Tabela: fo_psl
CREATE TABLE IF NOT EXISTS [fo_psl] ([numero] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [admitido] SHORTDATE NOT NULL, [funcao] TEXT(20) NOT NULL, [salant] REAL NOT NULL, [salatu] REAL NOT NULL, [salpro] REAL NOT NULL, [taxa1] REAL NOT NULL, [taxa2] REAL NOT NULL);

-- Tabela: fo_ptt
CREATE TABLE IF NOT EXISTS [fo_ptt] ([numero] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [cta01] REAL NOT NULL, [cta02] REAL NOT NULL, [cta03] REAL NOT NULL, [cta04] REAL NOT NULL, [cta05] REAL NOT NULL, [cta06] REAL NOT NULL, [cta07] REAL NOT NULL, [cta08] REAL NOT NULL, [cta09] REAL NOT NULL, [cta10] REAL NOT NULL, [cta11] REAL NOT NULL, [cta12] REAL NOT NULL, [cta13] REAL NOT NULL, [cta14] REAL NOT NULL, [cta15] REAL NOT NULL, [cta16] REAL NOT NULL, [val01] REAL NOT NULL, [val02] REAL NOT NULL, [val03] REAL NOT NULL, [val04] REAL NOT NULL, [val05] REAL NOT NULL, [val06] REAL NOT NULL, [val07] REAL NOT NULL, [val08] REAL NOT NULL, [val09] REAL NOT NULL, [val10] REAL NOT NULL, [val11] REAL NOT NULL, [val12] REAL NOT NULL, [val13] REAL NOT NULL, [val14] REAL NOT NULL, [val15] REAL NOT NULL, [val16] REAL NOT NULL, [bcohrs] REAL NOT NULL);

-- Tabela: fo_rdd
CREATE TABLE IF NOT EXISTS [fo_rdd] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [mes] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL);

-- Tabela: fo_relhr
CREATE TABLE IF NOT EXISTS [fo_relhr] ([numero] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [hfol00] TEXT(1) NOT NULL, [grupo] TEXT(2) NOT NULL, [almoco] TEXT(1) NOT NULL, [padrao] TEXT(1) NOT NULL, [horref] TEXT(2) NOT NULL, [maralm] TEXT(1) NOT NULL, [marmes] TEXT(1) NOT NULL, [dataref1] SHORTDATE NOT NULL);

-- Tabela: fo_res
CREATE TABLE IF NOT EXISTS [fo_res] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [mes] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL);

-- Tabela: fo_rss
CREATE TABLE IF NOT EXISTS [fo_rss] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL, [mes1] REAL NOT NULL, [valormes1] REAL NOT NULL, [mes2] REAL NOT NULL, [valormes2] REAL NOT NULL);

-- Tabela: fo_sal
CREATE TABLE IF NOT EXISTS [fo_sal] ([numero] REAL NOT NULL, [ano] REAL NOT NULL, [saljan] REAL NOT NULL, [mot1] TEXT(2) NOT NULL, [salfev] REAL NOT NULL, [mot2] TEXT(2) NOT NULL, [salmar] REAL NOT NULL, [mot3] TEXT(2) NOT NULL, [salabr] REAL NOT NULL, [mot4] TEXT(2) NOT NULL, [salmai] REAL NOT NULL, [mot5] TEXT(2) NOT NULL, [saljun] REAL NOT NULL, [mot6] TEXT(2) NOT NULL, [saljul] REAL NOT NULL, [mot7] TEXT(2) NOT NULL, [salago] REAL NOT NULL, [mot8] TEXT(2) NOT NULL, [salset] REAL NOT NULL, [mot9] TEXT(2) NOT NULL, [salout] REAL NOT NULL, [mot10] TEXT(2) NOT NULL, [salnov] REAL NOT NULL, [mot11] TEXT(2) NOT NULL, [saldez] REAL NOT NULL, [mot12] TEXT(2) NOT NULL);

-- Tabela: fo_var
CREATE TABLE IF NOT EXISTS [fo_var] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [tipo] REAL NOT NULL, [controle] REAL NOT NULL, [varfer] REAL NOT NULL, [varres] REAL NOT NULL, [var13s] REAL NOT NULL, [nivfer] REAL NOT NULL, [nivres] REAL NOT NULL, [niv13s] REAL NOT NULL);

-- Tabela: fo_vbr
CREATE TABLE IF NOT EXISTS [fo_vbr] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [tipo] REAL NOT NULL, [controle] REAL NOT NULL, [varfer] REAL NOT NULL, [varres] REAL NOT NULL, [var13s] REAL NOT NULL, [nivfer] REAL NOT NULL, [nivres] REAL NOT NULL, [niv13s] REAL NOT NULL);

-- Tabela: foopes
CREATE TABLE IF NOT EXISTS [foopes] ([numero] REAL NOT NULL, [cnumero] TEXT(8) NOT NULL, [depto] REAL NOT NULL, [secao] REAL NOT NULL, [setor] REAL NOT NULL, [depsetsec] REAL NOT NULL, [chapa] REAL NOT NULL, [ordem] REAL NOT NULL, [nome] TEXT(60) NOT NULL, [endtip] TEXT(3) NOT NULL, [ender] TEXT(40) NOT NULL, [endnum] TEXT(10) NOT NULL, [endcompl] TEXT(30) NOT NULL, [bairro] TEXT(30) NOT NULL, [ibge] TEXT(7) NOT NULL, [cidade] TEXT(35) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [fone] TEXT(14) NOT NULL, [nasc] SHORTDATE NOT NULL, [nascibge] TEXT(7) NOT NULL, [anonasci] REAL NOT NULL, [nascpais] TEXT(4) NOT NULL, [civil] REAL NOT NULL, [estcivil] TEXT(1) NOT NULL, [escrais] TEXT(2) NOT NULL, [pai] TEXT(40) NOT NULL, [mae] TEXT(40) NOT NULL, [cpf] TEXT(14) NOT NULL, [profis] TEXT(7) NOT NULL, [ctpsdata] SHORTDATE NOT NULL, [ctpsuf] TEXT(2) NOT NULL, [serie] TEXT(5) NOT NULL, [pis] TEXT(11) NOT NULL, [rgtip] TEXT(3) NOT NULL, [rg] TEXT(14) NOT NULL, [rguf] TEXT(2) NOT NULL, [rgemis] TEXT(6) NOT NULL, [rgdata] SHORTDATE NOT NULL, [fgts] SHORTDATE NOT NULL, [admitido] SHORTDATE NOT NULL, [tipfgts] TEXT(2) NOT NULL, [tipo] TEXT(1) NOT NULL, [hrsem] REAL NOT NULL, [funcao] REAL NOT NULL, [demitido] SHORTDATE NOT NULL, [motivo] TEXT(2) NOT NULL, [datcontsin] SHORTDATE NOT NULL, [sindicato] REAL NOT NULL, [banco] TEXT(3) NOT NULL, [agencia] TEXT(7) NOT NULL, [conta] TEXT(12) NOT NULL, [sociosind] TEXT(1) NOT NULL, [situacao] TEXT(2) NOT NULL, [insalubri] TEXT(1) NOT NULL, [periculo] TEXT(1) NOT NULL, [avisoprev] SHORTDATE NOT NULL, [altfgts] TEXT(3) NOT NULL, [contafgts] TEXT(11) NOT NULL, [avosm] REAL NOT NULL, [sexo] TEXT(1) NOT NULL, [assm] TEXT(1) NOT NULL, [asso] TEXT(1) NOT NULL, [ht] TEXT(40) NOT NULL, [fgtsmot] TEXT(2) NOT NULL, [motivodem] REAL NOT NULL, [htt] TEXT(2) NOT NULL, [excvale] TEXT(1) NOT NULL, [valehora] REAL NOT NULL, [salvar13s] REAL NOT NULL, [cnh] TEXT(11) NOT NULL, [catcnh] TEXT(2) NOT NULL, [valcnh] SHORTDATE NOT NULL, [expcnh] SHORTDATE NOT NULL, [oc] TEXT(10) NOT NULL, [ocval] SHORTDATE NOT NULL, [ocexp] SHORTDATE NOT NULL, [ocemi] TEXT(10) NOT NULL, [exadat] SHORTDATE NOT NULL, [exapro] SHORTDATE NOT NULL, [categoria] TEXT(2) NOT NULL, [pgfgts] TEXT(1) NOT NULL, [ocofgts] TEXT(1) NOT NULL, [eoco] TEXT(1) NOT NULL, [vtdias] REAL NOT NULL, [ci] REAL NOT NULL, [classe] REAL NOT NULL, [tomador] REAL NOT NULL, [pgassi] TEXT(1) NOT NULL, [racs] TEXT(1) NOT NULL, [defici] TEXT(1) NOT NULL, [ccusto] REAL NOT NULL, [unifun] TEXT(10) NOT NULL, [modireta] TEXT(1) NOT NULL, [cesta] TEXT(1) NOT NULL, [vt] TEXT(1) NOT NULL, [email] TEXT(50) NOT NULL, [titulo] TEXT(14) NOT NULL, [tituzona] TEXT(3) NOT NULL, [tituseca] TEXT(3) NOT NULL, [cns] TEXT(15) NOT NULL, [numregant] REAL NOT NULL, [numempant] REAL NOT NULL, [dattransf] SHORTDATE NOT NULL, [etadm] TEXT(1) NOT NULL, [eiadm] TEXT(1) NOT NULL, [e1adm] TEXT(1) NOT NULL, [eregi] TEXT(3) NOT NULL, [eprev] TEXT(4) NOT NULL, [evinc] TEXT(3) NOT NULL, [eltra] TEXT(1) NOT NULL, [etjor] TEXT(1) NOT NULL, [etcor] TEXT(1) NOT NULL, [saladm] REAL NOT NULL, [aposent] TEXT(1) NOT NULL, [aposend] SHORTDATE NOT NULL, [reserv] TEXT(12) NOT NULL, [resecat] TEXT(1) NOT NULL, [ocuf] TEXT(2) NOT NULL, [celular] TEXT(14) NOT NULL, [ricuf] TEXT(2) NOT NULL, [ricexp] SHORTDATE NOT NULL, [ric] TEXT(32) NOT NULL, [ricemi] TEXT(3) NOT NULL);

-- Tabela: foptoatr
CREATE TABLE IF NOT EXISTS [foptoatr] ([numero] REAL NOT NULL, [nome] TEXT(40) NOT NULL, [data] SHORTDATE NOT NULL, [ent] REAL NOT NULL, [rent] REAL NOT NULL, [sai] REAL NOT NULL, [rsai] REAL NOT NULL, [codanl] TEXT(2) NOT NULL, [cod] TEXT(2) NOT NULL, [sod] TEXT(2) NOT NULL, [bcosn] TEXT(1) NOT NULL, [obsatr] TEXT(78) NOT NULL, [horxxx] REAL NOT NULL);

-- Tabela: foptoeve
CREATE TABLE IF NOT EXISTS [foptoeve] ([dia] REAL NOT NULL, [mes] REAL NOT NULL, [codigo] TEXT(2) NOT NULL, [descricao] TEXT(40) NOT NULL, [bcosn] TEXT(1) NOT NULL, [redsn] TEXT(1) NOT NULL, [folsn] TEXT(1) NOT NULL);

-- Tabela: foptoprd
CREATE TABLE IF NOT EXISTS [foptoprd] ([origem] REAL NOT NULL, [destino] REAL NOT NULL, [data] SHORTDATE NOT NULL, [nome] TEXT(30) NOT NULL);

-- Tabela: forais
CREATE TABLE IF NOT EXISTS [forais] ([ano] REAL NOT NULL, [numero] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [raizjan] REAL NOT NULL, [raizfev] REAL NOT NULL, [raizmar] REAL NOT NULL, [raizabr] REAL NOT NULL, [raizmai] REAL NOT NULL, [raizjun] REAL NOT NULL, [raizjul] REAL NOT NULL, [raizago] REAL NOT NULL, [raizset] REAL NOT NULL, [raizout] REAL NOT NULL, [raiznov] REAL NOT NULL, [raizdez] REAL NOT NULL, [raizavi] REAL NOT NULL, [sal13_1] REAL NOT NULL, [mes_1] REAL NOT NULL, [sal13_2] REAL NOT NULL, [mes_2] REAL NOT NULL, [raizfer] REAL NOT NULL, [raizacr] REAL NOT NULL, [raizgra] REAL NOT NULL, [raizmul] REAL NOT NULL, [raizbch] REAL NOT NULL, [mesbch] REAL NOT NULL, [mesacr] REAL NOT NULL, [mesgra] REAL NOT NULL, [ibgecod] TEXT(7) NOT NULL, [horjan] REAL NOT NULL, [horfev] REAL NOT NULL, [hormar] REAL NOT NULL, [horabr] REAL NOT NULL, [hormai] REAL NOT NULL, [horjun] REAL NOT NULL, [horjul] REAL NOT NULL, [horago] REAL NOT NULL, [horset] REAL NOT NULL, [horout] REAL NOT NULL, [hornov] REAL NOT NULL, [hordez] REAL NOT NULL, [codafa01] TEXT(2) NOT NULL, [iniafa01] TEXT(4) NOT NULL, [fimafa01] TEXT(4) NOT NULL, [codafa02] TEXT(2) NOT NULL, [iniafa02] TEXT(4) NOT NULL, [fimafa02] TEXT(4) NOT NULL, [codafa03] TEXT(2) NOT NULL, [iniafa03] TEXT(4) NOT NULL, [fimafa03] TEXT(4) NOT NULL, [diasafa] REAL NOT NULL, [cgcsoc1] TEXT(14) NOT NULL, [valsoc1] REAL NOT NULL, [cgcsoc2] TEXT(14) NOT NULL, [valsoc2] REAL NOT NULL, [cgcsin] TEXT(14) NOT NULL, [valsin] REAL NOT NULL, [cgcass] TEXT(14) NOT NULL, [valass] REAL NOT NULL, [cgccon] TEXT(14) NOT NULL, [valcon] REAL NOT NULL, [raisvinc] TEXT(2) NOT NULL, [raissitu] TEXT(1) NOT NULL, [raisdem] TEXT(2) NOT NULL, [alvara] TEXT(1) NOT NULL, [tipoadm] TEXT(2) NOT NULL);

-- Tabela: fosfam
CREATE TABLE IF NOT EXISTS [fosfam] ([requisi] REAL NOT NULL, [numero] REAL NOT NULL, [nome] TEXT(40) NOT NULL, [nascto] SHORTDATE NOT NULL, [local] TEXT(35) NOT NULL, [cartorio] TEXT(15) NOT NULL, [nregis] TEXT(32) NOT NULL, [livro] TEXT(5) NOT NULL, [folha] TEXT(5) NOT NULL, [entrega] SHORTDATE NOT NULL, [baixa] SHORTDATE NOT NULL, [cns] TEXT(15) NOT NULL, [irrf] TEXT(1) NOT NULL, [salfam] TEXT(1) NOT NULL, [grpa] TEXT(2) NOT NULL, [esocial] TEXT(2) NOT NULL, [ncartorio] TEXT(6) NOT NULL, [termo] TEXT(7) NOT NULL, [localibge] TEXT(7) NOT NULL, [sexo] TEXT(1) NOT NULL, [localuf] TEXT(2) NOT NULL, [cpf] TEXT(14) NOT NULL, [cpftit] TEXT(14) NOT NULL, [vivo] TEXT(1) NOT NULL, [casamento] SHORTDATE NOT NULL, [estcivil] TEXT(1) NOT NULL, [estudo] TEXT(1) NOT NULL, [invalidez] TEXT(1) NOT NULL, [rg] TEXT(14) NOT NULL, [rguf] TEXT(2) NOT NULL, [rgemis] TEXT(6) NOT NULL, [rgdata] SHORTDATE NOT NULL);

-- Tabela: fp000100
CREATE TABLE IF NOT EXISTS [fp000100] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL);

-- Tabela: fp000101
CREATE TABLE IF NOT EXISTS [fp000101] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL);

-- Tabela: fp000102
CREATE TABLE IF NOT EXISTS [fp000102] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL);

-- Tabela: fp000103
CREATE TABLE IF NOT EXISTS [fp000103] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL);

-- Tabela: fp000104
CREATE TABLE IF NOT EXISTS [fp000104] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL);

-- Tabela: fp000105
CREATE TABLE IF NOT EXISTS [fp000105] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL);

-- Tabela: fp000106
CREATE TABLE IF NOT EXISTS [fp000106] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL);

-- Tabela: fp000107
CREATE TABLE IF NOT EXISTS [fp000107] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL);

-- Tabela: fp000108
CREATE TABLE IF NOT EXISTS [fp000108] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL);

-- Tabela: fp000109
CREATE TABLE IF NOT EXISTS [fp000109] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL);

-- Tabela: fp000110
CREATE TABLE IF NOT EXISTS [fp000110] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL);

-- Tabela: fp000111
CREATE TABLE IF NOT EXISTS [fp000111] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL);

-- Tabela: fp000112
CREATE TABLE IF NOT EXISTS [fp000112] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [fator] REAL NOT NULL, [tributirr] REAL NOT NULL, [tributinps] REAL NOT NULL, [trib_fgts] REAL NOT NULL, [tipo] REAL NOT NULL, [valorbase] REAL NOT NULL);

-- Tabela: htttroca
CREATE TABLE IF NOT EXISTS [htttroca] ([numero] REAL NOT NULL, [data] TEXT(10) NOT NULL, [hora] TEXT(10) NOT NULL, [ant] TEXT(10) NOT NULL, [htt] TEXT(10) NOT NULL);

-- Tabela: irrf
CREATE TABLE IF NOT EXISTS [irrf] ([cgc] TEXT(18) NOT NULL, [cpf] TEXT(18) NOT NULL, [nome] TEXT(40) NOT NULL, [v401] REAL NOT NULL, [v402] REAL NOT NULL, [v403] REAL NOT NULL, [v404] REAL NOT NULL, [v407] REAL NOT NULL, [v405] REAL NOT NULL, [v501] REAL NOT NULL, [v502] REAL NOT NULL, [v503] REAL NOT NULL, [v504] REAL NOT NULL, [v505] REAL NOT NULL, [v506] REAL NOT NULL, [v507] REAL NOT NULL, [v611] REAL NOT NULL, [v612] REAL NOT NULL, [v613] REAL NOT NULL, [v614] REAL NOT NULL, [v615] REAL NOT NULL, [v617] REAL NOT NULL, [obs01] TEXT(60) NOT NULL, [obs02] TEXT(60) NOT NULL, [obs03] TEXT(60) NOT NULL, [obs04] TEXT(60) NOT NULL, [obs05] TEXT(60) NOT NULL, [v601] REAL NOT NULL, [v602] REAL NOT NULL, [v603] REAL NOT NULL, [v604] REAL NOT NULL, [v605] REAL NOT NULL, [v607] REAL NOT NULL);

-- Tabela: irrf01
CREATE TABLE IF NOT EXISTS [irrf01] ([numero] REAL NOT NULL, [documento] TEXT(20) NOT NULL, [ano] REAL NOT NULL, [cgc] TEXT(18) NOT NULL, [pessoa] TEXT(1) NOT NULL, [nome] TEXT(40) NOT NULL, [endereco] TEXT(40) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(30) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [ddd] TEXT(4) NOT NULL, [telefone] TEXT(9) NOT NULL, [contato] TEXT(12) NOT NULL);

-- Tabela: irrf02
CREATE TABLE IF NOT EXISTS [irrf02] ([numero] REAL NOT NULL, [item] REAL NOT NULL, [mes] REAL NOT NULL, [darf] TEXT(4) NOT NULL, [natureza] TEXT(20) NOT NULL, [renda] REAL NOT NULL, [aliquota] REAL NOT NULL, [irrf] REAL NOT NULL);

-- Tabela: pe2408
CREATE TABLE IF NOT EXISTS [pe2408] ([grupo] TEXT(2) NOT NULL, [data] SHORTDATE NOT NULL, [codrev] TEXT(2) NOT NULL, [entrev] REAL NOT NULL, [alirev] REAL NOT NULL, [alsrev] REAL NOT NULL, [sairev] REAL NOT NULL, [virada] TEXT(1) NOT NULL, [seq] REAL NOT NULL, [folgasn] TEXT(1) NOT NULL, [codadc] TEXT(2) NOT NULL, [bcosn] TEXT(1) NOT NULL, [horario] REAL NOT NULL);

-- Tabela: ph2408
CREATE TABLE IF NOT EXISTS [ph2408] ([numero] REAL NOT NULL, [ocoini] SHORTDATE NOT NULL, [ocofim] SHORTDATE NOT NULL, [ococod] TEXT(2) NOT NULL, [ocomot] TEXT(60) NOT NULL, [motivo] REAL NOT NULL);

-- Tabela: ph2409
CREATE TABLE IF NOT EXISTS [ph2409] ([numero] REAL NOT NULL, [ocoini] SHORTDATE NOT NULL, [ocofim] SHORTDATE NOT NULL, [ococod] TEXT(2) NOT NULL, [ocomot] TEXT(60) NOT NULL, [motivo] REAL NOT NULL);

-- Tabela: pm2408
CREATE TABLE IF NOT EXISTS [pm2408] ([numero] REAL NOT NULL, [datoco] SHORTDATE NOT NULL, [horoco] REAL NOT NULL, [horoc2] REAL NOT NULL, [horoc3] REAL NOT NULL, [horoc4] REAL NOT NULL, [tipoco] TEXT(1) NOT NULL, [motoco] TEXT(60) NOT NULL, [motivo] REAL NOT NULL, [zerhor] TEXT(1) NOT NULL);

-- Tabela: pm2409
CREATE TABLE IF NOT EXISTS [pm2409] ([numero] REAL NOT NULL, [datoco] SHORTDATE NOT NULL, [horoco] REAL NOT NULL, [horoc2] REAL NOT NULL, [horoc3] REAL NOT NULL, [horoc4] REAL NOT NULL, [tipoco] TEXT(1) NOT NULL, [motoco] TEXT(60) NOT NULL, [motivo] REAL NOT NULL, [zerhor] TEXT(1) NOT NULL);

-- Tabela: pn2408
CREATE TABLE IF NOT EXISTS [pn2408] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [ent] REAL NOT NULL, [als] REAL NOT NULL, [ale] REAL NOT NULL, [sai] REAL NOT NULL, [cod] TEXT(2) NOT NULL, [sod] TEXT(2) NOT NULL, [almoco] TEXT(1) NOT NULL, [codrev] TEXT(2) NOT NULL, [entrev] REAL NOT NULL, [alirev] REAL NOT NULL, [alsrev] REAL NOT NULL, [sairev] REAL NOT NULL, [cta01] REAL NOT NULL, [cta02] REAL NOT NULL, [cta03] REAL NOT NULL, [cta04] REAL NOT NULL, [cta05] REAL NOT NULL, [cta06] REAL NOT NULL, [cta07] REAL NOT NULL, [cta08] REAL NOT NULL, [cta09] REAL NOT NULL, [cta10] REAL NOT NULL, [cta11] REAL NOT NULL, [cta12] REAL NOT NULL, [cta13] REAL NOT NULL, [cta14] REAL NOT NULL, [cta15] REAL NOT NULL, [cta16] REAL NOT NULL, [bcosn] TEXT(1) NOT NULL, [bcohrs] REAL NOT NULL, [redsn] TEXT(1) NOT NULL, [folsn] TEXT(1) NOT NULL, [extsn] TEXT(1) NOT NULL, [virada] TEXT(1) NOT NULL, [mudent] TEXT(1) NOT NULL, [mudsai] TEXT(1) NOT NULL, [mudals] TEXT(1) NOT NULL, [mudale] TEXT(1) NOT NULL, [mudhor] TEXT(1) NOT NULL, [horario] REAL NOT NULL);

-- Tabela: pn2409
CREATE TABLE IF NOT EXISTS [pn2409] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [ent] REAL NOT NULL, [als] REAL NOT NULL, [ale] REAL NOT NULL, [sai] REAL NOT NULL, [cod] TEXT(2) NOT NULL, [sod] TEXT(2) NOT NULL, [almoco] TEXT(1) NOT NULL, [codrev] TEXT(2) NOT NULL, [entrev] REAL NOT NULL, [alirev] REAL NOT NULL, [alsrev] REAL NOT NULL, [sairev] REAL NOT NULL, [cta01] REAL NOT NULL, [cta02] REAL NOT NULL, [cta03] REAL NOT NULL, [cta04] REAL NOT NULL, [cta05] REAL NOT NULL, [cta06] REAL NOT NULL, [cta07] REAL NOT NULL, [cta08] REAL NOT NULL, [cta09] REAL NOT NULL, [cta10] REAL NOT NULL, [cta11] REAL NOT NULL, [cta12] REAL NOT NULL, [cta13] REAL NOT NULL, [cta14] REAL NOT NULL, [cta15] REAL NOT NULL, [cta16] REAL NOT NULL, [bcosn] TEXT(1) NOT NULL, [bcohrs] REAL NOT NULL, [redsn] TEXT(1) NOT NULL, [folsn] TEXT(1) NOT NULL, [extsn] TEXT(1) NOT NULL, [virada] TEXT(1) NOT NULL, [mudent] TEXT(1) NOT NULL, [mudsai] TEXT(1) NOT NULL, [mudals] TEXT(1) NOT NULL, [mudale] TEXT(1) NOT NULL, [mudhor] TEXT(1) NOT NULL, [horario] REAL NOT NULL);

-- Tabela: po2408
CREATE TABLE IF NOT EXISTS [po2408] ([numero] REAL NOT NULL, [ocoini] SHORTDATE NOT NULL, [ocofim] SHORTDATE NOT NULL, [ococod] TEXT(2) NOT NULL, [ocomot] TEXT(60) NOT NULL, [ocosub] TEXT(2) NOT NULL, [ocobco] TEXT(1) NOT NULL, [ocored] TEXT(1) NOT NULL, [ocofol] TEXT(1) NOT NULL, [ocoext] TEXT(1) NOT NULL, [ocoalm] TEXT(1) NOT NULL, [hrrel] REAL NOT NULL, [cesta] TEXT(1) NOT NULL, [abona] TEXT(1) NOT NULL, [hrabo] REAL NOT NULL, [hrreldec] REAL NOT NULL, [hrabodec] REAL NOT NULL, [motivo] REAL NOT NULL);

-- Tabela: po2409
CREATE TABLE IF NOT EXISTS [po2409] ([numero] REAL NOT NULL, [ocoini] SHORTDATE NOT NULL, [ocofim] SHORTDATE NOT NULL, [ococod] TEXT(2) NOT NULL, [ocomot] TEXT(60) NOT NULL, [ocosub] TEXT(2) NOT NULL, [ocobco] TEXT(1) NOT NULL, [ocored] TEXT(1) NOT NULL, [ocofol] TEXT(1) NOT NULL, [ocoext] TEXT(1) NOT NULL, [ocoalm] TEXT(1) NOT NULL, [hrrel] REAL NOT NULL, [cesta] TEXT(1) NOT NULL, [abona] TEXT(1) NOT NULL, [hrabo] REAL NOT NULL, [hrreldec] REAL NOT NULL, [hrabodec] REAL NOT NULL, [motivo] REAL NOT NULL);

-- Tabela: provfe
CREATE TABLE IF NOT EXISTS [provfe] ([numero] REAL NOT NULL, [comp] SHORTDATE NOT NULL, [salario] REAL NOT NULL, [salvar] REAL NOT NULL, [avos] REAL NOT NULL, [dias] REAL NOT NULL, [valor] REAL NOT NULL, [valter] REAL NOT NULL, [valenc] REAL NOT NULL, [valtot] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [depto] REAL NOT NULL, [setor] REAL NOT NULL, [secao] REAL NOT NULL, [controle] TEXT(24) NOT NULL);

-- Tabela: ps2408
CREATE TABLE IF NOT EXISTS [ps2408] ([numero] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [semini] SHORTDATE NOT NULL, [semfim] SHORTDATE NOT NULL, [cta01] REAL NOT NULL, [cta02] REAL NOT NULL, [cta03] REAL NOT NULL, [cta04] REAL NOT NULL, [cta05] REAL NOT NULL, [cta06] REAL NOT NULL, [cta07] REAL NOT NULL, [cta08] REAL NOT NULL, [cta09] REAL NOT NULL, [cta10] REAL NOT NULL, [cta11] REAL NOT NULL, [cta12] REAL NOT NULL, [cta13] REAL NOT NULL, [cta14] REAL NOT NULL, [cta15] REAL NOT NULL, [cta16] REAL NOT NULL, [cta17] REAL NOT NULL, [cta18] REAL NOT NULL, [cta19] REAL NOT NULL, [cta20] REAL NOT NULL, [cta21] REAL NOT NULL, [cta22] REAL NOT NULL, [cta23] REAL NOT NULL, [cta24] REAL NOT NULL, [val01] REAL NOT NULL, [val02] REAL NOT NULL, [val03] REAL NOT NULL, [val04] REAL NOT NULL, [val05] REAL NOT NULL, [val06] REAL NOT NULL, [val07] REAL NOT NULL, [val08] REAL NOT NULL, [val09] REAL NOT NULL, [val10] REAL NOT NULL, [val11] REAL NOT NULL, [val12] REAL NOT NULL, [val13] REAL NOT NULL, [val14] REAL NOT NULL, [val15] REAL NOT NULL, [val16] REAL NOT NULL, [val17] REAL NOT NULL, [val18] REAL NOT NULL, [val19] REAL NOT NULL, [val20] REAL NOT NULL, [val21] REAL NOT NULL, [val22] REAL NOT NULL, [val23] REAL NOT NULL, [val24] REAL NOT NULL, [bcohrs] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: ps2409
CREATE TABLE IF NOT EXISTS [ps2409] ([numero] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [semini] SHORTDATE NOT NULL, [semfim] SHORTDATE NOT NULL, [cta01] REAL NOT NULL, [cta02] REAL NOT NULL, [cta03] REAL NOT NULL, [cta04] REAL NOT NULL, [cta05] REAL NOT NULL, [cta06] REAL NOT NULL, [cta07] REAL NOT NULL, [cta08] REAL NOT NULL, [cta09] REAL NOT NULL, [cta10] REAL NOT NULL, [cta11] REAL NOT NULL, [cta12] REAL NOT NULL, [cta13] REAL NOT NULL, [cta14] REAL NOT NULL, [cta15] REAL NOT NULL, [cta16] REAL NOT NULL, [cta17] REAL NOT NULL, [cta18] REAL NOT NULL, [cta19] REAL NOT NULL, [cta20] REAL NOT NULL, [cta21] REAL NOT NULL, [cta22] REAL NOT NULL, [cta23] REAL NOT NULL, [cta24] REAL NOT NULL, [val01] REAL NOT NULL, [val02] REAL NOT NULL, [val03] REAL NOT NULL, [val04] REAL NOT NULL, [val05] REAL NOT NULL, [val06] REAL NOT NULL, [val07] REAL NOT NULL, [val08] REAL NOT NULL, [val09] REAL NOT NULL, [val10] REAL NOT NULL, [val11] REAL NOT NULL, [val12] REAL NOT NULL, [val13] REAL NOT NULL, [val14] REAL NOT NULL, [val15] REAL NOT NULL, [val16] REAL NOT NULL, [val17] REAL NOT NULL, [val18] REAL NOT NULL, [val19] REAL NOT NULL, [val20] REAL NOT NULL, [val21] REAL NOT NULL, [val22] REAL NOT NULL, [val23] REAL NOT NULL, [val24] REAL NOT NULL, [bcohrs] REAL NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL);

-- Tabela: pt2408
CREATE TABLE IF NOT EXISTS [pt2408] ([numero] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [cta01] REAL NOT NULL, [cta02] REAL NOT NULL, [cta03] REAL NOT NULL, [cta04] REAL NOT NULL, [cta05] REAL NOT NULL, [cta06] REAL NOT NULL, [cta07] REAL NOT NULL, [cta08] REAL NOT NULL, [cta09] REAL NOT NULL, [cta10] REAL NOT NULL, [cta11] REAL NOT NULL, [cta12] REAL NOT NULL, [cta13] REAL NOT NULL, [cta14] REAL NOT NULL, [cta15] REAL NOT NULL, [cta16] REAL NOT NULL, [cta17] REAL NOT NULL, [cta18] REAL NOT NULL, [cta19] REAL NOT NULL, [cta20] REAL NOT NULL, [cta21] REAL NOT NULL, [cta22] REAL NOT NULL, [cta23] REAL NOT NULL, [cta24] REAL NOT NULL, [val01] REAL NOT NULL, [val02] REAL NOT NULL, [val03] REAL NOT NULL, [val04] REAL NOT NULL, [val05] REAL NOT NULL, [val06] REAL NOT NULL, [val07] REAL NOT NULL, [val08] REAL NOT NULL, [val09] REAL NOT NULL, [val10] REAL NOT NULL, [val11] REAL NOT NULL, [val12] REAL NOT NULL, [val13] REAL NOT NULL, [val14] REAL NOT NULL, [val15] REAL NOT NULL, [val16] REAL NOT NULL, [val17] REAL NOT NULL, [val18] REAL NOT NULL, [val19] REAL NOT NULL, [val20] REAL NOT NULL, [val21] REAL NOT NULL, [val22] REAL NOT NULL, [val23] REAL NOT NULL, [val24] REAL NOT NULL, [bcohrs] REAL NOT NULL);

-- Tabela: pt2409
CREATE TABLE IF NOT EXISTS [pt2409] ([numero] REAL NOT NULL, [nome] TEXT(30) NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [cta01] REAL NOT NULL, [cta02] REAL NOT NULL, [cta03] REAL NOT NULL, [cta04] REAL NOT NULL, [cta05] REAL NOT NULL, [cta06] REAL NOT NULL, [cta07] REAL NOT NULL, [cta08] REAL NOT NULL, [cta09] REAL NOT NULL, [cta10] REAL NOT NULL, [cta11] REAL NOT NULL, [cta12] REAL NOT NULL, [cta13] REAL NOT NULL, [cta14] REAL NOT NULL, [cta15] REAL NOT NULL, [cta16] REAL NOT NULL, [cta17] REAL NOT NULL, [cta18] REAL NOT NULL, [cta19] REAL NOT NULL, [cta20] REAL NOT NULL, [cta21] REAL NOT NULL, [cta22] REAL NOT NULL, [cta23] REAL NOT NULL, [cta24] REAL NOT NULL, [val01] REAL NOT NULL, [val02] REAL NOT NULL, [val03] REAL NOT NULL, [val04] REAL NOT NULL, [val05] REAL NOT NULL, [val06] REAL NOT NULL, [val07] REAL NOT NULL, [val08] REAL NOT NULL, [val09] REAL NOT NULL, [val10] REAL NOT NULL, [val11] REAL NOT NULL, [val12] REAL NOT NULL, [val13] REAL NOT NULL, [val14] REAL NOT NULL, [val15] REAL NOT NULL, [val16] REAL NOT NULL, [val17] REAL NOT NULL, [val18] REAL NOT NULL, [val19] REAL NOT NULL, [val20] REAL NOT NULL, [val21] REAL NOT NULL, [val22] REAL NOT NULL, [val23] REAL NOT NULL, [val24] REAL NOT NULL, [bcohrs] REAL NOT NULL);

-- Tabela: px2408
CREATE TABLE IF NOT EXISTS [px2408] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [obs] TEXT(60) NOT NULL, [hora2] REAL NOT NULL);

-- Tabela: px2409
CREATE TABLE IF NOT EXISTS [px2409] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [obs] TEXT(60) NOT NULL, [hora2] REAL NOT NULL);

-- Tabela: resfor
CREATE TABLE IF NOT EXISTS [resfor] ([numero] REAL NOT NULL, [val29] REAL NOT NULL, [hor29] REAL NOT NULL, [val30] REAL NOT NULL, [hor30] REAL NOT NULL, [val31] REAL NOT NULL, [hor31] REAL NOT NULL, [val32] REAL NOT NULL, [hor32] REAL NOT NULL, [val33] REAL NOT NULL, [hor33] REAL NOT NULL, [val34] REAL NOT NULL, [hor34] REAL NOT NULL, [val35] REAL NOT NULL, [hor35] REAL NOT NULL, [val36] REAL NOT NULL, [hor36] REAL NOT NULL, [val37] REAL NOT NULL, [hor37] REAL NOT NULL, [val38] REAL NOT NULL, [hor38] REAL NOT NULL, [val39] REAL NOT NULL, [hor39] REAL NOT NULL, [val40] REAL NOT NULL, [hor40] REAL NOT NULL, [val41] REAL NOT NULL, [hor41] REAL NOT NULL, [val42] REAL NOT NULL, [hor42] REAL NOT NULL, [val43] REAL NOT NULL, [hor43] REAL NOT NULL, [val44] REAL NOT NULL, [hor44] REAL NOT NULL, [val45] REAL NOT NULL, [hor45] REAL NOT NULL, [val46] REAL NOT NULL, [hor46] REAL NOT NULL, [val47] REAL NOT NULL, [hor47] REAL NOT NULL, [val48] REAL NOT NULL, [hor48] REAL NOT NULL, [val49] REAL NOT NULL, [hor49] REAL NOT NULL, [val50] REAL NOT NULL, [hor50] REAL NOT NULL, [val51] REAL NOT NULL, [hor51] REAL NOT NULL, [val52] REAL NOT NULL, [hor52] REAL NOT NULL, [val53] REAL NOT NULL, [hor53] REAL NOT NULL, [val54] REAL NOT NULL, [hor54] REAL NOT NULL, [val55] REAL NOT NULL, [hor55] REAL NOT NULL, [des29] TEXT(20) NOT NULL, [des30] TEXT(20) NOT NULL, [des31] TEXT(20) NOT NULL, [des32] TEXT(20) NOT NULL, [des33] TEXT(20) NOT NULL, [des34] TEXT(20) NOT NULL, [des35] TEXT(20) NOT NULL, [des36] TEXT(20) NOT NULL, [des37] TEXT(20) NOT NULL, [des38] TEXT(20) NOT NULL, [des39] TEXT(20) NOT NULL, [des40] TEXT(20) NOT NULL, [des41] TEXT(20) NOT NULL, [des42] TEXT(20) NOT NULL, [des43] TEXT(20) NOT NULL, [des44] TEXT(20) NOT NULL, [des45] TEXT(20) NOT NULL, [des46] TEXT(20) NOT NULL, [des47] TEXT(20) NOT NULL, [des48] TEXT(20) NOT NULL, [des49] TEXT(20) NOT NULL, [des50] TEXT(20) NOT NULL, [des51] TEXT(20) NOT NULL, [des52] TEXT(20) NOT NULL, [des53] TEXT(20) NOT NULL, [des54] TEXT(20) NOT NULL, [des55] TEXT(20) NOT NULL);

-- Tabela: vtavul
CREATE TABLE IF NOT EXISTS [vtavul] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL);

-- Tabela: vtfixo
CREATE TABLE IF NOT EXISTS [vtfixo] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL, [ctacom] REAL NOT NULL);

-- Tabela: vtfolha
CREATE TABLE IF NOT EXISTS [vtfolha] ([numero] REAL NOT NULL, [conta] REAL NOT NULL, [horas] REAL NOT NULL, [valor] REAL NOT NULL, [controle] REAL NOT NULL);

-- �ndice: idx_afdterr_afdterr
CREATE INDEX IF NOT EXISTS [idx_afdterr_afdterr] ON [afdterr] ([numero], [data], [hora]);

-- �ndice: idx_ajudira_d:\develop
CREATE INDEX IF NOT EXISTS [idx_ajudira_d:\develop] ON [ajudira] ([cpf], [mes]);

-- �ndice: idx_ajudird_d:\develop
CREATE INDEX IF NOT EXISTS [idx_ajudird_d:\develop] ON [ajudird] ([cpf], [mes]);

-- �ndice: idx_ajudirf_d:\develop
CREATE INDEX IF NOT EXISTS [idx_ajudirf_d:\develop] ON [ajudirf] ([cpf], [mes]);

-- �ndice: idx_bcobak_bcobak
CREATE INDEX IF NOT EXISTS [idx_bcobak_bcobak] ON [bcobak] ([numero], [ano], [mes]);

-- �ndice: idx_bcodek_bcodek
CREATE INDEX IF NOT EXISTS [idx_bcodek_bcodek] ON [bcodek] ([numero], [ano], [mes]);

-- �ndice: idx_bcodem_bcodem
CREATE INDEX IF NOT EXISTS [idx_bcodem_bcodem] ON [bcodem] ([numero], [ano], [mes]);

-- �ndice: idx_bcohrs_bcohrs
CREATE INDEX IF NOT EXISTS [idx_bcohrs_bcohrs] ON [bcohrs] ([numero], [ano], [mes]);

-- �ndice: idx_bcrbak_bcrbak
CREATE INDEX IF NOT EXISTS [idx_bcrbak_bcrbak] ON [bcrbak] ([requisi]);

-- �ndice: idx_bh2408_bcoreq
CREATE INDEX IF NOT EXISTS [idx_bh2408_bcoreq] ON [bh2408] ([requisi]);

-- �ndice: idx_bh2408_bh2408
CREATE INDEX IF NOT EXISTS [idx_bh2408_bh2408] ON [bh2408] ([requisi]);

-- �ndice: idx_bh2409_bh2409
CREATE INDEX IF NOT EXISTS [idx_bh2409_bh2409] ON [bh2409] ([requisi]);

-- �ndice: idx_bk2408_bk2408
CREATE INDEX IF NOT EXISTS [idx_bk2408_bk2408] ON [bk2408] ([requisi]);

-- �ndice: idx_bk2409_bk2409
CREATE INDEX IF NOT EXISTS [idx_bk2409_bk2409] ON [bk2409] ([requisi]);

-- �ndice: idx_cesta_cesta
CREATE INDEX IF NOT EXISTS [idx_cesta_cesta] ON [cesta] ([numero]);

-- �ndice: idx_ctrhor_ctrhor
CREATE INDEX IF NOT EXISTS [idx_ctrhor_ctrhor] ON [ctrhor] ([ano], [mes], [depto]);

-- �ndice: idx_ferias_ferias01
CREATE INDEX IF NOT EXISTS [idx_ferias_ferias01] ON [ferias] ([numero]);

-- �ndice: idx_ferias_ferias02
CREATE INDEX IF NOT EXISTS [idx_ferias_ferias02] ON [ferias] ([iniper]);

-- �ndice: idx_ferias_ferias03
CREATE INDEX IF NOT EXISTS [idx_ferias_ferias03] ON [ferias] ([numero], [iniper]);

-- �ndice: idx_fo_comp_fo_comp
CREATE INDEX IF NOT EXISTS [idx_fo_comp_fo_comp] ON [fo_comp] ([controle]);

-- �ndice: idx_fo_exp_d:\develop
CREATE INDEX IF NOT EXISTS [idx_fo_exp_d:\develop] ON [fo_exp] ([numero]);

-- �ndice: idx_fo_exp_fo_exp
CREATE INDEX IF NOT EXISTS [idx_fo_exp_fo_exp] ON [fo_exp] ([numero]);

-- �ndice: idx_fo_fer_d:\develop
CREATE INDEX IF NOT EXISTS [idx_fo_fer_d:\develop] ON [fo_fer] ([controle]);

-- �ndice: idx_fo_ffe_fo_ffe
CREATE INDEX IF NOT EXISTS [idx_fo_ffe_fo_ffe] ON [fo_ffe] ([controle]);

-- �ndice: idx_fo_fp13a_d:\develop
CREATE INDEX IF NOT EXISTS [idx_fo_fp13a_d:\develop] ON [fo_fp13a] ([controle]);

-- �ndice: idx_fo_fp13b_d:\develop
CREATE INDEX IF NOT EXISTS [idx_fo_fp13b_d:\develop] ON [fo_fp13b] ([controle]);

-- �ndice: idx_fo_fp13c_d:\develop
CREATE INDEX IF NOT EXISTS [idx_fo_fp13c_d:\develop] ON [fo_fp13c] ([controle]);

-- �ndice: idx_fo_hor_fo_hor
CREATE INDEX IF NOT EXISTS [idx_fo_hor_fo_hor] ON [fo_hor] ([numero]);

-- �ndice: idx_fo_ira_d:\develop
CREATE INDEX IF NOT EXISTS [idx_fo_ira_d:\develop] ON [fo_ira] ([control2]);

-- �ndice: idx_fo_ird_d:\develop
CREATE INDEX IF NOT EXISTS [idx_fo_ird_d:\develop] ON [fo_ird] ([control2]);

-- �ndice: idx_fo_irr_d:\develop
CREATE INDEX IF NOT EXISTS [idx_fo_irr_d:\develop] ON [fo_irr] ([control2]);

-- �ndice: idx_fo_oco_fo_oco
CREATE INDEX IF NOT EXISTS [idx_fo_oco_fo_oco] ON [fo_oco] ([numero], [datasaida]);

-- �ndice: idx_fo_pes_fo_pes
CREATE INDEX IF NOT EXISTS [idx_fo_pes_fo_pes] ON [fo_pes] ([numero]);

-- �ndice: idx_fo_pes_fo_pes2
CREATE INDEX IF NOT EXISTS [idx_fo_pes_fo_pes2] ON [fo_pes] ([nome]);

-- �ndice: idx_fo_pes_fo_pes3
CREATE INDEX IF NOT EXISTS [idx_fo_pes_fo_pes3] ON [fo_pes] ([cpf]);

-- �ndice: idx_fo_pes_fo_pes4
CREATE INDEX IF NOT EXISTS [idx_fo_pes_fo_pes4] ON [fo_pes] ([pis]);

-- �ndice: idx_fo_pes_fo_pes5
CREATE INDEX IF NOT EXISTS [idx_fo_pes_fo_pes5] ON [fo_pes] ([ordem]);

-- �ndice: idx_fo_pes_temp
CREATE INDEX IF NOT EXISTS [idx_fo_pes_temp] ON [fo_pes] ([pis], [admitido]);

-- �ndice: idx_fo_pfe_d:\develop
CREATE INDEX IF NOT EXISTS [idx_fo_pfe_d:\develop] ON [fo_pfe] ([controle]);

-- �ndice: idx_fo_psl_fo_psl
CREATE INDEX IF NOT EXISTS [idx_fo_psl_fo_psl] ON [fo_psl] ([numero]);

-- �ndice: idx_fo_ptt_fo_ptt
CREATE INDEX IF NOT EXISTS [idx_fo_ptt_fo_ptt] ON [fo_ptt] ([numero], [ano], [mes]);

-- �ndice: idx_fo_relhr_fo_relhr
CREATE INDEX IF NOT EXISTS [idx_fo_relhr_fo_relhr] ON [fo_relhr] ([numero]);

-- �ndice: idx_fo_res_d:\develop
CREATE INDEX IF NOT EXISTS [idx_fo_res_d:\develop] ON [fo_res] ([controle]);

-- �ndice: idx_fo_rss_d:\develop
CREATE INDEX IF NOT EXISTS [idx_fo_rss_d:\develop] ON [fo_rss] ([controle]);

-- �ndice: idx_fo_var_d:\develop
CREATE INDEX IF NOT EXISTS [idx_fo_var_d:\develop] ON [fo_var] ([controle]);

-- �ndice: idx_fo_vbr_d:\develop
CREATE INDEX IF NOT EXISTS [idx_fo_vbr_d:\develop] ON [fo_vbr] ([controle]);

-- �ndice: idx_foopes_fo_pes
CREATE INDEX IF NOT EXISTS [idx_foopes_fo_pes] ON [foopes] ([numero]);

-- �ndice: idx_foopes_fo_pes2
CREATE INDEX IF NOT EXISTS [idx_foopes_fo_pes2] ON [foopes] ([nome]);

-- �ndice: idx_foopes_fo_pes3
CREATE INDEX IF NOT EXISTS [idx_foopes_fo_pes3] ON [foopes] ([cpf]);

-- �ndice: idx_foopes_fo_pes4
CREATE INDEX IF NOT EXISTS [idx_foopes_fo_pes4] ON [foopes] ([pis]);

-- �ndice: idx_foopes_fo_pes5
CREATE INDEX IF NOT EXISTS [idx_foopes_fo_pes5] ON [foopes] ([ordem]);

-- �ndice: idx_foopes_temp
CREATE INDEX IF NOT EXISTS [idx_foopes_temp] ON [foopes] ([pis], [admitido]);

-- �ndice: idx_foptoatr_foptoatr
CREATE INDEX IF NOT EXISTS [idx_foptoatr_foptoatr] ON [foptoatr] ([numero], [data], [codanl]);

-- �ndice: idx_foptoeve_foptoeve
CREATE INDEX IF NOT EXISTS [idx_foptoeve_foptoeve] ON [foptoeve] ([dia], [mes]);

-- �ndice: idx_foptoprd_foptoprd
CREATE INDEX IF NOT EXISTS [idx_foptoprd_foptoprd] ON [foptoprd] ([origem], [data]);

-- �ndice: idx_forais_forais
CREATE INDEX IF NOT EXISTS [idx_forais_forais] ON [forais] ([ano], [numero]);

-- �ndice: idx_forais_forais-2
CREATE INDEX IF NOT EXISTS [idx_forais_forais-2] ON [forais] ([ano], [nome]);

-- �ndice: idx_fosfam_fosfam
CREATE INDEX IF NOT EXISTS [idx_fosfam_fosfam] ON [fosfam] ([numero], [requisi]);

-- �ndice: idx_fosfam_fosfam-2
CREATE INDEX IF NOT EXISTS [idx_fosfam_fosfam-2] ON [fosfam] ([cpftit], [cpf]);

-- �ndice: idx_fosfam_fosfam-3
CREATE INDEX IF NOT EXISTS [idx_fosfam_fosfam-3] ON [fosfam] ([cpftit], [nome]);

-- �ndice: idx_fosfam_fosfam2
CREATE INDEX IF NOT EXISTS [idx_fosfam_fosfam2] ON [fosfam] ([cpftit], [cpf]);

-- �ndice: idx_fosfam_fosfam3
CREATE INDEX IF NOT EXISTS [idx_fosfam_fosfam3] ON [fosfam] ([cpftit], [nome]);

-- �ndice: idx_fp000101_c:\develop
CREATE INDEX IF NOT EXISTS [idx_fp000101_c:\develop] ON [fp000101] ([controle]);

-- �ndice: idx_fp000103_c:\develop
CREATE INDEX IF NOT EXISTS [idx_fp000103_c:\develop] ON [fp000103] ([controle]);

-- �ndice: idx_fp000104_c:\develop
CREATE INDEX IF NOT EXISTS [idx_fp000104_c:\develop] ON [fp000104] ([controle]);

-- �ndice: idx_fp000108_d:\develop
CREATE INDEX IF NOT EXISTS [idx_fp000108_d:\develop] ON [fp000108] ([controle]);

-- �ndice: idx_fp000108_fol
CREATE INDEX IF NOT EXISTS [idx_fp000108_fol] ON [fp000108] ([controle]);

-- �ndice: idx_fp000112_c:\develop
CREATE INDEX IF NOT EXISTS [idx_fp000112_c:\develop] ON [fp000112] ([controle]);

-- �ndice: idx_htttroca_htttroca
CREATE INDEX IF NOT EXISTS [idx_htttroca_htttroca] ON [htttroca] ([numero]);

-- �ndice: idx_irrf01_d:\develop
CREATE INDEX IF NOT EXISTS [idx_irrf01_d:\develop] ON [irrf01] ([numero]);

-- �ndice: idx_irrf02_d:\develop
CREATE INDEX IF NOT EXISTS [idx_irrf02_d:\develop] ON [irrf02] ([numero], [item]);

-- �ndice: idx_irrf_d:\develop
CREATE INDEX IF NOT EXISTS [idx_irrf_d:\develop] ON [irrf] ([cpf]);

-- �ndice: idx_pe2408_foptorev
CREATE INDEX IF NOT EXISTS [idx_pe2408_foptorev] ON [pe2408] ([grupo], [data]);

-- �ndice: idx_pe2408_pe2408
CREATE INDEX IF NOT EXISTS [idx_pe2408_pe2408] ON [pe2408] ([grupo], [data]);

-- �ndice: idx_ph2408_fo_phor
CREATE INDEX IF NOT EXISTS [idx_ph2408_fo_phor] ON [ph2408] ([numero], [ocoini]);

-- �ndice: idx_ph2408_ph2408
CREATE INDEX IF NOT EXISTS [idx_ph2408_ph2408] ON [ph2408] ([numero], [ocoini]);

-- �ndice: idx_ph2409_ph2409
CREATE INDEX IF NOT EXISTS [idx_ph2409_ph2409] ON [ph2409] ([numero], [ocoini]);

-- �ndice: idx_pm2408_fo_pman
CREATE INDEX IF NOT EXISTS [idx_pm2408_fo_pman] ON [pm2408] ([numero], [datoco], [tipoco]);

-- �ndice: idx_pm2408_pm2408
CREATE INDEX IF NOT EXISTS [idx_pm2408_pm2408] ON [pm2408] ([numero], [datoco], [tipoco]);

-- �ndice: idx_pm2409_pm2409
CREATE INDEX IF NOT EXISTS [idx_pm2409_pm2409] ON [pm2409] ([numero], [datoco], [tipoco]);

-- �ndice: idx_pn2408_fo_pon
CREATE INDEX IF NOT EXISTS [idx_pn2408_fo_pon] ON [pn2408] ([numero], [data]);

-- �ndice: idx_pn2408_pn2408
CREATE INDEX IF NOT EXISTS [idx_pn2408_pn2408] ON [pn2408] ([numero], [data]);

-- �ndice: idx_pn2409_pn2409
CREATE INDEX IF NOT EXISTS [idx_pn2409_pn2409] ON [pn2409] ([numero], [data]);

-- �ndice: idx_po2408_fo_poco
CREATE INDEX IF NOT EXISTS [idx_po2408_fo_poco] ON [po2408] ([numero], [ocoini]);

-- �ndice: idx_po2408_po2408
CREATE INDEX IF NOT EXISTS [idx_po2408_po2408] ON [po2408] ([numero], [ocoini]);

-- �ndice: idx_po2409_po2409
CREATE INDEX IF NOT EXISTS [idx_po2409_po2409] ON [po2409] ([numero], [ocoini]);

-- �ndice: idx_provfe_d:\develop
CREATE INDEX IF NOT EXISTS [idx_provfe_d:\develop] ON [provfe] ([controle]);

-- �ndice: idx_ps2408_fo_pos
CREATE INDEX IF NOT EXISTS [idx_ps2408_fo_pos] ON [ps2408] ([numero], [semfim]);

-- �ndice: idx_ps2408_ps2408
CREATE INDEX IF NOT EXISTS [idx_ps2408_ps2408] ON [ps2408] ([numero], [semfim]);

-- �ndice: idx_ps2409_ps2409
CREATE INDEX IF NOT EXISTS [idx_ps2409_ps2409] ON [ps2409] ([numero], [semfim]);

-- �ndice: idx_pt2408_fo_pot
CREATE INDEX IF NOT EXISTS [idx_pt2408_fo_pot] ON [pt2408] ([numero]);

-- �ndice: idx_pt2408_pt2408
CREATE INDEX IF NOT EXISTS [idx_pt2408_pt2408] ON [pt2408] ([numero]);

-- �ndice: idx_pt2409_pt2409
CREATE INDEX IF NOT EXISTS [idx_pt2409_pt2409] ON [pt2409] ([numero]);

-- �ndice: idx_px2408_fo_pdes
CREATE INDEX IF NOT EXISTS [idx_px2408_fo_pdes] ON [px2408] ([numero], [data], [conta]);

-- �ndice: idx_px2408_px2408
CREATE INDEX IF NOT EXISTS [idx_px2408_px2408] ON [px2408] ([numero], [data], [conta]);

-- �ndice: idx_px2409_px2409
CREATE INDEX IF NOT EXISTS [idx_px2409_px2409] ON [px2409] ([numero], [data], [conta]);

-- �ndice: idx_resfor_d:\develop
CREATE INDEX IF NOT EXISTS [idx_resfor_d:\develop] ON [resfor] ([numero]);

-- �ndice: idx_vtavul_vtavul
CREATE INDEX IF NOT EXISTS [idx_vtavul_vtavul] ON [vtavul] ([controle]);

-- �ndice: idx_vtfixo_vtfixo
CREATE INDEX IF NOT EXISTS [idx_vtfixo_vtfixo] ON [vtfixo] ([numero], [conta], [ctacom]);

-- �ndice: idx_vtfolha
CREATE INDEX IF NOT EXISTS [idx_vtfolha] ON [vtfolha] ([controle]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
