--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom set 15 14:41:24 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: RPT
CREATE TABLE IF NOT EXISTS RPT (
    GRP       VARCHAR (4),
    RPT       VARCHAR (8),
    COGNOME   VARCHAR (100),
    NOME      VARCHAR (100),
    ARVORE    BOOLEAN       NOT NULL
                            DEFAULT (0),
    BUSCA     BOOLEAN       NOT NULL
                            DEFAULT (0),
    ARQUIVO   VARCHAR (100),
    ABRIRCOM  VARCHAR (30),
    DATAIMP   DATETIME,
    UTILIZADO INT,
    DATACRI   DATETIME,
    SUBGRP    VARCHAR (4),
    CAMINHO   VARCHAR (200),
    MENSAGEM  LONGTEXT,
    CAMINH2   VARCHAR (200),
    CAMINH3   VARCHAR (200),
    CAMINH4   VARCHAR (200),
    CARQUSO   VARCHAR (8),
    CARQBAI   VARCHAR (8),
    CARQFEC   VARCHAR (2),
    CARQACU   VARCHAR (8),
    COBSMSG   VARCHAR (50),
    LFILTRO   BOOLEAN       NOT NULL
                            DEFAULT (0),
    PREFILTRO VARCHAR (255),
    TABALIAS  VARCHAR (8),
    TABNAME   VARCHAR (8),
    TITULO    VARCHAR (255),
    CODIGO    VARCHAR (8),
    SQLUSO    LONGTEXT,
    ID        INT           PRIMARY KEY
);


-- Tabela: RPTGRP
CREATE TABLE IF NOT EXISTS RPTGRP (
    GRP     VARCHAR (4),
    NOME    VARCHAR (50),
    CODIGO  VARCHAR (8),
    CAMINHO VARCHAR (255),
    LIBERAR BOOLEAN       NOT NULL
                          DEFAULT (0),
    ID      INTEGER       PRIMARY KEY AUTOINCREMENT
);


-- Tabela: RPTMAIN
CREATE TABLE IF NOT EXISTS RPTMAIN (
    NOME       VARCHAR (50),
    CODIGO     VARCHAR (8),
    CAMINHO    VARCHAR (255),
    ID         INTEGER       PRIMARY KEY AUTOINCREMENT,
    DISPONIVEL BOOLEAN       NOT NULL
                             DEFAULT (0) 
);


-- �ndice: IDXRPTGRP_CODIGO
CREATE INDEX IF NOT EXISTS IDXRPTGRP_CODIGO ON RPTGRP (
    CODIGO
);


-- �ndice: IDXRPTGRP_GRP
CREATE INDEX IF NOT EXISTS IDXRPTGRP_GRP ON RPTGRP (
    GRP
);


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
