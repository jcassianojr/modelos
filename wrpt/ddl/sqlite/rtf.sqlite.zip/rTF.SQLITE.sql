--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom set 15 14:44:52 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: RPT
CREATE TABLE IF NOT EXISTS RPT (
    RPT       VARCHAR (8),
    COGNOME   VARCHAR (100),
    NOME      VARCHAR (100),
    ARVORE    BOOLEAN       NOT NULL
                            DEFAULT (0),
    BUSCA     BOOLEAN       NOT NULL
                            DEFAULT (0),
    ARQUIVO   VARCHAR (100),
    DATAIMP   DATETIME,
    UTILIZADO INT,
    DATACRI   DATETIME,
    SUBGRP    VARCHAR (4),
    CAMINHO   VARCHAR (200),
    MENSAGEM  LONGTEXT,
    CAMINH2   VARCHAR (200),
    CAMINH3   VARCHAR (200),
    CAMINH4   VARCHAR (200),
    CARQUSO   VARCHAR (8),
    CARQBAI   VARCHAR (8),
    CARQFEC   VARCHAR (2),
    CARQACU   VARCHAR (8),
    COBSMSG   VARCHAR (8),
    LFILTRO   BOOLEAN       NOT NULL
                            DEFAULT (0),
    TABALIAS  VARCHAR (8),
    TABNAME   VARCHAR (8),
    PREFILTRO VARCHAR (255),
    ABRIRCOM  VARCHAR (30),
    CODIGO    VARCHAR (8),
    GRP       VARCHAR (8),
    TITULO    VARCHAR (250),
    SQLUSO    LONGTEXT,
    ID        INTEGER       NOT NULL
                            PRIMARY KEY AUTOINCREMENT
);


-- Tabela: RPTGRP
CREATE TABLE IF NOT EXISTS RPTGRP (
    NOME    VARCHAR (50),
    GRP     VARCHAR (8),
    CODIGO  VARCHAR (8),
    CAMINHO VARCHAR (255),
    LIBERAR BOOLEAN       NOT NULL
                          DEFAULT (0),
    ID      INTEGER       NOT NULL
                          PRIMARY KEY AUTOINCREMENT
);


-- Tabela: RPTMAIN
CREATE TABLE IF NOT EXISTS RPTMAIN (
    NOME       VARCHAR (50),
    CODIGO     VARCHAR (8),
    CAMINHO    VARCHAR (255),
    DISPONIVEL BOOLEAN       NOT NULL
                             DEFAULT (0),
    ID         INTEGER       NOT NULL
                             PRIMARY KEY AUTOINCREMENT
);


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
