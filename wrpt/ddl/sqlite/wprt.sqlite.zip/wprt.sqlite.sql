--
-- File generated with SQLiteStudio v3.4.21 on s�b mai 16 08:46:40 2026
--
-- Text encoding used: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: CONTROLE
DROP TABLE IF EXISTS CONTROLE;

CREATE TABLE IF NOT EXISTS CONTROLE (
    FORM       VARCHAR (20),
    CONTROLE   VARCHAR (20),
    INDICE     INT          DEFAULT 0,
    IMAGEM     SMALLINT     DEFAULT 0,
    CAPTION    VARCHAR (20),
    TOOLTIP    VARCHAR (50),
    TOP        INT          DEFAULT 0,
    [LEFT]     INT          DEFAULT 0,
    HEIGHT     INT          DEFAULT 0,
    WIDTH      INT          DEFAULT 0,
    MAXLEN     INT          DEFAULT 0,
    CORFRENTE  VARCHAR (12),
    CORFUNDO   VARCHAR (12),
    FONTE      VARCHAR (12),
    TAMANHO    SMALLINT     DEFAULT 0,
    LIGADO     BOOLEAN      NOT NULL
                            DEFAULT (0),
    ATUALIZADO BOOLEAN      NOT NULL
                            DEFAULT (0),
    DISPONIVEL BOOLEAN      NOT NULL
                            DEFAULT (0),
    PRIMARY KEY (
        FORM,
        CONTROLE,
        INDICE
    )
);

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escBTN',
                         'Toolbar1',
                         1,
                         1,
                         'Novo',
                         'Novo',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escBTN',
                         'Toolbar1',
                         2,
                         13,
                         'Editar',
                         'Editar',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escBTN',
                         'Toolbar1',
                         3,
                         3,
                         'Excluir',
                         'Excluir',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escBTN',
                         'Toolbar1',
                         4,
                         4,
                         'Localizar',
                         'Localizar',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escBTN',
                         'Toolbar1',
                         5,
                         12,
                         'Liberar',
                         'Liberar',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escBTN',
                         'Toolbar1',
                         6,
                         19,
                         'Sair',
                         'Sair',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMANREG',
                         'Toolbar1',
                         1,
                         4,
                         '&Localizar',
                         'Localizar',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMANREG',
                         'Toolbar1',
                         2,
                         11,
                         '&Escolher',
                         'Escolher',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMANREG',
                         'Toolbar1',
                         3,
                         19,
                         '&Sair',
                         'Sair',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMANREL',
                         'Toolbar1',
                         1,
                         6,
                         '&Imprimir',
                         'Imprimir',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMANREL',
                         'Toolbar1',
                         2,
                         10,
                         '&Conf.Imp',
                         'Configura Impressora',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMANREL',
                         'Toolbar1',
                         3,
                         19,
                         '&Sair',
                         'Sair',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMENU',
                         'Toolbar1',
                         1,
                         1,
                         '&Novo',
                         'Novo',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMENU',
                         'Toolbar1',
                         2,
                         13,
                         '&Editar',
                         'Editar',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMENU',
                         'Toolbar1',
                         3,
                         3,
                         'e&Xcluir',
                         'Excluir',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMENU',
                         'Toolbar1',
                         4,
                         4,
                         '&Localizar',
                         'Localizar',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMENU',
                         'Toolbar1',
                         5,
                         12,
                         'l&Iberar',
                         'Liberar',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMENU',
                         'Toolbar1',
                         6,
                         19,
                         'Sair',
                         'Sair',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMP04',
                         'Toolbar1',
                         1,
                         11,
                         'Escolher',
                         'Escolher',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMP04',
                         'Toolbar1',
                         2,
                         4,
                         'Localizar',
                         'Localizar',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMP04',
                         'Toolbar1',
                         3,
                         8,
                         'Foto',
                         'Foto',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMP04',
                         'Toolbar1',
                         4,
                         6,
                         'Imprimir',
                         'Imprimir',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escMP04',
                         'Toolbar1',
                         5,
                         19,
                         'Sair',
                         'Sair',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escRPT',
                         'Toolbar1',
                         1,
                         1,
                         '&Novo',
                         'Novo',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escRPT',
                         'Toolbar1',
                         2,
                         13,
                         '&Editar',
                         'Editar',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escRPT',
                         'Toolbar1',
                         3,
                         3,
                         'E&xcluir',
                         'Excluir',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escRPT',
                         'Toolbar1',
                         4,
                         4,
                         '&Localizar',
                         'Localizar',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escRPT',
                         'Toolbar1',
                         5,
                         12,
                         'L&iberar',
                         'Liberar',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escRPT',
                         'Toolbar1',
                         6,
                         6,
                         '&Imprimir',
                         'Imprimir/Visualizar',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escRPT',
                         'Toolbar1',
                         7,
                         10,
                         'Conf. Imp.',
                         'Configura Impressora',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escRPT',
                         'Toolbar1',
                         8,
                         19,
                         '&Sair',
                         'Sair',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escRPTGRP',
                         'Toolbar1',
                         1,
                         1,
                         '&Novo',
                         'Incluir',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escRPTGRP',
                         'Toolbar1',
                         2,
                         13,
                         '&Editar',
                         'Editar',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escRPTGRP',
                         'Toolbar1',
                         3,
                         3,
                         'E&xcluir',
                         'Excluir',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escRPTGRP',
                         'Toolbar1',
                         4,
                         4,
                         '&Localizar',
                         'Localizar',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escRPTGRP',
                         'Toolbar1',
                         5,
                         11,
                         'Escolher',
                         'Escolher',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escRPTGRP',
                         'Toolbar1',
                         6,
                         19,
                         '&Sair',
                         'Sair',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escUSER',
                         'Toolbar1',
                         1,
                         1,
                         '&Novo',
                         'Novo Usuario',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escUSER',
                         'Toolbar1',
                         2,
                         13,
                         '&Editar',
                         'Editar Configuracao do Usuario',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escUSER',
                         'Toolbar1',
                         3,
                         3,
                         'E&xcluir',
                         'Excluir Usuario',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escUSER',
                         'Toolbar1',
                         4,
                         4,
                         '&Localizar',
                         'Localizar Usuario',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escUSER',
                         'Toolbar1',
                         5,
                         17,
                         '&Senha',
                         'Senha Usuario',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'escUSER',
                         'Toolbar1',
                         6,
                         19,
                         'Sair',
                         'Sair',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmimagens',
                         'Toolbar1',
                         1,
                         1,
                         '&Novo',
                         'Incluir',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmimagens',
                         'Toolbar1',
                         2,
                         2,
                         '&Gravar',
                         'Gravar',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmimagens',
                         'Toolbar1',
                         3,
                         3,
                         '&Excluir',
                         'Excluir',
                         0,
                         0,
                         0,
                         0,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         1,
                         0,
                         'Novo',
                         'new.ICO',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         '0',
                         '-1',
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         2,
                         0,
                         'Gravar',
                         'save.ICO',
                         0,
                         0,
                         NULL,
                         NULL,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         3,
                         0,
                         'Excluir',
                         'delete.ICO',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         '0',
                         '-1',
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         4,
                         0,
                         'Localizar',
                         'find.ICO',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         1,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         5,
                         0,
                         'copy',
                         'copy.ICO',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         1,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         6,
                         0,
                         'Imprimir',
                         'print.ICO',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         '0',
                         '-1',
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         7,
                         0,
                         'Setup',
                         '243.ico',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         1,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         8,
                         0,
                         'Foto',
                         'camera.ico',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         '0',
                         '-1',
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         9,
                         0,
                         'Consultar',
                         'clip.ico',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         '0',
                         '-1',
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         10,
                         0,
                         'ConfImpr',
                         'printcfg.ico',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         '0',
                         '-1',
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         11,
                         0,
                         'escolher',
                         'prop.ICO',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         '0',
                         '-1',
                         NULL,
                         0,
                         0,
                         0,
                         1
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         12,
                         0,
                         'liberar',
                         'pencil05.ico',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         '0',
                         '-1',
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         13,
                         0,
                         'Editar',
                         'open.ICO',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         '0',
                         '-1',
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         14,
                         0,
                         'c___',
                         'BRANCO.ICO',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         15,
                         0,
                         'd___',
                         'BRANCO.ICO',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         16,
                         0,
                         'e___',
                         'branco.ico',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         17,
                         0,
                         'senha',
                         'senha.ico',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         18,
                         0,
                         'troca',
                         '236.ico',
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMDIPRINCIPAL',
                         'ImageList1',
                         19,
                         0,
                         'Sair',
                         'sair.ICO',
                         0,
                         0,
                         NULL,
                         NULL,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMENU',
                         'Toolbar1',
                         1,
                         1,
                         'Novo',
                         'Inclui novo menu',
                         0,
                         0,
                         NULL,
                         NULL,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMENU',
                         'Toolbar1',
                         2,
                         2,
                         'Gravar',
                         'Grava altera��es ou inclus�o no menu',
                         0,
                         0,
                         NULL,
                         NULL,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );

INSERT INTO CONTROLE (
                         FORM,
                         CONTROLE,
                         INDICE,
                         IMAGEM,
                         CAPTION,
                         TOOLTIP,
                         TOP,
                         [LEFT],
                         HEIGHT,
                         WIDTH,
                         MAXLEN,
                         CORFRENTE,
                         CORFUNDO,
                         FONTE,
                         TAMANHO,
                         LIGADO,
                         ATUALIZADO,
                         DISPONIVEL
                     )
                     VALUES (
                         'frmMENU',
                         'Toolbar1',
                         3,
                         3,
                         'Excluir',
                         'Exclui o menu editado',
                         0,
                         0,
                         NULL,
                         NULL,
                         0,
                         NULL,
                         NULL,
                         NULL,
                         0,
                         0,
                         0,
                         0
                     );


-- Table: EMPRESA
DROP TABLE IF EXISTS EMPRESA;

CREATE TABLE IF NOT EXISTS EMPRESA (
    NUMERO    SMALLINT,
    NOME      VARCHAR (40),
    ENDERECO  VARCHAR (40),
    ENDNUM    SMALLINT,
    ENDCOM    VARCHAR (20),
    BAIRRO    VARCHAR (30),
    CIDADE    VARCHAR (30),
    ESTADO    VARCHAR (2),
    CEP       VARCHAR (9),
    DDD       VARCHAR (4),
    TELEFONE  VARCHAR (9),
    FAX       VARCHAR (9),
    MAXCAIXA  DOUBLE,
    COBRANCA  BOOLEAN      NOT NULL
                           DEFAULT (0),
    DIACOBR   SMALLINT,
    JUROS     BOOLEAN      NOT NULL
                           DEFAULT (0),
    TXJUROS   DOUBLE,
    NUMUSER   SMALLINT,
    REF       VARCHAR (50),
    CGC       VARCHAR (19),
    INSCR     VARCHAR (16),
    NUMSOC    SMALLINT,
    CONTRATO  LONGTEXT,
    VLCLIENTE CURRENCY     DEFAULT 0,
    IOF       CURRENCY     DEFAULT 0,
    ISS       CURRENCY     DEFAULT 0,
    SERVICO   CURRENCY     DEFAULT 0,
    CAPTACAO  CURRENCY     DEFAULT 0,
    LIMITECGC CURRENCY     DEFAULT 0,
    CPMF      CURRENCY     DEFAULT 0,
    COGNOME   VARCHAR (20),
    idempresa INTEGER      PRIMARY KEY AUTOINCREMENT
);

INSERT INTO EMPRESA (
                        NUMERO,
                        NOME,
                        ENDERECO,
                        ENDNUM,
                        ENDCOM,
                        BAIRRO,
                        CIDADE,
                        ESTADO,
                        CEP,
                        DDD,
                        TELEFONE,
                        FAX,
                        MAXCAIXA,
                        COBRANCA,
                        DIACOBR,
                        JUROS,
                        TXJUROS,
                        NUMUSER,
                        REF,
                        CGC,
                        INSCR,
                        NUMSOC,
                        CONTRATO,
                        VLCLIENTE,
                        IOF,
                        ISS,
                        SERVICO,
                        CAPTACAO,
                        LIMITECGC,
                        CPMF,
                        COGNOME,
                        idempresa
                    )
                    VALUES (
                        1,
                        'SOFTEC SISTEMAS S/C LTDA.',
                        'RUA ARMELIN A.F. COUTINHO ',
                        357,
                        '',
                        'PQ REAL',
                        'DIADEMA',
                        'SP',
                        '09990-190',
                        '011',
                        '4055-2265',
                        '7640-6312',
                        130.0,
                        0,
                        12,
                        1,
                        8.0,
                        NULL,
                        'PR�XIMO AO CEMIT�RIO DE DIADEMA',
                        '00.000.000/0000-00',
                        '000.000.000.110',
                        2,
                        '',
                        0,
                        0.0041,
                        5,
                        1,
                        0,
                        2000,
                        0.38,
                        NULL,
                        1
                    );


-- Table: MENU
DROP TABLE IF EXISTS MENU;

CREATE TABLE IF NOT EXISTS MENU (
    MENU      VARCHAR (12),
    DESCRICAO VARCHAR (50),
    INDICE    SMALLINT     DEFAULT 0,
    LIGADO    BOOLEAN      NOT NULL
                           DEFAULT (0),
    CADASTRO  SMALLINT     DEFAULT 0,
    HOTKEY    VARCHAR (20),
    PRIMARY KEY (
        MENU,
        INDICE
    )
);

INSERT INTO MENU (
                     MENU,
                     DESCRICAO,
                     INDICE,
                     LIGADO,
                     CADASTRO,
                     HOTKEY
                 )
                 VALUES (
                     'mnuSUBMENU4',
                     '&Impressora',
                     0,
                     1,
                     99,
                     NULL
                 );

INSERT INTO MENU (
                     MENU,
                     DESCRICAO,
                     INDICE,
                     LIGADO,
                     CADASTRO,
                     HOTKEY
                 )
                 VALUES (
                     'mnuSUBMENU4',
                     '&Alteracos',
                     1,
                     1,
                     98,
                     NULL
                 );

INSERT INTO MENU (
                     MENU,
                     DESCRICAO,
                     INDICE,
                     LIGADO,
                     CADASTRO,
                     HOTKEY
                 )
                 VALUES (
                     'mnuSUBMENU4',
                     '&Usu�rios',
                     2,
                     1,
                     97,
                     NULL
                 );

INSERT INTO MENU (
                     MENU,
                     DESCRICAO,
                     INDICE,
                     LIGADO,
                     CADASTRO,
                     HOTKEY
                 )
                 VALUES (
                     'mnuSUBMENU4',
                     '&Menu',
                     3,
                     1,
                     93,
                     NULL
                 );

INSERT INTO MENU (
                     MENU,
                     DESCRICAO,
                     INDICE,
                     LIGADO,
                     CADASTRO,
                     HOTKEY
                 )
                 VALUES (
                     'mnuSUBMENU4',
                     '&Botoes',
                     4,
                     1,
                     92,
                     NULL
                 );

INSERT INTO MENU (
                     MENU,
                     DESCRICAO,
                     INDICE,
                     LIGADO,
                     CADASTRO,
                     HOTKEY
                 )
                 VALUES (
                     'mnuSUBMENU4',
                     'configurar ODBC',
                     5,
                     1,
                     91,
                     ''
                 );

INSERT INTO MENU (
                     MENU,
                     DESCRICAO,
                     INDICE,
                     LIGADO,
                     CADASTRO,
                     HOTKEY
                 )
                 VALUES (
                     'mnuSUBMENU4',
                     '&Troca de Senha',
                     6,
                     1,
                     94,
                     NULL
                 );

INSERT INTO MENU (
                     MENU,
                     DESCRICAO,
                     INDICE,
                     LIGADO,
                     CADASTRO,
                     HOTKEY
                 )
                 VALUES (
                     'mnuSUBMENU4',
                     'Frase do Dia',
                     7,
                     0,
                     1,
                     NULL
                 );

INSERT INTO MENU (
                     MENU,
                     DESCRICAO,
                     INDICE,
                     LIGADO,
                     CADASTRO,
                     HOTKEY
                 )
                 VALUES (
                     'mnuSUBMENU4',
                     'Calculadora',
                     8,
                     0,
                     1,
                     NULL
                 );


-- Table: MENUUSU
DROP TABLE IF EXISTS MENUUSU;

CREATE TABLE IF NOT EXISTS MENUUSU (
    IDUSUARIO  INT          DEFAULT 0,
    MENU       VARCHAR (12),
    INDICE     SMALLINT     DEFAULT 0,
    LIGADO     BOOLEAN      NOT NULL
                            DEFAULT (0),
    ATUALIZADO BOOLEAN      NOT NULL
                            DEFAULT (0),
    PRIMARY KEY (
        IDUSUARIO,
        MENU,
        INDICE
    )
);


-- Table: RPTFOLUSR
DROP TABLE IF EXISTS RPTFOLUSR;

CREATE TABLE IF NOT EXISTS RPTFOLUSR (
    IDUSUARIO INT,
    IMPRIME   BOOLEAN      NOT NULL
                           DEFAULT (0),
    RPT       VARCHAR (8),
    EXPORTA   BOOLEAN      NOT NULL
                           DEFAULT (0),
    VISUALIZA BOOLEAN      NOT NULL
                           DEFAULT (0),
    SALVARTF  BOOLEAN      NOT NULL
                           DEFAULT (0),
    SALVATXT  BOOLEAN      NOT NULL
                           DEFAULT (0),
    NOVO      BOOLEAN      NOT NULL
                           DEFAULT (0),
    ABRIR     BOOLEAN      NOT NULL
                           DEFAULT (0),
    EDITAR    BOOLEAN      NOT NULL
                           DEFAULT (0),
    ABRIRCOM  VARCHAR (50),
    GRP       VARCHAR (8) 
);


-- Table: RPTINTUSR
DROP TABLE IF EXISTS RPTINTUSR;

CREATE TABLE IF NOT EXISTS RPTINTUSR (
    IDUSUARIO INT,
    RPT       VARCHAR (8),
    IMPRIME   BOOLEAN      NOT NULL
                           DEFAULT (0),
    EXPORTA   BOOLEAN      NOT NULL
                           DEFAULT (0),
    VISUALIZA BOOLEAN      NOT NULL
                           DEFAULT (0),
    SALVARTF  BOOLEAN      NOT NULL
                           DEFAULT (0),
    SALVATXT  BOOLEAN      NOT NULL
                           DEFAULT (0),
    NOVO      BOOLEAN      NOT NULL
                           DEFAULT (0),
    ABRIR     BOOLEAN      NOT NULL
                           DEFAULT (0),
    EDITAR    BOOLEAN      NOT NULL
                           DEFAULT (0),
    ABRIRCOM  VARCHAR (50),
    GRP       VARCHAR (8) 
);


-- Table: RPTUSR
DROP TABLE IF EXISTS RPTUSR;

CREATE TABLE IF NOT EXISTS RPTUSR (
    IDUSUARIO INT,
    RPT       VARCHAR (8),
    IMPRIME   BOOLEAN      NOT NULL
                           DEFAULT (0),
    EXPORTA   BOOLEAN      NOT NULL
                           DEFAULT (0),
    VISUALIZA BOOLEAN      NOT NULL
                           DEFAULT (0),
    SALVARTF  BOOLEAN      NOT NULL
                           DEFAULT (0),
    SALVATXT  BOOLEAN      NOT NULL
                           DEFAULT (0),
    NOVO      BOOLEAN      NOT NULL
                           DEFAULT (0),
    ABRIR     BOOLEAN      NOT NULL
                           DEFAULT (0),
    EDITAR    BOOLEAN      NOT NULL
                           DEFAULT (0),
    ABRIRCOM  VARCHAR (50),
    GRP       VARCHAR (8) 
);

INSERT INTO RPTUSR (
                       IDUSUARIO,
                       RPT,
                       IMPRIME,
                       EXPORTA,
                       VISUALIZA,
                       SALVARTF,
                       SALVATXT,
                       NOVO,
                       ABRIR,
                       EDITAR,
                       ABRIRCOM,
                       GRP
                   )
                   VALUES (
                       2,
                       'ITA00012',
                       1,
                       1,
                       1,
                       1,
                       1,
                       1,
                       1,
                       1,
                       '',
                       'CP'
                   );

INSERT INTO RPTUSR (
                       IDUSUARIO,
                       RPT,
                       IMPRIME,
                       EXPORTA,
                       VISUALIZA,
                       SALVARTF,
                       SALVATXT,
                       NOVO,
                       ABRIR,
                       EDITAR,
                       ABRIRCOM,
                       GRP
                   )
                   VALUES (
                       2,
                       'TESTEZPL',
                       1,
                       1,
                       1,
                       1,
                       1,
                       1,
                       1,
                       1,
                       '',
                       'ADP'
                   );

INSERT INTO RPTUSR (
                       IDUSUARIO,
                       RPT,
                       IMPRIME,
                       EXPORTA,
                       VISUALIZA,
                       SALVARTF,
                       SALVATXT,
                       NOVO,
                       ABRIR,
                       EDITAR,
                       ABRIRCOM,
                       GRP
                   )
                   VALUES (
                       2,
                       'ITA00112',
                       0,
                       0,
                       1,
                       0,
                       0,
                       0,
                       0,
                       0,
                       '',
                       'CU'
                   );

INSERT INTO RPTUSR (
                       IDUSUARIO,
                       RPT,
                       IMPRIME,
                       EXPORTA,
                       VISUALIZA,
                       SALVARTF,
                       SALVATXT,
                       NOVO,
                       ABRIR,
                       EDITAR,
                       ABRIRCOM,
                       GRP
                   )
                   VALUES (
                       2,
                       'FOL00001',
                       1,
                       1,
                       1,
                       1,
                       1,
                       1,
                       1,
                       1,
                       '',
                       'CU'
                   );

INSERT INTO RPTUSR (
                       IDUSUARIO,
                       RPT,
                       IMPRIME,
                       EXPORTA,
                       VISUALIZA,
                       SALVARTF,
                       SALVATXT,
                       NOVO,
                       ABRIR,
                       EDITAR,
                       ABRIRCOM,
                       GRP
                   )
                   VALUES (
                       3,
                       'ITA00423',
                       0,
                       0,
                       1,
                       0,
                       0,
                       0,
                       0,
                       0,
                       '',
                       'CU'
                   );

INSERT INTO RPTUSR (
                       IDUSUARIO,
                       RPT,
                       IMPRIME,
                       EXPORTA,
                       VISUALIZA,
                       SALVARTF,
                       SALVATXT,
                       NOVO,
                       ABRIR,
                       EDITAR,
                       ABRIRCOM,
                       GRP
                   )
                   VALUES (
                       2,
                       'U2LWIN',
                       1,
                       1,
                       1,
                       1,
                       1,
                       1,
                       1,
                       1,
                       '',
                       'CU'
                   );

INSERT INTO RPTUSR (
                       IDUSUARIO,
                       RPT,
                       IMPRIME,
                       EXPORTA,
                       VISUALIZA,
                       SALVARTF,
                       SALVATXT,
                       NOVO,
                       ABRIR,
                       EDITAR,
                       ABRIRCOM,
                       GRP
                   )
                   VALUES (
                       4,
                       'ITA00128',
                       0,
                       0,
                       1,
                       0,
                       0,
                       0,
                       0,
                       0,
                       NULL,
                       'EN'
                   );


-- Table: RTFUSR
DROP TABLE IF EXISTS RTFUSR;

CREATE TABLE IF NOT EXISTS RTFUSR (
    IDUSUARIO INT          PRIMARY KEY,
    RPT       VARCHAR (8),
    IMPRIME   BOOLEAN      NOT NULL
                           DEFAULT (0),
    EXPORTA   BOOLEAN      NOT NULL
                           DEFAULT (0),
    VISUALIZA BOOLEAN      NOT NULL
                           DEFAULT (0),
    SALVARTF  BOOLEAN      NOT NULL
                           DEFAULT (0),
    SALVATXT  BOOLEAN      NOT NULL
                           DEFAULT (0),
    NOVO      BOOLEAN      NOT NULL
                           DEFAULT (0),
    ABRIR     BOOLEAN      NOT NULL
                           DEFAULT (0),
    EDITAR    BOOLEAN      NOT NULL
                           DEFAULT (0),
    ABRIRCOM  VARCHAR (50),
    GRP       VARCHAR (8) 
);


-- Table: USUARIO
DROP TABLE IF EXISTS USUARIO;

CREATE TABLE IF NOT EXISTS USUARIO (
    IDUSUARIO   INTEGER   DEFAULT 0,
    USUARIO     TEXT (10),
    SENHA       TEXT (8),
    DATAVAL     TEXT,
    DATAULT     TEXT,
    EQUIVALENTE INTEGER   DEFAULT 0,
    ATIVO       INTEGER   NOT NULL
                          DEFAULT (0),
    HORAINI     TEXT,
    HORAFIM     TEXT,
    WEEKEND     INTEGER   NOT NULL
                          DEFAULT (0),
    IDFOLHA     INTEGER   DEFAULT 0,
    NOMEFOLHA   TEXT (50),
    TROCAR      TEXT,
    ID          INTEGER   NOT NULL,
    postelaa    TEXT (30) DEFAULT '000',
    postelaB    TEXT (30) DEFAULT '000',
    CHAVEH      TEXT (64),
    CHAVEV      TEXT (64),
    PRIMARY KEY (
        ID AUTOINCREMENT
    )
);

INSERT INTO USUARIO (
                        IDUSUARIO,
                        USUARIO,
                        SENHA,
                        DATAVAL,
                        DATAULT,
                        EQUIVALENTE,
                        ATIVO,
                        HORAINI,
                        HORAFIM,
                        WEEKEND,
                        IDFOLHA,
                        NOMEFOLHA,
                        TROCAR,
                        ID,
                        postelaa,
                        postelaB,
                        CHAVEH,
                        CHAVEV
                    )
                    VALUES (
                        2,
                        'ADMIN',
                        ')_*^?',
                        '2015-12-31',
                        '2026-05-14 12:07:26',
                        NULL,
                        1,
                        NULL,
                        NULL,
                        1,
                        9000,
                        'admin',
                        '2030-04-25',
                        1,
                        NULL,
                        NULL,
                        NULL,
                        NULL
                    );

INSERT INTO USUARIO (
                        IDUSUARIO,
                        USUARIO,
                        SENHA,
                        DATAVAL,
                        DATAULT,
                        EQUIVALENTE,
                        ATIVO,
                        HORAINI,
                        HORAFIM,
                        WEEKEND,
                        IDFOLHA,
                        NOMEFOLHA,
                        TROCAR,
                        ID,
                        postelaa,
                        postelaB,
                        CHAVEH,
                        CHAVEV
                    )
                    VALUES (
                        1,
                        'LIBERADOR',
                        '#6_R`]',
                        '2021-03-30',
                        '1999-11-30',
                        0,
                        0,
                        '1900-01-01',
                        '1900-01-01',
                        0,
                        9000,
                        'Liberado pelo administrador',
                        '2030-02-21',
                        2,
                        NULL,
                        NULL,
                        NULL,
                        '3CE9C30C0996BE9F678C06A0D76277D1765432DFCFDC5AD77CCC21FBEBE17D8A'
                    );

INSERT INTO USUARIO (
                        IDUSUARIO,
                        USUARIO,
                        SENHA,
                        DATAVAL,
                        DATAULT,
                        EQUIVALENTE,
                        ATIVO,
                        HORAINI,
                        HORAFIM,
                        WEEKEND,
                        IDFOLHA,
                        NOMEFOLHA,
                        TROCAR,
                        ID,
                        postelaa,
                        postelaB,
                        CHAVEH,
                        CHAVEV
                    )
                    VALUES (
                        3,
                        'USUARIO',
                        ':1R`]',
                        '2006-06-26 00:00:06',
                        '2005-02-17',
                        0,
                        0,
                        '3/30/2021 7:06:03 AM',
                        '3/30/2021 9:21:03 PM',
                        0,
                        1415,
                        'USARIO 1415 hhh',
                        '2033-03-03 00:00:03',
                        3,
                        '218206224190230226230',
                        '164162160158224198226230',
                        '0E7BA99829313CE5D0CF5E40C6E5BB1941B02F12153A2CACFF1B48334B0A3C61',
                        'F99828877B3B7F178A32860FBF008B6F0B170CA380D9B512505ADD311845C247'
                    );

INSERT INTO USUARIO (
                        IDUSUARIO,
                        USUARIO,
                        SENHA,
                        DATAVAL,
                        DATAULT,
                        EQUIVALENTE,
                        ATIVO,
                        HORAINI,
                        HORAFIM,
                        WEEKEND,
                        IDFOLHA,
                        NOMEFOLHA,
                        TROCAR,
                        ID,
                        postelaa,
                        postelaB,
                        CHAVEH,
                        CHAVEV
                    )
                    VALUES (
                        4,
                        'SOFTEC',
                        '<!*~&',
                        '2021-03-30 00:00:03',
                        '1999-11-30',
                        0,
                        0,
                        '1/1/1900',
                        '1/1/1900',
                        0,
                        9000,
                        'softec',
                        '2030-02-21 00:00:02',
                        4,
                        '194198228200218226',
                        '218234218206196230228226',
                        '0E7BA99829313CE5D0CF5E40C6E5BB1941B02F12153A2CACFF1B48334B0A3C61',
                        '0E7BA99829313CE5D0CF5E40C6E5BB1941B02F12153A2CACFF1B48334B0A3C61'
                    );


-- Table: USUCAD
DROP TABLE IF EXISTS USUCAD;

CREATE TABLE IF NOT EXISTS USUCAD (
    IDUSUARIO  INT          DEFAULT 0,
    FORM       VARCHAR (20),
    CADASTRO   SMALLINT     DEFAULT 0,
    CONTROLE   VARCHAR (20),
    INDICE     INT          DEFAULT 0,
    CAPTION    VARCHAR (20),
    TOOLTIP    VARCHAR (50),
    CORFRENTE  VARCHAR (12),
    CORFUNDO   VARCHAR (12),
    FONTE      VARCHAR (12),
    LIGADO     BOOLEAN      NOT NULL
                            DEFAULT (0),
    ATUALIZADO BOOLEAN      NOT NULL
                            DEFAULT (0),
    PRIMARY KEY (
        IDUSUARIO,
        FORM,
        CADASTRO,
        CONTROLE,
        INDICE
    )
);


-- Index: IDXMENU_CADASTRO
DROP INDEX IF EXISTS IDXMENU_CADASTRO;

CREATE INDEX IF NOT EXISTS IDXMENU_CADASTRO ON MENU (
    CADASTRO
);


-- Index: IDXUSUARIO_IDFOLHA
DROP INDEX IF EXISTS IDXUSUARIO_IDFOLHA;

CREATE INDEX IF NOT EXISTS IDXUSUARIO_IDFOLHA ON USUARIO (
    IDFOLHA
);


-- Index: IDXUSUARIO_IDUSUARIO
DROP INDEX IF EXISTS IDXUSUARIO_IDUSUARIO;

CREATE UNIQUE INDEX IF NOT EXISTS IDXUSUARIO_IDUSUARIO ON USUARIO (
    IDUSUARIO
);


-- Index: MENUUSU1
DROP INDEX IF EXISTS MENUUSU1;

CREATE INDEX IF NOT EXISTS MENUUSU1 ON MENUUSU (
    IDUSUARIO DESC,
    MENU DESC,
    INDICE DESC
);


-- Index: numero
DROP INDEX IF EXISTS numero;

CREATE INDEX IF NOT EXISTS numero ON EMPRESA (
    NUMERO DESC
);


-- Index: rptfolusr1
DROP INDEX IF EXISTS rptfolusr1;

CREATE INDEX IF NOT EXISTS rptfolusr1 ON RPTFOLUSR (
    GRP,
    RPT,
    IDUSUARIO
);


-- Index: rptintusr1
DROP INDEX IF EXISTS rptintusr1;

CREATE INDEX IF NOT EXISTS rptintusr1 ON RPTintUSR (
    GRP,
    RPT,
    IDUSUARIO
);


-- Index: rptusr1
DROP INDEX IF EXISTS rptusr1;

CREATE INDEX IF NOT EXISTS rptusr1 ON RPTUSR (
    GRP,
    RPT,
    IDUSUARIO
);


-- Index: rtfusr1
DROP INDEX IF EXISTS rtfusr1;

CREATE INDEX IF NOT EXISTS rtfusr1 ON rtfUSR (
    GRP,
    RPT,
    IDUSUARIO
);


-- Index: USUCAD1
DROP INDEX IF EXISTS USUCAD1;

CREATE INDEX IF NOT EXISTS USUCAD1 ON USUCAD (
    IDUSUARIO DESC,
    FORM DESC,
    CADASTRO DESC,
    CONTROLE DESC,
    INDICE DESC
);


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
