--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 17:34:34 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: CONTROLE
CREATE TABLE IF NOT EXISTS [CONTROLE] (
	[FORM] varchar(20), 
	[CONTROLE] varchar(20), 
	[INDICE] int DEFAULT 0, 
	[IMAGEM] smallint DEFAULT 0, 
	[CAPTION] varchar(20), 
	[TOOLTIP] varchar(50), 
	[TOP] int DEFAULT 0, 
	[LEFT] int DEFAULT 0, 
	[HEIGHT] int DEFAULT 0, 
	[WIDTH] int DEFAULT 0, 
	[MAXLEN] int DEFAULT 0, 
	[CORFRENTE] varchar(12), 
	[CORFUNDO] varchar(12), 
	[FONTE] varchar(12), 
	[TAMANHO] smallint DEFAULT 0, 
	[LIGADO] boolean NOT NULL, 
	[ATUALIZADO] boolean NOT NULL, 
	[DISPONIVEL] boolean NOT NULL,
	PRIMARY KEY ([FORM], [CONTROLE], [INDICE])
);

-- Tabela: EMPRESA
CREATE TABLE IF NOT EXISTS [EMPRESA] (
	[NUMERO] smallint, 
	[NOME] varchar(40), 
	[ENDERECO] varchar(40), 
	[ENDNUM] smallint, 
	[ENDCOM] varchar(20), 
	[BAIRRO] varchar(30), 
	[CIDADE] varchar(30), 
	[ESTADO] varchar(2), 
	[CEP] varchar(9), 
	[DDD] varchar(4), 
	[TELEFONE] varchar(9), 
	[FAX] varchar(9), 
	[MAXCAIXA] double, 
	[COBRANCA] boolean NOT NULL, 
	[DIACOBR] smallint, 
	[JUROS] boolean NOT NULL, 
	[TXJUROS] double, 
	[NUMUSER] smallint, 
	[REF] varchar(50), 
	[CGC] varchar(19), 
	[INSCR] varchar(16), 
	[NUMSOC] smallint, 
	[CONTRATO] longtext, 
	[VLCLIENTE] currency DEFAULT 0, 
	[IOF] currency DEFAULT 0, 
	[ISS] currency DEFAULT 0, 
	[SERVICO] currency DEFAULT 0, 
	[CAPTACAO] currency DEFAULT 0, 
	[LIMITECGC] currency DEFAULT 0, 
	[CPMF] currency DEFAULT 0, 
	[COGNOME] varchar(20)
);

-- Tabela: MENU
CREATE TABLE IF NOT EXISTS [MENU] (
	[MENU] varchar(12), 
	[DESCRICAO] varchar(50), 
	[INDICE] smallint DEFAULT 0, 
	[LIGADO] boolean NOT NULL, 
	[CADASTRO] smallint DEFAULT 0, 
	[HOTKEY] varchar(20),
	PRIMARY KEY ([MENU], [INDICE])
);

-- Tabela: MENUUSU
CREATE TABLE IF NOT EXISTS [MENUUSU] (
	[IDUSUARIO] int DEFAULT 0, 
	[MENU] varchar(12), 
	[INDICE] smallint DEFAULT 0, 
	[LIGADO] boolean NOT NULL, 
	[ATUALIZADO] boolean NOT NULL,
	PRIMARY KEY ([IDUSUARIO], [MENU], [INDICE])
);

-- Tabela: RPTFOLUSR
CREATE TABLE IF NOT EXISTS [RPTFOLUSR] (
	[IDUSUARIO] int, 
	[IMPRIME] boolean NOT NULL, 
	[RPT] varchar(8), 
	[EXPORTA] boolean NOT NULL, 
	[VISUALIZA] boolean NOT NULL, 
	[SALVARTF] boolean NOT NULL, 
	[SALVATXT] boolean NOT NULL, 
	[NOVO] boolean NOT NULL, 
	[ABRIR] boolean NOT NULL, 
	[EDITAR] boolean NOT NULL, 
	[ABRIRCOM] varchar(50), 
	[GRP] varchar(8)
);

-- Tabela: RPTINTUSR
CREATE TABLE IF NOT EXISTS [RPTINTUSR] (
	[IDUSUARIO] int, 
	[RPT] varchar(8), 
	[IMPRIME] boolean NOT NULL, 
	[EXPORTA] boolean NOT NULL, 
	[VISUALIZA] boolean NOT NULL, 
	[SALVARTF] boolean NOT NULL, 
	[SALVATXT] boolean NOT NULL, 
	[NOVO] boolean NOT NULL, 
	[ABRIR] boolean NOT NULL, 
	[EDITAR] boolean NOT NULL, 
	[ABRIRCOM] varchar(50), 
	[GRP] varchar(8)
);

-- Tabela: RPTUSR
CREATE TABLE IF NOT EXISTS [RPTUSR] (
	[IDUSUARIO] int, 
	[RPT] varchar(8), 
	[IMPRIME] boolean NOT NULL, 
	[EXPORTA] boolean NOT NULL, 
	[VISUALIZA] boolean NOT NULL, 
	[SALVARTF] boolean NOT NULL, 
	[SALVATXT] boolean NOT NULL, 
	[NOVO] boolean NOT NULL, 
	[ABRIR] boolean NOT NULL, 
	[EDITAR] boolean NOT NULL, 
	[ABRIRCOM] varchar(50), 
	[GRP] varchar(8)
);

-- Tabela: RTFUSR
CREATE TABLE IF NOT EXISTS [RTFUSR] (
	[IDUSUARIO] int, 
	[RPT] varchar(8), 
	[IMPRIME] boolean NOT NULL, 
	[EXPORTA] boolean NOT NULL, 
	[VISUALIZA] boolean NOT NULL, 
	[SALVARTF] boolean NOT NULL, 
	[SALVATXT] boolean NOT NULL, 
	[NOVO] boolean NOT NULL, 
	[ABRIR] boolean NOT NULL, 
	[EDITAR] boolean NOT NULL, 
	[ABRIRCOM] varchar(50), 
	[GRP] varchar(8)
);

-- Tabela: USUARIO
CREATE TABLE IF NOT EXISTS [USUARIO] (
	[IDUSUARIO] int DEFAULT 0, 
	[USUARIO] varchar(10), 
	[SENHA] varchar(8), 
	[DATAVAL] datetime, 
	[DATAULT] datetime, 
	[EQUIVALENTE] int DEFAULT 0, 
	[ATIVO] boolean NOT NULL, 
	[HORAINI] datetime, 
	[HORAFIM] datetime, 
	[WEEKEND] boolean NOT NULL, 
	[IDFOLHA] single DEFAULT 0, 
	[NOMEFOLHA] varchar(50), 
	[TROCAR] datetime, 
	[ID] integer NOT NULL, 
	[postelaa] varchar(30) DEFAULT '000', 
	[postelaB] varchar(30) DEFAULT '000', 
	[CHAVEH] varchar(64), 
	[CHAVEV] varchar(64),
	PRIMARY KEY ([USUARIO], [ID])
);

-- Tabela: USUCAD
CREATE TABLE IF NOT EXISTS [USUCAD] (
	[IDUSUARIO] int DEFAULT 0, 
	[FORM] varchar(20), 
	[CADASTRO] smallint DEFAULT 0, 
	[CONTROLE] varchar(20), 
	[INDICE] int DEFAULT 0, 
	[CAPTION] varchar(20), 
	[TOOLTIP] varchar(50), 
	[CORFRENTE] varchar(12), 
	[CORFUNDO] varchar(12), 
	[FONTE] varchar(12), 
	[LIGADO] boolean NOT NULL, 
	[ATUALIZADO] boolean NOT NULL,
	PRIMARY KEY ([IDUSUARIO], [FORM], [CADASTRO], [CONTROLE], [INDICE])
);

-- �ndice: IDXMENU_CADASTRO
CREATE INDEX IF NOT EXISTS [IDXMENU_CADASTRO]
	ON [MENU] ([CADASTRO]);

-- �ndice: IDXUSUARIO_IDFOLHA
CREATE INDEX IF NOT EXISTS [IDXUSUARIO_IDFOLHA]
	ON [USUARIO] ([IDFOLHA]);

-- �ndice: IDXUSUARIO_IDUSUARIO
CREATE UNIQUE INDEX IF NOT EXISTS [IDXUSUARIO_IDUSUARIO]
	ON [USUARIO] ([IDUSUARIO]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
