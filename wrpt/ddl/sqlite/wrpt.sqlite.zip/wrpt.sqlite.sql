--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom set 15 15:43:54 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: CONTROLE
CREATE TABLE IF NOT EXISTS CONTROLE (
    FORM       VARCHAR (20),
    CONTROLE   VARCHAR (20),
    INDICE     INT          DEFAULT 0,
    IMAGEM     SMALLINT     DEFAULT 0,
    CAPTION    VARCHAR (20),
    TOOLTIP    VARCHAR (50),
    TOP        INT          DEFAULT 0,
    [LEFT]     INT          DEFAULT 0,
    HEIGHT     INT          DEFAULT 0,
    WIDTH      INT          DEFAULT 0,
    MAXLEN     INT          DEFAULT 0,
    CORFRENTE  VARCHAR (12),
    CORFUNDO   VARCHAR (12),
    FONTE      VARCHAR (12),
    TAMANHO    SMALLINT     DEFAULT 0,
    LIGADO     BOOLEAN      NOT NULL
                            DEFAULT (0),
    ATUALIZADO BOOLEAN      NOT NULL
                            DEFAULT (0),
    DISPONIVEL BOOLEAN      NOT NULL
                            DEFAULT (0),
    PRIMARY KEY (
        FORM,
        CONTROLE,
        INDICE
    )
);


-- Tabela: EMPRESA
CREATE TABLE IF NOT EXISTS EMPRESA (
    NUMERO    SMALLINT,
    NOME      VARCHAR (40),
    ENDERECO  VARCHAR (40),
    ENDNUM    SMALLINT,
    ENDCOM    VARCHAR (20),
    BAIRRO    VARCHAR (30),
    CIDADE    VARCHAR (30),
    ESTADO    VARCHAR (2),
    CEP       VARCHAR (9),
    DDD       VARCHAR (4),
    TELEFONE  VARCHAR (9),
    FAX       VARCHAR (9),
    MAXCAIXA  DOUBLE,
    COBRANCA  BOOLEAN      NOT NULL
                           DEFAULT (0),
    DIACOBR   SMALLINT,
    JUROS     BOOLEAN      NOT NULL
                           DEFAULT (0),
    TXJUROS   DOUBLE,
    NUMUSER   SMALLINT,
    REF       VARCHAR (50),
    CGC       VARCHAR (19),
    INSCR     VARCHAR (16),
    NUMSOC    SMALLINT,
    CONTRATO  LONGTEXT,
    VLCLIENTE CURRENCY     DEFAULT 0,
    IOF       CURRENCY     DEFAULT 0,
    ISS       CURRENCY     DEFAULT 0,
    SERVICO   CURRENCY     DEFAULT 0,
    CAPTACAO  CURRENCY     DEFAULT 0,
    LIMITECGC CURRENCY     DEFAULT 0,
    CPMF      CURRENCY     DEFAULT 0,
    COGNOME   VARCHAR (20),
    idempresa INTEGER      PRIMARY KEY AUTOINCREMENT
);


-- Tabela: MENU
CREATE TABLE IF NOT EXISTS MENU (
    MENU      VARCHAR (12),
    DESCRICAO VARCHAR (50),
    INDICE    SMALLINT     DEFAULT 0,
    LIGADO    BOOLEAN      NOT NULL
                           DEFAULT (0),
    CADASTRO  SMALLINT     DEFAULT 0,
    HOTKEY    VARCHAR (20),
    PRIMARY KEY (
        MENU,
        INDICE
    )
);


-- Tabela: MENUUSU
CREATE TABLE IF NOT EXISTS MENUUSU (
    IDUSUARIO  INT          DEFAULT 0,
    MENU       VARCHAR (12),
    INDICE     SMALLINT     DEFAULT 0,
    LIGADO     BOOLEAN      NOT NULL
                            DEFAULT (0),
    ATUALIZADO BOOLEAN      NOT NULL
                            DEFAULT (0),
    PRIMARY KEY (
        IDUSUARIO,
        MENU,
        INDICE
    )
);


-- Tabela: RPTFOLUSR
CREATE TABLE IF NOT EXISTS RPTFOLUSR (
    IDUSUARIO INT,
    IMPRIME   BOOLEAN      NOT NULL
                           DEFAULT (0),
    RPT       VARCHAR (8),
    EXPORTA   BOOLEAN      NOT NULL
                           DEFAULT (0),
    VISUALIZA BOOLEAN      NOT NULL
                           DEFAULT (0),
    SALVARTF  BOOLEAN      NOT NULL
                           DEFAULT (0),
    SALVATXT  BOOLEAN      NOT NULL
                           DEFAULT (0),
    NOVO      BOOLEAN      NOT NULL
                           DEFAULT (0),
    ABRIR     BOOLEAN      NOT NULL
                           DEFAULT (0),
    EDITAR    BOOLEAN      NOT NULL
                           DEFAULT (0),
    ABRIRCOM  VARCHAR (50),
    GRP       VARCHAR (8) 
);


-- Tabela: RPTINTUSR
CREATE TABLE IF NOT EXISTS RPTINTUSR (
    IDUSUARIO INT,
    RPT       VARCHAR (8),
    IMPRIME   BOOLEAN      NOT NULL
                           DEFAULT (0),
    EXPORTA   BOOLEAN      NOT NULL
                           DEFAULT (0),
    VISUALIZA BOOLEAN      NOT NULL
                           DEFAULT (0),
    SALVARTF  BOOLEAN      NOT NULL
                           DEFAULT (0),
    SALVATXT  BOOLEAN      NOT NULL
                           DEFAULT (0),
    NOVO      BOOLEAN      NOT NULL
                           DEFAULT (0),
    ABRIR     BOOLEAN      NOT NULL
                           DEFAULT (0),
    EDITAR    BOOLEAN      NOT NULL
                           DEFAULT (0),
    ABRIRCOM  VARCHAR (50),
    GRP       VARCHAR (8) 
);


-- Tabela: RPTUSR
CREATE TABLE IF NOT EXISTS RPTUSR (
    IDUSUARIO INT,
    RPT       VARCHAR (8),
    IMPRIME   BOOLEAN      NOT NULL
                           DEFAULT (0),
    EXPORTA   BOOLEAN      NOT NULL
                           DEFAULT (0),
    VISUALIZA BOOLEAN      NOT NULL
                           DEFAULT (0),
    SALVARTF  BOOLEAN      NOT NULL
                           DEFAULT (0),
    SALVATXT  BOOLEAN      NOT NULL
                           DEFAULT (0),
    NOVO      BOOLEAN      NOT NULL
                           DEFAULT (0),
    ABRIR     BOOLEAN      NOT NULL
                           DEFAULT (0),
    EDITAR    BOOLEAN      NOT NULL
                           DEFAULT (0),
    ABRIRCOM  VARCHAR (50),
    GRP       VARCHAR (8) 
);


-- Tabela: RTFUSR
CREATE TABLE IF NOT EXISTS RTFUSR (
    IDUSUARIO INT          PRIMARY KEY,
    RPT       VARCHAR (8),
    IMPRIME   BOOLEAN      NOT NULL
                           DEFAULT (0),
    EXPORTA   BOOLEAN      NOT NULL
                           DEFAULT (0),
    VISUALIZA BOOLEAN      NOT NULL
                           DEFAULT (0),
    SALVARTF  BOOLEAN      NOT NULL
                           DEFAULT (0),
    SALVATXT  BOOLEAN      NOT NULL
                           DEFAULT (0),
    NOVO      BOOLEAN      NOT NULL
                           DEFAULT (0),
    ABRIR     BOOLEAN      NOT NULL
                           DEFAULT (0),
    EDITAR    BOOLEAN      NOT NULL
                           DEFAULT (0),
    ABRIRCOM  VARCHAR (50),
    GRP       VARCHAR (8) 
);


-- Tabela: USUARIO
CREATE TABLE IF NOT EXISTS USUARIO (
    IDUSUARIO   INT          DEFAULT 0,
    USUARIO     VARCHAR (10),
    SENHA       VARCHAR (8),
    DATAVAL     DATETIME,
    DATAULT     DATETIME,
    EQUIVALENTE INTEGER      DEFAULT 0,
    ATIVO       BOOLEAN      NOT NULL
                             DEFAULT (0),
    HORAINI     DATETIME,
    HORAFIM     DATETIME,
    WEEKEND     BOOLEAN      NOT NULL
                             DEFAULT (0),
    IDFOLHA     SINGLE       DEFAULT 0,
    NOMEFOLHA   VARCHAR (50),
    TROCAR      DATETIME,
    ID          INTEGER      NOT NULL,
    postelaa    VARCHAR (30) DEFAULT '000',
    postelaB    VARCHAR (30) DEFAULT '000',
    CHAVEH      VARCHAR (64),
    CHAVEV      VARCHAR (64),
    PRIMARY KEY (
        ID AUTOINCREMENT
    )
);


-- Tabela: USUCAD
CREATE TABLE IF NOT EXISTS USUCAD (
    IDUSUARIO  INT          DEFAULT 0,
    FORM       VARCHAR (20),
    CADASTRO   SMALLINT     DEFAULT 0,
    CONTROLE   VARCHAR (20),
    INDICE     INT          DEFAULT 0,
    CAPTION    VARCHAR (20),
    TOOLTIP    VARCHAR (50),
    CORFRENTE  VARCHAR (12),
    CORFUNDO   VARCHAR (12),
    FONTE      VARCHAR (12),
    LIGADO     BOOLEAN      NOT NULL
                            DEFAULT (0),
    ATUALIZADO BOOLEAN      NOT NULL
                            DEFAULT (0),
    PRIMARY KEY (
        IDUSUARIO,
        FORM,
        CADASTRO,
        CONTROLE,
        INDICE
    )
);


-- �ndice: IDXMENU_CADASTRO
CREATE INDEX IF NOT EXISTS IDXMENU_CADASTRO ON MENU (
    CADASTRO
);


-- �ndice: IDXUSUARIO_IDFOLHA
CREATE INDEX IF NOT EXISTS IDXUSUARIO_IDFOLHA ON USUARIO (
    IDFOLHA
);


-- �ndice: IDXUSUARIO_IDUSUARIO
CREATE UNIQUE INDEX IF NOT EXISTS IDXUSUARIO_IDUSUARIO ON USUARIO (
    IDUSUARIO
);


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
