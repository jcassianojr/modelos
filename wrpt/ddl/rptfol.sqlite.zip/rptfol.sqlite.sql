--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 17:29:29 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: RPT
CREATE TABLE IF NOT EXISTS [RPT] (
	[GRP] varchar(4), 
	[RPT] varchar(8), 
	[COGNOME] varchar(100), 
	[NOME] varchar(100), 
	[ARVORE] boolean NOT NULL, 
	[BUSCA] boolean NOT NULL, 
	[ARQUIVO] varchar(100), 
	[ABRIRCOM] varchar(30), 
	[DATAIMP] datetime, 
	[UTILIZADO] int, 
	[DATACRI] datetime, 
	[SUBGRP] varchar(4), 
	[CAMINHO] varchar(200), 
	[MENSAGEM] longtext, 
	[CAMINH2] varchar(200), 
	[CAMINH3] varchar(200), 
	[CAMINH4] varchar(200), 
	[CARQUSO] varchar(8), 
	[CARQBAI] varchar(8), 
	[CARQFEC] varchar(2), 
	[CARQACU] varchar(8), 
	[COBSMSG] varchar(50), 
	[LFILTRO] boolean NOT NULL, 
	[PREFILTRO] varchar(255), 
	[TABALIAS] varchar(8), 
	[TABNAME] varchar(8), 
	[TITULO] varchar(255), 
	[CODIGO] varchar(8), 
	[SQLUSO] longtext, 
	[ID] int
);

-- Tabela: RPTGRP
CREATE TABLE IF NOT EXISTS [RPTGRP] (
	[GRP] varchar(4), 
	[NOME] varchar(50), 
	[CODIGO] varchar(8), 
	[CAMINHO] varchar(255), 
	[LIBERAR] boolean NOT NULL, 
	[ID] int
);

-- Tabela: RPTMAIN
CREATE TABLE IF NOT EXISTS [RPTMAIN] (
	[NOME] varchar(50), 
	[CODIGO] varchar(8), 
	[CAMINHO] varchar(255), 
	[ID] int, 
	[DISPONIVEL] boolean NOT NULL
);

-- �ndice: IDXRPTGRP_CODIGO
CREATE INDEX IF NOT EXISTS [IDXRPTGRP_CODIGO]
	ON [RPTGRP] ([CODIGO]);

-- �ndice: IDXRPTGRP_GRP
CREATE INDEX IF NOT EXISTS [IDXRPTGRP_GRP]
	ON [RPTGRP] ([GRP]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
