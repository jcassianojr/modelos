call c:\devprg\hb\hb32msys_c.bat
hbmk2.exe processa.prg hbct.hbc
