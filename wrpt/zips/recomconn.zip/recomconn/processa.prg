#include "fileio.ch"
#include "directry.ch"

PROCEDURE Main()

    aIniChaves  := {}
    aIniValores := {}
    aLogs       := {}
    cLOG:=""
    cINI:=""
    
    SETMODE(25,80)
    CLS
    
    aRetFiles   := Directory("*.ret")
    cCHAVEBUSCA := UPPER("QRYTBL")
    cCHAVEFIM   := UPPER('qrylnk')
    cCHAVEFIM2  := UPPER("qrycol")

    FOR i := 1 TO Len(aRetFiles)
        //? aRetFiles[i, F_NAME]
        filecopy(aRetFiles[i, F_NAME],aRetFiles[i, F_NAME]+".old")
        cConteudo := upper(MemoRead(aRetFiles[i, F_NAME]))
        //? left(cConteudo,80)
        nPOSINI:=At(cCHAVEBUSCA, cCONTEUDO)
       // ? STR(nPOSINI)
        IF nPOSINI>0
           cSUBSTRING:=SubStr(cCONTEUDO, nPOSINI ) 
           //? LEFT(CSUBSTRING,60)
           nPOSFIM:=AT(cCHAVEFIM,cSUBSTRING)
           IF nPOSFIM = 0
              nPOSFIM:=AT(cCHAVEFIM2,cSUBSTRING)
           ENDIF
           //? aRetFiles[i, F_NAME]+STR(nPOSFIM)
           //?? aRetFiles[i, F_NAME]
           IF nPOSFIM>0
              cSUBSTRING:=SUBSTR(cSUBSTRING,1,nPOSFIM)
              //?? LEFT(CSUBSTRING,80)
              aCAMPOS:=HB_ATokens(CSUBSTRING,"}") 
         //     ? aRetFiles[i, F_NAME]
          //    ? len(acampos)
              nFIMLOOP:=lEN(acampos)
              IF nFIMLOOP>10
                 nFIMLOOP:=10
              ENDIF
            //  ? nFIMLOOP
             // INKEY(0)
             cINI+="["+UPPER(aRetFiles[i, F_NAME])+"]"+hb_eol()
              FOR IC=1 TO nFIMLOOP
                  cCAMPO:=acampos[iC]
                  IF AT("[_PARAMETER",cCAMPO)>0
                     cCAMPO:=""
                  endif
                  IF AT(".DBF",cCAMPO)>0
                    nPOSCAMPO:=AT(" ",cCAMPO)
                    IF nPOSCAMPO>0
                       cCAMPO:=SUBSTR(cCAMPO,nPOSCAMPO+1)
                    ENDIF
                    //?? cCAMPO
                    cCAMPO:=ALLTRIM(cCAMPO)
                    nPOSALOG:=AScan(aLogs, cCAMPO )
                    cCONTEUDO:=STRTRAN(cCONTEUDO,lower(ccampo)," ")
                    cCONTEUDO:=STRTRAN(cCONTEUDO,upper(ccampo)," ")
                    IF nPOSaLOG=0
                       //? cCAMPO
                       AAdd(aLogs, cCAMPO)
                    ELSE
                       //? str(Nposalog)+ccampo
                    ENDIF  
                    IF IC=1
                       cCONN:=PEGCONN(cCAMPO)
                       cINI+= "CONEXAO="+cCONN+hb_eol()+hb_eol()
                    ENDIF
                 ENDIF    
                  //inkeY(0)
              NEXT IC
           ENDIF
        ENDIF
        HB_MemoWrit(lower(aRetFiles[i, F_NAME]), cCONTEUDO,.F.) 
    NEXT I
    
    
    
nFIMLOOP:=LEN(aLOGS)
FOR IA:=1 TO nFIMLOOP
    //? ALOGS[IA]
     cPATH:=SPACE(100)
    cFILENAME:=SPACE(100)
    cExtension:=SPACE(10)
    cCAMINHO:=STRTRAN(ALOGS[IA],"\\","\")
   // ? cCAMINHO
    cCONN:=""
    HB_FNameSplit( cCAMINHO, @cPath , @cFileName , @cExtension ) 
    cLOG+=ALOGS[IA]+hb_eol()
     cCONN:=PEGCONN(ALOGS[IA])
    cINI+="["+cFILENAME+".DBF]"+hb_eol()
    cINI+= "CONEXAO="+cCONN+hb_eol()+hb_eol()
NEXT IA
HB_MEMOWRIT("CAMINHO.TXT",cLOG,.F.)
HB_MEMOWRIT("VORETRUN.INI",cINI,.F.)
RETURN




FUNCTION PEGCONN(cCAMINHO)
    cPATH:=SPACE(100)
    cFILENAME:=SPACE(100)
    cExtension:=SPACE(10)
    cCAMINHO:=STRTRAN(cCAMINHO,"\\","\")
   // ? cCAMINHO
    cCONN:=""
    HB_FNameSplit( cCAMINHO, @cPath , @cFileName , @cExtension ) 
    cPatH:=LOWER(CPATH)
    DO CASE
       CASE AT("\apura\",cPath)>0
            cCONN:="MANA5APU"
       CASE AT("\banco\",cPath)>0
            cCONN:="MANA5BCO"
       CASE AT("\configur\",cPath)>0
            cCONN:="MANA5CON"
       CASE AT("\crm\",cPath)>0
            cCONN:="MANA5CRM"
       CASE AT("\fiscal\",cPath)>0
            cCONN:="MANA5FIS"
       CASE AT("\graficos\",cPath)>0
            cCONN:="MANA5GRA"
       CASE AT("\instrume\",cPath)>0
            cCONN:="MANA5INS"
       CASE AT("\pcp\",cPath)>0
            cCONN:="MANA5PCP"
       CASE AT("\producao\",cPath)>0
            cCONN:="MANA5PRO"
       CASE AT("\qualida\",cPath)>0
            cCONN:="MANA5QUA"
       CASE AT("\rh\",cPath)>0
            cCONN:="MANA5RH"
       CASE AT("\tgq\",cPath)>0
            cCONN:="MANA5TGQ"
       CASE AT("\viabili\",cPath)>0
            cCONN:="MANA5VIA"
       CASE AT("\ferramen\",cPath)>0
            cCONN:="MANA5FER"
       CASE AT("\engenha\",cPath)>0
            cCONN:="MANA5ENG"
       CASE AT("\mana5\emp00001\",cPath)>0
            cCONN:="MANA5EMP"
       CASE AT("\prd\",cPath)>0
            cCONN:="MANA5EMP"
       CASE AT("\itaesbra\emp00001\",cPath)>0
            cCONN:="MANA5EMP"
       CASE AT("\final\",cPath)>0
            cCONN:="MANA5FIN"
       CASE AT("",cPath)>0
            cCONN:="\folha\emp00001\"
       CASE AT("FOLHAEMP",cPath)>0
            cCONN:="FOLHA"
       CASE AT("\folha\",cPath)>0
            cCONN:="FOLHA"
       //CASE AT("",cPath)>0
       //     cCONN:="FOLHA"
            
            
    ENDCASE
    RETURN cCONN