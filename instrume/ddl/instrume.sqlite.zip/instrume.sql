--
-- Arquivo gerado com SQLiteStudio v3.4.4 em seg ago 5 13:41:48 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: me04
CREATE TABLE IF NOT EXISTS [me04] ([codigo] TEXT(8) NOT NULL, [tipo] TEXT(30) NOT NULL, [marca] TEXT(20) NOT NULL, [capaci] TEXT(30) NOT NULL, [divi] TEXT(10) NOT NULL, [nomtipo] TEXT(30) NOT NULL, [codtipo] TEXT(3) NOT NULL, [codfor] REAL NOT NULL, [cogfor] TEXT(12) NOT NULL, [compra] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [situacao] TEXT(1) NOT NULL, [datauso] SHORTDATE NOT NULL, [datafim] SHORTDATE NOT NULL, [norma] TEXT(30) NOT NULL, [aplic] TEXT(30) NOT NULL, [tipcal] TEXT(1) NOT NULL, [calibrar] REAL NOT NULL, [ativo] TEXT(1) NOT NULL, [erroadm] TEXT(15) NOT NULL, [obs01] TEXT(70) NOT NULL, [obs02] TEXT(70) NOT NULL, [obs03] TEXT(70) NOT NULL, [modelo] TEXT(20) NOT NULL, [calult] SHORTDATE NOT NULL, [calpro] SHORTDATE NOT NULL, [cadtip] TEXT(1) NOT NULL, [dime] TEXT(1) NOT NULL, [mate] TEXT(1) NOT NULL, [cara] TEXT(1) NOT NULL, [preco] REAL NOT NULL, [ultprc] REAL NOT NULL, [ultund] TEXT(2) NOT NULL, [ultdata] SHORTDATE NOT NULL, [nome] TEXT(1) NOT NULL, [aplicacao] TEXT(24) NOT NULL, [desenho] TEXT(25) NOT NULL, [dataext] SHORTDATE NOT NULL, [classipi] TEXT(10) NOT NULL, [unidade] TEXT(2) NOT NULL, [pf] REAL NOT NULL, [rrmdata] SHORTDATE NOT NULL, [codigoint] TEXT(15) NOT NULL);

-- Tabela: me04c
CREATE TABLE IF NOT EXISTS [me04c] ([occ] REAL NOT NULL, [codigo] TEXT(10) NOT NULL, [data] SHORTDATE NOT NULL, [datap] SHORTDATE NOT NULL, [codfor] REAL NOT NULL, [cogfor] TEXT(20) NOT NULL, [certifi] TEXT(10) NOT NULL, [nfcc] REAL NOT NULL);

-- Tabela: me04ci
CREATE TABLE IF NOT EXISTS [me04ci] ([occ] REAL NOT NULL, [item] REAL NOT NULL, [especi] TEXT(30) NOT NULL, [enctr] TEXT(30) NOT NULL, [desvio] TEXT(10) NOT NULL, [inctot] TEXT(10) NOT NULL, [laudo] TEXT(1) NOT NULL, [nrelat] TEXT(5) NOT NULL, [assnom] TEXT(10) NOT NULL, [assdat] SHORTDATE NOT NULL);

-- Tabela: me04d
CREATE TABLE IF NOT EXISTS [me04d] ([ocd] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [motivo] TEXT(1) NOT NULL, [obs01] TEXT(50) NOT NULL, [obs02] TEXT(50) NOT NULL, [obs03] TEXT(50) NOT NULL, [invalida] TEXT(1) NOT NULL, [verifi] TEXT(20) NOT NULL, [inspecao] TEXT(1) NOT NULL, [codigos] TEXT(40) NOT NULL, [clinome] TEXT(40) NOT NULL, [nf] TEXT(30) NOT NULL, [acli01] TEXT(50) NOT NULL, [acli02] TEXT(50) NOT NULL, [incide] TEXT(1) NOT NULL, [freq1] TEXT(20) NOT NULL, [freq2] TEXT(20) NOT NULL, [acor01] TEXT(75) NOT NULL, [acor02] TEXT(75) NOT NULL, [acor03] TEXT(75) NOT NULL, [acor04] TEXT(75) NOT NULL, [respon] TEXT(30) NOT NULL, [dataocd] SHORTDATE NOT NULL);

-- Tabela: me04r
CREATE TABLE IF NOT EXISTS [me04r] ([numero] REAL NOT NULL, [codigo] TEXT(8) NOT NULL, [codoper] REAL NOT NULL, [saida] SHORTDATE NOT NULL, [horasai] REAL NOT NULL, [devolucao] SHORTDATE NOT NULL, [horadev] REAL NOT NULL, [area] TEXT(2) NOT NULL, [setor] TEXT(3) NOT NULL);

-- Tabela: me06
CREATE TABLE IF NOT EXISTS [me06] ([codigo] TEXT(8) NOT NULL, [tipo] TEXT(30) NOT NULL, [marca] TEXT(20) NOT NULL, [capaci] TEXT(30) NOT NULL, [divi] TEXT(10) NOT NULL, [nomtipo] TEXT(30) NOT NULL, [codtipo] TEXT(3) NOT NULL, [codfor] REAL NOT NULL, [cogfor] TEXT(12) NOT NULL, [compra] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [situacao] TEXT(1) NOT NULL, [datauso] SHORTDATE NOT NULL, [datafim] SHORTDATE NOT NULL, [norma] TEXT(30) NOT NULL, [aplic] TEXT(30) NOT NULL, [tipcal] TEXT(1) NOT NULL, [calibrar] REAL NOT NULL, [ativo] TEXT(1) NOT NULL, [erroadm] TEXT(15) NOT NULL, [obs01] TEXT(70) NOT NULL, [obs02] TEXT(70) NOT NULL, [obs03] TEXT(70) NOT NULL, [modelo] TEXT(20) NOT NULL, [calult] SHORTDATE NOT NULL, [calpro] SHORTDATE NOT NULL, [cadtip] TEXT(1) NOT NULL, [dime] TEXT(1) NOT NULL, [mate] TEXT(1) NOT NULL, [cara] TEXT(1) NOT NULL, [preco] REAL NOT NULL, [ultprc] REAL NOT NULL, [ultund] TEXT(2) NOT NULL, [ultdata] SHORTDATE NOT NULL, [nome] TEXT(1) NOT NULL, [aplicacao] TEXT(24) NOT NULL, [desenho] TEXT(25) NOT NULL, [dataext] SHORTDATE NOT NULL, [classipi] TEXT(10) NOT NULL, [unidade] TEXT(2) NOT NULL, [pf] REAL NOT NULL, [rrmdata] SHORTDATE NOT NULL);

-- Tabela: me06r
CREATE TABLE IF NOT EXISTS [me06r] ([numero] REAL NOT NULL, [codigo] TEXT(8) NOT NULL, [codoper] REAL NOT NULL, [saida] SHORTDATE NOT NULL, [horasai] REAL NOT NULL, [devolucao] SHORTDATE NOT NULL, [horadev] REAL NOT NULL, [area] TEXT(2) NOT NULL, [setor] TEXT(3) NOT NULL);

-- Tabela: me06x
CREATE TABLE IF NOT EXISTS [me06x] ([codigo] TEXT(8) NOT NULL, [tipo] TEXT(30) NOT NULL, [marca] TEXT(20) NOT NULL, [capaci] TEXT(30) NOT NULL, [divi] TEXT(10) NOT NULL, [nomtipo] TEXT(30) NOT NULL, [codtipo] TEXT(3) NOT NULL, [codfor] REAL NOT NULL, [cogfor] TEXT(12) NOT NULL, [compra] SHORTDATE NOT NULL, [valor] REAL NOT NULL, [situacao] TEXT(1) NOT NULL, [datauso] SHORTDATE NOT NULL, [datafim] SHORTDATE NOT NULL, [norma] TEXT(30) NOT NULL, [aplic] TEXT(30) NOT NULL, [tipcal] TEXT(1) NOT NULL, [calibrar] REAL NOT NULL, [ativo] TEXT(8) NOT NULL, [erroadm] TEXT(15) NOT NULL, [obs01] TEXT(70) NOT NULL, [obs02] TEXT(70) NOT NULL, [obs03] TEXT(70) NOT NULL, [modelo] TEXT(20) NOT NULL, [calult] SHORTDATE NOT NULL, [calpro] SHORTDATE NOT NULL, [cadtip] TEXT(1) NOT NULL, [dime] TEXT(40) NOT NULL, [mate] TEXT(30) NOT NULL, [cara] TEXT(50) NOT NULL, [preco] REAL NOT NULL, [rrmdata] SHORTDATE NOT NULL);

-- Tabela: me4cc
CREATE TABLE IF NOT EXISTS [me4cc] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [codigo] TEXT(24) NOT NULL, [datarev] SHORTDATE NOT NULL, [codme04a] TEXT(8) NOT NULL, [codme04] TEXT(8) NOT NULL, [nomme04] TEXT(30) NOT NULL, [temper] TEXT(10) NOT NULL, [umidade] TEXT(5) NOT NULL, [novo] BIT NOT NULL, [sujoext] BIT NOT NULL, [sujoint] BIT NOT NULL, [danific] BIT NOT NULL, [laudof] TEXT(1) NOT NULL, [laudod] SHORTDATE NOT NULL, [numtec] REAL NOT NULL, [nomtec] TEXT(40) NOT NULL, [valpad] SHORTDATE NOT NULL, [instru] TEXT(20) NOT NULL, [displin] BIT NOT NULL, [dispmat] BIT NOT NULL);

-- Tabela: me4cci
CREATE TABLE IF NOT EXISTS [me4cci] ([numero] REAL NOT NULL, [dimensao] TEXT(50) NOT NULL, [encontra] TEXT(30) NOT NULL, [tendencia] TEXT(10) NOT NULL, [laudo] TEXT(1) NOT NULL, [inctot] TEXT(10) NOT NULL);

-- Tabela: rrm
CREATE TABLE IF NOT EXISTS [rrm] ([rrs] REAL NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(40) NOT NULL, [desenho] TEXT(24) NOT NULL, [descri] TEXT(40) NOT NULL, [instru] TEXT(8) NOT NULL, [descii] TEXT(25) NOT NULL, [carac] TEXT(40) NOT NULL, [espec] TEXT(40) NOT NULL, [ava] TEXT(40) NOT NULL, [avb] TEXT(40) NOT NULL, [avan] REAL NOT NULL, [avbn] REAL NOT NULL, [ama01] REAL NOT NULL, [ama02] REAL NOT NULL, [ama03] REAL NOT NULL, [ama04] REAL NOT NULL, [ama05] REAL NOT NULL, [amaa01] REAL NOT NULL, [amaa02] REAL NOT NULL, [amaa03] REAL NOT NULL, [amaa04] REAL NOT NULL, [amaa05] REAL NOT NULL, [amb01] REAL NOT NULL, [amb02] REAL NOT NULL, [amb03] REAL NOT NULL, [amb04] REAL NOT NULL, [amb05] REAL NOT NULL, [ambb01] REAL NOT NULL, [ambb02] REAL NOT NULL, [ambb03] REAL NOT NULL, [ambb04] REAL NOT NULL, [ambb05] REAL NOT NULL, [difa01] REAL NOT NULL, [difa02] REAL NOT NULL, [difa03] REAL NOT NULL, [difa04] REAL NOT NULL, [difa05] REAL NOT NULL, [difb01] REAL NOT NULL, [difb02] REAL NOT NULL, [difb03] REAL NOT NULL, [difb04] REAL NOT NULL, [difb05] REAL NOT NULL, [totaa] REAL NOT NULL, [totab] REAL NOT NULL, [medaa] REAL NOT NULL, [totala] REAL NOT NULL, [totba] REAL NOT NULL, [totbb] REAL NOT NULL, [medbb] REAL NOT NULL, [totalb] REAL NOT NULL, [media] REAL NOT NULL, [medib] REAL NOT NULL, [medsom] REAL NOT NULL, [medmed] REAL NOT NULL, [difmed] REAL NOT NULL, [ve] REAL NOT NULL, [va] REAL NOT NULL, [rr] REAL NOT NULL, [vp] REAL NOT NULL, [vt] REAL NOT NULL, [prr] REAL NOT NULL, [data] SHORTDATE NOT NULL, [obs01] TEXT(50) NOT NULL, [obs02] TEXT(50) NOT NULL, [rp] REAL NOT NULL, [m01] REAL NOT NULL, [m02] REAL NOT NULL, [m03] REAL NOT NULL, [m04] REAL NOT NULL, [m05] REAL NOT NULL, [rpmax] REAL NOT NULL, [rpmin] REAL NOT NULL, [xmax] REAL NOT NULL, [xmin] REAL NOT NULL, [k01] REAL NOT NULL, [k02] REAL NOT NULL, [k03] REAL NOT NULL, [tolmin] REAL NOT NULL, [tolmax] REAL NOT NULL, [numass] REAL NOT NULL, [datass] SHORTDATE NOT NULL, [nomass] TEXT(40) NOT NULL);

-- �ndice: idx_me04_me04-1
CREATE INDEX IF NOT EXISTS [idx_me04_me04-1] ON [me04] ([codigo]);

-- �ndice: idx_me04_me04-2
CREATE INDEX IF NOT EXISTS [idx_me04_me04-2] ON [me04] ([codtipo], [codigo]);

-- �ndice: idx_me04_me04-3
CREATE INDEX IF NOT EXISTS [idx_me04_me04-3] ON [me04] ([calpro]);

-- �ndice: idx_me04c_me04c-1
CREATE INDEX IF NOT EXISTS [idx_me04c_me04c-1] ON [me04c] ([occ]);

-- �ndice: idx_me04c_me04c-2
CREATE INDEX IF NOT EXISTS [idx_me04c_me04c-2] ON [me04c] ([codigo]);

-- �ndice: idx_me04c_me04c-3
CREATE INDEX IF NOT EXISTS [idx_me04c_me04c-3] ON [me04c] ([certifi]);

-- �ndice: idx_me04ci_me04ci-1
CREATE INDEX IF NOT EXISTS [idx_me04ci_me04ci-1] ON [me04ci] ([occ], [item]);

-- �ndice: idx_me04ci_me04ci-2
CREATE INDEX IF NOT EXISTS [idx_me04ci_me04ci-2] ON [me04ci] ([occ]);

-- �ndice: idx_me04d_me04d-1
CREATE INDEX IF NOT EXISTS [idx_me04d_me04d-1] ON [me04d] ([ocd]);

-- �ndice: idx_me04d_me04d-2
CREATE INDEX IF NOT EXISTS [idx_me04d_me04d-2] ON [me04d] ([codigo]);

-- �ndice: idx_me04r_me04r-1
CREATE INDEX IF NOT EXISTS [idx_me04r_me04r-1] ON [me04r] ([numero]);

-- �ndice: idx_me04r_me04r-2
CREATE INDEX IF NOT EXISTS [idx_me04r_me04r-2] ON [me04r] ([codoper]);

-- �ndice: idx_me04r_me04r-3
CREATE INDEX IF NOT EXISTS [idx_me04r_me04r-3] ON [me04r] ([codigo]);

-- �ndice: idx_me06_me06-1
CREATE INDEX IF NOT EXISTS [idx_me06_me06-1] ON [me06] ([codigo]);

-- �ndice: idx_me06_me06-2
CREATE INDEX IF NOT EXISTS [idx_me06_me06-2] ON [me06] ([codtipo], [codigo]);

-- �ndice: idx_me06_me06-3
CREATE INDEX IF NOT EXISTS [idx_me06_me06-3] ON [me06] ([calpro]);

-- �ndice: idx_me06r_me06r-1
CREATE INDEX IF NOT EXISTS [idx_me06r_me06r-1] ON [me06r] ([numero]);

-- �ndice: idx_me06r_me06r-2
CREATE INDEX IF NOT EXISTS [idx_me06r_me06r-2] ON [me06r] ([codoper]);

-- �ndice: idx_me06r_me06r-3
CREATE INDEX IF NOT EXISTS [idx_me06r_me06r-3] ON [me06r] ([codigo]);

-- �ndice: idx_me06x_me06x-1
CREATE INDEX IF NOT EXISTS [idx_me06x_me06x-1] ON [me06x] ([codigo]);

-- �ndice: idx_me06x_me06x-2
CREATE INDEX IF NOT EXISTS [idx_me06x_me06x-2] ON [me06x] ([codtipo], [codigo]);

-- �ndice: idx_me06x_me06x-3
CREATE INDEX IF NOT EXISTS [idx_me06x_me06x-3] ON [me06x] ([calpro]);

-- �ndice: idx_me4cc_codigo
CREATE INDEX IF NOT EXISTS [idx_me4cc_codigo] ON [me4cc] ([codigo]);

-- �ndice: idx_me4cc_numero
CREATE INDEX IF NOT EXISTS [idx_me4cc_numero] ON [me4cc] ([numero]);

-- �ndice: idx_me4cci_numero
CREATE INDEX IF NOT EXISTS [idx_me4cci_numero] ON [me4cci] ([numero]);

-- �ndice: idx_rrs
CREATE INDEX IF NOT EXISTS [idx_rrs] ON [rrm] ([rrs]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
