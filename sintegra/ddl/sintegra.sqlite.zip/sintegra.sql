--
-- Arquivo gerado com SQLiteStudio v3.4.4 em ter ago 6 17:31:05 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: sint
CREATE TABLE IF NOT EXISTS [sint] ([reg] TEXT(2) NOT NULL);

-- Tabela: sint10
CREATE TABLE IF NOT EXISTS [sint10] ([tipo] TEXT(2) NOT NULL, [cgc] TEXT(14) NOT NULL, [ie] TEXT(14) NOT NULL, [nome] TEXT(35) NOT NULL, [municipio] TEXT(30) NOT NULL, [uf] TEXT(2) NOT NULL, [fax] TEXT(10) NOT NULL, [dataini] SHORTDATE NOT NULL, [datafim] SHORTDATE NOT NULL, [convenio] TEXT(1) NOT NULL, [natureza] REAL NOT NULL, [finalidade] TEXT(1) NOT NULL);

-- Tabela: sint11
CREATE TABLE IF NOT EXISTS [sint11] ([tipo] TEXT(2) NOT NULL, [logradouro] TEXT(34) NOT NULL, [numero] REAL NOT NULL, [compl] TEXT(22) NOT NULL, [bairro] TEXT(15) NOT NULL, [cep] TEXT(8) NOT NULL, [contato] TEXT(28) NOT NULL, [telefone] TEXT(12) NOT NULL);

-- Tabela: sint50
CREATE TABLE IF NOT EXISTS [sint50] ([tipo] TEXT(2) NOT NULL, [cgc] TEXT(18) NOT NULL, [ie] TEXT(20) NOT NULL, [data] SHORTDATE NOT NULL, [uf] TEXT(2) NOT NULL, [modelo] REAL NOT NULL, [serie] TEXT(3) NOT NULL, [sub] TEXT(2) NOT NULL, [numero] REAL NOT NULL, [cfop] TEXT(4) NOT NULL, [valortot] REAL NOT NULL, [base] REAL NOT NULL, [valor] REAL NOT NULL, [isenta] REAL NOT NULL, [outras] REAL NOT NULL, [aliquota] REAL NOT NULL, [situacao] TEXT(1) NOT NULL, [tiponf] TEXT(1) NOT NULL, [obs] REAL NOT NULL, [emitente] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL);

-- Tabela: sint51
CREATE TABLE IF NOT EXISTS [sint51] ([tipo] TEXT(2) NOT NULL, [cgc] TEXT(18) NOT NULL, [ie] TEXT(20) NOT NULL, [data] SHORTDATE NOT NULL, [uf] TEXT(2) NOT NULL, [modelo] REAL NOT NULL, [serie] TEXT(3) NOT NULL, [sub] TEXT(2) NOT NULL, [numero] REAL NOT NULL, [cfop] TEXT(4) NOT NULL, [valortot] REAL NOT NULL, [base] REAL NOT NULL, [valor] REAL NOT NULL, [isenta] REAL NOT NULL, [outras] REAL NOT NULL, [aliquota] REAL NOT NULL, [situacao] TEXT(1) NOT NULL, [tiponf] TEXT(1) NOT NULL, [obs] REAL NOT NULL, [fornecedo] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [brancos] TEXT(1) NOT NULL);

-- Tabela: sint53
CREATE TABLE IF NOT EXISTS [sint53] ([tipo] TEXT(2) NOT NULL, [cgc] TEXT(18) NOT NULL, [ie] TEXT(20) NOT NULL, [data] SHORTDATE NOT NULL, [uf] TEXT(2) NOT NULL, [modelo] REAL NOT NULL, [serie] TEXT(3) NOT NULL, [sub] TEXT(2) NOT NULL, [numero] REAL NOT NULL, [cfop] TEXT(4) NOT NULL, [valortot] REAL NOT NULL, [base] REAL NOT NULL, [valor] REAL NOT NULL, [isenta] REAL NOT NULL, [outras] REAL NOT NULL, [aliquota] REAL NOT NULL, [situacao] TEXT(1) NOT NULL, [tiponf] TEXT(1) NOT NULL, [obs] REAL NOT NULL, [antecipa] TEXT(1) NOT NULL, [despesas] REAL NOT NULL, [fornecedo] REAL NOT NULL, [emitente] TEXT(1) NOT NULL, [tipocli] TEXT(1) NOT NULL);

-- Tabela: sint54
CREATE TABLE IF NOT EXISTS [sint54] ([tipo] TEXT(2) NOT NULL, [cgc] TEXT(18) NOT NULL, [modelo] REAL NOT NULL, [serie] TEXT(3) NOT NULL, [numero] REAL NOT NULL, [cfop] TEXT(4) NOT NULL, [situacao] REAL NOT NULL, [item] REAL NOT NULL, [codigored] TEXT(14) NOT NULL, [qtde] REAL NOT NULL, [valormer] REAL NOT NULL, [desconto] REAL NOT NULL, [baseicm] REAL NOT NULL, [basesub] REAL NOT NULL, [valoripi] REAL NOT NULL, [icm] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [tiponf] TEXT(1) NOT NULL, [tipocli] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [uf] TEXT(2) NOT NULL, [sub] TEXT(2) NOT NULL, [data] SHORTDATE NOT NULL);

-- Tabela: sint55
CREATE TABLE IF NOT EXISTS [sint55] ([tipo] TEXT(2) NOT NULL, [cgc] TEXT(14) NOT NULL, [ie] TEXT(14) NOT NULL, [dtgnre] SHORTDATE NOT NULL, [uf] TEXT(2) NOT NULL, [uffavor] TEXT(2) NOT NULL, [banco] TEXT(3) NOT NULL, [agencia] TEXT(4) NOT NULL, [numgnre] TEXT(20) NOT NULL, [valgnre] REAL NOT NULL, [dtvenc] SHORTDATE NOT NULL, [mesanoref] TEXT(6) NOT NULL, [convenio] TEXT(30) NOT NULL);

-- Tabela: sint56
CREATE TABLE IF NOT EXISTS [sint56] ([reg] TEXT(2) NOT NULL, [cnpjcpf] TEXT(14) NOT NULL, [modelo] REAL NOT NULL, [serie] TEXT(3) NOT NULL, [numero] TEXT(6) NOT NULL, [cfop] TEXT(4) NOT NULL, [cst] REAL NOT NULL, [nritem] REAL NOT NULL, [codprod] TEXT(14) NOT NULL, [tpoperacao] REAL NOT NULL, [cnpjconc] REAL NOT NULL, [alqipi] TEXT(4) NOT NULL, [chassi] TEXT(17) NOT NULL, [brancos] TEXT(39) NOT NULL);

-- Tabela: sint60a
CREATE TABLE IF NOT EXISTS [sint60a] ([tipo] TEXT(2) NOT NULL, [sub60a] TEXT(1) NOT NULL, [emis60a] SHORTDATE NOT NULL, [numfaba] TEXT(20) NOT NULL, [sittri60a] TEXT(4) NOT NULL, [valor60] REAL NOT NULL, [branco60a] TEXT(79) NOT NULL);

-- Tabela: sint60d
CREATE TABLE IF NOT EXISTS [sint60d] ([tipo] TEXT(2) NOT NULL, [sub60d] TEXT(1) NOT NULL, [emis60d] SHORTDATE NOT NULL, [numfabd] TEXT(20) NOT NULL, [prod60d] TEXT(14) NOT NULL, [quant60d] REAL NOT NULL, [valpro60d] REAL NOT NULL, [baseic60d] REAL NOT NULL, [sittri60d] TEXT(4) NOT NULL, [valicm60d] REAL NOT NULL, [branco60d] TEXT(19) NOT NULL);

-- Tabela: sint60i
CREATE TABLE IF NOT EXISTS [sint60i] ([tipo] TEXT(2) NOT NULL, [sub60i] TEXT(1) NOT NULL, [emis60i] SHORTDATE NOT NULL, [numfabi] TEXT(20) NOT NULL, [model60i] TEXT(2) NOT NULL, [numcoo] TEXT(6) NOT NULL, [numite60i] TEXT(3) NOT NULL, [prod60i] TEXT(14) NOT NULL, [quant60i] REAL NOT NULL, [valuni60i] REAL NOT NULL, [baseic60i] REAL NOT NULL, [sittri60i] TEXT(4) NOT NULL, [valicm60i] REAL NOT NULL, [branco60i] TEXT(16) NOT NULL);

-- Tabela: sint60m
CREATE TABLE IF NOT EXISTS [sint60m] ([tipo] TEXT(2) NOT NULL, [sub60m] TEXT(1) NOT NULL, [emis60m] SHORTDATE NOT NULL, [numfabm] TEXT(20) NOT NULL, [numpdvm] TEXT(3) NOT NULL, [model60m] TEXT(2) NOT NULL, [nuini60m] TEXT(6) NOT NULL, [nufim60m] TEXT(6) NOT NULL, [reduz60m] TEXT(6) NOT NULL, [cro60m] REAL NOT NULL, [venda60m] REAL NOT NULL, [totger60m] REAL NOT NULL, [branco60m] TEXT(37) NOT NULL);

-- Tabela: sint60r
CREATE TABLE IF NOT EXISTS [sint60r] ([tipo] TEXT(2) NOT NULL, [sub60r] TEXT(1) NOT NULL, [mesanoemr] TEXT(6) NOT NULL, [prod60r] TEXT(14) NOT NULL, [quant60r] REAL NOT NULL, [valuni60r] REAL NOT NULL, [baseic60r] REAL NOT NULL, [sittri60r] TEXT(4) NOT NULL, [branco60r] TEXT(54) NOT NULL);

-- Tabela: sint61
CREATE TABLE IF NOT EXISTS [sint61] ([tipo] TEXT(2) NOT NULL, [branco611] TEXT(14) NOT NULL, [branco612] TEXT(14) NOT NULL, [emis61] SHORTDATE NOT NULL, [model61m] TEXT(2) NOT NULL, [serie61] TEXT(3) NOT NULL, [subser61] TEXT(2) NOT NULL, [nuini61m] TEXT(6) NOT NULL, [nufim61m] TEXT(6) NOT NULL, [valtot61] REAL NOT NULL, [baseic61] REAL NOT NULL, [valicm61] REAL NOT NULL, [isenta61] REAL NOT NULL, [outras61] REAL NOT NULL, [aliqic61] REAL NOT NULL, [branco61] TEXT(1) NOT NULL);

-- Tabela: sint70
CREATE TABLE IF NOT EXISTS [sint70] ([tipo] TEXT(2) NOT NULL, [cgc] TEXT(18) NOT NULL, [ie] TEXT(20) NOT NULL, [data] SHORTDATE NOT NULL, [uf] TEXT(2) NOT NULL, [modelo] REAL NOT NULL, [serie] TEXT(3) NOT NULL, [sub] TEXT(2) NOT NULL, [numero] REAL NOT NULL, [cfop] TEXT(4) NOT NULL, [valortot] REAL NOT NULL, [base] REAL NOT NULL, [valor] REAL NOT NULL, [isenta] REAL NOT NULL, [outras] REAL NOT NULL, [aliquota] REAL NOT NULL, [situacao] TEXT(1) NOT NULL, [tiponf] TEXT(1) NOT NULL, [obs] REAL NOT NULL, [emitente] TEXT(1) NOT NULL, [frete] TEXT(1) NOT NULL, [fornecedo] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL);

-- Tabela: sint71
CREATE TABLE IF NOT EXISTS [sint71] ([tipo] TEXT(2) NOT NULL, [cgc] TEXT(14) NOT NULL, [ie] TEXT(14) NOT NULL, [emis71] SHORTDATE NOT NULL, [uf] TEXT(2) NOT NULL, [model71] TEXT(2) NOT NULL, [serie71] TEXT(1) NOT NULL, [subser71] TEXT(2) NOT NULL, [nfisc71] TEXT(6) NOT NULL, [ufrem] TEXT(2) NOT NULL, [cnpjrem] TEXT(14) NOT NULL, [inscrem] TEXT(14) NOT NULL, [emisrem71] SHORTDATE NOT NULL, [modrem71] TEXT(2) NOT NULL, [serirem71] TEXT(3) NOT NULL, [nfisrem71] TEXT(6) NOT NULL, [valtot71] REAL NOT NULL, [branco71] TEXT(12) NOT NULL);

-- Tabela: sint74
CREATE TABLE IF NOT EXISTS [sint74] ([tipo] TEXT(2) NOT NULL, [data_inven] TEXT(8) NOT NULL, [cod_mercad] TEXT(14) NOT NULL, [quantidade] REAL NOT NULL, [valortotal] REAL NOT NULL, [situ_estoq] TEXT(1) NOT NULL, [cgc] TEXT(14) NOT NULL, [ie] TEXT(14) NOT NULL, [uf] TEXT(2) NOT NULL, [branco74] TEXT(45) NOT NULL);

-- Tabela: sint75
CREATE TABLE IF NOT EXISTS [sint75] ([tipo] TEXT(2) NOT NULL, [dataini] SHORTDATE NOT NULL, [datafim] SHORTDATE NOT NULL, [codigored] TEXT(14) NOT NULL, [classipi] TEXT(14) NOT NULL, [descricao] TEXT(53) NOT NULL, [unid] TEXT(2) NOT NULL, [situacao] REAL NOT NULL, [tipoent] TEXT(1) NOT NULL, [ipi] REAL NOT NULL, [icm] REAL NOT NULL, [redicm] REAL NOT NULL, [subicm] REAL NOT NULL, [gerado] BIT NOT NULL, [codigo] TEXT(24) NOT NULL);

-- Tabela: sint76
CREATE TABLE IF NOT EXISTS [sint76] ([tipo] TEXT(2) NOT NULL, [cgc] TEXT(14) NOT NULL, [ie] TEXT(14) NOT NULL, [model76] TEXT(2) NOT NULL, [serie76] TEXT(2) NOT NULL, [subser76] TEXT(2) NOT NULL, [nfisc76] TEXT(10) NOT NULL, [cfop76] TEXT(4) NOT NULL, [tiprec76] TEXT(1) NOT NULL, [emis76] SHORTDATE NOT NULL, [uf] TEXT(2) NOT NULL, [valtot76] REAL NOT NULL, [baseic76] REAL NOT NULL, [valicm76] REAL NOT NULL, [isento76] REAL NOT NULL, [outras76] REAL NOT NULL, [aliqicm76] REAL NOT NULL, [situac76] TEXT(1) NOT NULL);

-- Tabela: sint77
CREATE TABLE IF NOT EXISTS [sint77] ([tipo] TEXT(2) NOT NULL, [cgc] TEXT(14) NOT NULL, [model77] TEXT(2) NOT NULL, [serie77] TEXT(2) NOT NULL, [subser77] TEXT(2) NOT NULL, [nfisc77] TEXT(10) NOT NULL, [cfop77] TEXT(4) NOT NULL, [tiprec77] TEXT(1) NOT NULL, [item77] TEXT(3) NOT NULL, [produt77] TEXT(11) NOT NULL, [quant77] REAL NOT NULL, [valpro77] REAL NOT NULL, [valdes77] REAL NOT NULL, [baseic77] REAL NOT NULL, [aliqic77] REAL NOT NULL, [cnpjmf] TEXT(14) NOT NULL, [codterm] TEXT(10) NOT NULL);

-- Tabela: sint85
CREATE TABLE IF NOT EXISTS [sint85] ([reg] TEXT(2) NOT NULL, [declaracao] REAL NOT NULL, [datadec] SHORTDATE NOT NULL, [averbacao] TEXT(1) NOT NULL, [regexp] REAL NOT NULL, [dtregexp] SHORTDATE NOT NULL, [conhec] TEXT(16) NOT NULL, [dtconhec] SHORTDATE NOT NULL, [tipoconhec] REAL NOT NULL, [pais] REAL NOT NULL, [comprov] REAL NOT NULL, [dtcomprov] SHORTDATE NOT NULL, [nfexport] TEXT(6) NOT NULL, [emissao] SHORTDATE NOT NULL, [modelo] REAL NOT NULL, [serie] TEXT(3) NOT NULL, [brancos] TEXT(19) NOT NULL);

-- Tabela: sint86
CREATE TABLE IF NOT EXISTS [sint86] ([reg] TEXT(2) NOT NULL, [regexp] REAL NOT NULL, [dtregexp] SHORTDATE NOT NULL, [cnpjremet] REAL NOT NULL, [ieremet] TEXT(14) NOT NULL, [ufremet] TEXT(2) NOT NULL, [nf] TEXT(6) NOT NULL, [emissao] SHORTDATE NOT NULL, [modelo] REAL NOT NULL, [serie] TEXT(3) NOT NULL, [produto] TEXT(14) NOT NULL, [quant] REAL NOT NULL, [valunit] REAL NOT NULL, [valprod] REAL NOT NULL, [relac] REAL NOT NULL, [brancos] TEXT(5) NOT NULL);

-- Tabela: sint88c
CREATE TABLE IF NOT EXISTS [sint88c] ([reg] TEXT(2) NOT NULL, [sub] TEXT(1) NOT NULL, [cnpj] TEXT(14) NOT NULL, [modelonf] TEXT(2) NOT NULL, [serienf] TEXT(3) NOT NULL, [numeronf] TEXT(6) NOT NULL, [cfop] TEXT(4) NOT NULL, [numitem] TEXT(3) NOT NULL, [codproduto] TEXT(14) NOT NULL, [quantidade] REAL NOT NULL, [bcst] REAL NOT NULL, [vlrst] REAL NOT NULL, [vlrstcompl] REAL NOT NULL, [retencao] REAL NOT NULL, [parcimpret] REAL NOT NULL, [brancos] TEXT(6) NOT NULL);

-- Tabela: sint88d
CREATE TABLE IF NOT EXISTS [sint88d] ([reg] TEXT(2) NOT NULL, [sub] TEXT(1) NOT NULL, [cnpj] TEXT(14) NOT NULL, [ie] TEXT(14) NOT NULL, [uf] TEXT(2) NOT NULL, [modelonf] TEXT(2) NOT NULL, [serienf] TEXT(3) NOT NULL, [numeronf] TEXT(6) NOT NULL, [emitente] TEXT(1) NOT NULL, [dtemissao] TEXT(8) NOT NULL, [dtsaida] TEXT(8) NOT NULL, [cnpjsaida] TEXT(14) NOT NULL, [ufsaida] TEXT(2) NOT NULL, [iesaida] TEXT(14) NOT NULL, [cnpjent] TEXT(14) NOT NULL, [ufentrega] TEXT(2) NOT NULL, [ieentrega] TEXT(14) NOT NULL, [brancos] TEXT(5) NOT NULL);

-- Tabela: sint88e
CREATE TABLE IF NOT EXISTS [sint88e] ([reg] TEXT(2) NOT NULL, [sub] TEXT(1) NOT NULL, [cnpj] TEXT(14) NOT NULL, [ie] TEXT(14) NOT NULL, [codproinf] TEXT(14) NOT NULL, [codprosef] TEXT(14) NOT NULL, [brancos] TEXT(67) NOT NULL);

-- Tabela: sint88m
CREATE TABLE IF NOT EXISTS [sint88m] ([reg] TEXT(2) NOT NULL, [sub] TEXT(1) NOT NULL, [cnpj] TEXT(14) NOT NULL, [mensagem] TEXT(34) NOT NULL, [brancos] TEXT(75) NOT NULL);

-- Tabela: sint88t
CREATE TABLE IF NOT EXISTS [sint88t] ([reg] TEXT(2) NOT NULL, [sub] TEXT(1) NOT NULL, [cnpj] TEXT(14) NOT NULL, [dtemissao] TEXT(8) NOT NULL, [uf] TEXT(2) NOT NULL, [modelonf] TEXT(2) NOT NULL, [serienf] TEXT(3) NOT NULL, [numeronf] TEXT(6) NOT NULL, [emitente] TEXT(1) NOT NULL, [ciffob] TEXT(1) NOT NULL, [cnpjfrete] TEXT(14) NOT NULL, [uffrete] TEXT(2) NOT NULL, [iefrete] TEXT(14) NOT NULL, [modal] TEXT(1) NOT NULL, [placa1] TEXT(7) NOT NULL, [uf1] TEXT(2) NOT NULL, [placa2] TEXT(7) NOT NULL, [uf2] TEXT(2) NOT NULL, [placa3] TEXT(7) NOT NULL, [uf3] TEXT(2) NOT NULL, [brancos] TEXT(28) NOT NULL);

-- Tabela: sint90
CREATE TABLE IF NOT EXISTS [sint90] ([reg90] TEXT(126) NOT NULL);

-- �ndice: idx_sint50_sint50-1
CREATE INDEX IF NOT EXISTS [idx_sint50_sint50-1] ON [sint50] ([data], [numero]);

-- �ndice: idx_sint50_sint50-2
CREATE INDEX IF NOT EXISTS [idx_sint50_sint50-2] ON [sint50] ([numero], [tiponf]);

-- �ndice: idx_sint51_sint51-1
CREATE INDEX IF NOT EXISTS [idx_sint51_sint51-1] ON [sint51] ([data], [numero]);

-- �ndice: idx_sint51_sint51-2
CREATE INDEX IF NOT EXISTS [idx_sint51_sint51-2] ON [sint51] ([numero], [tiponf]);

-- �ndice: idx_sint53_sint53-1
CREATE INDEX IF NOT EXISTS [idx_sint53_sint53-1] ON [sint53] ([data], [numero]);

-- �ndice: idx_sint53_sint53-2
CREATE INDEX IF NOT EXISTS [idx_sint53_sint53-2] ON [sint53] ([numero], [tiponf]);

-- �ndice: idx_sint54_sint54-1
CREATE INDEX IF NOT EXISTS [idx_sint54_sint54-1] ON [sint54] ([cgc], [serie], [sub], [numero], [item]);

-- �ndice: idx_sint54_sint54-2
CREATE INDEX IF NOT EXISTS [idx_sint54_sint54-2] ON [sint54] ([numero], [tiponf]);

-- �ndice: idx_sint54_sint54-3
CREATE INDEX IF NOT EXISTS [idx_sint54_sint54-3] ON [sint54] ([codigored]);

-- �ndice: idx_sint54_sint54-4
CREATE INDEX IF NOT EXISTS [idx_sint54_sint54-4] ON [sint54] ([codigo]);

-- �ndice: idx_sint54_sint54-5
CREATE INDEX IF NOT EXISTS [idx_sint54_sint54-5] ON [sint54] ([fornecedo]);

-- �ndice: idx_sint54_sint54-6
CREATE INDEX IF NOT EXISTS [idx_sint54_sint54-6] ON [sint54] ([numero], [cgc]);

-- �ndice: idx_sint70_sint70-1
CREATE INDEX IF NOT EXISTS [idx_sint70_sint70-1] ON [sint70] ([data], [numero]);

-- �ndice: idx_sint70_sint70-2
CREATE INDEX IF NOT EXISTS [idx_sint70_sint70-2] ON [sint70] ([numero], [tiponf]);

-- �ndice: idx_sint75-2
CREATE INDEX IF NOT EXISTS [idx_sint75-2] ON [sint75] ([codigo]);

-- �ndice: idx_sint75_sint75-1
CREATE INDEX IF NOT EXISTS [idx_sint75_sint75-1] ON [sint75] ([codigored]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
