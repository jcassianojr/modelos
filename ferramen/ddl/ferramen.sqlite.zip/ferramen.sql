--
-- Arquivo gerado com SQLiteStudio v3.4.4 em sex ago 2 20:10:38 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: cs
CREATE TABLE IF NOT EXISTS [cs] ([cs] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [ferram] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [tecnico] REAL NOT NULL, [tecnome] TEXT(40) NOT NULL, [qtdebase] REAL NOT NULL, [qtdesaldo] REAL NOT NULL, [qtdeped] REAL NOT NULL, [qtdeurg] REAL NOT NULL, [datasaldo] SHORTDATE NOT NULL, [dataped] SHORTDATE NOT NULL, [dataurg] SHORTDATE NOT NULL, [qtdetot] REAL NOT NULL, [hrbas] REAL NOT NULL, [hrtot] REAL NOT NULL, [hrpre] REAL NOT NULL, [hrurg] REAL NOT NULL, [hrsal] REAL NOT NULL, [dathped] SHORTDATE NOT NULL, [dathurg] SHORTDATE NOT NULL, [dathsal] SHORTDATE NOT NULL, [lancada] BIT NOT NULL, [lancdat] SHORTDATE NOT NULL, [lancusr] REAL NOT NULL);

-- Tabela: fapu
CREATE TABLE IF NOT EXISTS [fapu] ([seq] REAL NOT NULL, [dini] SHORTDATE NOT NULL, [dfim] SHORTDATE NOT NULL, [apurado] BIT NOT NULL, [pcplib] BIT NOT NULL, [pcpnum] REAL NOT NULL, [pcpdat] SHORTDATE NOT NULL);

-- Tabela: fapubai
CREATE TABLE IF NOT EXISTS [fapubai] ([seq] REAL NOT NULL, [ferram] TEXT(24) NOT NULL, [qtde] REAL NOT NULL, [horas] REAL NOT NULL);

-- Tabela: fapufer
CREATE TABLE IF NOT EXISTS [fapufer] ([seq] REAL NOT NULL, [ferram] TEXT(24) NOT NULL, [qtde] REAL NOT NULL, [horas] REAL NOT NULL);

-- Tabela: fapui
CREATE TABLE IF NOT EXISTS [fapui] ([seq] REAL NOT NULL, [ferram] TEXT(24) NOT NULL, [qtde] REAL NOT NULL, [horas] REAL NOT NULL);

-- Tabela: fapumaq
CREATE TABLE IF NOT EXISTS [fapumaq] ([seq] REAL NOT NULL, [ferram] TEXT(4) NOT NULL, [qtde] REAL NOT NULL, [horas] REAL NOT NULL);

-- Tabela: fe02
CREATE TABLE IF NOT EXISTS [fe02] ([tipo] TEXT(24) NOT NULL, [codigo] TEXT(20) NOT NULL, [ano] REAL NOT NULL, [mes] REAL NOT NULL, [uso] REAL NOT NULL);

-- Tabela: fe99
CREATE TABLE IF NOT EXISTS [fe99] ([arquivo] TEXT(8) NOT NULL, [documento] TEXT(40) NOT NULL, [operacao] TEXT(1) NOT NULL, [usuario] TEXT(5) NOT NULL, [qtde] REAL NOT NULL, [oldqtde] REAL NOT NULL, [numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [codigo] TEXT(24) NOT NULL, [rastro] TEXT(6) NOT NULL, [estqxxx] REAL NOT NULL, [estqyyy] REAL NOT NULL);

-- Tabela: fergi
CREATE TABLE IF NOT EXISTS [fergi] ([ferram] TEXT(24) NOT NULL, [codigo] TEXT(20) NOT NULL, [nome] TEXT(40) NOT NULL, [desenho] TEXT(40) NOT NULL, [saimin] REAL NOT NULL, [estqmin] REAL NOT NULL, [estqent] REAL NOT NULL, [estqsai] REAL NOT NULL, [estqini] REAL NOT NULL, [estqsal] REAL NOT NULL, [diasent] REAL NOT NULL, [diasest] REAL NOT NULL, [databalan] SHORTDATE NOT NULL, [datmin] SHORTDATE NOT NULL, [mindi] REAL NOT NULL, [minind] REAL NOT NULL, [cauto] REAL NOT NULL, [ccm] REAL NOT NULL, [nom2] TEXT(1) NOT NULL, [unidade] TEXT(2) NOT NULL);

-- Tabela: fergrp
CREATE TABLE IF NOT EXISTS [fergrp] ([grupo] TEXT(24) NOT NULL);

-- Tabela: ferhg
CREATE TABLE IF NOT EXISTS [ferhg] ([os] REAL NOT NULL, [codferr] TEXT(24) NOT NULL, [codme01] TEXT(4) NOT NULL, [data] SHORTDATE NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [tipser] TEXT(1) NOT NULL, [servico] TEXT(255) NOT NULL);

-- Tabela: ferhgi
CREATE TABLE IF NOT EXISTS [ferhgi] ([os] REAL NOT NULL, [data] SHORTDATE NOT NULL, [hini] REAL NOT NULL, [hfim] REAL NOT NULL, [hgas] REAL NOT NULL, [obs] TEXT(255) NOT NULL);

-- Tabela: fernf
CREATE TABLE IF NOT EXISTS [fernf] ([ferram] TEXT(24) NOT NULL, [tipo] TEXT(2) NOT NULL, [nrnota] REAL NOT NULL, [dtnota] SHORTDATE NOT NULL, [vlnota] REAL NOT NULL, [tipcad] TEXT(1) NOT NULL, [clifor] REAL NOT NULL, [clicog] TEXT(12) NOT NULL, [obs] TEXT(70) NOT NULL);

-- Tabela: feros
CREATE TABLE IF NOT EXISTS [feros] ([feros] REAL NOT NULL, [revisao] TEXT(1) NOT NULL, [chave] TEXT(9) NOT NULL, [cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [ferram] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [dataos] SHORTDATE NOT NULL, [datape] SHORTDATE NOT NULL, [datanf] SHORTDATE NOT NULL, [dataprz] SHORTDATE NOT NULL, [nrnota] REAL NOT NULL, [valormer] REAL NOT NULL, [valoricm] REAL NOT NULL, [valoripi] REAL NOT NULL, [valortot] REAL NOT NULL, [baseicm] REAL NOT NULL, [baseipi] REAL NOT NULL, [icm] REAL NOT NULL, [ipi] REAL NOT NULL, [consumo] TEXT(1) NOT NULL, [somanf] TEXT(1) NOT NULL, [qtde] REAL NOT NULL, [preco] REAL NOT NULL, [obs] TEXT(240) NOT NULL, [codipi] TEXT(2) NOT NULL, [classipi] TEXT(10) NOT NULL, [pedidocli] TEXT(20) NOT NULL, [antigo] REAL NOT NULL, [ppapprev] SHORTDATE NOT NULL, [ppapdata] SHORTDATE NOT NULL, [gp11prev] SHORTDATE NOT NULL, [gp11data] SHORTDATE NOT NULL, [adtodata] SHORTDATE NOT NULL, [adtovalor] REAL NOT NULL, [obs2] TEXT(254) NOT NULL, [tipo] TEXT(1) NOT NULL, [nfpgvcto] SHORTDATE NOT NULL);

-- Tabela: ferram
CREATE TABLE IF NOT EXISTS [ferram] ([ferram] TEXT(24) NOT NULL, [grupo] TEXT(24) NOT NULL, [numero] REAL NOT NULL, [nome] TEXT(40) NOT NULL, [cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [situacao] TEXT(1) NOT NULL, [obs] TEXT(50) NOT NULL, [dataatv] SHORTDATE NOT NULL, [datades] SHORTDATE NOT NULL, [datadev] SHORTDATE NOT NULL, [dataout] SHORTDATE NOT NULL, [classe] TEXT(1) NOT NULL, [qtdebase] REAL NOT NULL, [qtdesaldo] REAL NOT NULL, [qtdeped] REAL NOT NULL, [qtdeurg] REAL NOT NULL, [datasaldo] SHORTDATE NOT NULL, [dataped] SHORTDATE NOT NULL, [dataurg] SHORTDATE NOT NULL, [tipofer] TEXT(1) NOT NULL, [qtdetot] REAL NOT NULL, [hrbas] REAL NOT NULL, [hrtot] REAL NOT NULL, [hrpre] REAL NOT NULL, [hrurg] REAL NOT NULL, [hrsal] REAL NOT NULL, [dathped] SHORTDATE NOT NULL, [dathurg] SHORTDATE NOT NULL, [dathsal] SHORTDATE NOT NULL, [prever] TEXT(1) NOT NULL, [vdbas] REAL NOT NULL, [vdpre] REAL NOT NULL, [vdurg] REAL NOT NULL, [vddpre] SHORTDATE NOT NULL, [vddurg] SHORTDATE NOT NULL, [vdhbas] REAL NOT NULL, [vdhpre] REAL NOT NULL, [vdhurg] REAL NOT NULL, [vdhdpre] SHORTDATE NOT NULL, [vdhdurg] SHORTDATE NOT NULL, [propria] TEXT(1) NOT NULL, [naempresa] TEXT(1) NOT NULL, [visualnum] REAL NOT NULL, [visualnom] TEXT(40) NOT NULL, [visualobs] TEXT(50) NOT NULL, [meda] REAL NOT NULL, [medb] REAL NOT NULL, [medc] REAL NOT NULL, [medd] REAL NOT NULL, [medh] REAL NOT NULL, [peso] REAL NOT NULL, [contabil] TEXT(8) NOT NULL, [codmp01] TEXT(12) NOT NULL, [peca] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [opern] TEXT(40) NOT NULL, [pecan] TEXT(40) NOT NULL, [prensa] TEXT(4) NOT NULL, [prensan] TEXT(40) NOT NULL, [altura] TEXT(30) NOT NULL, [almofada] TEXT(20) NOT NULL, [pinos] TEXT(30) NOT NULL, [matcod] TEXT(24) NOT NULL, [matnom] TEXT(100) NOT NULL, [larg] TEXT(30) NOT NULL, [espmat] TEXT(30) NOT NULL, [passofer] TEXT(25) NOT NULL, [pecarol] TEXT(5) NOT NULL, [pratile] TEXT(5) NOT NULL, [usademi] TEXT(1) NOT NULL, [usadisp] TEXT(1) NOT NULL, [obst01] TEXT(40) NOT NULL, [datat] SHORTDATE NOT NULL, [esqtip] TEXT(1) NOT NULL, [esql01] TEXT(8) NOT NULL, [esql02] TEXT(8) NOT NULL, [esql03] TEXT(8) NOT NULL, [esql04] TEXT(8) NOT NULL, [esql05] TEXT(8) NOT NULL, [esql06] TEXT(8) NOT NULL, [esql07] TEXT(8) NOT NULL, [esql08] TEXT(8) NOT NULL, [mediaro] REAL NOT NULL, [pf] REAL NOT NULL);

-- Tabela: ferrami
CREATE TABLE IF NOT EXISTS [ferrami] ([ferram] TEXT(24) NOT NULL, [item] REAL NOT NULL, [lin01] TEXT(80) NOT NULL);

-- Tabela: lvf
CREATE TABLE IF NOT EXISTS [lvf] ([lvf] REAL NOT NULL, [ferram] TEXT(24) NOT NULL, [area] TEXT(2) NOT NULL, [descri] TEXT(40) NOT NULL, [acessor] TEXT(50) NOT NULL, [nome] TEXT(40) NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [data] SHORTDATE NOT NULL, [tecnico] REAL NOT NULL, [tecnome] TEXT(40) NOT NULL, [obs01] TEXT(60) NOT NULL, [obs02] TEXT(60) NOT NULL, [obs03] TEXT(60) NOT NULL, [obs04] TEXT(60) NOT NULL, [obs05] TEXT(60) NOT NULL, [ro] REAL NOT NULL);

-- Tabela: lvfi
CREATE TABLE IF NOT EXISTS [lvfi] ([lvf] REAL NOT NULL, [item] REAL NOT NULL, [descri] TEXT(50) NOT NULL, [oper01] TEXT(1) NOT NULL, [oper02] TEXT(1) NOT NULL);

-- Tabela: lvfp
CREATE TABLE IF NOT EXISTS [lvfp] ([item] REAL NOT NULL, [descri] TEXT(60) NOT NULL, [grupo] TEXT(1) NOT NULL);

-- Tabela: lvm
CREATE TABLE IF NOT EXISTS [lvm] ([lvm] REAL NOT NULL, [numero] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [data] SHORTDATE NOT NULL, [setor] TEXT(10) NOT NULL, [acessor] TEXT(20) NOT NULL, [contabil] TEXT(8) NOT NULL, [fabricante] TEXT(20) NOT NULL, [modelo] TEXT(20) NOT NULL, [tecnico] REAL NOT NULL, [tecnome] TEXT(40) NOT NULL, [obs01] TEXT(60) NOT NULL, [obs02] TEXT(60) NOT NULL, [obs03] TEXT(60) NOT NULL, [obs04] TEXT(60) NOT NULL, [obs05] TEXT(60) NOT NULL, [ro] REAL NOT NULL, [horas] REAL NOT NULL);

-- Tabela: lvmi
CREATE TABLE IF NOT EXISTS [lvmi] ([lvm] REAL NOT NULL, [item] REAL NOT NULL, [descri] TEXT(150) NOT NULL, [oper01] TEXT(1) NOT NULL, [oper02] TEXT(1) NOT NULL, [oper03] TEXT(1) NOT NULL);

-- Tabela: lvmp
CREATE TABLE IF NOT EXISTS [lvmp] ([item] REAL NOT NULL, [descri] TEXT(200) NOT NULL, [grupo] TEXT(3) NOT NULL);

-- Tabela: mapu
CREATE TABLE IF NOT EXISTS [mapu] ([seq] REAL NOT NULL, [dini] SHORTDATE NOT NULL, [dfim] SHORTDATE NOT NULL, [apurado] BIT NOT NULL, [pcplib] BIT NOT NULL, [pcpnum] REAL NOT NULL, [pcpdat] SHORTDATE NOT NULL);

-- Tabela: mapubai
CREATE TABLE IF NOT EXISTS [mapubai] ([seq] REAL NOT NULL, [ferram] TEXT(4) NOT NULL, [qtde] REAL NOT NULL, [horas] REAL NOT NULL);

-- Tabela: mapui
CREATE TABLE IF NOT EXISTS [mapui] ([seq] REAL NOT NULL, [ferram] TEXT(4) NOT NULL, [qtde] REAL NOT NULL, [horas] REAL NOT NULL);

-- Tabela: me01cr
CREATE TABLE IF NOT EXISTS [me01cr] ([codigo] TEXT(4) NOT NULL, [nome] TEXT(40) NOT NULL, [programa] SHORTDATE NOT NULL, [efetuada] SHORTDATE NOT NULL, [lvm] REAL NOT NULL, [ano] REAL NOT NULL, [cano] TEXT(4) NOT NULL);

-- Tabela: rl
CREATE TABLE IF NOT EXISTS [rl] ([rl] REAL NOT NULL, [data] SHORTDATE NOT NULL);

-- Tabela: rli
CREATE TABLE IF NOT EXISTS [rli] ([rl] REAL NOT NULL, [codme01] TEXT(5) NOT NULL, [lub01] TEXT(1) NOT NULL, [lub02] TEXT(1) NOT NULL, [lub03] TEXT(1) NOT NULL, [lub04] TEXT(1) NOT NULL, [lub05] TEXT(1) NOT NULL);

-- Tabela: ro
CREATE TABLE IF NOT EXISTS [ro] ([ro] REAL NOT NULL, [area] TEXT(2) NOT NULL, [descri] TEXT(20) NOT NULL, [ferram] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [data] SHORTDATE NOT NULL, [tecnico] REAL NOT NULL, [tecnome] TEXT(40) NOT NULL, [hora] REAL NOT NULL, [tipo] TEXT(1) NOT NULL, [tiporo] TEXT(1) NOT NULL, [defeito] TEXT(80) NOT NULL, [defeit2] TEXT(40) NOT NULL, [defeit3] TEXT(40) NOT NULL, [solucao] TEXT(200) NOT NULL, [soluca2] TEXT(80) NOT NULL, [soluca3] TEXT(80) NOT NULL, [soluca4] TEXT(80) NOT NULL, [sm] REAL NOT NULL, [qtdesaldo] REAL NOT NULL, [qtdeped] REAL NOT NULL, [qtdeurg] REAL NOT NULL, [datasaldo] SHORTDATE NOT NULL, [dataped] SHORTDATE NOT NULL, [dataurg] SHORTDATE NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [concluida] BIT NOT NULL, [qtdetot] REAL NOT NULL, [hrbas] REAL NOT NULL, [hrtot] REAL NOT NULL, [hrpre] REAL NOT NULL, [hrurg] REAL NOT NULL, [hrsal] REAL NOT NULL, [dathped] SHORTDATE NOT NULL, [dathurg] SHORTDATE NOT NULL, [dathsal] SHORTDATE NOT NULL, [reqnum] REAL NOT NULL, [reqnome] TEXT(40) NOT NULL, [zero] REAL NOT NULL, [datapar] SHORTDATE NOT NULL, [horapar] REAL NOT NULL, [horaini] REAL NOT NULL, [horafim] REAL NOT NULL, [dataini] SHORTDATE NOT NULL, [datafim] SHORTDATE NOT NULL, [horapini] REAL NOT NULL, [diasant] REAL NOT NULL, [diaspai] REAL NOT NULL, [diasavo] REAL NOT NULL);

-- Tabela: roapud
CREATE TABLE IF NOT EXISTS [roapud] ([diaini] SHORTDATE NOT NULL, [diafim] SHORTDATE NOT NULL);

-- Tabela: roi
CREATE TABLE IF NOT EXISTS [roi] ([ro] REAL NOT NULL, [codigo] TEXT(20) NOT NULL, [qtde] REAL NOT NULL);

-- Tabela: sm
CREATE TABLE IF NOT EXISTS [sm] ([sm] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tipo] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [def01] TEXT(80) NOT NULL, [def02] TEXT(30) NOT NULL, [datapp] SHORTDATE NOT NULL, [prior] TEXT(1) NOT NULL, [ro] REAL NOT NULL, [concluida] BIT NOT NULL, [reqnum] REAL NOT NULL, [reqnome] TEXT(40) NOT NULL, [horapini] REAL NOT NULL, [datapar] SHORTDATE NOT NULL);

-- �ndice: idx_cs_cs
CREATE INDEX IF NOT EXISTS [idx_cs_cs] ON [cs] ([cs]);

-- �ndice: idx_fapu_fapu
CREATE INDEX IF NOT EXISTS [idx_fapu_fapu] ON [fapu] ([seq]);

-- �ndice: idx_fapubai_fapubai
CREATE INDEX IF NOT EXISTS [idx_fapubai_fapubai] ON [fapubai] ([seq], [ferram]);

-- �ndice: idx_fapufer_fapufer
CREATE INDEX IF NOT EXISTS [idx_fapufer_fapufer] ON [fapufer] ([seq], [ferram]);

-- �ndice: idx_fapufer_fapufer2
CREATE INDEX IF NOT EXISTS [idx_fapufer_fapufer2] ON [fapufer] ([ferram]);

-- �ndice: idx_fapui_fapui
CREATE INDEX IF NOT EXISTS [idx_fapui_fapui] ON [fapui] ([seq]);

-- �ndice: idx_fapumaq_fapumaq
CREATE INDEX IF NOT EXISTS [idx_fapumaq_fapumaq] ON [fapumaq] ([seq], [ferram]);

-- �ndice: idx_fapumaq_fapumaq2
CREATE INDEX IF NOT EXISTS [idx_fapumaq_fapumaq2] ON [fapumaq] ([ferram]);

-- �ndice: idx_fe02_fe02-1
CREATE INDEX IF NOT EXISTS [idx_fe02_fe02-1] ON [fe02] ([tipo], [codigo], [ano], [mes]);

-- �ndice: idx_fe99_fe99-1
CREATE INDEX IF NOT EXISTS [idx_fe99_fe99-1] ON [fe99] ([arquivo], [documento]);

-- �ndice: idx_fe99_fe99-2
CREATE INDEX IF NOT EXISTS [idx_fe99_fe99-2] ON [fe99] ([codigo], [data]);

-- �ndice: idx_fergi_fergi
CREATE INDEX IF NOT EXISTS [idx_fergi_fergi] ON [fergi] ([ferram]);

-- �ndice: idx_fergi_fergi-2
CREATE INDEX IF NOT EXISTS [idx_fergi_fergi-2] ON [fergi] ([ferram], [codigo]);

-- �ndice: idx_fergrp_fergrp
CREATE INDEX IF NOT EXISTS [idx_fergrp_fergrp] ON [fergrp] ([grupo]);

-- �ndice: idx_ferhg_codferr
CREATE INDEX IF NOT EXISTS [idx_ferhg_codferr] ON [ferhg] ([codferr]);

-- �ndice: idx_ferhg_os
CREATE INDEX IF NOT EXISTS [idx_ferhg_os] ON [ferhg] ([os]);

-- �ndice: idx_ferhgi_os
CREATE INDEX IF NOT EXISTS [idx_ferhgi_os] ON [ferhgi] ([os]);

-- �ndice: idx_fernf_fernf
CREATE INDEX IF NOT EXISTS [idx_fernf_fernf] ON [fernf] ([ferram], [nrnota]);

-- �ndice: idx_fernf_fernf-2
CREATE INDEX IF NOT EXISTS [idx_fernf_fernf-2] ON [fernf] ([ferram]);

-- �ndice: idx_feros_feros-1
CREATE INDEX IF NOT EXISTS [idx_feros_feros-1] ON [feros] ([chave]);

-- �ndice: idx_feros_feros-2
CREATE INDEX IF NOT EXISTS [idx_feros_feros-2] ON [feros] ([ferram]);

-- �ndice: idx_feros_feros-3
CREATE INDEX IF NOT EXISTS [idx_feros_feros-3] ON [feros] ([cliente], [ferram]);

-- �ndice: idx_feros_feros-4
CREATE INDEX IF NOT EXISTS [idx_feros_feros-4] ON [feros] ([pedidocli]);

-- �ndice: idx_ferram_ferram
CREATE INDEX IF NOT EXISTS [idx_ferram_ferram] ON [ferram] ([ferram]);

-- �ndice: idx_ferram_ferram2
CREATE INDEX IF NOT EXISTS [idx_ferram_ferram2] ON [ferram] ([grupo]);

-- �ndice: idx_ferram_ferram3
CREATE INDEX IF NOT EXISTS [idx_ferram_ferram3] ON [ferram] ([numero]);

-- �ndice: idx_lvf_lvf
CREATE INDEX IF NOT EXISTS [idx_lvf_lvf] ON [lvf] ([lvf]);

-- �ndice: idx_lvfi_lvfi
CREATE INDEX IF NOT EXISTS [idx_lvfi_lvfi] ON [lvfi] ([lvf]);

-- �ndice: idx_lvfp_lvfp
CREATE INDEX IF NOT EXISTS [idx_lvfp_lvfp] ON [lvfp] ([item]);

-- �ndice: idx_lvm_lvm
CREATE INDEX IF NOT EXISTS [idx_lvm_lvm] ON [lvm] ([lvm]);

-- �ndice: idx_lvmi_lvmi
CREATE INDEX IF NOT EXISTS [idx_lvmi_lvmi] ON [lvmi] ([lvm]);

-- �ndice: idx_lvmp_lvmp
CREATE INDEX IF NOT EXISTS [idx_lvmp_lvmp] ON [lvmp] ([item], [grupo]);

-- �ndice: idx_mapu_mapu
CREATE INDEX IF NOT EXISTS [idx_mapu_mapu] ON [mapu] ([seq]);

-- �ndice: idx_mapubai_mapubai
CREATE INDEX IF NOT EXISTS [idx_mapubai_mapubai] ON [mapubai] ([seq], [ferram]);

-- �ndice: idx_mapui_mupui
CREATE INDEX IF NOT EXISTS [idx_mapui_mupui] ON [mapui] ([seq]);

-- �ndice: idx_me01cr_me01cr
CREATE INDEX IF NOT EXISTS [idx_me01cr_me01cr] ON [me01cr] ([codigo], [programa]);

-- �ndice: idx_rl_rl
CREATE INDEX IF NOT EXISTS [idx_rl_rl] ON [rl] ([rl]);

-- �ndice: idx_rli_rl
CREATE INDEX IF NOT EXISTS [idx_rli_rl] ON [rli] ([rl]);

-- �ndice: idx_ro_ro
CREATE INDEX IF NOT EXISTS [idx_ro_ro] ON [ro] ([ro]);

-- �ndice: idx_ro_ro-2
CREATE INDEX IF NOT EXISTS [idx_ro_ro-2] ON [ro] ([sm]);

-- �ndice: idx_ro_ro-3
CREATE INDEX IF NOT EXISTS [idx_ro_ro-3] ON [ro] ([tipo], [ferram], [data]);

-- �ndice: idx_ro_ro-4
CREATE INDEX IF NOT EXISTS [idx_ro_ro-4] ON [ro] ([tipo], [ferram], [dataini]);

-- �ndice: idx_ro_ro-5
CREATE INDEX IF NOT EXISTS [idx_ro_ro-5] ON [ro] ([tipo], [ferram], [datafim]);

-- �ndice: idx_roi_roi
CREATE INDEX IF NOT EXISTS [idx_roi_roi] ON [roi] ([ro]);

-- �ndice: idx_sm
CREATE INDEX IF NOT EXISTS [idx_sm] ON [sm] ([sm]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
