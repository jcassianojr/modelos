--
-- Arquivo gerado com SQLiteStudio v3.4.4 em sex ago 2 16:51:48 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: bti
CREATE TABLE IF NOT EXISTS [bti] ([bti] REAL NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(50) NOT NULL, [duns] TEXT(20) NOT NULL, [rfq] TEXT(20) NOT NULL, [data] SHORTDATE NOT NULL);

-- Tabela: btii
CREATE TABLE IF NOT EXISTS [btii] ([bti] REAL NOT NULL, [qtde] REAL NOT NULL, [descricao] TEXT(80) NOT NULL, [cavidade] REAL NOT NULL, [preco] REAL NOT NULL, [ciclo] TEXT(20) NOT NULL, [capacida] TEXT(20) NOT NULL);

-- Tabela: cd
CREATE TABLE IF NOT EXISTS [cd] ([cd] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [chave] TEXT(9) NOT NULL, [data] SHORTDATE NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [clicogn] TEXT(15) NOT NULL, [comprador] TEXT(5) NOT NULL, [compnome] TEXT(40) NOT NULL, [peca] TEXT(24) NOT NULL, [projeto] TEXT(50) NOT NULL, [nome] TEXT(100) NOT NULL, [engenha] TEXT(50) NOT NULL, [planta] TEXT(50) NOT NULL, [dataaut] SHORTDATE NOT NULL, [pt] BIT NOT NULL, [ptqt] REAL NOT NULL, [fd] BIT NOT NULL, [dc] BIT NOT NULL, [pcmp] BIT NOT NULL, [pcmo] BIT NOT NULL, [mp] BIT NOT NULL, [out] BIT NOT NULL, [outobs] TEXT(80) NOT NULL, [obs01] TEXT(80) NOT NULL, [obs02] TEXT(80) NOT NULL, [obs03] TEXT(80) NOT NULL, [obs04] TEXT(80) NOT NULL, [obs05] TEXT(80) NOT NULL, [datadim] TEXT(80) NOT NULL, [datapro] TEXT(80) NOT NULL, [ep] BIT NOT NULL, [mm] BIT NOT NULL, [nt] BIT NOT NULL, [fe] BIT NOT NULL, [de] BIT NOT NULL, [amo] BIT NOT NULL, [outanx] BIT NOT NULL, [outanxobs] TEXT(80) NOT NULL, [funnum] REAL NOT NULL, [funnom] TEXT(40) NOT NULL, [dataemi] SHORTDATE NOT NULL, [dataobs] SHORTDATE NOT NULL, [obsg01] TEXT(80) NOT NULL, [obsg02] TEXT(80) NOT NULL, [obsg03] TEXT(80) NOT NULL, [atual] BIT NOT NULL, [loteanual] REAL NOT NULL, [setor] TEXT(2) NOT NULL, [cargo] TEXT(40) NOT NULL, [respo] TEXT(40) NOT NULL, [codigoint] TEXT(24) NOT NULL, [loteentr] REAL NOT NULL, [ret] BIT NOT NULL, [valpec] REAL NOT NULL, [imposto] TEXT(1) NOT NULL, [cpagp] TEXT(50) NOT NULL, [cemb] TEXT(50) NOT NULL, [frete] TEXT(1) NOT NULL, [ferra] REAL NOT NULL, [impfer] TEXT(1) NOT NULL, [cpagf] TEXT(50) NOT NULL, [obsc01] TEXT(80) NOT NULL, [obsc02] TEXT(80) NOT NULL, [obsc03] TEXT(80) NOT NULL, [numpre] REAL NOT NULL, [nompre] TEXT(50) NOT NULL, [datapre] SHORTDATE NOT NULL, [viabili] REAL NOT NULL, [codcli] TEXT(15) NOT NULL);

-- Tabela: cdapuprd
CREATE TABLE IF NOT EXISTS [cdapuprd] ([cd] REAL NOT NULL, [ano] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [codigoint] TEXT(24) NOT NULL, [dataini] SHORTDATE NOT NULL, [datapro] SHORTDATE NOT NULL, [eac] REAL NOT NULL, [ativa] TEXT(1) NOT NULL, [mes01] REAL NOT NULL, [mes02] REAL NOT NULL, [mes03] REAL NOT NULL, [mes04] REAL NOT NULL, [mes05] REAL NOT NULL, [mes06] REAL NOT NULL, [mes07] REAL NOT NULL, [mes08] REAL NOT NULL, [mes09] REAL NOT NULL, [mes10] REAL NOT NULL, [mes11] REAL NOT NULL, [mes12] REAL NOT NULL, [prc01] REAL NOT NULL, [prc02] REAL NOT NULL, [prc03] REAL NOT NULL, [prc04] REAL NOT NULL, [prc05] REAL NOT NULL, [prc06] REAL NOT NULL, [prc07] REAL NOT NULL, [prc08] REAL NOT NULL, [prc09] REAL NOT NULL, [prc10] REAL NOT NULL, [prc11] REAL NOT NULL, [prc12] REAL NOT NULL, [mesesf] REAL NOT NULL, [mesesp] REAL NOT NULL, [preco] REAL NOT NULL, [cliente] REAL NOT NULL, [cogcli] TEXT(15) NOT NULL);

-- Tabela: cdi
CREATE TABLE IF NOT EXISTS [cdi] ([cd] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [chave] TEXT(9) NOT NULL, [desenho] TEXT(24) NOT NULL, [destem] BIT NOT NULL, [rev] TEXT(20) NOT NULL, [datarev] SHORTDATE NOT NULL);

-- Tabela: declmot
CREATE TABLE IF NOT EXISTS [declmot] ([numero] REAL NOT NULL, [nome] TEXT(40) NOT NULL);

-- Tabela: esc
CREATE TABLE IF NOT EXISTS [esc] ([cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(75) NOT NULL, [vcom] REAL NOT NULL, [vcomi] REAL NOT NULL, [vcoml] REAL NOT NULL, [vmat] REAL NOT NULL, [vmati] REAL NOT NULL, [vmatl] REAL NOT NULL, [vter] REAL NOT NULL, [vmaom] REAL NOT NULL, [vmaoo] REAL NOT NULL, [vrej] REAL NOT NULL, [vmar] REAL NOT NULL, [fmar] REAL NOT NULL, [puf] TEXT(2) NOT NULL, [pmak] REAL NOT NULL, [picm] REAL NOT NULL, [pmar] REAL NOT NULL, [lanu] REAL NOT NULL, [lmes] REAL NOT NULL, [lmin] REAL NOT NULL, [vfer] REAL NOT NULL, [vferhr] REAL NOT NULL, [vferid] REAL NOT NULL, [prazo] SHORTDATE NOT NULL, [pven] REAL NOT NULL, [pven2] REAL NOT NULL, [pref] REAL NOT NULL, [dluc] REAL NOT NULL, [dpre] REAL NOT NULL, [obs01] TEXT(80) NOT NULL, [obs02] TEXT(80) NOT NULL, [obs03] TEXT(80) NOT NULL, [obs04] TEXT(80) NOT NULL, [obs05] TEXT(80) NOT NULL, [obs06] TEXT(80) NOT NULL, [obs07] TEXT(80) NOT NULL, [obs08] TEXT(80) NOT NULL, [obc01] TEXT(80) NOT NULL, [obc02] TEXT(80) NOT NULL, [obc03] TEXT(80) NOT NULL, [obc04] TEXT(80) NOT NULL, [obc05] TEXT(80) NOT NULL, [obe01] TEXT(60) NOT NULL, [obe02] TEXT(60) NOT NULL, [obe03] TEXT(60) NOT NULL, [subtot01] REAL NOT NULL, [subtot02] REAL NOT NULL, [rev] TEXT(1) NOT NULL, [viabili] REAL NOT NULL, [duns] TEXT(5) NOT NULL, [projeto] TEXT(5) NOT NULL, [niveldat] SHORTDATE NOT NULL, [vigendat] SHORTDATE NOT NULL, [data] SHORTDATE NOT NULL, [usumedio] REAL NOT NULL, [elanum] REAL NOT NULL, [elanom] TEXT(40) NOT NULL, [eladat] SHORTDATE NOT NULL, [elahor] TEXT(8) NOT NULL, [pcprgmed] REAL NOT NULL, [tipoimp] TEXT(1) NOT NULL, [ppis] REAL NOT NULL, [pcon] REAL NOT NULL, [tipmedia] TEXT(1) NOT NULL, [pluc] REAL NOT NULL, [padm] REAL NOT NULL, [pcom] REAL NOT NULL, [pcpm] REAL NOT NULL, [licm] BIT NOT NULL, [prrj] REAL NOT NULL, [cappro] TEXT(5) NOT NULL, [ov] REAL NOT NULL, [datacalc] SHORTDATE NOT NULL, [ovori] REAL NOT NULL, [piscon] TEXT(1) NOT NULL, [vteri] REAL NOT NULL, [vterl] REAL NOT NULL, [obsp01] TEXT(60) NOT NULL, [obsp02] TEXT(60) NOT NULL, [ovrev] TEXT(1) NOT NULL, [vsimp] REAL NOT NULL);

-- Tabela: escms03
CREATE TABLE IF NOT EXISTS [escms03] ([ov] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [tipoent] TEXT(1) NOT NULL, [codcomp] TEXT(24) NOT NULL, [nomecomp] TEXT(120) NOT NULL, [origem] TEXT(20) NOT NULL, [qtdde] REAL NOT NULL, [preco] REAL NOT NULL, [total] REAL NOT NULL, [iicm] BIT NOT NULL, [redicm] REAL NOT NULL, [codfolha] REAL NOT NULL, [obs01] TEXT(80) NOT NULL, [ultdata] SHORTDATE NOT NULL, [ultund] TEXT(2) NOT NULL);

-- Tabela: escms06
CREATE TABLE IF NOT EXISTS [escms06] ([ov] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [descri] TEXT(70) NOT NULL, [codmp01] TEXT(12) NOT NULL, [nommp01] TEXT(30) NOT NULL, [codmp02] TEXT(12) NOT NULL, [nommp02] TEXT(30) NOT NULL, [codmp02b] TEXT(12) NOT NULL, [nommp02b] TEXT(30) NOT NULL, [codmp02c] TEXT(12) NOT NULL, [nommp02c] TEXT(30) NOT NULL, [codmp02d] TEXT(12) NOT NULL, [nommp02d] TEXT(30) NOT NULL, [codmp03] TEXT(24) NOT NULL, [nommp03] TEXT(30) NOT NULL, [pchora] REAL NOT NULL, [area] TEXT(2) NOT NULL, [hrfer] REAL NOT NULL, [codfolha] REAL NOT NULL, [preco] REAL NOT NULL, [qtdde] REAL NOT NULL, [total] REAL NOT NULL, [cogmp01] TEXT(10) NOT NULL, [pcmedia] REAL NOT NULL, [fluxo] REAL NOT NULL, [fator] REAL NOT NULL);

-- Tabela: esf
CREATE TABLE IF NOT EXISTS [esf] ([cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(75) NOT NULL, [vcom] REAL NOT NULL, [vcomi] REAL NOT NULL, [vcoml] REAL NOT NULL, [vmat] REAL NOT NULL, [vmati] REAL NOT NULL, [vmatl] REAL NOT NULL, [vter] REAL NOT NULL, [vmaom] REAL NOT NULL, [vmaoo] REAL NOT NULL, [vrej] REAL NOT NULL, [vmar] REAL NOT NULL, [fmar] REAL NOT NULL, [puf] TEXT(2) NOT NULL, [pmak] REAL NOT NULL, [picm] REAL NOT NULL, [pmar] REAL NOT NULL, [lanu] REAL NOT NULL, [lmes] REAL NOT NULL, [lmin] REAL NOT NULL, [vfer] REAL NOT NULL, [vferhr] REAL NOT NULL, [vferid] REAL NOT NULL, [prazo] SHORTDATE NOT NULL, [pven] REAL NOT NULL, [pven2] REAL NOT NULL, [pref] REAL NOT NULL, [dluc] REAL NOT NULL, [dpre] REAL NOT NULL, [obs01] TEXT(80) NOT NULL, [obs02] TEXT(80) NOT NULL, [obs03] TEXT(80) NOT NULL, [obs04] TEXT(80) NOT NULL, [obs05] TEXT(80) NOT NULL, [obs06] TEXT(80) NOT NULL, [obs07] TEXT(80) NOT NULL, [obs08] TEXT(80) NOT NULL, [obc01] TEXT(80) NOT NULL, [obc02] TEXT(80) NOT NULL, [obc03] TEXT(80) NOT NULL, [obc04] TEXT(80) NOT NULL, [obc05] TEXT(80) NOT NULL, [obe01] TEXT(60) NOT NULL, [obe02] TEXT(60) NOT NULL, [obe03] TEXT(60) NOT NULL, [subtot01] REAL NOT NULL, [subtot02] REAL NOT NULL, [rev] TEXT(1) NOT NULL, [viabili] REAL NOT NULL, [duns] TEXT(5) NOT NULL, [projeto] TEXT(5) NOT NULL, [niveldat] SHORTDATE NOT NULL, [vigendat] SHORTDATE NOT NULL, [data] SHORTDATE NOT NULL, [usumedio] REAL NOT NULL, [elanum] REAL NOT NULL, [elanom] TEXT(40) NOT NULL, [eladat] SHORTDATE NOT NULL, [elahor] TEXT(8) NOT NULL, [pcprgmed] REAL NOT NULL, [tipoimp] TEXT(1) NOT NULL, [ppis] REAL NOT NULL, [pcon] REAL NOT NULL, [tipmedia] TEXT(1) NOT NULL, [pluc] REAL NOT NULL, [padm] REAL NOT NULL, [pcom] REAL NOT NULL, [pcpm] REAL NOT NULL, [licm] BIT NOT NULL, [prrj] REAL NOT NULL, [cappro] TEXT(5) NOT NULL, [ov] REAL NOT NULL, [datacalc] SHORTDATE NOT NULL, [ovori] REAL NOT NULL, [piscon] TEXT(1) NOT NULL, [vteri] REAL NOT NULL, [vterl] REAL NOT NULL, [obsp01] TEXT(60) NOT NULL, [obsp02] TEXT(60) NOT NULL, [ovrev] TEXT(1) NOT NULL, [vsimp] REAL NOT NULL);

-- Tabela: esfms03
CREATE TABLE IF NOT EXISTS [esfms03] ([ov] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [tipoent] TEXT(1) NOT NULL, [codcomp] TEXT(24) NOT NULL, [nomecomp] TEXT(120) NOT NULL, [origem] TEXT(20) NOT NULL, [qtdde] REAL NOT NULL, [preco] REAL NOT NULL, [total] REAL NOT NULL, [iicm] BIT NOT NULL, [redicm] REAL NOT NULL, [codfolha] REAL NOT NULL, [obs01] TEXT(80) NOT NULL, [ultdata] SHORTDATE NOT NULL, [ultund] TEXT(2) NOT NULL);

-- Tabela: esfms06
CREATE TABLE IF NOT EXISTS [esfms06] ([ov] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [descri] TEXT(70) NOT NULL, [codmp01] TEXT(12) NOT NULL, [nommp01] TEXT(30) NOT NULL, [codmp02] TEXT(12) NOT NULL, [nommp02] TEXT(30) NOT NULL, [codmp02b] TEXT(12) NOT NULL, [nommp02b] TEXT(30) NOT NULL, [codmp02c] TEXT(12) NOT NULL, [nommp02c] TEXT(30) NOT NULL, [codmp02d] TEXT(12) NOT NULL, [nommp02d] TEXT(30) NOT NULL, [codmp03] TEXT(24) NOT NULL, [nommp03] TEXT(30) NOT NULL, [pchora] REAL NOT NULL, [area] TEXT(2) NOT NULL, [hrfer] REAL NOT NULL, [codfolha] REAL NOT NULL, [preco] REAL NOT NULL, [qtdde] REAL NOT NULL, [total] REAL NOT NULL, [cogmp01] TEXT(10) NOT NULL, [pcmedia] REAL NOT NULL, [fluxo] REAL NOT NULL, [fator] REAL NOT NULL);

-- Tabela: eso
CREATE TABLE IF NOT EXISTS [eso] ([cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(75) NOT NULL, [vcom] REAL NOT NULL, [vcomi] REAL NOT NULL, [vcoml] REAL NOT NULL, [vmat] REAL NOT NULL, [vmati] REAL NOT NULL, [vmatl] REAL NOT NULL, [vter] REAL NOT NULL, [vmaom] REAL NOT NULL, [vmaoo] REAL NOT NULL, [vrej] REAL NOT NULL, [vmar] REAL NOT NULL, [fmar] REAL NOT NULL, [puf] TEXT(2) NOT NULL, [pmak] REAL NOT NULL, [picm] REAL NOT NULL, [pmar] REAL NOT NULL, [lanu] REAL NOT NULL, [lmes] REAL NOT NULL, [lmin] REAL NOT NULL, [vfer] REAL NOT NULL, [vferhr] REAL NOT NULL, [vferid] REAL NOT NULL, [prazo] SHORTDATE NOT NULL, [pven] REAL NOT NULL, [pven2] REAL NOT NULL, [pref] REAL NOT NULL, [dluc] REAL NOT NULL, [dpre] REAL NOT NULL, [obs01] TEXT(80) NOT NULL, [obs02] TEXT(80) NOT NULL, [obs03] TEXT(80) NOT NULL, [obs04] TEXT(80) NOT NULL, [obs05] TEXT(80) NOT NULL, [obs06] TEXT(80) NOT NULL, [obs07] TEXT(80) NOT NULL, [obs08] TEXT(80) NOT NULL, [obc01] TEXT(80) NOT NULL, [obc02] TEXT(80) NOT NULL, [obc03] TEXT(80) NOT NULL, [obc04] TEXT(80) NOT NULL, [obc05] TEXT(80) NOT NULL, [obe01] TEXT(60) NOT NULL, [obe02] TEXT(60) NOT NULL, [obe03] TEXT(60) NOT NULL, [subtot01] REAL NOT NULL, [subtot02] REAL NOT NULL, [rev] TEXT(1) NOT NULL, [viabili] REAL NOT NULL, [duns] TEXT(5) NOT NULL, [projeto] TEXT(5) NOT NULL, [niveldat] SHORTDATE NOT NULL, [vigendat] SHORTDATE NOT NULL, [data] SHORTDATE NOT NULL, [usumedio] REAL NOT NULL, [elanum] REAL NOT NULL, [elanom] TEXT(40) NOT NULL, [eladat] SHORTDATE NOT NULL, [elahor] TEXT(8) NOT NULL, [pcprgmed] REAL NOT NULL, [tipoimp] TEXT(1) NOT NULL, [ppis] REAL NOT NULL, [pcon] REAL NOT NULL, [tipmedia] TEXT(1) NOT NULL, [pluc] REAL NOT NULL, [padm] REAL NOT NULL, [pcom] REAL NOT NULL, [pcpm] REAL NOT NULL, [licm] BIT NOT NULL, [prrj] REAL NOT NULL, [cappro] TEXT(5) NOT NULL, [ov] REAL NOT NULL, [datacalc] SHORTDATE NOT NULL, [ovori] REAL NOT NULL, [piscon] TEXT(1) NOT NULL, [vteri] REAL NOT NULL, [vterl] REAL NOT NULL, [obsp01] TEXT(60) NOT NULL, [obsp02] TEXT(60) NOT NULL, [ovrev] TEXT(1) NOT NULL, [vsimp] REAL NOT NULL);

-- Tabela: esoms03
CREATE TABLE IF NOT EXISTS [esoms03] ([ov] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [tipoent] TEXT(1) NOT NULL, [codcomp] TEXT(24) NOT NULL, [nomecomp] TEXT(120) NOT NULL, [origem] TEXT(20) NOT NULL, [qtdde] REAL NOT NULL, [preco] REAL NOT NULL, [total] REAL NOT NULL, [iicm] BIT NOT NULL, [redicm] REAL NOT NULL, [codfolha] REAL NOT NULL, [obs01] TEXT(80) NOT NULL, [ultdata] SHORTDATE NOT NULL, [ultund] TEXT(2) NOT NULL);

-- Tabela: esoms06
CREATE TABLE IF NOT EXISTS [esoms06] ([ov] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [descri] TEXT(70) NOT NULL, [codmp01] TEXT(12) NOT NULL, [nommp01] TEXT(30) NOT NULL, [codmp02] TEXT(12) NOT NULL, [nommp02] TEXT(30) NOT NULL, [codmp02b] TEXT(12) NOT NULL, [nommp02b] TEXT(30) NOT NULL, [codmp02c] TEXT(12) NOT NULL, [nommp02c] TEXT(30) NOT NULL, [codmp02d] TEXT(12) NOT NULL, [nommp02d] TEXT(30) NOT NULL, [codmp03] TEXT(24) NOT NULL, [nommp03] TEXT(30) NOT NULL, [pchora] REAL NOT NULL, [area] TEXT(2) NOT NULL, [hrfer] REAL NOT NULL, [codfolha] REAL NOT NULL, [preco] REAL NOT NULL, [qtdde] REAL NOT NULL, [total] REAL NOT NULL, [cogmp01] TEXT(10) NOT NULL, [pcmedia] REAL NOT NULL, [fluxo] REAL NOT NULL, [fator] REAL NOT NULL);

-- Tabela: esp
CREATE TABLE IF NOT EXISTS [esp] ([cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(75) NOT NULL, [vcom] REAL NOT NULL, [vcomi] REAL NOT NULL, [vcoml] REAL NOT NULL, [vmat] REAL NOT NULL, [vmati] REAL NOT NULL, [vmatl] REAL NOT NULL, [vter] REAL NOT NULL, [vmaom] REAL NOT NULL, [vmaoo] REAL NOT NULL, [vrej] REAL NOT NULL, [vmar] REAL NOT NULL, [fmar] REAL NOT NULL, [puf] TEXT(2) NOT NULL, [pmak] REAL NOT NULL, [picm] REAL NOT NULL, [pmar] REAL NOT NULL, [lanu] REAL NOT NULL, [lmes] REAL NOT NULL, [lmin] REAL NOT NULL, [vfer] REAL NOT NULL, [vferhr] REAL NOT NULL, [vferid] REAL NOT NULL, [prazo] SHORTDATE NOT NULL, [pven] REAL NOT NULL, [pven2] REAL NOT NULL, [pref] REAL NOT NULL, [dluc] REAL NOT NULL, [dpre] REAL NOT NULL, [obs01] TEXT(80) NOT NULL, [obs02] TEXT(80) NOT NULL, [obs03] TEXT(80) NOT NULL, [obs04] TEXT(80) NOT NULL, [obs05] TEXT(80) NOT NULL, [obs06] TEXT(80) NOT NULL, [obs07] TEXT(80) NOT NULL, [obs08] TEXT(80) NOT NULL, [obc01] TEXT(80) NOT NULL, [obc02] TEXT(80) NOT NULL, [obc03] TEXT(80) NOT NULL, [obc04] TEXT(80) NOT NULL, [obc05] TEXT(80) NOT NULL, [obe01] TEXT(60) NOT NULL, [obe02] TEXT(60) NOT NULL, [obe03] TEXT(60) NOT NULL, [subtot01] REAL NOT NULL, [subtot02] REAL NOT NULL, [rev] TEXT(1) NOT NULL, [viabili] REAL NOT NULL, [duns] TEXT(5) NOT NULL, [projeto] TEXT(5) NOT NULL, [niveldat] SHORTDATE NOT NULL, [vigendat] SHORTDATE NOT NULL, [data] SHORTDATE NOT NULL, [usumedio] REAL NOT NULL, [elanum] REAL NOT NULL, [elanom] TEXT(40) NOT NULL, [eladat] SHORTDATE NOT NULL, [elahor] TEXT(8) NOT NULL, [pcprgmed] REAL NOT NULL, [tipoimp] TEXT(1) NOT NULL, [ppis] REAL NOT NULL, [pcon] REAL NOT NULL, [tipmedia] TEXT(1) NOT NULL, [pluc] REAL NOT NULL, [padm] REAL NOT NULL, [pcom] REAL NOT NULL, [pcpm] REAL NOT NULL, [licm] BIT NOT NULL, [prrj] REAL NOT NULL, [cappro] TEXT(5) NOT NULL, [ov] REAL NOT NULL, [datacalc] SHORTDATE NOT NULL, [ovori] REAL NOT NULL, [piscon] TEXT(1) NOT NULL, [vteri] REAL NOT NULL, [vterl] REAL NOT NULL, [obsp01] TEXT(60) NOT NULL, [obsp02] TEXT(60) NOT NULL, [ovrev] TEXT(1) NOT NULL, [vsimp] REAL NOT NULL);

-- Tabela: espms03
CREATE TABLE IF NOT EXISTS [espms03] ([ov] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [tipoent] TEXT(1) NOT NULL, [codcomp] TEXT(24) NOT NULL, [nomecomp] TEXT(120) NOT NULL, [origem] TEXT(20) NOT NULL, [qtdde] REAL NOT NULL, [preco] REAL NOT NULL, [total] REAL NOT NULL, [iicm] BIT NOT NULL, [redicm] REAL NOT NULL, [codfolha] REAL NOT NULL, [obs01] TEXT(80) NOT NULL, [ultdata] SHORTDATE NOT NULL, [ultund] TEXT(2) NOT NULL);

-- Tabela: espms06
CREATE TABLE IF NOT EXISTS [espms06] ([ov] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [descri] TEXT(70) NOT NULL, [codmp01] TEXT(12) NOT NULL, [nommp01] TEXT(30) NOT NULL, [codmp02] TEXT(12) NOT NULL, [nommp02] TEXT(30) NOT NULL, [codmp02b] TEXT(12) NOT NULL, [nommp02b] TEXT(30) NOT NULL, [codmp02c] TEXT(12) NOT NULL, [nommp02c] TEXT(30) NOT NULL, [codmp02d] TEXT(12) NOT NULL, [nommp02d] TEXT(30) NOT NULL, [codmp03] TEXT(24) NOT NULL, [nommp03] TEXT(30) NOT NULL, [pchora] REAL NOT NULL, [area] TEXT(2) NOT NULL, [hrfer] REAL NOT NULL, [codfolha] REAL NOT NULL, [preco] REAL NOT NULL, [qtdde] REAL NOT NULL, [total] REAL NOT NULL, [cogmp01] TEXT(10) NOT NULL, [pcmedia] REAL NOT NULL, [fluxo] REAL NOT NULL, [fator] REAL NOT NULL);

-- Tabela: fluxo
CREATE TABLE IF NOT EXISTS [fluxo] ([codigo] TEXT(1) NOT NULL, [nome] TEXT(50) NOT NULL, [numero] REAL NOT NULL);

-- Tabela: np
CREATE TABLE IF NOT EXISTS [np] ([np] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(40) NOT NULL, [veiculo] TEXT(20) NOT NULL, [prsicm] REAL NOT NULL, [prcicm] REAL NOT NULL, [vlfer] REAL NOT NULL, [prazo] SHORTDATE NOT NULL, [qtdmes] REAL NOT NULL, [comprador] TEXT(5) NOT NULL, [compnome] TEXT(40) NOT NULL, [desanual] REAL NOT NULL, [os] TEXT(20) NOT NULL, [ano] REAL NOT NULL, [pendente] BIT NOT NULL);

-- Tabela: orca
CREATE TABLE IF NOT EXISTS [orca] ([orca] REAL NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [ac] TEXT(40) NOT NULL, [refer] TEXT(20) NOT NULL, [data] SHORTDATE NOT NULL, [orc] TEXT(40) NOT NULL, [orc01] TEXT(100) NOT NULL, [orc02] TEXT(100) NOT NULL, [prazo] TEXT(150) NOT NULL, [praz2] TEXT(150) NOT NULL, [praz3] TEXT(150) NOT NULL, [praz4] TEXT(150) NOT NULL, [cpag] TEXT(50) NOT NULL, [cfer] TEXT(100) NOT NULL, [cval] TEXT(20) NOT NULL, [obs01] TEXT(200) NOT NULL, [obs02] TEXT(200) NOT NULL, [obs03] TEXT(200) NOT NULL, [obs04] TEXT(200) NOT NULL, [obs05] TEXT(200) NOT NULL, [obs06] TEXT(200) NOT NULL, [obs07] TEXT(200) NOT NULL, [obs08] TEXT(200) NOT NULL, [setor] TEXT(2) NOT NULL, [cargo] TEXT(40) NOT NULL, [respo] TEXT(40) NOT NULL, [nivel] SHORTDATE NOT NULL, [cambio] TEXT(15) NOT NULL, [revi] TEXT(1) NOT NULL);

-- Tabela: orcai
CREATE TABLE IF NOT EXISTS [orcai] ([orca] REAL NOT NULL, [ord] REAL NOT NULL, [qtdde] REAL NOT NULL, [unid] TEXT(2) NOT NULL, [descr] TEXT(100) NOT NULL, [unipec] TEXT(2) NOT NULL, [valpec] REAL NOT NULL, [ferra] REAL NOT NULL, [lotemin] REAL NOT NULL, [viabili] REAL NOT NULL, [obsitem] TEXT(80) NOT NULL, [obsite2] TEXT(80) NOT NULL, [obsite3] TEXT(80) NOT NULL, [obsite4] TEXT(80) NOT NULL, [obsite5] TEXT(80) NOT NULL, [desenho] TEXT(20) NOT NULL, [rev] TEXT(20) NOT NULL, [datarev] TEXT(10) NOT NULL);

-- Tabela: vfms03
CREATE TABLE IF NOT EXISTS [vfms03] ([ov] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [tipoent] TEXT(1) NOT NULL, [codcomp] TEXT(24) NOT NULL, [nomecomp] TEXT(120) NOT NULL, [origem] TEXT(20) NOT NULL, [qtdde] REAL NOT NULL, [preco] REAL NOT NULL, [total] REAL NOT NULL, [iicm] BIT NOT NULL, [redicm] REAL NOT NULL, [codfolha] REAL NOT NULL, [obs01] TEXT(80) NOT NULL, [ultdata] SHORTDATE NOT NULL, [ultund] TEXT(2) NOT NULL);

-- Tabela: vfms06
CREATE TABLE IF NOT EXISTS [vfms06] ([ov] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [descri] TEXT(70) NOT NULL, [codmp01] TEXT(12) NOT NULL, [nommp01] TEXT(30) NOT NULL, [codmp02] TEXT(12) NOT NULL, [nommp02] TEXT(30) NOT NULL, [codmp02b] TEXT(12) NOT NULL, [nommp02b] TEXT(30) NOT NULL, [codmp02c] TEXT(12) NOT NULL, [nommp02c] TEXT(30) NOT NULL, [codmp02d] TEXT(12) NOT NULL, [nommp02d] TEXT(30) NOT NULL, [codmp03] TEXT(24) NOT NULL, [nommp03] TEXT(30) NOT NULL, [pchora] REAL NOT NULL, [area] TEXT(2) NOT NULL, [hrfer] REAL NOT NULL, [codfolha] REAL NOT NULL, [preco] REAL NOT NULL, [qtdde] REAL NOT NULL, [total] REAL NOT NULL, [cogmp01] TEXT(10) NOT NULL, [pcmedia] REAL NOT NULL, [fluxo] REAL NOT NULL, [fator] REAL NOT NULL);

-- Tabela: vforc
CREATE TABLE IF NOT EXISTS [vforc] ([cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(75) NOT NULL, [vcom] REAL NOT NULL, [vcomi] REAL NOT NULL, [vcoml] REAL NOT NULL, [vmat] REAL NOT NULL, [vmati] REAL NOT NULL, [vmatl] REAL NOT NULL, [vter] REAL NOT NULL, [vmaom] REAL NOT NULL, [vmaoo] REAL NOT NULL, [vrej] REAL NOT NULL, [vmar] REAL NOT NULL, [fmar] REAL NOT NULL, [puf] TEXT(2) NOT NULL, [pmak] REAL NOT NULL, [picm] REAL NOT NULL, [pmar] REAL NOT NULL, [lanu] REAL NOT NULL, [lmes] REAL NOT NULL, [lmin] REAL NOT NULL, [vfer] REAL NOT NULL, [vferhr] REAL NOT NULL, [vferid] REAL NOT NULL, [prazo] SHORTDATE NOT NULL, [pven] REAL NOT NULL, [pven2] REAL NOT NULL, [pref] REAL NOT NULL, [dluc] REAL NOT NULL, [dpre] REAL NOT NULL, [obs01] TEXT(80) NOT NULL, [obs02] TEXT(80) NOT NULL, [obs03] TEXT(80) NOT NULL, [obs04] TEXT(80) NOT NULL, [obs05] TEXT(80) NOT NULL, [obs06] TEXT(80) NOT NULL, [obs07] TEXT(80) NOT NULL, [obs08] TEXT(80) NOT NULL, [obc01] TEXT(80) NOT NULL, [obc02] TEXT(80) NOT NULL, [obc03] TEXT(80) NOT NULL, [obc04] TEXT(80) NOT NULL, [obc05] TEXT(80) NOT NULL, [obe01] TEXT(60) NOT NULL, [obe02] TEXT(60) NOT NULL, [obe03] TEXT(60) NOT NULL, [subtot01] REAL NOT NULL, [subtot02] REAL NOT NULL, [rev] TEXT(1) NOT NULL, [viabili] REAL NOT NULL, [duns] TEXT(5) NOT NULL, [projeto] TEXT(5) NOT NULL, [niveldat] SHORTDATE NOT NULL, [vigendat] SHORTDATE NOT NULL, [data] SHORTDATE NOT NULL, [usumedio] REAL NOT NULL, [elanum] REAL NOT NULL, [elanom] TEXT(40) NOT NULL, [eladat] SHORTDATE NOT NULL, [elahor] TEXT(8) NOT NULL, [pcprgmed] REAL NOT NULL, [tipoimp] TEXT(1) NOT NULL, [ppis] REAL NOT NULL, [pcon] REAL NOT NULL, [tipmedia] TEXT(1) NOT NULL, [pluc] REAL NOT NULL, [padm] REAL NOT NULL, [pcom] REAL NOT NULL, [pcpm] REAL NOT NULL, [licm] BIT NOT NULL, [prrj] REAL NOT NULL, [cappro] TEXT(5) NOT NULL, [ov] REAL NOT NULL, [datacalc] SHORTDATE NOT NULL, [ovori] REAL NOT NULL, [piscon] TEXT(1) NOT NULL, [vteri] REAL NOT NULL, [vterl] REAL NOT NULL, [obsp01] TEXT(60) NOT NULL, [obsp02] TEXT(60) NOT NULL, [ovrev] TEXT(1) NOT NULL, [vsimp] REAL NOT NULL);

-- Tabela: viabiii
CREATE TABLE IF NOT EXISTS [viabiii] ([ov] REAL NOT NULL, [item] REAL NOT NULL, [tipo] TEXT(1) NOT NULL, [rev] TEXT(10) NOT NULL, [situacao] TEXT(1) NOT NULL, [situser] TEXT(10) NOT NULL, [sitdata] SHORTDATE NOT NULL, [sithora] TEXT(10) NOT NULL, [preco] REAL NOT NULL, [precodt] SHORTDATE NOT NULL, [precoun] TEXT(2) NOT NULL, [clifor] REAL NOT NULL, [clicog] TEXT(12) NOT NULL, [aprovacao] TEXT(1) NOT NULL, [apruser] TEXT(10) NOT NULL, [aprdata] SHORTDATE NOT NULL, [aprtime] TEXT(10) NOT NULL, [cotusr] TEXT(10) NOT NULL, [cotdata] SHORTDATE NOT NULL, [cottime] TEXT(10) NOT NULL, [datalc] SHORTDATE NOT NULL, [prazoi] SHORTDATE NOT NULL, [dado] TEXT(2147483647) NOT NULL, [sitobs] TEXT(2147483647) NOT NULL, [aprobs] TEXT(2147483647) NOT NULL);

-- Tabela: viabili
CREATE TABLE IF NOT EXISTS [viabili] ([ov] REAL NOT NULL, [ovori] REAL NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [clicogn] TEXT(12) NOT NULL, [comcomp] TEXT(40) NOT NULL, [comprador] TEXT(5) NOT NULL, [desenho] TEXT(20) NOT NULL, [peca] TEXT(20) NOT NULL, [gps] TEXT(20) NOT NULL, [denomina] TEXT(100) NOT NULL, [normat] TEXT(10) NOT NULL, [am] TEXT(1) NOT NULL, [qtdeano] REAL NOT NULL, [lotemin] REAL NOT NULL, [pr] TEXT(1) NOT NULL, [datas] SHORTDATE NOT NULL, [cotar] TEXT(1) NOT NULL, [datav] SHORTDATE NOT NULL, [dataec] SHORTDATE NOT NULL, [situacao] TEXT(1) NOT NULL, [eac] TEXT(35) NOT NULL, [viavel] TEXT(1) NOT NULL, [via01] TEXT(50) NOT NULL, [via02] TEXT(50) NOT NULL, [fesp] TEXT(1) NOT NULL, [obsf01] TEXT(50) NOT NULL, [obsf02] TEXT(50) NOT NULL, [matm] TEXT(1) NOT NULL, [mats] TEXT(1) NOT NULL, [obsm01] TEXT(50) NOT NULL, [tratm] TEXT(1) NOT NULL, [trats] TEXT(1) NOT NULL, [obst01] TEXT(50) NOT NULL, [obst02] TEXT(50) NOT NULL, [dispe] TEXT(1) NOT NULL, [obse01] TEXT(50) NOT NULL, [obse02] TEXT(50) NOT NULL, [dispo] TEXT(1) NOT NULL, [obso01] TEXT(50) NOT NULL, [obsg01] TEXT(80) NOT NULL, [obsg02] TEXT(80) NOT NULL, [obsg03] TEXT(80) NOT NULL, [obsg04] TEXT(80) NOT NULL, [obsg05] TEXT(80) NOT NULL, [obsg06] TEXT(80) NOT NULL, [obsg07] TEXT(80) NOT NULL, [obsg08] TEXT(80) NOT NULL, [cot01] BIT NOT NULL, [cot02] BIT NOT NULL, [cot03] BIT NOT NULL, [cot04] BIT NOT NULL, [cot05] BIT NOT NULL, [cot06] BIT NOT NULL, [cot07] BIT NOT NULL, [reqc] TEXT(1) NOT NULL, [req01] TEXT(50) NOT NULL, [pedcli] TEXT(20) NOT NULL, [przcli] SHORTDATE NOT NULL, [datapre] SHORTDATE NOT NULL, [obsven] TEXT(100) NOT NULL, [valorfer] REAL NOT NULL, [valoruni] REAL NOT NULL, [qtdeneg] REAL NOT NULL, [orcamento] REAL NOT NULL, [item] REAL NOT NULL, [fvalorfer] REAL NOT NULL, [fvaloruni] REAL NOT NULL, [fdata] SHORTDATE NOT NULL, [incuser] TEXT(10) NOT NULL, [incdata] SHORTDATE NOT NULL, [inchora] TEXT(10) NOT NULL, [esp] REAL NOT NULL, [obscus01] TEXT(100) NOT NULL, [obscus02] TEXT(100) NOT NULL, [obscus03] TEXT(100) NOT NULL, [rfqn] TEXT(15) NOT NULL, [duns] TEXT(30) NOT NULL, [projeto] TEXT(20) NOT NULL, [risco] TEXT(1) NOT NULL, [obsr01] TEXT(50) NOT NULL, [tipovia] TEXT(1) NOT NULL, [codigoint] TEXT(24) NOT NULL, [rev] TEXT(1) NOT NULL, [obscli] TEXT(50) NOT NULL, [desorc] TEXT(24) NOT NULL, [desorcrev] TEXT(20) NOT NULL, [desorcdat] SHORTDATE NOT NULL, [cancelado] BIT NOT NULL, [envelope] TEXT(5) NOT NULL, [declinado] BIT NOT NULL, [followup] BIT NOT NULL, [gi] TEXT(1) NOT NULL, [segmento] TEXT(2) NOT NULL, [declmot] REAL NOT NULL, [vendedor] TEXT(5) NOT NULL, [comvend] TEXT(40) NOT NULL);

-- Tabela: viarev
CREATE TABLE IF NOT EXISTS [viarev] ([ov] REAL NOT NULL, [opr] TEXT(1) NOT NULL, [rev] TEXT(1) NOT NULL, [data] SHORTDATE NOT NULL, [hora] TEXT(8) NOT NULL, [usuario] TEXT(10) NOT NULL, [motivo] TEXT(255) NOT NULL);

-- Tabela: vmark
CREATE TABLE IF NOT EXISTS [vmark] ([seq] REAL NOT NULL, [descri] TEXT(12) NOT NULL, [perce] REAL NOT NULL);

-- Tabela: vms03
CREATE TABLE IF NOT EXISTS [vms03] ([ov] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [tipoent] TEXT(1) NOT NULL, [codcomp] TEXT(24) NOT NULL, [nomecomp] TEXT(120) NOT NULL, [origem] TEXT(20) NOT NULL, [qtdde] REAL NOT NULL, [preco] REAL NOT NULL, [total] REAL NOT NULL, [iicm] BIT NOT NULL, [redicm] REAL NOT NULL, [codfolha] REAL NOT NULL, [obs01] TEXT(80) NOT NULL, [ultdata] SHORTDATE NOT NULL, [ultund] TEXT(2) NOT NULL);

-- Tabela: vms06
CREATE TABLE IF NOT EXISTS [vms06] ([ov] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [seq] REAL NOT NULL, [ssq] REAL NOT NULL, [descri] TEXT(70) NOT NULL, [codmp01] TEXT(12) NOT NULL, [nommp01] TEXT(30) NOT NULL, [codmp02] TEXT(12) NOT NULL, [nommp02] TEXT(30) NOT NULL, [codmp02b] TEXT(12) NOT NULL, [nommp02b] TEXT(30) NOT NULL, [codmp02c] TEXT(12) NOT NULL, [nommp02c] TEXT(30) NOT NULL, [codmp02d] TEXT(12) NOT NULL, [nommp02d] TEXT(30) NOT NULL, [codmp03] TEXT(24) NOT NULL, [nommp03] TEXT(30) NOT NULL, [pchora] REAL NOT NULL, [area] TEXT(2) NOT NULL, [hrfer] REAL NOT NULL, [codfolha] REAL NOT NULL, [preco] REAL NOT NULL, [qtdde] REAL NOT NULL, [total] REAL NOT NULL, [cogmp01] TEXT(10) NOT NULL, [pcmedia] REAL NOT NULL, [fluxo] REAL NOT NULL, [fator] REAL NOT NULL);

-- Tabela: vporc
CREATE TABLE IF NOT EXISTS [vporc] ([cliente] REAL NOT NULL, [cogcli] TEXT(12) NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(75) NOT NULL, [vcom] REAL NOT NULL, [vcomi] REAL NOT NULL, [vcoml] REAL NOT NULL, [vmat] REAL NOT NULL, [vmati] REAL NOT NULL, [vmatl] REAL NOT NULL, [vter] REAL NOT NULL, [vmaom] REAL NOT NULL, [vmaoo] REAL NOT NULL, [vrej] REAL NOT NULL, [vmar] REAL NOT NULL, [fmar] REAL NOT NULL, [puf] TEXT(2) NOT NULL, [pmak] REAL NOT NULL, [picm] REAL NOT NULL, [pmar] REAL NOT NULL, [lanu] REAL NOT NULL, [lmes] REAL NOT NULL, [lmin] REAL NOT NULL, [vfer] REAL NOT NULL, [vferhr] REAL NOT NULL, [vferid] REAL NOT NULL, [prazo] SHORTDATE NOT NULL, [pven] REAL NOT NULL, [pven2] REAL NOT NULL, [pref] REAL NOT NULL, [dluc] REAL NOT NULL, [dpre] REAL NOT NULL, [obs01] TEXT(80) NOT NULL, [obs02] TEXT(80) NOT NULL, [obs03] TEXT(80) NOT NULL, [obs04] TEXT(80) NOT NULL, [obs05] TEXT(80) NOT NULL, [obs06] TEXT(80) NOT NULL, [obs07] TEXT(80) NOT NULL, [obs08] TEXT(80) NOT NULL, [obc01] TEXT(80) NOT NULL, [obc02] TEXT(80) NOT NULL, [obc03] TEXT(80) NOT NULL, [obc04] TEXT(80) NOT NULL, [obc05] TEXT(80) NOT NULL, [obe01] TEXT(60) NOT NULL, [obe02] TEXT(60) NOT NULL, [obe03] TEXT(60) NOT NULL, [subtot01] REAL NOT NULL, [subtot02] REAL NOT NULL, [rev] TEXT(1) NOT NULL, [viabili] REAL NOT NULL, [duns] TEXT(5) NOT NULL, [projeto] TEXT(5) NOT NULL, [niveldat] SHORTDATE NOT NULL, [vigendat] SHORTDATE NOT NULL, [data] SHORTDATE NOT NULL, [usumedio] REAL NOT NULL, [elanum] REAL NOT NULL, [elanom] TEXT(40) NOT NULL, [eladat] SHORTDATE NOT NULL, [elahor] TEXT(8) NOT NULL, [pcprgmed] REAL NOT NULL, [tipoimp] TEXT(1) NOT NULL, [ppis] REAL NOT NULL, [pcon] REAL NOT NULL, [tipmedia] TEXT(1) NOT NULL, [pluc] REAL NOT NULL, [padm] REAL NOT NULL, [pcom] REAL NOT NULL, [pcpm] REAL NOT NULL, [licm] BIT NOT NULL, [prrj] REAL NOT NULL, [cappro] TEXT(5) NOT NULL, [ov] REAL NOT NULL, [datacalc] SHORTDATE NOT NULL, [ovori] REAL NOT NULL, [piscon] TEXT(1) NOT NULL, [vteri] REAL NOT NULL, [vterl] REAL NOT NULL, [obsp01] TEXT(60) NOT NULL, [obsp02] TEXT(60) NOT NULL, [ovrev] TEXT(1) NOT NULL, [vsimp] REAL NOT NULL);

-- �ndice: idx_bti_bti
CREATE INDEX IF NOT EXISTS [idx_bti_bti] ON [bti] ([bti]);

-- �ndice: idx_btii_bti
CREATE INDEX IF NOT EXISTS [idx_btii_bti] ON [btii] ([bti]);

-- �ndice: idx_cd_cd-1
CREATE INDEX IF NOT EXISTS [idx_cd_cd-1] ON [cd] ([chave]);

-- �ndice: idx_cd_cd-2
CREATE INDEX IF NOT EXISTS [idx_cd_cd-2] ON [cd] ([peca]);

-- �ndice: idx_cd_cd-3
CREATE INDEX IF NOT EXISTS [idx_cd_cd-3] ON [cd] ([codigoint]);

-- �ndice: idx_cd_cd-4
CREATE INDEX IF NOT EXISTS [idx_cd_cd-4] ON [cd] ([cliente], [peca]);

-- �ndice: idx_cd_cd-5
CREATE INDEX IF NOT EXISTS [idx_cd_cd-5] ON [cd] ([viabili]);

-- �ndice: idx_cdapuprd_cd01
CREATE INDEX IF NOT EXISTS [idx_cdapuprd_cd01] ON [cdapuprd] ([cd]);

-- �ndice: idx_cdapuprd_cd02
CREATE INDEX IF NOT EXISTS [idx_cdapuprd_cd02] ON [cdapuprd] ([ano], [codigo]);

-- �ndice: idx_cdapuprd_cd03
CREATE INDEX IF NOT EXISTS [idx_cdapuprd_cd03] ON [cdapuprd] ([codigo], [ano]);

-- �ndice: idx_cdapuprd_cd04
CREATE INDEX IF NOT EXISTS [idx_cdapuprd_cd04] ON [cdapuprd] ([codigoint], [ano]);

-- �ndice: idx_cdi_chave
CREATE INDEX IF NOT EXISTS [idx_cdi_chave] ON [cdi] ([chave]);

-- �ndice: idx_declmot_declmot
CREATE INDEX IF NOT EXISTS [idx_declmot_declmot] ON [declmot] ([numero]);

-- �ndice: idx_esc_codigo
CREATE INDEX IF NOT EXISTS [idx_esc_codigo] ON [esc] ([codigo]);

-- �ndice: idx_esc_ov
CREATE INDEX IF NOT EXISTS [idx_esc_ov] ON [esc] ([ov]);

-- �ndice: idx_esc_viabili
CREATE INDEX IF NOT EXISTS [idx_esc_viabili] ON [esc] ([viabili]);

-- �ndice: idx_escms03_ov
CREATE INDEX IF NOT EXISTS [idx_escms03_ov] ON [escms03] ([ov]);

-- �ndice: idx_escms06_ov
CREATE INDEX IF NOT EXISTS [idx_escms06_ov] ON [escms06] ([ov]);

-- �ndice: idx_esf_codigo
CREATE INDEX IF NOT EXISTS [idx_esf_codigo] ON [esf] ([codigo]);

-- �ndice: idx_esf_ov
CREATE INDEX IF NOT EXISTS [idx_esf_ov] ON [esf] ([ov]);

-- �ndice: idx_esf_viabili
CREATE INDEX IF NOT EXISTS [idx_esf_viabili] ON [esf] ([viabili]);

-- �ndice: idx_esfms03_ov
CREATE INDEX IF NOT EXISTS [idx_esfms03_ov] ON [esfms03] ([ov]);

-- �ndice: idx_esfms06_ov
CREATE INDEX IF NOT EXISTS [idx_esfms06_ov] ON [esfms06] ([ov]);

-- �ndice: idx_eso_codigo
CREATE INDEX IF NOT EXISTS [idx_eso_codigo] ON [eso] ([codigo]);

-- �ndice: idx_eso_ov
CREATE INDEX IF NOT EXISTS [idx_eso_ov] ON [eso] ([ov]);

-- �ndice: idx_eso_viabili
CREATE INDEX IF NOT EXISTS [idx_eso_viabili] ON [eso] ([viabili]);

-- �ndice: idx_esoms03_ov
CREATE INDEX IF NOT EXISTS [idx_esoms03_ov] ON [esoms03] ([ov]);

-- �ndice: idx_esp_codigo
CREATE INDEX IF NOT EXISTS [idx_esp_codigo] ON [esp] ([codigo]);

-- �ndice: idx_esp_ov
CREATE INDEX IF NOT EXISTS [idx_esp_ov] ON [esp] ([ov]);

-- �ndice: idx_esp_viabili
CREATE INDEX IF NOT EXISTS [idx_esp_viabili] ON [esp] ([viabili]);

-- �ndice: idx_espms03_ov
CREATE INDEX IF NOT EXISTS [idx_espms03_ov] ON [espms03] ([ov]);

-- �ndice: idx_espms06_ov
CREATE INDEX IF NOT EXISTS [idx_espms06_ov] ON [espms06] ([ov]);

-- �ndice: idx_fluxo_fluxo-1
CREATE INDEX IF NOT EXISTS [idx_fluxo_fluxo-1] ON [fluxo] ([numero]);

-- �ndice: idx_np_cliente
CREATE INDEX IF NOT EXISTS [idx_np_cliente] ON [np] ([cliente]);

-- �ndice: idx_np_codigo
CREATE INDEX IF NOT EXISTS [idx_np_codigo] ON [np] ([codigo]);

-- �ndice: idx_np_np
CREATE INDEX IF NOT EXISTS [idx_np_np] ON [np] ([np]);

-- �ndice: idx_orca_orca
CREATE INDEX IF NOT EXISTS [idx_orca_orca] ON [orca] ([orca]);

-- �ndice: idx_orcai_orca
CREATE INDEX IF NOT EXISTS [idx_orcai_orca] ON [orcai] ([orca]);

-- �ndice: idx_vfms03_ov
CREATE INDEX IF NOT EXISTS [idx_vfms03_ov] ON [vfms03] ([ov]);

-- �ndice: idx_vfms06_ov
CREATE INDEX IF NOT EXISTS [idx_vfms06_ov] ON [vfms06] ([ov]);

-- �ndice: idx_vforc_codigo
CREATE INDEX IF NOT EXISTS [idx_vforc_codigo] ON [vforc] ([codigo]);

-- �ndice: idx_vforc_ov
CREATE INDEX IF NOT EXISTS [idx_vforc_ov] ON [vforc] ([ov]);

-- �ndice: idx_vforc_viabili
CREATE INDEX IF NOT EXISTS [idx_vforc_viabili] ON [vforc] ([viabili]);

-- �ndice: idx_viabiii_ov
CREATE INDEX IF NOT EXISTS [idx_viabiii_ov] ON [viabiii] ([ov]);

-- �ndice: idx_viabiii_ovitem
CREATE INDEX IF NOT EXISTS [idx_viabiii_ovitem] ON [viabiii] ([ov], [item]);

-- �ndice: idx_viabili
CREATE INDEX IF NOT EXISTS [idx_viabili] ON [vporc] ([viabili]);

-- �ndice: idx_viabili_codigoin
CREATE INDEX IF NOT EXISTS [idx_viabili_codigoin] ON [viabili] ([codigoint]);

-- �ndice: idx_viabili_codigoint
CREATE INDEX IF NOT EXISTS [idx_viabili_codigoint] ON [viabili] ([codigoint]);

-- �ndice: idx_viabili_desenho
CREATE INDEX IF NOT EXISTS [idx_viabili_desenho] ON [viabili] ([desenho]);

-- �ndice: idx_viabili_ov
CREATE INDEX IF NOT EXISTS [idx_viabili_ov] ON [viabili] ([ov]);

-- �ndice: idx_viabili_pedcli
CREATE INDEX IF NOT EXISTS [idx_viabili_pedcli] ON [viabili] ([pedcli]);

-- �ndice: idx_viarev_viarev
CREATE INDEX IF NOT EXISTS [idx_viarev_viarev] ON [viarev] ([ov]);

-- �ndice: idx_vmark_seq
CREATE INDEX IF NOT EXISTS [idx_vmark_seq] ON [vmark] ([seq]);

-- �ndice: idx_vms03_ov
CREATE INDEX IF NOT EXISTS [idx_vms03_ov] ON [vms03] ([ov]);

-- �ndice: idx_vms06_ov
CREATE INDEX IF NOT EXISTS [idx_vms06_ov] ON [vms06] ([ov]);

-- �ndice: idx_vporc_codigo
CREATE INDEX IF NOT EXISTS [idx_vporc_codigo] ON [vporc] ([codigo]);

-- �ndice: idx_vporc_ov
CREATE INDEX IF NOT EXISTS [idx_vporc_ov] ON [vporc] ([ov]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
