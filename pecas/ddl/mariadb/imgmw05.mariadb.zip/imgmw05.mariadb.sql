#
# DUMP FILE
#
# Database is ported from MS Access
#------------------------------------------------------------------
# Created using "MS Access to MySQL" form http://www.bullzip.com
# Program Version 5.5.282
#
# OPTIONS:
#   sourcefilename=C:/temp/imgmw05.mdb
#   sourceusername=
#   sourcepassword=
#   sourcesystemdatabase=
#   destinationdatabase=imgmw05
#   storageengine=InnoDB
#   dropdatabase=0
#   createtables=1
#   unicode=0
#   autocommit=1
#   transferdefaultvalues=1
#   transferindexes=1
#   transferautonumbers=1
#   transferrecords=0
#   columnlist=1
#   tableprefix=
#   negativeboolean=0
#   ignorelargeblobs=0
#   memotype=LONGTEXT
#   datetimetype=DATETIME
#

CREATE DATABASE IF NOT EXISTS `imgmw05`;
USE `imgmw05`;

#
# Table structure for table 'IMAGENS'
#

DROP TABLE IF EXISTS `IMAGENS`;

CREATE TABLE `IMAGENS` (
  `CODIGO` VARCHAR(24) NOT NULL, 
  `IMAGEM` LONGBLOB, 
  `NUMERO` DOUBLE NULL, 
  INDEX (`CODIGO`), 
  INDEX (`NUMERO`), 
  INDEX (`CODIGO`)
) ENGINE=innodb;

