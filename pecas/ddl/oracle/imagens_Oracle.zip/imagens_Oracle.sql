--------------------------------------------
--------------- Dump details ---------------
--------------------------------------------
-- Original file: C:\cnvoracle\pecas\imagens.mdb
-- Dump date: 12-18-2024 10:17:28
--------------------------------------------

-- creating table
CREATE TABLE IMAGENS (
	CODIGO VARCHAR2 (24) NOT NULL,
	IMAGEM BLOB,
	NUMERO NUMBER
);


