--------------------------------------------
--------------- Dump details ---------------
--------------------------------------------
-- Original file: C:\cnvoracle\pecas\imgmw05.mdb
-- Dump date: 12-18-2024 10:18:20
--------------------------------------------

-- creating table
CREATE TABLE IMAGENS (
	CODIGO VARCHAR2 (24) NOT NULL,
	IMAGEM BLOB,
	NUMERO NUMBER
);


