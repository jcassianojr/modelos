--
-- Arquivo gerado com SQLiteStudio v3.4.4 em dom jul 28 17:25:07 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: IMAGENS
CREATE TABLE IF NOT EXISTS [IMAGENS] (
	[CODIGO] varchar(24) NOT NULL, 
	[NUMERO] double
);

-- �ndice: IDXIMAGENS_CODIGO
CREATE INDEX IF NOT EXISTS [IDXIMAGENS_CODIGO]
	ON [IMAGENS] ([CODIGO]);

-- �ndice: IDXIMAGENS_NUMERO
CREATE INDEX IF NOT EXISTS [IDXIMAGENS_NUMERO]
	ON [IMAGENS] ([NUMERO]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
