--
-- DUMP FILE
--
-- Database is ported from MS Access
--------------------------------------------------------------------
-- Created using "MS Access to PostgreSQL" form http://www.bullzip.com
-- Program Version 5.5.281
--
-- OPTIONS:
--   sourcefilename=C:/Users/jcass/Downloads/imagens.mdb
--   sourceusername=
--   sourcepassword=
--   sourcesystemdatabase=
--   destinationserver=localhost
--   destinationdatabase=imagem
--   maintenancedb=postgres
--   dropdatabase=0
--   createtables=1
--   unicode=0
--   autocommit=1
--   transferdefaultvalues=1
--   transferindexes=1
--   transferautonumbers=1
--   transferrecords=1
--   columnlist=1
--   tableprefix=
--   negativeboolean=0
--   ignorelargeblobs=0
--   memotype=TEXT
--   datetimetype=TIMESTAMP
--

CREATE DATABASE "imagem";

-- NOTICE: At this place you need to connect to the new database and run the rest of the statements.

--
-- Table structure for table 'IMAGENS'
--

DROP TABLE IF EXISTS "IMAGENS";

CREATE TABLE "IMAGENS" (
  "CODIGO" VARCHAR(24) NOT NULL, 
  "IMAGEM" TEXT, 
  "NUMERO" DOUBLE PRECISION NULL
);

--
-- Dumping data for table 'IMAGENS'
--

-- 0 records

CREATE INDEX "IMAGENS_CODIGO" ON "IMAGENS" ("CODIGO");

CREATE INDEX "IMAGENS_NUMERO" ON "IMAGENS" ("NUMERO");

CREATE INDEX "IMAGENS_PRIMARYKEY" ON "IMAGENS" ("CODIGO");

