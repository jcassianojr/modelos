-- ======================================================
-- SCRIPT DE ESTRUTURA COMPLETA: DESTINO (ACCDB)
-- Gerado em: 17/05/2026 09:24:42
-- ======================================================

-- --------------------------------------------------
-- Estrutura da Tabela: IMAGENS
-- --------------------------------------------------
CREATE TABLE [IMAGENS] ([CODIGO] TEXT(24), [IMAGEM] LONGBINARY, [NUMERO] DOUBLE);
CREATE INDEX [CODIGO] ON [IMAGENS] ([CODIGO]);
CREATE INDEX [NUMERO] ON [IMAGENS] ([NUMERO]);
CREATE INDEX [PRIMARYKEY] ON [IMAGENS] ([CODIGO]);

-- Fim do Script de DESTINO (ACCDB)
