--
-- Arquivo gerado com SQLiteStudio v3.4.4 em qua ago 7 11:45:37 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: ba01
CREATE TABLE IF NOT EXISTS ba01 (NUMERO INTEGER, SUB CHAR(1), DATA DATE, NRCONTA INTEGER, CODIGO CHAR(4), HISTORICO CHAR(30), ITEM CHAR(4), VALOR FLOAT, TIPO CHAR(1), DATADEP DATE, CHAVE CHAR(24));

-- Tabela: bc01
CREATE TABLE IF NOT EXISTS [bc01] ([codigo] TEXT(4) NOT NULL, [descricao] TEXT(35) NOT NULL, [valor] REAL NOT NULL, [valor1] REAL NOT NULL, [tipo] TEXT(1) NOT NULL, [item] TEXT(3) NOT NULL);

-- Tabela: bd01
CREATE TABLE IF NOT EXISTS [bd01] ([numero] REAL NOT NULL, [cognome] TEXT(15) NOT NULL, [nome] TEXT(40) NOT NULL, [endereco] TEXT(40) NOT NULL, [bairro] TEXT(30) NOT NULL, [cidade] TEXT(30) NOT NULL, [estado] TEXT(2) NOT NULL, [cep] TEXT(9) NOT NULL, [ddd] TEXT(2) NOT NULL, [telefone] TEXT(12) NOT NULL, [ramal] TEXT(4) NOT NULL, [contato] TEXT(22) NOT NULL, [dddfax] TEXT(2) NOT NULL, [telefax] TEXT(12) NOT NULL, [cgc] TEXT(18) NOT NULL, [iestadual] TEXT(16) NOT NULL, [ddd1] TEXT(2) NOT NULL, [telefone1] TEXT(12) NOT NULL, [ramal1] TEXT(4) NOT NULL, [contato1] TEXT(22) NOT NULL, [pessoa] TEXT(1) NOT NULL, [site] TEXT(30) NOT NULL, [email] TEXT(30) NOT NULL);

-- Tabela: be01
CREATE TABLE IF NOT EXISTS [be01] ([codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL);

-- Tabela: bf01
CREATE TABLE IF NOT EXISTS [bf01] ([venda] REAL NOT NULL, [numero] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [data] SHORTDATE NOT NULL, [valor] REAL NOT NULL);

-- �ndice: BA01-1
CREATE INDEX IF NOT EXISTS "BA01-1" ON ba01 (NRCONTA, NUMERO);

-- �ndice: BA01-2
CREATE INDEX IF NOT EXISTS "BA01-2" ON ba01 (NUMERO, SUB);

-- �ndice: BA01-3
CREATE INDEX IF NOT EXISTS "BA01-3" ON ba01 (CHAVE);

-- �ndice: BA01-4
CREATE INDEX IF NOT EXISTS "BA01-4" ON ba01 (DATA);

-- �ndice: BA01-5
CREATE INDEX IF NOT EXISTS "BA01-5" ON ba01 (ITEM);

-- �ndice: idx_bc01_codigo
CREATE INDEX IF NOT EXISTS [idx_bc01_codigo] ON [bc01] ([codigo]);

-- �ndice: idx_bc01_descricao
CREATE INDEX IF NOT EXISTS [idx_bc01_descricao] ON [bc01] ([descricao]);

-- �ndice: idx_bd01_cognome
CREATE INDEX IF NOT EXISTS [idx_bd01_cognome] ON [bd01] ([cognome]);

-- �ndice: idx_bd01_numero
CREATE INDEX IF NOT EXISTS [idx_bd01_numero] ON [bd01] ([numero]);

-- �ndice: idx_be01_codigo
CREATE INDEX IF NOT EXISTS [idx_be01_codigo] ON [be01] ([codigo]);

-- �ndice: idx_be01_nome
CREATE INDEX IF NOT EXISTS [idx_be01_nome] ON [be01] ([nome]);

-- �ndice: idx_bf01_codigo
CREATE INDEX IF NOT EXISTS [idx_bf01_codigo] ON [bf01] ([codigo]);

-- �ndice: idx_bf01_numero
CREATE INDEX IF NOT EXISTS [idx_bf01_numero] ON [bf01] ([numero]);

-- �ndice: idx_venda
CREATE INDEX IF NOT EXISTS [idx_venda] ON [bf01] ([venda]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
