--
-- Arquivo gerado com Letos v4.0.0 em Sun Jun 28 14:42:08 2026
--
-- Codifica��o de texto usada: windows-1252
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: ba01
CREATE TABLE IF NOT EXISTS ba01 (
    NUMERO    INTEGER DEFAULT 0,
    SUB       TEXT    NOT NULL
                      DEFAULT (''),
    DATA      DATE    NOT NULL
                      DEFAULT (''),
    NRCONTA   INTEGER DEFAULT 0,
    CODIGO    TEXT    NOT NULL
                      DEFAULT (''),
    HISTORICO TEXT    NOT NULL
                      DEFAULT (''),
    ITEM      TEXT    NOT NULL
                      DEFAULT (''),
    VALOR     FLOAT   DEFAULT 0,
    TIPO      TEXT    NOT NULL
                      DEFAULT (''),
    DATADEP   DATE    NOT NULL
                      DEFAULT (''),
    CHAVE     TEXT    NOT NULL
                      DEFAULT ('') 
);


-- Tabela: bc01
CREATE TABLE IF NOT EXISTS bc01 (
    CODIGO    TEXT  NOT NULL
                    DEFAULT (''),
    DESCRICAO TEXT  NOT NULL
                    DEFAULT (''),
    VALOR     FLOAT DEFAULT 0,
    VALOR1    FLOAT DEFAULT 0,
    TIPO      TEXT  NOT NULL
                    DEFAULT (''),
    ITEM      TEXT  NOT NULL
                    DEFAULT ('') 
);


-- Tabela: bd01
CREATE TABLE IF NOT EXISTS bd01 (
    NUMERO    INTEGER DEFAULT 0,
    COGNOME   TEXT    NOT NULL
                      DEFAULT (''),
    NOME      TEXT    NOT NULL
                      DEFAULT (''),
    ENDERECO  TEXT    NOT NULL
                      DEFAULT (''),
    BAIRRO    TEXT    NOT NULL
                      DEFAULT (''),
    CIDADE    TEXT    NOT NULL
                      DEFAULT (''),
    ESTADO    TEXT    NOT NULL
                      DEFAULT (''),
    CEP       TEXT    NOT NULL
                      DEFAULT (''),
    DDD       TEXT    NOT NULL
                      DEFAULT (''),
    TELEFONE  TEXT    NOT NULL
                      DEFAULT (''),
    RAMAL     TEXT    NOT NULL
                      DEFAULT (''),
    CONTATO   TEXT    NOT NULL
                      DEFAULT (''),
    DDDFAX    TEXT    NOT NULL
                      DEFAULT (''),
    TELEFAX   TEXT    NOT NULL
                      DEFAULT (''),
    CGC       TEXT    NOT NULL
                      DEFAULT (''),
    IESTADUAL TEXT    NOT NULL
                      DEFAULT (''),
    DDD1      TEXT    NOT NULL
                      DEFAULT (''),
    TELEFONE1 TEXT    NOT NULL
                      DEFAULT (''),
    RAMAL1    TEXT    NOT NULL
                      DEFAULT (''),
    CONTATO1  TEXT    NOT NULL
                      DEFAULT (''),
    PESSOA    TEXT    NOT NULL
                      DEFAULT (''),
    SITE      TEXT    NOT NULL
                      DEFAULT (''),
    EMAIL     TEXT    NOT NULL
                      DEFAULT ('') 
);


-- Tabela: be01
CREATE TABLE IF NOT EXISTS be01 (
    CODIGO TEXT NOT NULL
                DEFAULT (''),
    NOME   TEXT NOT NULL
                DEFAULT ('') 
);


-- Tabela: bf01
CREATE TABLE IF NOT EXISTS bf01 (
    VENDA  INTEGER DEFAULT 0,
    NUMERO INTEGER DEFAULT 0,
    CODIGO TEXT    NOT NULL
                   DEFAULT (''),
    DATA   DATE    NOT NULL
                   DEFAULT (''),
    VALOR  FLOAT   DEFAULT 0
);


-- Tabela: index_metadata
CREATE TABLE IF NOT EXISTS index_metadata (
    nome_tabela       TEXT,
    index_name        TEXT,
    expression        TEXT,
    sql_expression    TEXT,
    filter_expression TEXT,
    is_unique         INTEGER,
    is_bag            INTEGER
);

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'ba01',
                               'IDX_ba01_BA01_1',
                               'STR NRCONTA 2 +STR NUMERO 7',
                               'NRCONTA NUMERO',
                               '',
                               0,
                               1
                           );

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'ba01',
                               'IDX_ba01_BA01_2',
                               'STR NUMERO 7 +SUB',
                               'NUMERO SUB',
                               '',
                               0,
                               1
                           );

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'ba01',
                               'IDX_ba01_BA01_3',
                               'CHAVE',
                               'CHAVE',
                               '',
                               0,
                               1
                           );

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'ba01',
                               'IDX_ba01_BA01_4',
                               'DATA',
                               'DATA',
                               '',
                               0,
                               1
                           );

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'ba01',
                               'IDX_ba01_BA01_5',
                               'ITEM',
                               'ITEM',
                               '',
                               0,
                               1
                           );

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'bc01',
                               'IDX_bc01_CODIGO',
                               'CODIGO',
                               'CODIGO',
                               '',
                               0,
                               1
                           );

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'bc01',
                               'IDX_bc01_DESCRICAO',
                               'DESCRICAO',
                               'DESCRICAO',
                               '',
                               0,
                               1
                           );

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'bd01',
                               'IDX_bd01_NUMERO',
                               'NUMERO',
                               'NUMERO',
                               '',
                               0,
                               1
                           );

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'bd01',
                               'IDX_bd01_COGNOME',
                               'COGNOME',
                               'COGNOME',
                               '',
                               0,
                               1
                           );

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'be01',
                               'IDX_be01_CODIGO',
                               'CODIGO',
                               'CODIGO',
                               '',
                               0,
                               1
                           );

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'be01',
                               'IDX_be01_NOME',
                               'NOME',
                               'NOME',
                               '',
                               0,
                               1
                           );

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'bf01',
                               'IDX_bf01_VENDA',
                               'VENDA',
                               'VENDA',
                               '',
                               0,
                               1
                           );

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'bf01',
                               'IDX_bf01_NUMERO',
                               'NUMERO',
                               'NUMERO',
                               '',
                               0,
                               1
                           );

INSERT INTO index_metadata (
                               nome_tabela,
                               index_name,
                               expression,
                               sql_expression,
                               filter_expression,
                               is_unique,
                               is_bag
                           )
                           VALUES (
                               'bf01',
                               'IDX_bf01_CODIGO',
                               'CODIGO',
                               'CODIGO',
                               '',
                               0,
                               1
                           );


-- Tabela: table_metadata
CREATE TABLE IF NOT EXISTS table_metadata (
    nome_tabela          TEXT,
    column_name          TEXT,
    original_type        TEXT,
    tamanho              INTEGER,
    precisao             INTEGER,
    is_nullable          INTEGER,
    field_visual_picture TEXT
);

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'ba01',
                               'NUMERO',
                               'N',
                               8,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'ba01',
                               'SUB',
                               'C',
                               1,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'ba01',
                               'DATA',
                               'D',
                               8,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'ba01',
                               'NRCONTA',
                               'N',
                               2,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'ba01',
                               'CODIGO',
                               'C',
                               4,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'ba01',
                               'HISTORICO',
                               'C',
                               30,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'ba01',
                               'ITEM',
                               'C',
                               4,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'ba01',
                               'VALOR',
                               'N',
                               12,
                               2,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'ba01',
                               'TIPO',
                               'C',
                               1,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'ba01',
                               'DATADEP',
                               'D',
                               8,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'ba01',
                               'CHAVE',
                               'C',
                               24,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bc01',
                               'CODIGO',
                               'C',
                               4,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bc01',
                               'DESCRICAO',
                               'C',
                               35,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bc01',
                               'VALOR',
                               'N',
                               15,
                               2,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bc01',
                               'VALOR1',
                               'N',
                               15,
                               2,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bc01',
                               'TIPO',
                               'C',
                               1,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bc01',
                               'ITEM',
                               'C',
                               3,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'NUMERO',
                               'N',
                               5,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'COGNOME',
                               'C',
                               15,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'NOME',
                               'C',
                               40,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'ENDERECO',
                               'C',
                               40,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'BAIRRO',
                               'C',
                               30,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'CIDADE',
                               'C',
                               30,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'ESTADO',
                               'C',
                               2,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'CEP',
                               'C',
                               9,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'DDD',
                               'C',
                               2,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'TELEFONE',
                               'C',
                               12,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'RAMAL',
                               'C',
                               4,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'CONTATO',
                               'C',
                               22,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'DDDFAX',
                               'C',
                               2,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'TELEFAX',
                               'C',
                               12,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'CGC',
                               'C',
                               18,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'IESTADUAL',
                               'C',
                               16,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'DDD1',
                               'C',
                               2,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'TELEFONE1',
                               'C',
                               12,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'RAMAL1',
                               'C',
                               4,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'CONTATO1',
                               'C',
                               22,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'PESSOA',
                               'C',
                               1,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'SITE',
                               'C',
                               30,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bd01',
                               'EMAIL',
                               'C',
                               30,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'be01',
                               'CODIGO',
                               'C',
                               24,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'be01',
                               'NOME',
                               'C',
                               40,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bf01',
                               'VENDA',
                               'N',
                               8,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bf01',
                               'NUMERO',
                               'N',
                               8,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bf01',
                               'CODIGO',
                               'C',
                               24,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bf01',
                               'DATA',
                               'D',
                               8,
                               0,
                               NULL,
                               NULL
                           );

INSERT INTO table_metadata (
                               nome_tabela,
                               column_name,
                               original_type,
                               tamanho,
                               precisao,
                               is_nullable,
                               field_visual_picture
                           )
                           VALUES (
                               'bf01',
                               'VALOR',
                               'N',
                               10,
                               2,
                               NULL,
                               NULL
                           );


-- �ndice: IDX_ba01_BA01_1
CREATE INDEX IF NOT EXISTS IDX_ba01_BA01_1 ON ba01 (
    NRCONTA,
    NUMERO
);


-- �ndice: IDX_ba01_BA01_2
CREATE INDEX IF NOT EXISTS IDX_ba01_BA01_2 ON ba01 (
    NUMERO,
    SUB
);


-- �ndice: IDX_ba01_BA01_3
CREATE INDEX IF NOT EXISTS IDX_ba01_BA01_3 ON ba01 (
    CHAVE
);


-- �ndice: IDX_ba01_BA01_4
CREATE INDEX IF NOT EXISTS IDX_ba01_BA01_4 ON ba01 (
    DATA
);


-- �ndice: IDX_ba01_BA01_5
CREATE INDEX IF NOT EXISTS IDX_ba01_BA01_5 ON ba01 (
    ITEM
);


-- �ndice: IDX_bc01_CODIGO
CREATE INDEX IF NOT EXISTS IDX_bc01_CODIGO ON bc01 (
    CODIGO
);


-- �ndice: IDX_bc01_DESCRICAO
CREATE INDEX IF NOT EXISTS IDX_bc01_DESCRICAO ON bc01 (
    DESCRICAO
);


-- �ndice: IDX_bd01_COGNOME
CREATE INDEX IF NOT EXISTS IDX_bd01_COGNOME ON bd01 (
    COGNOME
);


-- �ndice: IDX_bd01_NUMERO
CREATE INDEX IF NOT EXISTS IDX_bd01_NUMERO ON bd01 (
    NUMERO
);


-- �ndice: IDX_be01_CODIGO
CREATE INDEX IF NOT EXISTS IDX_be01_CODIGO ON be01 (
    CODIGO
);


-- �ndice: IDX_be01_NOME
CREATE INDEX IF NOT EXISTS IDX_be01_NOME ON be01 (
    NOME
);


-- �ndice: IDX_bf01_CODIGO
CREATE INDEX IF NOT EXISTS IDX_bf01_CODIGO ON bf01 (
    CODIGO
);


-- �ndice: IDX_bf01_NUMERO
CREATE INDEX IF NOT EXISTS IDX_bf01_NUMERO ON bf01 (
    NUMERO
);


-- �ndice: IDX_bf01_VENDA
CREATE INDEX IF NOT EXISTS IDX_bf01_VENDA ON bf01 (
    VENDA
);


COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
