--
-- Arquivo gerado com SQLiteStudio v3.4.4 em seg ago 5 10:45:22 2024
--
-- Codifica��o de texto usada: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Tabela: acpnc
CREATE TABLE IF NOT EXISTS [acpnc] ([acpnc] REAL NOT NULL, [data] SHORTDATE NOT NULL, [datafec] SHORTDATE NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [produto] TEXT(24) NOT NULL, [despro] TEXT(40) NOT NULL, [apnc] REAL NOT NULL, [rnc] REAL NOT NULL, [rat] REAL NOT NULL, [sair] BIT NOT NULL, [qti01] REAL NOT NULL, [qti02] REAL NOT NULL, [qti03] REAL NOT NULL, [qti04] REAL NOT NULL, [qti05] REAL NOT NULL, [qti06] REAL NOT NULL, [qti07] REAL NOT NULL, [qte01] REAL NOT NULL, [qte02] REAL NOT NULL, [qte03] REAL NOT NULL, [qte04] REAL NOT NULL, [qte05] REAL NOT NULL, [qte06] REAL NOT NULL, [qte07] REAL NOT NULL, [qte08] REAL NOT NULL, [qte09] REAL NOT NULL, [qte10] REAL NOT NULL, [qte11] REAL NOT NULL, [vli01] REAL NOT NULL, [vli02] REAL NOT NULL, [vli03] REAL NOT NULL, [vli04] REAL NOT NULL, [vli05] REAL NOT NULL, [vli06] REAL NOT NULL, [vli07] REAL NOT NULL, [vle01] REAL NOT NULL, [vle02] REAL NOT NULL, [vle03] REAL NOT NULL, [vle04] REAL NOT NULL, [vle05] REAL NOT NULL, [vle06] REAL NOT NULL, [vle07] REAL NOT NULL, [vle08] REAL NOT NULL, [vle09] REAL NOT NULL, [vle10] REAL NOT NULL, [vle11] REAL NOT NULL, [pcvalext] REAL NOT NULL, [pcvalint] REAL NOT NULL, [sac] REAL NOT NULL, [compete] TEXT(6) NOT NULL);

-- Tabela: adp
CREATE TABLE IF NOT EXISTS [adp] ([adp] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [nfdev] TEXT(15) NOT NULL, [cliret] TEXT(30) NOT NULL, [rastro] TEXT(10) NOT NULL, [insnum] REAL NOT NULL, [insnome] TEXT(40) NOT NULL, [data] SHORTDATE NOT NULL, [inihor] REAL NOT NULL, [fimhor] REAL NOT NULL, [horas] REAL NOT NULL, [requer] TEXT(1) NOT NULL, [area] TEXT(2) NOT NULL, [respo] TEXT(40) NOT NULL, [rnc] REAL NOT NULL);

-- Tabela: adpi
CREATE TABLE IF NOT EXISTS [adpi] ([adp] REAL NOT NULL, [espc] TEXT(80) NOT NULL, [enco] TEXT(80) NOT NULL, [laudo] TEXT(1) NOT NULL);

-- Tabela: caf
CREATE TABLE IF NOT EXISTS [caf] ([numero] REAL NOT NULL, [previsto] SHORTDATE NOT NULL, [efetuado] SHORTDATE NOT NULL, [dplano] SHORTDATE NOT NULL, [eficaz] TEXT(1) NOT NULL, [obs] TEXT(80) NOT NULL);

-- Tabela: cfe
CREATE TABLE IF NOT EXISTS [cfe] ([numero] REAL NOT NULL, [data] SHORTDATE NOT NULL, [tipocli] TEXT(1) NOT NULL, [clifor] REAL NOT NULL, [cognome] TEXT(20) NOT NULL, [nota] TEXT(30) NOT NULL, [peso] REAL NOT NULL, [meiotran] TEXT(30) NOT NULL, [justifi] TEXT(80) NOT NULL, [tipoent] TEXT(1) NOT NULL, [produto] TEXT(24) NOT NULL);

-- Tabela: crdias
CREATE TABLE IF NOT EXISTS [crdias] ([seq] REAL NOT NULL, [nfor] REAL NOT NULL, [dias] REAL NOT NULL, [qtent] REAL NOT NULL, [qtprz] REAL NOT NULL);

-- Tabela: crfa
CREATE TABLE IF NOT EXISTS [crfa] ([seq] REAL NOT NULL, [nfor] REAL NOT NULL, [nome] TEXT(40) NOT NULL, [qtra] REAL NOT NULL, [qtna] REAL NOT NULL, [ppma] REAL NOT NULL, [diaa] REAL NOT NULL, [iafa] REAL NOT NULL, [iqfa] REAL NOT NULL, [mesa] REAL NOT NULL, [qtrs] REAL NOT NULL, [qtns] REAL NOT NULL, [ppms] REAL NOT NULL, [dias] REAL NOT NULL, [iafs] REAL NOT NULL, [iqfs] REAL NOT NULL, [mess] REAL NOT NULL, [conceito] TEXT(1) NOT NULL, [ppm] REAL NOT NULL, [iaf] REAL NOT NULL, [subramo] TEXT(3) NOT NULL);

-- Tabela: crfor
CREATE TABLE IF NOT EXISTS [crfor] ([seq] REAL NOT NULL, [nfor] REAL NOT NULL, [qtdrec] REAL NOT NULL, [qtdnc] REAL NOT NULL, [ppm] REAL NOT NULL, [dias] REAL NOT NULL, [iaf] REAL NOT NULL, [iqf] REAL NOT NULL, [anual] TEXT(1) NOT NULL, [semes] TEXT(1) NOT NULL, [descri] TEXT(20) NOT NULL, [ppms] REAL NOT NULL, [ppma] REAL NOT NULL, [iafs] REAL NOT NULL, [iafa] REAL NOT NULL, [nome] TEXT(50) NOT NULL);

-- Tabela: crft
CREATE TABLE IF NOT EXISTS [crft] ([nfor] REAL NOT NULL, [seq] REAL NOT NULL, [item] REAL NOT NULL, [descricao] TEXT(15) NOT NULL, [val01] REAL NOT NULL, [val02] REAL NOT NULL, [val03] REAL NOT NULL, [val04] REAL NOT NULL, [val05] REAL NOT NULL, [val06] REAL NOT NULL, [val07] REAL NOT NULL, [val08] REAL NOT NULL, [val09] REAL NOT NULL, [val10] REAL NOT NULL, [val11] REAL NOT NULL, [val12] REAL NOT NULL, [total] REAL NOT NULL, [iafs] REAL NOT NULL, [ppms] REAL NOT NULL);

-- Tabela: crrsapc
CREATE TABLE IF NOT EXISTS [crrsapc] ([seq] REAL NOT NULL, [cliente] REAL NOT NULL, [qtde] REAL NOT NULL);

-- Tabela: crrsapp
CREATE TABLE IF NOT EXISTS [crrsapp] ([seq] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [nome] TEXT(40) NOT NULL, [produso] TEXT(1) NOT NULL, [qtde] REAL NOT NULL, [set01] REAL NOT NULL, [set02] REAL NOT NULL, [set03] REAL NOT NULL, [set04] REAL NOT NULL, [set05] REAL NOT NULL, [set06] REAL NOT NULL, [set07] REAL NOT NULL, [set08] REAL NOT NULL, [set09] REAL NOT NULL, [set00] REAL NOT NULL);

-- Tabela: crrsaps
CREATE TABLE IF NOT EXISTS [crrsaps] ([seq] REAL NOT NULL, [setcod] TEXT(1) NOT NULL, [setor] TEXT(10) NOT NULL, [setcog] TEXT(5) NOT NULL, [qtde] REAL NOT NULL, [qtdenc] REAL NOT NULL, [ppm] REAL NOT NULL, [ret] REAL NOT NULL, [dev] REAL NOT NULL, [suc] REAL NOT NULL, [ppmret] REAL NOT NULL, [ppmdev] REAL NOT NULL, [ppmsuc] REAL NOT NULL, [semret] REAL NOT NULL, [semsuc] REAL NOT NULL, [semdev] REAL NOT NULL, [semppm] REAL NOT NULL, [semppmret] REAL NOT NULL, [semppmsuc] REAL NOT NULL, [semppmdev] REAL NOT NULL, [semtot] REAL NOT NULL, [sempro] REAL NOT NULL, [anuret] REAL NOT NULL, [anusuc] REAL NOT NULL, [anudev] REAL NOT NULL, [anuppm] REAL NOT NULL, [anuppmret] REAL NOT NULL, [anuppmsuc] REAL NOT NULL, [anuppmdev] REAL NOT NULL, [anutot] REAL NOT NULL, [anupro] REAL NOT NULL);

-- Tabela: crrserr
CREATE TABLE IF NOT EXISTS [crrserr] ([codigo] TEXT(3) NOT NULL, [nome] TEXT(40) NOT NULL, [grafico] BIT NOT NULL, [cognome] TEXT(5) NOT NULL);

-- Tabela: crrsseq
CREATE TABLE IF NOT EXISTS [crrsseq] ([seq] REAL NOT NULL, [diafim] SHORTDATE NOT NULL, [diaini] SHORTDATE NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [descr2] TEXT(10) NOT NULL, [descri] TEXT(30) NOT NULL, [ret] REAL NOT NULL, [suc] REAL NOT NULL, [dev] REAL NOT NULL, [totmes] REAL NOT NULL, [ppmmes] REAL NOT NULL, [ppmret] REAL NOT NULL, [ppmsuc] REAL NOT NULL, [ppmdev] REAL NOT NULL, [prodmes] REAL NOT NULL, [prodmy] REAL NOT NULL, [anual] TEXT(1) NOT NULL, [semes] TEXT(1) NOT NULL, [prodnf] REAL NOT NULL, [semret] REAL NOT NULL, [semsuc] REAL NOT NULL, [semdev] REAL NOT NULL, [semppmret] REAL NOT NULL, [semppmsuc] REAL NOT NULL, [semppmdev] REAL NOT NULL, [semtot] REAL NOT NULL, [sempro] REAL NOT NULL, [semppm] REAL NOT NULL, [semini] SHORTDATE NOT NULL, [semfim] SHORTDATE NOT NULL, [anuret] REAL NOT NULL, [anusuc] REAL NOT NULL, [anudev] REAL NOT NULL, [anuppmret] REAL NOT NULL, [anuppmsuc] REAL NOT NULL, [anuppmdev] REAL NOT NULL, [anutot] REAL NOT NULL, [anupro] REAL NOT NULL, [anuppm] REAL NOT NULL, [anuini] SHORTDATE NOT NULL, [anufim] SHORTDATE NOT NULL, [plano01] TEXT(120) NOT NULL, [plano02] TEXT(120) NOT NULL, [plano03] TEXT(120) NOT NULL, [plano04] TEXT(120) NOT NULL, [plano05] TEXT(120) NOT NULL, [plano06] TEXT(120) NOT NULL, [plano07] TEXT(120) NOT NULL, [acao01] TEXT(120) NOT NULL, [acao02] TEXT(120) NOT NULL, [acao03] TEXT(120) NOT NULL, [acao04] TEXT(120) NOT NULL, [acao05] TEXT(120) NOT NULL, [acao06] TEXT(120) NOT NULL, [acao07] TEXT(120) NOT NULL, [numfun] REAL NOT NULL, [numreg] REAL NOT NULL, [numtem] REAL NOT NULL, [zero] REAL NOT NULL);

-- Tabela: crrsset
CREATE TABLE IF NOT EXISTS [crrsset] ([codigo] TEXT(1) NOT NULL, [nome] TEXT(10) NOT NULL, [grafico] BIT NOT NULL, [cognome] TEXT(5) NOT NULL);

-- Tabela: crseq
CREATE TABLE IF NOT EXISTS [crseq] ([seq] REAL NOT NULL, [diafim] SHORTDATE NOT NULL, [diaini] SHORTDATE NOT NULL, [mes] REAL NOT NULL, [ano] REAL NOT NULL, [descri] TEXT(30) NOT NULL, [anual] TEXT(1) NOT NULL, [semes] TEXT(1) NOT NULL);

-- Tabela: crts
CREATE TABLE IF NOT EXISTS [crts] ([seq] REAL NOT NULL, [prodmes] REAL NOT NULL, [ret] REAL NOT NULL, [suc] REAL NOT NULL, [dev] REAL NOT NULL, [ppmret] REAL NOT NULL, [ppmsuc] REAL NOT NULL, [ppmdev] REAL NOT NULL);

-- Tabela: msrd
CREATE TABLE IF NOT EXISTS [msrd] ([msrd] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [pf] REAL NOT NULL, [data] SHORTDATE NOT NULL, [ocorreu] TEXT(20) NOT NULL, [desc01] TEXT(80) NOT NULL, [desc02] TEXT(80) NOT NULL, [inv01] TEXT(80) NOT NULL, [aca01] TEXT(80) NOT NULL, [cliente] REAL NOT NULL);

-- Tabela: pe01tmp
CREATE TABLE IF NOT EXISTS [pe01tmp] ([tipped] TEXT(1) NOT NULL, [codigo] TEXT(24) NOT NULL, [unidade] TEXT(2) NOT NULL, [nome] TEXT(50) NOT NULL, [nom2] TEXT(50) NOT NULL, [nrnotaini] REAL NOT NULL, [digctr] TEXT(1) NOT NULL, [datafat] SHORTDATE NOT NULL, [valorini] REAL NOT NULL, [totkgini] REAL NOT NULL, [nrnotasai] REAL NOT NULL, [totkgant] REAL NOT NULL, [totkgsai] REAL NOT NULL, [totkgest] REAL NOT NULL, [tipocli] TEXT(1) NOT NULL, [cliente] REAL NOT NULL, [cognome] TEXT(12) NOT NULL, [datasai] SHORTDATE NOT NULL, [crm] REAL NOT NULL, [pedido] REAL NOT NULL, [item] REAL NOT NULL, [receber] TEXT(1) NOT NULL, [obs] TEXT(20) NOT NULL, [rastrofor] TEXT(20) NOT NULL, [dcorte] SHORTDATE NOT NULL, [ar] REAL NOT NULL, [aritem] REAL NOT NULL, [rirm] REAL NOT NULL);

-- Tabela: racf
CREATE TABLE IF NOT EXISTS [racf] ([racf] REAL NOT NULL, [rnc] REAL NOT NULL, [rat] REAL NOT NULL, [data] SHORTDATE NOT NULL, [deno] TEXT(40) NOT NULL, [desenho] TEXT(24) NOT NULL, [revisao] TEXT(2) NOT NULL, [rastro] TEXT(20) NOT NULL, [fornecedo] REAL NOT NULL, [nomef] TEXT(40) NOT NULL, [resp] TEXT(30) NOT NULL, [respc] TEXT(30) NOT NULL, [fone] TEXT(12) NOT NULL, [fax] TEXT(12) NOT NULL, [email] TEXT(30) NOT NULL, [desc01] TEXT(90) NOT NULL, [desc02] TEXT(90) NOT NULL, [desc03] TEXT(90) NOT NULL, [desc04] TEXT(90) NOT NULL, [desc05] TEXT(90) NOT NULL, [acao01] TEXT(80) NOT NULL, [acao02] TEXT(80) NOT NULL, [causa01] TEXT(80) NOT NULL, [causa02] TEXT(80) NOT NULL, [causa03] TEXT(80) NOT NULL, [causa04] TEXT(80) NOT NULL, [corre01] TEXT(80) NOT NULL, [corre02] TEXT(80) NOT NULL, [corre03] TEXT(80) NOT NULL, [corre04] TEXT(80) NOT NULL, [datai] SHORTDATE NOT NULL, [respf] TEXT(30) NOT NULL, [cargof] TEXT(30) NOT NULL, [dataf] SHORTDATE NOT NULL, [datae] SHORTDATE NOT NULL, [veri] TEXT(25) NOT NULL, [apro] TEXT(1) NOT NULL, [nota] TEXT(8) NOT NULL, [cnfita] TEXT(8) NOT NULL, [cnffor] TEXT(25) NOT NULL, [area] TEXT(2) NOT NULL, [respo] TEXT(40) NOT NULL, [cargo] TEXT(40) NOT NULL, [qtl1] REAL NOT NULL, [qtl2] REAL NOT NULL, [qtn1] REAL NOT NULL, [qtn2] REAL NOT NULL, [qtd1] REAL NOT NULL, [qtd2] REAL NOT NULL, [unid] TEXT(3) NOT NULL, [crm] REAL NOT NULL, [tipoe] TEXT(1) NOT NULL, [cbusca] TEXT(24) NOT NULL, [descri] TEXT(100) NOT NULL, [incuser] TEXT(10) NOT NULL, [incdata] SHORTDATE NOT NULL, [eficaz] TEXT(1) NOT NULL, [demerito] TEXT(1) NOT NULL, [descri01] TEXT(50) NOT NULL);

-- Tabela: racfsal
CREATE TABLE IF NOT EXISTS [racfsal] ([seq] REAL NOT NULL, [clifor] REAL NOT NULL, [qtde] REAL NOT NULL);

-- Tabela: rat
CREATE TABLE IF NOT EXISTS [rat] ([rat] REAL NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [data] SHORTDATE NOT NULL, [visita] BIT NOT NULL, [reccli] BIT NOT NULL, [relcli] BIT NOT NULL);

-- Tabela: rati
CREATE TABLE IF NOT EXISTS [rati] ([rat] REAL NOT NULL, [codigo] TEXT(24) NOT NULL, [qtde] REAL NOT NULL, [rastro] TEXT(9) NOT NULL, [prob01] TEXT(100) NOT NULL, [prob02] TEXT(100) NOT NULL, [prob03] TEXT(100) NOT NULL, [anal01] TEXT(100) NOT NULL, [anal02] TEXT(100) NOT NULL, [anal03] TEXT(100) NOT NULL, [anal04] TEXT(100) NOT NULL, [anal05] TEXT(100) NOT NULL, [acao01] TEXT(100) NOT NULL, [acao02] TEXT(100) NOT NULL, [acao03] TEXT(100) NOT NULL, [prazo] SHORTDATE NOT NULL, [resnum] REAL NOT NULL, [resnome] TEXT(40) NOT NULL, [lacao] BIT NOT NULL, [sac] REAL NOT NULL, [racf] REAL NOT NULL, [parada] BIT NOT NULL, [relacao] TEXT(1) NOT NULL);

-- Tabela: rnc
CREATE TABLE IF NOT EXISTS [rnc] ([rnc] REAL NOT NULL, [codrnc] TEXT(1) NOT NULL, [descri] TEXT(30) NOT NULL, [codigo] TEXT(20) NOT NULL, [revi] TEXT(2) NOT NULL, [ofc] TEXT(20) NOT NULL, [setor] TEXT(20) NOT NULL, [rastro] TEXT(20) NOT NULL, [nome] TEXT(45) NOT NULL, [nfc] TEXT(20) NOT NULL, [ric] TEXT(20) NOT NULL, [nfic] TEXT(20) NOT NULL, [ped] TEXT(20) NOT NULL, [qtl] REAL NOT NULL, [qtln] REAL NOT NULL, [dec01] TEXT(100) NOT NULL, [dec02] TEXT(100) NOT NULL, [dec03] TEXT(100) NOT NULL, [data] SHORTDATE NOT NULL, [dispo] TEXT(1) NOT NULL, [datad] SHORTDATE NOT NULL, [rac] TEXT(1) NOT NULL, [sacr] TEXT(20) NOT NULL, [obs01] TEXT(100) NOT NULL, [obs02] TEXT(100) NOT NULL, [obs03] TEXT(100) NOT NULL, [obs04] TEXT(100) NOT NULL, [resp] TEXT(30) NOT NULL, [acao01] TEXT(60) NOT NULL, [acao02] TEXT(60) NOT NULL, [acao03] TEXT(60) NOT NULL, [acao04] TEXT(60) NOT NULL, [laudo] TEXT(1) NOT NULL, [datar] SHORTDATE NOT NULL, [dist01] TEXT(60) NOT NULL, [dist02] TEXT(60) NOT NULL, [refdoc] TEXT(15) NOT NULL, [qtderei] REAL NOT NULL, [tipcad] TEXT(1) NOT NULL, [clifor] REAL NOT NULL, [tipacao] TEXT(1) NOT NULL, [nsac] REAL NOT NULL, [nracf] REAL NOT NULL, [tiperr] TEXT(1) NOT NULL, [unid] TEXT(2) NOT NULL, [area] TEXT(2) NOT NULL, [respo] TEXT(40) NOT NULL, [cargo] TEXT(40) NOT NULL, [codret] TEXT(1) NOT NULL, [incuser] TEXT(10) NOT NULL, [incdata] SHORTDATE NOT NULL, [fecuser] TEXT(10) NOT NULL, [fecdata] SHORTDATE NOT NULL, [abrnum] REAL NOT NULL, [abrnom] TEXT(40) NOT NULL, [selhi] REAL NOT NULL, [selhf] REAL NOT NULL, [seldi] SHORTDATE NOT NULL, [seldf] SHORTDATE NOT NULL, [selvl] REAL NOT NULL, [selth] REAL NOT NULL, [rethi] REAL NOT NULL, [rethf] REAL NOT NULL, [retdi] SHORTDATE NOT NULL, [retdf] SHORTDATE NOT NULL, [retvl] REAL NOT NULL, [retth] REAL NOT NULL, [reiqt] REAL NOT NULL, [reihi] REAL NOT NULL, [reihf] REAL NOT NULL, [reidi] SHORTDATE NOT NULL, [reidf] SHORTDATE NOT NULL, [reivl] REAL NOT NULL, [reith] REAL NOT NULL, [matcod] TEXT(20) NOT NULL, [matnom] TEXT(40) NOT NULL, [retopr] REAL NOT NULL, [retop2] REAL NOT NULL, [retop3] REAL NOT NULL, [retnom] TEXT(40) NOT NULL, [retno2] TEXT(40) NOT NULL, [retno3] TEXT(40) NOT NULL, [retval] REAL NOT NULL, [crm] REAL NOT NULL, [tipoe] TEXT(1) NOT NULL, [desce] TEXT(40) NOT NULL, [cbusca] TEXT(24) NOT NULL, [fechada] BIT NOT NULL, [rat] REAL NOT NULL, [rehhi] REAL NOT NULL, [rehhf] REAL NOT NULL, [rehdi] SHORTDATE NOT NULL, [rehdf] SHORTDATE NOT NULL, [rehvl] REAL NOT NULL, [rehth] REAL NOT NULL, [valsuc] REAL NOT NULL, [qtdsuc] REAL NOT NULL, [pecsuc] REAL NOT NULL);

-- Tabela: rnci
CREATE TABLE IF NOT EXISTS [rnci] ([rnc] REAL NOT NULL, [qtnc] REAL NOT NULL, [setcod] TEXT(1) NOT NULL, [coderr] TEXT(3) NOT NULL);

-- Tabela: sac
CREATE TABLE IF NOT EXISTS [sac] ([rnc] REAL NOT NULL, [rat] REAL NOT NULL, [documento] TEXT(25) NOT NULL, [rastro] TEXT(12) NOT NULL, [data] SHORTDATE NOT NULL, [nome] TEXT(40) NOT NULL, [codigo] TEXT(24) NOT NULL, [qtl] REAL NOT NULL, [qtn] REAL NOT NULL, [cliente] REAL NOT NULL, [clinome] TEXT(50) NOT NULL, [desc01] TEXT(100) NOT NULL, [desc02] TEXT(100) NOT NULL, [desc03] TEXT(100) NOT NULL, [desc04] TEXT(80) NOT NULL, [os] REAL NOT NULL, [nf] REAL NOT NULL, [item] REAL NOT NULL, [tipsac] TEXT(2) NOT NULL, [datos] SHORTDATE NOT NULL, [daten] SHORTDATE NOT NULL, [prazo] SHORTDATE NOT NULL, [dataf] SHORTDATE NOT NULL, [efica] TEXT(1) NOT NULL, [nova] REAL NOT NULL, [tipo] TEXT(1) NOT NULL, [fecho] SHORTDATE NOT NULL, [cong] TEXT(40) NOT NULL, [resul] TEXT(1) NOT NULL, [eqp01] TEXT(25) NOT NULL, [eqp02] TEXT(25) NOT NULL, [eqp03] TEXT(25) NOT NULL, [eqp04] TEXT(25) NOT NULL, [pf] REAL NOT NULL, [femearev] REAL NOT NULL, [femearevd] SHORTDATE NOT NULL, [incdata] SHORTDATE NOT NULL, [incuser] TEXT(10) NOT NULL, [notsetor] TEXT(25) NOT NULL, [anterior] REAL NOT NULL, [fecnome] TEXT(40) NOT NULL, [sac] REAL NOT NULL, [pmed01] TEXT(30) NOT NULL, [pmed02] TEXT(30) NOT NULL, [pmed03] TEXT(30) NOT NULL, [pmed04] TEXT(30) NOT NULL, [pmed05] TEXT(30) NOT NULL, [pamb01] TEXT(30) NOT NULL, [pamb02] TEXT(30) NOT NULL, [pamb03] TEXT(30) NOT NULL, [pamb04] TEXT(30) NOT NULL, [pamb05] TEXT(30) NOT NULL, [pmao01] TEXT(30) NOT NULL, [pmao02] TEXT(30) NOT NULL, [pmao03] TEXT(30) NOT NULL, [pmao04] TEXT(30) NOT NULL, [pmao05] TEXT(30) NOT NULL, [pmaq01] TEXT(30) NOT NULL, [pmaq02] TEXT(30) NOT NULL, [pmaq03] TEXT(30) NOT NULL, [pmaq04] TEXT(30) NOT NULL, [pmaq05] TEXT(30) NOT NULL, [pmet01] TEXT(30) NOT NULL, [pmet02] TEXT(30) NOT NULL, [pmet03] TEXT(30) NOT NULL, [pmet04] TEXT(30) NOT NULL, [pmet05] TEXT(30) NOT NULL, [pmat01] TEXT(30) NOT NULL, [pmat02] TEXT(30) NOT NULL, [pmat03] TEXT(30) NOT NULL, [pmat04] TEXT(30) NOT NULL, [pmat05] TEXT(30) NOT NULL, [poa] REAL NOT NULL, [revpf] TEXT(1) NOT NULL, [revpc] TEXT(1) NOT NULL, [revpfobs] TEXT(30) NOT NULL, [revpcobs] TEXT(30) NOT NULL);

-- Tabela: saci
CREATE TABLE IF NOT EXISTS [saci] ([sac] REAL NOT NULL, [causa] REAL NOT NULL, [acao] REAL NOT NULL, [area] TEXT(2) NOT NULL, [desare] TEXT(30) NOT NULL, [respon] TEXT(40) NOT NULL, [acao01] TEXT(100) NOT NULL, [acao02] TEXT(100) NOT NULL, [acao03] TEXT(100) NOT NULL, [acao04] TEXT(100) NOT NULL, [acao05] TEXT(100) NOT NULL, [acao06] TEXT(100) NOT NULL, [acao07] TEXT(100) NOT NULL, [acao08] TEXT(100) NOT NULL, [acao09] TEXT(100) NOT NULL, [acao10] TEXT(100) NOT NULL, [prazo] SHORTDATE NOT NULL, [dataf] SHORTDATE NOT NULL, [fecho] SHORTDATE NOT NULL, [posicao] TEXT(1) NOT NULL, [inv01] TEXT(100) NOT NULL, [inv02] TEXT(100) NOT NULL, [inv03] TEXT(100) NOT NULL, [inv04] TEXT(100) NOT NULL, [inv05] TEXT(100) NOT NULL, [inv06] TEXT(100) NOT NULL, [inv07] TEXT(100) NOT NULL, [inv08] TEXT(100) NOT NULL, [inv09] TEXT(100) NOT NULL, [inv10] TEXT(100) NOT NULL, [acm01] TEXT(100) NOT NULL, [acm02] TEXT(100) NOT NULL, [acm03] TEXT(100) NOT NULL, [acm04] TEXT(100) NOT NULL, [acm05] TEXT(100) NOT NULL, [acm06] TEXT(100) NOT NULL, [lpae] BIT NOT NULL);

-- �ndice: idx_acpnc_acpnc
CREATE INDEX IF NOT EXISTS [idx_acpnc_acpnc] ON [acpnc] ([acpnc]);

-- �ndice: idx_acpnc_compete
CREATE INDEX IF NOT EXISTS [idx_acpnc_compete] ON [acpnc] ([compete]);

-- �ndice: idx_acpnc_data
CREATE INDEX IF NOT EXISTS [idx_acpnc_data] ON [acpnc] ([data]);

-- �ndice: idx_acpnc_ratproduto
CREATE INDEX IF NOT EXISTS [idx_acpnc_ratproduto] ON [acpnc] ([rat], [produto]);

-- �ndice: idx_acpnc_rnc
CREATE INDEX IF NOT EXISTS [idx_acpnc_rnc] ON [acpnc] ([rnc]);

-- �ndice: idx_acpnc_sac
CREATE INDEX IF NOT EXISTS [idx_acpnc_sac] ON [acpnc] ([sac]);

-- �ndice: idx_adp_adp
CREATE INDEX IF NOT EXISTS [idx_adp_adp] ON [adp] ([adp]);

-- �ndice: idx_adp_rnc
CREATE INDEX IF NOT EXISTS [idx_adp_rnc] ON [adp] ([rnc]);

-- �ndice: idx_adpi_adp
CREATE INDEX IF NOT EXISTS [idx_adpi_adp] ON [adpi] ([adp]);

-- �ndice: idx_caf_numero
CREATE INDEX IF NOT EXISTS [idx_caf_numero] ON [caf] ([numero]);

-- �ndice: idx_cfe_numero
CREATE INDEX IF NOT EXISTS [idx_cfe_numero] ON [cfe] ([numero]);

-- �ndice: idx_crdias_seq
CREATE INDEX IF NOT EXISTS [idx_crdias_seq] ON [crdias] ([seq]);

-- �ndice: idx_crfa_nfor
CREATE INDEX IF NOT EXISTS [idx_crfa_nfor] ON [crfa] ([nfor]);

-- �ndice: idx_crfa_seqnfor
CREATE INDEX IF NOT EXISTS [idx_crfa_seqnfor] ON [crfa] ([seq], [nfor]);

-- �ndice: idx_crfor_nfor
CREATE INDEX IF NOT EXISTS [idx_crfor_nfor] ON [crfor] ([nfor]);

-- �ndice: idx_crfor_seq
CREATE INDEX IF NOT EXISTS [idx_crfor_seq] ON [crfor] ([seq]);

-- �ndice: idx_crfor_seqnfor
CREATE INDEX IF NOT EXISTS [idx_crfor_seqnfor] ON [crfor] ([seq], [nfor]);

-- �ndice: idx_crft_seqnfor
CREATE INDEX IF NOT EXISTS [idx_crft_seqnfor] ON [crft] ([seq], [nfor]);

-- �ndice: idx_crrsapc_seqcliente
CREATE INDEX IF NOT EXISTS [idx_crrsapc_seqcliente] ON [crrsapc] ([seq], [cliente]);

-- �ndice: idx_crrsapp_seqcodigo
CREATE INDEX IF NOT EXISTS [idx_crrsapp_seqcodigo] ON [crrsapp] ([seq], [codigo]);

-- �ndice: idx_crrsaps_seqsetor
CREATE INDEX IF NOT EXISTS [idx_crrsaps_seqsetor] ON [crrsaps] ([seq], [setcod]);

-- �ndice: idx_crrserr_codigo
CREATE INDEX IF NOT EXISTS [idx_crrserr_codigo] ON [crrserr] ([codigo]);

-- �ndice: idx_crrsseq_seq
CREATE INDEX IF NOT EXISTS [idx_crrsseq_seq] ON [crrsseq] ([seq]);

-- �ndice: idx_crrsset_seq
CREATE INDEX IF NOT EXISTS [idx_crrsset_seq] ON [crrsset] ([codigo]);

-- �ndice: idx_crseq_seq
CREATE INDEX IF NOT EXISTS [idx_crseq_seq] ON [crseq] ([seq]);

-- �ndice: idx_crts_seq
CREATE INDEX IF NOT EXISTS [idx_crts_seq] ON [crts] ([seq]);

-- �ndice: idx_msrd_codigo
CREATE INDEX IF NOT EXISTS [idx_msrd_codigo] ON [msrd] ([codigo]);

-- �ndice: idx_msrd_msrd
CREATE INDEX IF NOT EXISTS [idx_msrd_msrd] ON [msrd] ([msrd]);

-- �ndice: idx_pe01tmp_pe01tmp1
CREATE INDEX IF NOT EXISTS [idx_pe01tmp_pe01tmp1] ON [pe01tmp] ([pedido], [item], [digctr]);

-- �ndice: idx_pe01tmp_pe01tmp2
CREATE INDEX IF NOT EXISTS [idx_pe01tmp_pe01tmp2] ON [pe01tmp] ([nrnotasai], [cliente]);

-- �ndice: idx_pe01tmp_pe01tmp3
CREATE INDEX IF NOT EXISTS [idx_pe01tmp_pe01tmp3] ON [pe01tmp] ([pedido]);

-- �ndice: idx_pe01tmp_pe01tmp4
CREATE INDEX IF NOT EXISTS [idx_pe01tmp_pe01tmp4] ON [pe01tmp] ([cliente]);

-- �ndice: idx_pe01tmp_pe01tmp5
CREATE INDEX IF NOT EXISTS [idx_pe01tmp_pe01tmp5] ON [pe01tmp] ([ar], [aritem]);

-- �ndice: idx_pe01tmp_pe01tmp6
CREATE INDEX IF NOT EXISTS [idx_pe01tmp_pe01tmp6] ON [pe01tmp] ([codigo]);

-- �ndice: idx_pe01tmp_pe01tmp7
CREATE INDEX IF NOT EXISTS [idx_pe01tmp_pe01tmp7] ON [pe01tmp] ([cliente], [nrnotasai], [codigo]);

-- �ndice: idx_racf_racf
CREATE INDEX IF NOT EXISTS [idx_racf_racf] ON [racf] ([racf]);

-- �ndice: idx_racf_racf-2
CREATE INDEX IF NOT EXISTS [idx_racf_racf-2] ON [racf] ([data]);

-- �ndice: idx_racfsal_seqclifor
CREATE INDEX IF NOT EXISTS [idx_racfsal_seqclifor] ON [racfsal] ([seq], [clifor]);

-- �ndice: idx_rat_data
CREATE INDEX IF NOT EXISTS [idx_rat_data] ON [rat] ([data]);

-- �ndice: idx_rat_rat
CREATE INDEX IF NOT EXISTS [idx_rat_rat] ON [rat] ([rat]);

-- �ndice: idx_rati_rat
CREATE INDEX IF NOT EXISTS [idx_rati_rat] ON [rati] ([rat]);

-- �ndice: idx_rnc_rnc
CREATE INDEX IF NOT EXISTS [idx_rnc_rnc] ON [rnc] ([rnc]);

-- �ndice: idx_rnc_rnc-2
CREATE INDEX IF NOT EXISTS [idx_rnc_rnc-2] ON [rnc] ([data]);

-- �ndice: idx_rnci_rnci
CREATE INDEX IF NOT EXISTS [idx_rnci_rnci] ON [rnci] ([rnc]);

-- �ndice: idx_sac_sac
CREATE INDEX IF NOT EXISTS [idx_sac_sac] ON [sac] ([sac]);

-- �ndice: idx_sac_sac-2
CREATE INDEX IF NOT EXISTS [idx_sac_sac-2] ON [sac] ([os], [nf], [item]);

-- �ndice: idx_sac_sac-3
CREATE INDEX IF NOT EXISTS [idx_sac_sac-3] ON [sac] ([codigo]);

-- �ndice: idx_saci
CREATE INDEX IF NOT EXISTS [idx_saci] ON [saci] ([sac]);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
